# -*- coding: utf8 -*-
# Copyright (c) 2017-2025 Tencent. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import warnings

from tencentcloud.common.abstract_model import AbstractModel


class CreateProbeTasksRequest(AbstractModel):
    r"""CreateProbeTasks请求参数结构体

    """

    def __init__(self):
        r"""
        :param _BatchTasks: 批量任务名-地址
        :type BatchTasks: list of ProbeTaskBasicConfiguration
        :param _TaskType: 任务类型，如1、2、3、4、5、6、7；1-页面性能、2-文件上传、3-文件下载、4-端口性能、5-网络质量、6-音视频体验、7-域名whois
        :type TaskType: int
        :param _Nodes: 拨测节点，如10001，具体拨测地域运营商对应的拨测点编号可联系云拨测确认。
        :type Nodes: list of str
        :param _Interval: 拨测间隔，单位为分钟
        :type Interval: int
        :param _Parameters: 拨测参数，详细可参考云拨测官方文档,链接:https://cloud.tencent.com/document/product/248/87308#createprobetasks。
        :type Parameters: str
        :param _TaskCategory: 任务分类
<li>1 = PC</li>
<li> 2 = Mobile </li>
        :type TaskCategory: int
        :param _Cron: 定时任务cron表达式
        :type Cron: str
        :param _Tag: 资源标签值
        :type Tag: list of Tag
        :param _ProbeType: 测试类型，包含定时测试与即时测试。0-定时拨测，其它表示即时拨测。
        :type ProbeType: int
        :param _PluginSource: 插件类型，如CDN，详情参考云拨测官方文档。
        :type PluginSource: str
        :param _ClientNum: 客户端ID
        :type ClientNum: str
        :param _NodeIpType: 拨测点IP类型：0-不限制IP类型，1-IPv4，2-IPv6
        :type NodeIpType: int
        :param _SubSyncFlag: 供应商子账户同步标志
        :type SubSyncFlag: int
        :param _RtxName: 创建者名称
        :type RtxName: str
        """
        self._BatchTasks = None
        self._TaskType = None
        self._Nodes = None
        self._Interval = None
        self._Parameters = None
        self._TaskCategory = None
        self._Cron = None
        self._Tag = None
        self._ProbeType = None
        self._PluginSource = None
        self._ClientNum = None
        self._NodeIpType = None
        self._SubSyncFlag = None
        self._RtxName = None

    @property
    def BatchTasks(self):
        r"""批量任务名-地址
        :rtype: list of ProbeTaskBasicConfiguration
        """
        return self._BatchTasks

    @BatchTasks.setter
    def BatchTasks(self, BatchTasks):
        self._BatchTasks = BatchTasks

    @property
    def TaskType(self):
        r"""任务类型，如1、2、3、4、5、6、7；1-页面性能、2-文件上传、3-文件下载、4-端口性能、5-网络质量、6-音视频体验、7-域名whois
        :rtype: int
        """
        return self._TaskType

    @TaskType.setter
    def TaskType(self, TaskType):
        self._TaskType = TaskType

    @property
    def Nodes(self):
        r"""拨测节点，如10001，具体拨测地域运营商对应的拨测点编号可联系云拨测确认。
        :rtype: list of str
        """
        return self._Nodes

    @Nodes.setter
    def Nodes(self, Nodes):
        self._Nodes = Nodes

    @property
    def Interval(self):
        r"""拨测间隔，单位为分钟
        :rtype: int
        """
        return self._Interval

    @Interval.setter
    def Interval(self, Interval):
        self._Interval = Interval

    @property
    def Parameters(self):
        r"""拨测参数，详细可参考云拨测官方文档,链接:https://cloud.tencent.com/document/product/248/87308#createprobetasks。
        :rtype: str
        """
        return self._Parameters

    @Parameters.setter
    def Parameters(self, Parameters):
        self._Parameters = Parameters

    @property
    def TaskCategory(self):
        r"""任务分类
<li>1 = PC</li>
<li> 2 = Mobile </li>
        :rtype: int
        """
        return self._TaskCategory

    @TaskCategory.setter
    def TaskCategory(self, TaskCategory):
        self._TaskCategory = TaskCategory

    @property
    def Cron(self):
        r"""定时任务cron表达式
        :rtype: str
        """
        return self._Cron

    @Cron.setter
    def Cron(self, Cron):
        self._Cron = Cron

    @property
    def Tag(self):
        r"""资源标签值
        :rtype: list of Tag
        """
        return self._Tag

    @Tag.setter
    def Tag(self, Tag):
        self._Tag = Tag

    @property
    def ProbeType(self):
        r"""测试类型，包含定时测试与即时测试。0-定时拨测，其它表示即时拨测。
        :rtype: int
        """
        return self._ProbeType

    @ProbeType.setter
    def ProbeType(self, ProbeType):
        self._ProbeType = ProbeType

    @property
    def PluginSource(self):
        r"""插件类型，如CDN，详情参考云拨测官方文档。
        :rtype: str
        """
        return self._PluginSource

    @PluginSource.setter
    def PluginSource(self, PluginSource):
        self._PluginSource = PluginSource

    @property
    def ClientNum(self):
        r"""客户端ID
        :rtype: str
        """
        return self._ClientNum

    @ClientNum.setter
    def ClientNum(self, ClientNum):
        self._ClientNum = ClientNum

    @property
    def NodeIpType(self):
        r"""拨测点IP类型：0-不限制IP类型，1-IPv4，2-IPv6
        :rtype: int
        """
        return self._NodeIpType

    @NodeIpType.setter
    def NodeIpType(self, NodeIpType):
        self._NodeIpType = NodeIpType

    @property
    def SubSyncFlag(self):
        r"""供应商子账户同步标志
        :rtype: int
        """
        return self._SubSyncFlag

    @SubSyncFlag.setter
    def SubSyncFlag(self, SubSyncFlag):
        self._SubSyncFlag = SubSyncFlag

    @property
    def RtxName(self):
        r"""创建者名称
        :rtype: str
        """
        return self._RtxName

    @RtxName.setter
    def RtxName(self, RtxName):
        self._RtxName = RtxName


    def _deserialize(self, params):
        if params.get("BatchTasks") is not None:
            self._BatchTasks = []
            for item in params.get("BatchTasks"):
                obj = ProbeTaskBasicConfiguration()
                obj._deserialize(item)
                self._BatchTasks.append(obj)
        self._TaskType = params.get("TaskType")
        self._Nodes = params.get("Nodes")
        self._Interval = params.get("Interval")
        self._Parameters = params.get("Parameters")
        self._TaskCategory = params.get("TaskCategory")
        self._Cron = params.get("Cron")
        if params.get("Tag") is not None:
            self._Tag = []
            for item in params.get("Tag"):
                obj = Tag()
                obj._deserialize(item)
                self._Tag.append(obj)
        self._ProbeType = params.get("ProbeType")
        self._PluginSource = params.get("PluginSource")
        self._ClientNum = params.get("ClientNum")
        self._NodeIpType = params.get("NodeIpType")
        self._SubSyncFlag = params.get("SubSyncFlag")
        self._RtxName = params.get("RtxName")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class CreateProbeTasksResponse(AbstractModel):
    r"""CreateProbeTasks返回参数结构体

    """

    def __init__(self):
        r"""
        :param _TaskIDs: 任务ID列表
        :type TaskIDs: list of str
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._TaskIDs = None
        self._RequestId = None

    @property
    def TaskIDs(self):
        r"""任务ID列表
        :rtype: list of str
        """
        return self._TaskIDs

    @TaskIDs.setter
    def TaskIDs(self, TaskIDs):
        self._TaskIDs = TaskIDs

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._TaskIDs = params.get("TaskIDs")
        self._RequestId = params.get("RequestId")


class DeleteProbeTaskRequest(AbstractModel):
    r"""DeleteProbeTask请求参数结构体

    """

    def __init__(self):
        r"""
        :param _TaskIds: 任务 ID
        :type TaskIds: list of str
        """
        self._TaskIds = None

    @property
    def TaskIds(self):
        r"""任务 ID
        :rtype: list of str
        """
        return self._TaskIds

    @TaskIds.setter
    def TaskIds(self, TaskIds):
        self._TaskIds = TaskIds


    def _deserialize(self, params):
        self._TaskIds = params.get("TaskIds")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DeleteProbeTaskResponse(AbstractModel):
    r"""DeleteProbeTask返回参数结构体

    """

    def __init__(self):
        r"""
        :param _Total: 任务总量
        :type Total: int
        :param _SuccessCount: 任务成功量
注意：此字段可能返回 null，表示取不到有效值。
        :type SuccessCount: int
        :param _Results: 任务执行结果
注意：此字段可能返回 null，表示取不到有效值。
        :type Results: list of TaskResult
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._Total = None
        self._SuccessCount = None
        self._Results = None
        self._RequestId = None

    @property
    def Total(self):
        r"""任务总量
        :rtype: int
        """
        return self._Total

    @Total.setter
    def Total(self, Total):
        self._Total = Total

    @property
    def SuccessCount(self):
        r"""任务成功量
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: int
        """
        return self._SuccessCount

    @SuccessCount.setter
    def SuccessCount(self, SuccessCount):
        self._SuccessCount = SuccessCount

    @property
    def Results(self):
        r"""任务执行结果
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of TaskResult
        """
        return self._Results

    @Results.setter
    def Results(self, Results):
        self._Results = Results

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._Total = params.get("Total")
        self._SuccessCount = params.get("SuccessCount")
        if params.get("Results") is not None:
            self._Results = []
            for item in params.get("Results"):
                obj = TaskResult()
                obj._deserialize(item)
                self._Results.append(obj)
        self._RequestId = params.get("RequestId")


class DescribeDetailedSingleProbeDataRequest(AbstractModel):
    r"""DescribeDetailedSingleProbeData请求参数结构体

    """

    def __init__(self):
        r"""
        :param _BeginTime: <p>开始时间戳（毫秒级）</p>
        :type BeginTime: int
        :param _EndTime: <p>结束时间戳（毫秒级）</p>
        :type EndTime: int
        :param _TaskType: <p>任务类型<br>AnalyzeTaskType_Network：网络质量<br>AnalyzeTaskType_Browse：页面性能<br>AnalyzeTaskType_UploadDownload：文件传输（含文件上传、文件下载）<br>AnalyzeTaskType_Transport：端口性能<br>AnalyzeTaskType_MediaStream：音视频体验</p>
        :type TaskType: str
        :param _SortField: <p>待排序字段<br>可以填写 ProbeTime 拨测时间排序<br>也可填写SelectedFields 中的选中字段</p>
        :type SortField: str
        :param _Ascending: <p>true表示升序</p>
        :type Ascending: bool
        :param _SelectedFields: <p>选中字段，如ProbeTime、TransferTime、TransferSize等。</p>
        :type SelectedFields: list of str
        :param _Offset: <p>起始取数位置</p>
        :type Offset: int
        :param _Limit: <p>取数数量</p>
        :type Limit: int
        :param _TaskID: <p>任务ID</p>
        :type TaskID: list of str
        :param _Operators: <p>拨测点运营商</p><p>这里实际按拨测结果中的运营商来填写即可</p><p>电信：中国电信<br>移动：中国移动<br>联通：中国联通</p>
        :type Operators: list of str
        :param _Districts: <p>拨测点地区</p><p>这里实际按拨测结果中的地区来填写即可</p><p>国内一般是省级单位，如广东、广西、中国香港；直辖市则填北京、上海</p><p>境外一般是国家名，如澳大利亚、新加坡</p>
        :type Districts: list of str
        :param _ErrorTypes: <p>错误类型</p>
        :type ErrorTypes: list of str
        :param _City: <p>城市<br>这里实际按拨测结果中的城市来填写即可</p><p>示例：</p><p>深圳市<br>武汉市<br>首尔<br>多伦多</p>
        :type City: list of str
        :param _ScrollID: <p>es scroll查询id</p>
        :type ScrollID: str
        :param _QueryFlag: <p>详情数据下载</p>
        :type QueryFlag: str
        """
        self._BeginTime = None
        self._EndTime = None
        self._TaskType = None
        self._SortField = None
        self._Ascending = None
        self._SelectedFields = None
        self._Offset = None
        self._Limit = None
        self._TaskID = None
        self._Operators = None
        self._Districts = None
        self._ErrorTypes = None
        self._City = None
        self._ScrollID = None
        self._QueryFlag = None

    @property
    def BeginTime(self):
        r"""<p>开始时间戳（毫秒级）</p>
        :rtype: int
        """
        return self._BeginTime

    @BeginTime.setter
    def BeginTime(self, BeginTime):
        self._BeginTime = BeginTime

    @property
    def EndTime(self):
        r"""<p>结束时间戳（毫秒级）</p>
        :rtype: int
        """
        return self._EndTime

    @EndTime.setter
    def EndTime(self, EndTime):
        self._EndTime = EndTime

    @property
    def TaskType(self):
        r"""<p>任务类型<br>AnalyzeTaskType_Network：网络质量<br>AnalyzeTaskType_Browse：页面性能<br>AnalyzeTaskType_UploadDownload：文件传输（含文件上传、文件下载）<br>AnalyzeTaskType_Transport：端口性能<br>AnalyzeTaskType_MediaStream：音视频体验</p>
        :rtype: str
        """
        return self._TaskType

    @TaskType.setter
    def TaskType(self, TaskType):
        self._TaskType = TaskType

    @property
    def SortField(self):
        r"""<p>待排序字段<br>可以填写 ProbeTime 拨测时间排序<br>也可填写SelectedFields 中的选中字段</p>
        :rtype: str
        """
        return self._SortField

    @SortField.setter
    def SortField(self, SortField):
        self._SortField = SortField

    @property
    def Ascending(self):
        r"""<p>true表示升序</p>
        :rtype: bool
        """
        return self._Ascending

    @Ascending.setter
    def Ascending(self, Ascending):
        self._Ascending = Ascending

    @property
    def SelectedFields(self):
        r"""<p>选中字段，如ProbeTime、TransferTime、TransferSize等。</p>
        :rtype: list of str
        """
        return self._SelectedFields

    @SelectedFields.setter
    def SelectedFields(self, SelectedFields):
        self._SelectedFields = SelectedFields

    @property
    def Offset(self):
        r"""<p>起始取数位置</p>
        :rtype: int
        """
        return self._Offset

    @Offset.setter
    def Offset(self, Offset):
        self._Offset = Offset

    @property
    def Limit(self):
        r"""<p>取数数量</p>
        :rtype: int
        """
        return self._Limit

    @Limit.setter
    def Limit(self, Limit):
        self._Limit = Limit

    @property
    def TaskID(self):
        r"""<p>任务ID</p>
        :rtype: list of str
        """
        return self._TaskID

    @TaskID.setter
    def TaskID(self, TaskID):
        self._TaskID = TaskID

    @property
    def Operators(self):
        r"""<p>拨测点运营商</p><p>这里实际按拨测结果中的运营商来填写即可</p><p>电信：中国电信<br>移动：中国移动<br>联通：中国联通</p>
        :rtype: list of str
        """
        return self._Operators

    @Operators.setter
    def Operators(self, Operators):
        self._Operators = Operators

    @property
    def Districts(self):
        r"""<p>拨测点地区</p><p>这里实际按拨测结果中的地区来填写即可</p><p>国内一般是省级单位，如广东、广西、中国香港；直辖市则填北京、上海</p><p>境外一般是国家名，如澳大利亚、新加坡</p>
        :rtype: list of str
        """
        return self._Districts

    @Districts.setter
    def Districts(self, Districts):
        self._Districts = Districts

    @property
    def ErrorTypes(self):
        r"""<p>错误类型</p>
        :rtype: list of str
        """
        return self._ErrorTypes

    @ErrorTypes.setter
    def ErrorTypes(self, ErrorTypes):
        self._ErrorTypes = ErrorTypes

    @property
    def City(self):
        r"""<p>城市<br>这里实际按拨测结果中的城市来填写即可</p><p>示例：</p><p>深圳市<br>武汉市<br>首尔<br>多伦多</p>
        :rtype: list of str
        """
        return self._City

    @City.setter
    def City(self, City):
        self._City = City

    @property
    def ScrollID(self):
        r"""<p>es scroll查询id</p>
        :rtype: str
        """
        return self._ScrollID

    @ScrollID.setter
    def ScrollID(self, ScrollID):
        self._ScrollID = ScrollID

    @property
    def QueryFlag(self):
        r"""<p>详情数据下载</p>
        :rtype: str
        """
        return self._QueryFlag

    @QueryFlag.setter
    def QueryFlag(self, QueryFlag):
        self._QueryFlag = QueryFlag


    def _deserialize(self, params):
        self._BeginTime = params.get("BeginTime")
        self._EndTime = params.get("EndTime")
        self._TaskType = params.get("TaskType")
        self._SortField = params.get("SortField")
        self._Ascending = params.get("Ascending")
        self._SelectedFields = params.get("SelectedFields")
        self._Offset = params.get("Offset")
        self._Limit = params.get("Limit")
        self._TaskID = params.get("TaskID")
        self._Operators = params.get("Operators")
        self._Districts = params.get("Districts")
        self._ErrorTypes = params.get("ErrorTypes")
        self._City = params.get("City")
        self._ScrollID = params.get("ScrollID")
        self._QueryFlag = params.get("QueryFlag")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeDetailedSingleProbeDataResponse(AbstractModel):
    r"""DescribeDetailedSingleProbeData返回参数结构体

    """

    def __init__(self):
        r"""
        :param _DataSet: <p>单次详情数据</p>
        :type DataSet: list of DetailedSingleDataDefine
        :param _TotalNumber: <p>符合条件的数据总数</p>
        :type TotalNumber: int
        :param _ScrollID: <p>es scroll查询的id</p>
        :type ScrollID: str
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._DataSet = None
        self._TotalNumber = None
        self._ScrollID = None
        self._RequestId = None

    @property
    def DataSet(self):
        r"""<p>单次详情数据</p>
        :rtype: list of DetailedSingleDataDefine
        """
        return self._DataSet

    @DataSet.setter
    def DataSet(self, DataSet):
        self._DataSet = DataSet

    @property
    def TotalNumber(self):
        r"""<p>符合条件的数据总数</p>
        :rtype: int
        """
        return self._TotalNumber

    @TotalNumber.setter
    def TotalNumber(self, TotalNumber):
        self._TotalNumber = TotalNumber

    @property
    def ScrollID(self):
        r"""<p>es scroll查询的id</p>
        :rtype: str
        """
        return self._ScrollID

    @ScrollID.setter
    def ScrollID(self, ScrollID):
        self._ScrollID = ScrollID

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("DataSet") is not None:
            self._DataSet = []
            for item in params.get("DataSet"):
                obj = DetailedSingleDataDefine()
                obj._deserialize(item)
                self._DataSet.append(obj)
        self._TotalNumber = params.get("TotalNumber")
        self._ScrollID = params.get("ScrollID")
        self._RequestId = params.get("RequestId")


class DescribeInstantTasksRequest(AbstractModel):
    r"""DescribeInstantTasks请求参数结构体

    """

    def __init__(self):
        r"""
        :param _Limit: 数量
        :type Limit: int
        :param _Offset: 起始位置
        :type Offset: int
        """
        self._Limit = None
        self._Offset = None

    @property
    def Limit(self):
        r"""数量
        :rtype: int
        """
        return self._Limit

    @Limit.setter
    def Limit(self, Limit):
        self._Limit = Limit

    @property
    def Offset(self):
        r"""起始位置
        :rtype: int
        """
        return self._Offset

    @Offset.setter
    def Offset(self, Offset):
        self._Offset = Offset


    def _deserialize(self, params):
        self._Limit = params.get("Limit")
        self._Offset = params.get("Offset")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeInstantTasksResponse(AbstractModel):
    r"""DescribeInstantTasks返回参数结构体

    """

    def __init__(self):
        r"""
        :param _Tasks: 任务
注意：此字段可能返回 null，表示取不到有效值。
        :type Tasks: list of SingleInstantTask
        :param _Total: 总数
        :type Total: int
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._Tasks = None
        self._Total = None
        self._RequestId = None

    @property
    def Tasks(self):
        r"""任务
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of SingleInstantTask
        """
        return self._Tasks

    @Tasks.setter
    def Tasks(self, Tasks):
        self._Tasks = Tasks

    @property
    def Total(self):
        r"""总数
        :rtype: int
        """
        return self._Total

    @Total.setter
    def Total(self, Total):
        self._Total = Total

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("Tasks") is not None:
            self._Tasks = []
            for item in params.get("Tasks"):
                obj = SingleInstantTask()
                obj._deserialize(item)
                self._Tasks.append(obj)
        self._Total = params.get("Total")
        self._RequestId = params.get("RequestId")


class DescribeNodeGroupsRequest(AbstractModel):
    r"""DescribeNodeGroups请求参数结构体

    """

    def __init__(self):
        r"""
        :param _NodeType: 节点类型。0: 全部 1: IDC 2: LastMile 3: Mobile，不填默认为0
        :type NodeType: list of int
        :param _TaskCategory: 节点分类。0: 全部 1: PC 2：Mobile，不填默认为0。PC分类包括IDC和LM节点类型，Mobile分类包括Mobile节点类型。与NodeType参数取交集。
        :type TaskCategory: int
        :param _IPType: IP类型。0: 全部 1: IPv4 2: IPv6，不填默认为0
        :type IPType: int
        :param _Name: 拨测点描述关键词。
        :type Name: str
        :param _RegionID: 地域ID。0: 精选拨测点 1: 国内 2: 港澳台 3: 亚太 4: 欧洲与美洲 5: 非洲与大洋洲，不填默认为0
        :type RegionID: int
        :param _DistrictID: 省份或国家ID。0表示全部，不填默认为0
        :type DistrictID: int
        :param _NetServiceID: 运营商ID。0: 全部 1: 中国电信 2: 中国联通 3: 中国移动 99: 其他，不填默认为0
        :type NetServiceID: int
        :param _NodeGroupType: 节点组类型。0: 高级拨测点组 1: 可用性节点 2: 我的拨测点组，不填默认为0
        :type NodeGroupType: int
        :param _TaskType: 任务类型，如1、2、3、4、5、6、7；1-页面性能、2-文件上传、3-文件下载、4-端口性能、5-网络质量、6-音视频体验、7-域名whois，不填默认为0，不对任务类型做过滤
        :type TaskType: int
        :param _ProbeType: 测试类型，包含定时测试与即时测试。0-定时拨测，其它表示即时拨测。
        :type ProbeType: int
        """
        self._NodeType = None
        self._TaskCategory = None
        self._IPType = None
        self._Name = None
        self._RegionID = None
        self._DistrictID = None
        self._NetServiceID = None
        self._NodeGroupType = None
        self._TaskType = None
        self._ProbeType = None

    @property
    def NodeType(self):
        r"""节点类型。0: 全部 1: IDC 2: LastMile 3: Mobile，不填默认为0
        :rtype: list of int
        """
        return self._NodeType

    @NodeType.setter
    def NodeType(self, NodeType):
        self._NodeType = NodeType

    @property
    def TaskCategory(self):
        r"""节点分类。0: 全部 1: PC 2：Mobile，不填默认为0。PC分类包括IDC和LM节点类型，Mobile分类包括Mobile节点类型。与NodeType参数取交集。
        :rtype: int
        """
        return self._TaskCategory

    @TaskCategory.setter
    def TaskCategory(self, TaskCategory):
        self._TaskCategory = TaskCategory

    @property
    def IPType(self):
        r"""IP类型。0: 全部 1: IPv4 2: IPv6，不填默认为0
        :rtype: int
        """
        return self._IPType

    @IPType.setter
    def IPType(self, IPType):
        self._IPType = IPType

    @property
    def Name(self):
        r"""拨测点描述关键词。
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def RegionID(self):
        r"""地域ID。0: 精选拨测点 1: 国内 2: 港澳台 3: 亚太 4: 欧洲与美洲 5: 非洲与大洋洲，不填默认为0
        :rtype: int
        """
        return self._RegionID

    @RegionID.setter
    def RegionID(self, RegionID):
        self._RegionID = RegionID

    @property
    def DistrictID(self):
        r"""省份或国家ID。0表示全部，不填默认为0
        :rtype: int
        """
        return self._DistrictID

    @DistrictID.setter
    def DistrictID(self, DistrictID):
        self._DistrictID = DistrictID

    @property
    def NetServiceID(self):
        r"""运营商ID。0: 全部 1: 中国电信 2: 中国联通 3: 中国移动 99: 其他，不填默认为0
        :rtype: int
        """
        return self._NetServiceID

    @NetServiceID.setter
    def NetServiceID(self, NetServiceID):
        self._NetServiceID = NetServiceID

    @property
    def NodeGroupType(self):
        r"""节点组类型。0: 高级拨测点组 1: 可用性节点 2: 我的拨测点组，不填默认为0
        :rtype: int
        """
        return self._NodeGroupType

    @NodeGroupType.setter
    def NodeGroupType(self, NodeGroupType):
        self._NodeGroupType = NodeGroupType

    @property
    def TaskType(self):
        r"""任务类型，如1、2、3、4、5、6、7；1-页面性能、2-文件上传、3-文件下载、4-端口性能、5-网络质量、6-音视频体验、7-域名whois，不填默认为0，不对任务类型做过滤
        :rtype: int
        """
        return self._TaskType

    @TaskType.setter
    def TaskType(self, TaskType):
        self._TaskType = TaskType

    @property
    def ProbeType(self):
        r"""测试类型，包含定时测试与即时测试。0-定时拨测，其它表示即时拨测。
        :rtype: int
        """
        return self._ProbeType

    @ProbeType.setter
    def ProbeType(self, ProbeType):
        self._ProbeType = ProbeType


    def _deserialize(self, params):
        self._NodeType = params.get("NodeType")
        self._TaskCategory = params.get("TaskCategory")
        self._IPType = params.get("IPType")
        self._Name = params.get("Name")
        self._RegionID = params.get("RegionID")
        self._DistrictID = params.get("DistrictID")
        self._NetServiceID = params.get("NetServiceID")
        self._NodeGroupType = params.get("NodeGroupType")
        self._TaskType = params.get("TaskType")
        self._ProbeType = params.get("ProbeType")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeNodeGroupsResponse(AbstractModel):
    r"""DescribeNodeGroups返回参数结构体

    """

    def __init__(self):
        r"""
        :param _NodeList: 树状节点列表，总共两级
注意：此字段可能返回 null，表示取不到有效值。
        :type NodeList: list of NodeTree
        :param _DistrictList: 省份或国家列表
注意：此字段可能返回 null，表示取不到有效值。
        :type DistrictList: list of DistinctOrNetServiceInfo
        :param _NetServiceList: 运营商列表
注意：此字段可能返回 null，表示取不到有效值。
        :type NetServiceList: list of DistinctOrNetServiceInfo
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._NodeList = None
        self._DistrictList = None
        self._NetServiceList = None
        self._RequestId = None

    @property
    def NodeList(self):
        r"""树状节点列表，总共两级
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of NodeTree
        """
        return self._NodeList

    @NodeList.setter
    def NodeList(self, NodeList):
        self._NodeList = NodeList

    @property
    def DistrictList(self):
        r"""省份或国家列表
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of DistinctOrNetServiceInfo
        """
        return self._DistrictList

    @DistrictList.setter
    def DistrictList(self, DistrictList):
        self._DistrictList = DistrictList

    @property
    def NetServiceList(self):
        r"""运营商列表
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of DistinctOrNetServiceInfo
        """
        return self._NetServiceList

    @NetServiceList.setter
    def NetServiceList(self, NetServiceList):
        self._NetServiceList = NetServiceList

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("NodeList") is not None:
            self._NodeList = []
            for item in params.get("NodeList"):
                obj = NodeTree()
                obj._deserialize(item)
                self._NodeList.append(obj)
        if params.get("DistrictList") is not None:
            self._DistrictList = []
            for item in params.get("DistrictList"):
                obj = DistinctOrNetServiceInfo()
                obj._deserialize(item)
                self._DistrictList.append(obj)
        if params.get("NetServiceList") is not None:
            self._NetServiceList = []
            for item in params.get("NetServiceList"):
                obj = DistinctOrNetServiceInfo()
                obj._deserialize(item)
                self._NetServiceList.append(obj)
        self._RequestId = params.get("RequestId")


class DescribeNodesRequest(AbstractModel):
    r"""DescribeNodes请求参数结构体

    """

    def __init__(self):
        r"""
        :param _NodeType: 节点类型
<li> 1 = IDC </li>
<li> 2 = LastMile </li>
<li> 3 = Mobile </li>
        :type NodeType: int
        :param _Location: 节点区域
<li> 1 = 中国大陆 </li>
<li> 2 = 港澳台 </li>
<li> 3 = 境外</li>
        :type Location: int
        :param _IsIPv6: 是否IPv6
        :type IsIPv6: bool
        :param _NodeName: 名字模糊搜索
        :type NodeName: str
        :param _PayMode: 付费模式
<li>1 = 试用版本</li>
<li> 2 = 付费版本 </li>
        :type PayMode: int
        :param _TaskType: 任务类型
<li>1 = 页面性能</li>
<li>2 = 文件上传</li>
<li>3 = 文件下载</li>
<li>4 = 端口性能</li>
<li>5 = 网络质量</li>
<li>6 = 音视频体验</li>
        :type TaskType: int
        """
        self._NodeType = None
        self._Location = None
        self._IsIPv6 = None
        self._NodeName = None
        self._PayMode = None
        self._TaskType = None

    @property
    def NodeType(self):
        r"""节点类型
<li> 1 = IDC </li>
<li> 2 = LastMile </li>
<li> 3 = Mobile </li>
        :rtype: int
        """
        return self._NodeType

    @NodeType.setter
    def NodeType(self, NodeType):
        self._NodeType = NodeType

    @property
    def Location(self):
        r"""节点区域
<li> 1 = 中国大陆 </li>
<li> 2 = 港澳台 </li>
<li> 3 = 境外</li>
        :rtype: int
        """
        return self._Location

    @Location.setter
    def Location(self, Location):
        self._Location = Location

    @property
    def IsIPv6(self):
        r"""是否IPv6
        :rtype: bool
        """
        return self._IsIPv6

    @IsIPv6.setter
    def IsIPv6(self, IsIPv6):
        self._IsIPv6 = IsIPv6

    @property
    def NodeName(self):
        r"""名字模糊搜索
        :rtype: str
        """
        return self._NodeName

    @NodeName.setter
    def NodeName(self, NodeName):
        self._NodeName = NodeName

    @property
    def PayMode(self):
        r"""付费模式
<li>1 = 试用版本</li>
<li> 2 = 付费版本 </li>
        :rtype: int
        """
        return self._PayMode

    @PayMode.setter
    def PayMode(self, PayMode):
        self._PayMode = PayMode

    @property
    def TaskType(self):
        r"""任务类型
<li>1 = 页面性能</li>
<li>2 = 文件上传</li>
<li>3 = 文件下载</li>
<li>4 = 端口性能</li>
<li>5 = 网络质量</li>
<li>6 = 音视频体验</li>
        :rtype: int
        """
        return self._TaskType

    @TaskType.setter
    def TaskType(self, TaskType):
        self._TaskType = TaskType


    def _deserialize(self, params):
        self._NodeType = params.get("NodeType")
        self._Location = params.get("Location")
        self._IsIPv6 = params.get("IsIPv6")
        self._NodeName = params.get("NodeName")
        self._PayMode = params.get("PayMode")
        self._TaskType = params.get("TaskType")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeNodesResponse(AbstractModel):
    r"""DescribeNodes返回参数结构体

    """

    def __init__(self):
        r"""
        :param _NodeSet: 节点列表
注意：此字段可能返回 null，表示取不到有效值。
        :type NodeSet: list of NodeDefineExt
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._NodeSet = None
        self._RequestId = None

    @property
    def NodeSet(self):
        r"""节点列表
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of NodeDefineExt
        """
        return self._NodeSet

    @NodeSet.setter
    def NodeSet(self, NodeSet):
        self._NodeSet = NodeSet

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("NodeSet") is not None:
            self._NodeSet = []
            for item in params.get("NodeSet"):
                obj = NodeDefineExt()
                obj._deserialize(item)
                self._NodeSet.append(obj)
        self._RequestId = params.get("RequestId")


class DescribeProbeMetricDataRequest(AbstractModel):
    r"""DescribeProbeMetricData请求参数结构体

    """

    def __init__(self):
        r"""
        :param _AnalyzeTaskType: <p>分析任务类型，支持以下几种类型：<br>AnalyzeTaskType_Network：网络质量<br>AnalyzeTaskType_Browse：页面性能<br>AnalyzeTaskType_Transport：端口性能<br>AnalyzeTaskType_UploadDownload：文件传输<br>AnalyzeTaskType_MediaStream：音视频体验</p>
        :type AnalyzeTaskType: str
        :param _MetricType: <p>指标类型（counter、gauge以及histogram），指标查询默认传gauge</p>
        :type MetricType: str
        :param _Field: <p>指标详细字段，可以传递传具体的指标也可以对指标进行聚合查询例如：&quot;avg(ping_time)&quot;代表整体时延(ms)；不同的任务类型支持不同的field查询，以及聚合规则，详情可见https://cloud.tencent.com/document/product/248/87584。</p>
        :type Field: str
        :param _Filter: <p>过滤条件可以传单个过滤条件也可以拼接多个参数</p>
        :type Filter: str
        :param _GroupBy: <p>聚合时间, 1m、1d、30d 等等</p>
        :type GroupBy: str
        :param _Filters: <p>多条件过滤，支持多个过滤条件组合查询<br>例如：[&quot;&quot;host&quot; = &#39;www.test.com&#39;&quot;, &quot;time &gt;= now()-1h&quot;]</p>
        :type Filters: list of str
        """
        self._AnalyzeTaskType = None
        self._MetricType = None
        self._Field = None
        self._Filter = None
        self._GroupBy = None
        self._Filters = None

    @property
    def AnalyzeTaskType(self):
        r"""<p>分析任务类型，支持以下几种类型：<br>AnalyzeTaskType_Network：网络质量<br>AnalyzeTaskType_Browse：页面性能<br>AnalyzeTaskType_Transport：端口性能<br>AnalyzeTaskType_UploadDownload：文件传输<br>AnalyzeTaskType_MediaStream：音视频体验</p>
        :rtype: str
        """
        return self._AnalyzeTaskType

    @AnalyzeTaskType.setter
    def AnalyzeTaskType(self, AnalyzeTaskType):
        self._AnalyzeTaskType = AnalyzeTaskType

    @property
    def MetricType(self):
        r"""<p>指标类型（counter、gauge以及histogram），指标查询默认传gauge</p>
        :rtype: str
        """
        return self._MetricType

    @MetricType.setter
    def MetricType(self, MetricType):
        self._MetricType = MetricType

    @property
    def Field(self):
        r"""<p>指标详细字段，可以传递传具体的指标也可以对指标进行聚合查询例如：&quot;avg(ping_time)&quot;代表整体时延(ms)；不同的任务类型支持不同的field查询，以及聚合规则，详情可见https://cloud.tencent.com/document/product/248/87584。</p>
        :rtype: str
        """
        return self._Field

    @Field.setter
    def Field(self, Field):
        self._Field = Field

    @property
    def Filter(self):
        r"""<p>过滤条件可以传单个过滤条件也可以拼接多个参数</p>
        :rtype: str
        """
        return self._Filter

    @Filter.setter
    def Filter(self, Filter):
        self._Filter = Filter

    @property
    def GroupBy(self):
        r"""<p>聚合时间, 1m、1d、30d 等等</p>
        :rtype: str
        """
        return self._GroupBy

    @GroupBy.setter
    def GroupBy(self, GroupBy):
        self._GroupBy = GroupBy

    @property
    def Filters(self):
        r"""<p>多条件过滤，支持多个过滤条件组合查询<br>例如：[&quot;&quot;host&quot; = &#39;www.test.com&#39;&quot;, &quot;time &gt;= now()-1h&quot;]</p>
        :rtype: list of str
        """
        return self._Filters

    @Filters.setter
    def Filters(self, Filters):
        self._Filters = Filters


    def _deserialize(self, params):
        self._AnalyzeTaskType = params.get("AnalyzeTaskType")
        self._MetricType = params.get("MetricType")
        self._Field = params.get("Field")
        self._Filter = params.get("Filter")
        self._GroupBy = params.get("GroupBy")
        self._Filters = params.get("Filters")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeProbeMetricDataResponse(AbstractModel):
    r"""DescribeProbeMetricData返回参数结构体

    """

    def __init__(self):
        r"""
        :param _MetricSet: <p>返回指标 JSON 序列化后的字符串，具体如下所示：&quot;[{"name":"task_navigate_request_gauge","columns":["time","avg(first_screen_time) / 1000"],"values":[[1641571200,6.756600000000001]],"tags":null}]&quot;</p>
        :type MetricSet: str
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._MetricSet = None
        self._RequestId = None

    @property
    def MetricSet(self):
        r"""<p>返回指标 JSON 序列化后的字符串，具体如下所示：&quot;[{"name":"task_navigate_request_gauge","columns":["time","avg(first_screen_time) / 1000"],"values":[[1641571200,6.756600000000001]],"tags":null}]&quot;</p>
        :rtype: str
        """
        return self._MetricSet

    @MetricSet.setter
    def MetricSet(self, MetricSet):
        self._MetricSet = MetricSet

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._MetricSet = params.get("MetricSet")
        self._RequestId = params.get("RequestId")


class DescribeProbeMetricTagValuesRequest(AbstractModel):
    r"""DescribeProbeMetricTagValues请求参数结构体

    """

    def __init__(self):
        r"""
        :param _AnalyzeTaskType: 分析任务类型，支持以下几种类型：
AnalyzeTaskType_Network：网络质量
AnalyzeTaskType_Browse：页面性能 
AnalyzeTaskType_Transport：端口性能
AnalyzeTaskType_UploadDownload：文件传输
AnalyzeTaskType_MediaStream：音视频体验

        :type AnalyzeTaskType: str
        :param _Key: 维度标签值，参考：
host：任务域名
errorInfo：状态类型
area：拨测点地区
operator：拨测点运营商
taskId：任务ID
        :type Key: str
        :param _Filter: 过滤条件，可以传单个过滤条件也可以拼接多个参数，支持正则匹配
        :type Filter: str
        :param _Filters: 过滤条件数组
        :type Filters: list of str
        :param _TimeRange: 时间范围
        :type TimeRange: str
        """
        self._AnalyzeTaskType = None
        self._Key = None
        self._Filter = None
        self._Filters = None
        self._TimeRange = None

    @property
    def AnalyzeTaskType(self):
        r"""分析任务类型，支持以下几种类型：
AnalyzeTaskType_Network：网络质量
AnalyzeTaskType_Browse：页面性能 
AnalyzeTaskType_Transport：端口性能
AnalyzeTaskType_UploadDownload：文件传输
AnalyzeTaskType_MediaStream：音视频体验

        :rtype: str
        """
        return self._AnalyzeTaskType

    @AnalyzeTaskType.setter
    def AnalyzeTaskType(self, AnalyzeTaskType):
        self._AnalyzeTaskType = AnalyzeTaskType

    @property
    def Key(self):
        r"""维度标签值，参考：
host：任务域名
errorInfo：状态类型
area：拨测点地区
operator：拨测点运营商
taskId：任务ID
        :rtype: str
        """
        return self._Key

    @Key.setter
    def Key(self, Key):
        self._Key = Key

    @property
    def Filter(self):
        r"""过滤条件，可以传单个过滤条件也可以拼接多个参数，支持正则匹配
        :rtype: str
        """
        return self._Filter

    @Filter.setter
    def Filter(self, Filter):
        self._Filter = Filter

    @property
    def Filters(self):
        r"""过滤条件数组
        :rtype: list of str
        """
        return self._Filters

    @Filters.setter
    def Filters(self, Filters):
        self._Filters = Filters

    @property
    def TimeRange(self):
        r"""时间范围
        :rtype: str
        """
        return self._TimeRange

    @TimeRange.setter
    def TimeRange(self, TimeRange):
        self._TimeRange = TimeRange


    def _deserialize(self, params):
        self._AnalyzeTaskType = params.get("AnalyzeTaskType")
        self._Key = params.get("Key")
        self._Filter = params.get("Filter")
        self._Filters = params.get("Filters")
        self._TimeRange = params.get("TimeRange")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeProbeMetricTagValuesResponse(AbstractModel):
    r"""DescribeProbeMetricTagValues返回参数结构体

    """

    def __init__(self):
        r"""
        :param _TagValueSet: 标签值序列化后的字符串
        :type TagValueSet: str
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._TagValueSet = None
        self._RequestId = None

    @property
    def TagValueSet(self):
        r"""标签值序列化后的字符串
        :rtype: str
        """
        return self._TagValueSet

    @TagValueSet.setter
    def TagValueSet(self, TagValueSet):
        self._TagValueSet = TagValueSet

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._TagValueSet = params.get("TagValueSet")
        self._RequestId = params.get("RequestId")


class DescribeProbeNodesRequest(AbstractModel):
    r"""DescribeProbeNodes请求参数结构体

    """

    def __init__(self):
        r"""
        :param _NodeType: 节点类型
<li> 1 = IDC </li>
<li> 2 = LastMile </li>
<li> 3 = Mobile </li>
        :type NodeType: int
        :param _Location: 节点区域
<li> 1 = 中国大陆 </li>
<li> 2 = 港澳台 </li>
<li> 3 = 海外 </li>
        :type Location: int
        :param _IsIPv6: 是否IPv6
        :type IsIPv6: bool
        :param _NodeName: 名字模糊搜索
        :type NodeName: str
        :param _PayMode: 付费模式
<li>1 = 试用版本</li>
<li> 2 = 付费版本 </li>
        :type PayMode: int
        """
        self._NodeType = None
        self._Location = None
        self._IsIPv6 = None
        self._NodeName = None
        self._PayMode = None

    @property
    def NodeType(self):
        r"""节点类型
<li> 1 = IDC </li>
<li> 2 = LastMile </li>
<li> 3 = Mobile </li>
        :rtype: int
        """
        return self._NodeType

    @NodeType.setter
    def NodeType(self, NodeType):
        self._NodeType = NodeType

    @property
    def Location(self):
        r"""节点区域
<li> 1 = 中国大陆 </li>
<li> 2 = 港澳台 </li>
<li> 3 = 海外 </li>
        :rtype: int
        """
        return self._Location

    @Location.setter
    def Location(self, Location):
        self._Location = Location

    @property
    def IsIPv6(self):
        r"""是否IPv6
        :rtype: bool
        """
        return self._IsIPv6

    @IsIPv6.setter
    def IsIPv6(self, IsIPv6):
        self._IsIPv6 = IsIPv6

    @property
    def NodeName(self):
        r"""名字模糊搜索
        :rtype: str
        """
        return self._NodeName

    @NodeName.setter
    def NodeName(self, NodeName):
        self._NodeName = NodeName

    @property
    def PayMode(self):
        r"""付费模式
<li>1 = 试用版本</li>
<li> 2 = 付费版本 </li>
        :rtype: int
        """
        return self._PayMode

    @PayMode.setter
    def PayMode(self, PayMode):
        self._PayMode = PayMode


    def _deserialize(self, params):
        self._NodeType = params.get("NodeType")
        self._Location = params.get("Location")
        self._IsIPv6 = params.get("IsIPv6")
        self._NodeName = params.get("NodeName")
        self._PayMode = params.get("PayMode")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeProbeNodesResponse(AbstractModel):
    r"""DescribeProbeNodes返回参数结构体

    """

    def __init__(self):
        r"""
        :param _NodeSet: 节点列表
注意：此字段可能返回 null，表示取不到有效值。
        :type NodeSet: list of NodeDefine
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._NodeSet = None
        self._RequestId = None

    @property
    def NodeSet(self):
        r"""节点列表
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of NodeDefine
        """
        return self._NodeSet

    @NodeSet.setter
    def NodeSet(self, NodeSet):
        self._NodeSet = NodeSet

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("NodeSet") is not None:
            self._NodeSet = []
            for item in params.get("NodeSet"):
                obj = NodeDefine()
                obj._deserialize(item)
                self._NodeSet.append(obj)
        self._RequestId = params.get("RequestId")


class DescribeProbeTasksRequest(AbstractModel):
    r"""DescribeProbeTasks请求参数结构体

    """

    def __init__(self):
        r"""
        :param _TaskIDs: 任务 ID  列表
        :type TaskIDs: list of str
        :param _TaskName: 任务名
        :type TaskName: str
        :param _TargetAddress: 拨测目标
        :type TargetAddress: str
        :param _TaskStatus: 任务状态列表
<li>1 = 创建中</li>
<li> 2 = 运行中 </li>
<li> 3 = 运行异常 </li>
<li> 4 = 暂停中 </li>
<li> 5 = 暂停异常 </li>
<li> 6 = 任务暂停 </li>
<li> 7 = 任务删除中 </li>
<li> 8 = 任务删除异常 </li>
<li> 9 = 任务删除</li>
<li> 10 = 定时任务暂停中 </li>
        :type TaskStatus: list of int
        :param _Offset: 偏移量，默认为0
        :type Offset: int
        :param _Limit: 返回数量，默认为20，最大值为100
        :type Limit: int
        :param _PayMode: 付费模式
<li>1 = 试用版本</li>
<li> 2 = 付费版本 </li>
        :type PayMode: int
        :param _OrderState: 订单状态
<li>1 = 正常</li>
<li> 2 = 欠费 </li>
        :type OrderState: int
        :param _TaskType: 拨测类型
<li>1 = 页面浏览</li>
<li> 2 =文件上传 </li>
<li> 3 = 文件下载</li>
<li> 4 = 端口性能 </li>
<li> 5 = 网络质量 </li>
<li> 6 =流媒体 </li>

即使拨测只支持页面浏览，网络质量，文件下载
        :type TaskType: list of int
        :param _TaskCategory: 节点类型
        :type TaskCategory: list of int
        :param _OrderBy: 排序的列
        :type OrderBy: str
        :param _Ascend: 是否正序
        :type Ascend: bool
        :param _TagFilters: 资源标签值
        :type TagFilters: list of KeyValuePair
        """
        self._TaskIDs = None
        self._TaskName = None
        self._TargetAddress = None
        self._TaskStatus = None
        self._Offset = None
        self._Limit = None
        self._PayMode = None
        self._OrderState = None
        self._TaskType = None
        self._TaskCategory = None
        self._OrderBy = None
        self._Ascend = None
        self._TagFilters = None

    @property
    def TaskIDs(self):
        r"""任务 ID  列表
        :rtype: list of str
        """
        return self._TaskIDs

    @TaskIDs.setter
    def TaskIDs(self, TaskIDs):
        self._TaskIDs = TaskIDs

    @property
    def TaskName(self):
        r"""任务名
        :rtype: str
        """
        return self._TaskName

    @TaskName.setter
    def TaskName(self, TaskName):
        self._TaskName = TaskName

    @property
    def TargetAddress(self):
        r"""拨测目标
        :rtype: str
        """
        return self._TargetAddress

    @TargetAddress.setter
    def TargetAddress(self, TargetAddress):
        self._TargetAddress = TargetAddress

    @property
    def TaskStatus(self):
        r"""任务状态列表
<li>1 = 创建中</li>
<li> 2 = 运行中 </li>
<li> 3 = 运行异常 </li>
<li> 4 = 暂停中 </li>
<li> 5 = 暂停异常 </li>
<li> 6 = 任务暂停 </li>
<li> 7 = 任务删除中 </li>
<li> 8 = 任务删除异常 </li>
<li> 9 = 任务删除</li>
<li> 10 = 定时任务暂停中 </li>
        :rtype: list of int
        """
        return self._TaskStatus

    @TaskStatus.setter
    def TaskStatus(self, TaskStatus):
        self._TaskStatus = TaskStatus

    @property
    def Offset(self):
        r"""偏移量，默认为0
        :rtype: int
        """
        return self._Offset

    @Offset.setter
    def Offset(self, Offset):
        self._Offset = Offset

    @property
    def Limit(self):
        r"""返回数量，默认为20，最大值为100
        :rtype: int
        """
        return self._Limit

    @Limit.setter
    def Limit(self, Limit):
        self._Limit = Limit

    @property
    def PayMode(self):
        r"""付费模式
<li>1 = 试用版本</li>
<li> 2 = 付费版本 </li>
        :rtype: int
        """
        return self._PayMode

    @PayMode.setter
    def PayMode(self, PayMode):
        self._PayMode = PayMode

    @property
    def OrderState(self):
        r"""订单状态
<li>1 = 正常</li>
<li> 2 = 欠费 </li>
        :rtype: int
        """
        return self._OrderState

    @OrderState.setter
    def OrderState(self, OrderState):
        self._OrderState = OrderState

    @property
    def TaskType(self):
        r"""拨测类型
<li>1 = 页面浏览</li>
<li> 2 =文件上传 </li>
<li> 3 = 文件下载</li>
<li> 4 = 端口性能 </li>
<li> 5 = 网络质量 </li>
<li> 6 =流媒体 </li>

即使拨测只支持页面浏览，网络质量，文件下载
        :rtype: list of int
        """
        return self._TaskType

    @TaskType.setter
    def TaskType(self, TaskType):
        self._TaskType = TaskType

    @property
    def TaskCategory(self):
        r"""节点类型
        :rtype: list of int
        """
        return self._TaskCategory

    @TaskCategory.setter
    def TaskCategory(self, TaskCategory):
        self._TaskCategory = TaskCategory

    @property
    def OrderBy(self):
        r"""排序的列
        :rtype: str
        """
        return self._OrderBy

    @OrderBy.setter
    def OrderBy(self, OrderBy):
        self._OrderBy = OrderBy

    @property
    def Ascend(self):
        r"""是否正序
        :rtype: bool
        """
        return self._Ascend

    @Ascend.setter
    def Ascend(self, Ascend):
        self._Ascend = Ascend

    @property
    def TagFilters(self):
        r"""资源标签值
        :rtype: list of KeyValuePair
        """
        return self._TagFilters

    @TagFilters.setter
    def TagFilters(self, TagFilters):
        self._TagFilters = TagFilters


    def _deserialize(self, params):
        self._TaskIDs = params.get("TaskIDs")
        self._TaskName = params.get("TaskName")
        self._TargetAddress = params.get("TargetAddress")
        self._TaskStatus = params.get("TaskStatus")
        self._Offset = params.get("Offset")
        self._Limit = params.get("Limit")
        self._PayMode = params.get("PayMode")
        self._OrderState = params.get("OrderState")
        self._TaskType = params.get("TaskType")
        self._TaskCategory = params.get("TaskCategory")
        self._OrderBy = params.get("OrderBy")
        self._Ascend = params.get("Ascend")
        if params.get("TagFilters") is not None:
            self._TagFilters = []
            for item in params.get("TagFilters"):
                obj = KeyValuePair()
                obj._deserialize(item)
                self._TagFilters.append(obj)
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeProbeTasksResponse(AbstractModel):
    r"""DescribeProbeTasks返回参数结构体

    """

    def __init__(self):
        r"""
        :param _TaskSet: 任务列表
注意：此字段可能返回 null，表示取不到有效值。
        :type TaskSet: list of ProbeTask
        :param _Total: 任务总数
        :type Total: int
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._TaskSet = None
        self._Total = None
        self._RequestId = None

    @property
    def TaskSet(self):
        r"""任务列表
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of ProbeTask
        """
        return self._TaskSet

    @TaskSet.setter
    def TaskSet(self, TaskSet):
        self._TaskSet = TaskSet

    @property
    def Total(self):
        r"""任务总数
        :rtype: int
        """
        return self._Total

    @Total.setter
    def Total(self, Total):
        self._Total = Total

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("TaskSet") is not None:
            self._TaskSet = []
            for item in params.get("TaskSet"):
                obj = ProbeTask()
                obj._deserialize(item)
                self._TaskSet.append(obj)
        self._Total = params.get("Total")
        self._RequestId = params.get("RequestId")


class DetailedSingleDataDefine(AbstractModel):
    r"""单条详细拨测数据

    """

    def __init__(self):
        r"""
        :param _ProbeTime: 拨测时间戳
        :type ProbeTime: int
        :param _Labels: 储存所有string类型字段
        :type Labels: list of Label
        :param _Fields: 储存所有float类型字段
        :type Fields: list of Field
        """
        self._ProbeTime = None
        self._Labels = None
        self._Fields = None

    @property
    def ProbeTime(self):
        r"""拨测时间戳
        :rtype: int
        """
        return self._ProbeTime

    @ProbeTime.setter
    def ProbeTime(self, ProbeTime):
        self._ProbeTime = ProbeTime

    @property
    def Labels(self):
        r"""储存所有string类型字段
        :rtype: list of Label
        """
        return self._Labels

    @Labels.setter
    def Labels(self, Labels):
        self._Labels = Labels

    @property
    def Fields(self):
        r"""储存所有float类型字段
        :rtype: list of Field
        """
        return self._Fields

    @Fields.setter
    def Fields(self, Fields):
        self._Fields = Fields


    def _deserialize(self, params):
        self._ProbeTime = params.get("ProbeTime")
        if params.get("Labels") is not None:
            self._Labels = []
            for item in params.get("Labels"):
                obj = Label()
                obj._deserialize(item)
                self._Labels.append(obj)
        if params.get("Fields") is not None:
            self._Fields = []
            for item in params.get("Fields"):
                obj = Field()
                obj._deserialize(item)
                self._Fields.append(obj)
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DistinctOrNetServiceInfo(AbstractModel):
    r"""省份(国际)或运营商基本信息

    """

    def __init__(self):
        r"""
        :param _ID: 省份(国际)或运营商ID
        :type ID: str
        :param _Name: 名称
        :type Name: str
        """
        self._ID = None
        self._Name = None

    @property
    def ID(self):
        r"""省份(国际)或运营商ID
        :rtype: str
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID

    @property
    def Name(self):
        r"""名称
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name


    def _deserialize(self, params):
        self._ID = params.get("ID")
        self._Name = params.get("Name")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class Field(AbstractModel):
    r"""储存float类型字段

    """

    def __init__(self):
        r"""
        :param _ID: 自定义字段编号
        :type ID: int
        :param _Name: 自定义字段名称/说明
        :type Name: str
        :param _Value: 字段值
        :type Value: float
        """
        self._ID = None
        self._Name = None
        self._Value = None

    @property
    def ID(self):
        r"""自定义字段编号
        :rtype: int
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID

    @property
    def Name(self):
        r"""自定义字段名称/说明
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def Value(self):
        r"""字段值
        :rtype: float
        """
        return self._Value

    @Value.setter
    def Value(self, Value):
        self._Value = Value


    def _deserialize(self, params):
        self._ID = params.get("ID")
        self._Name = params.get("Name")
        self._Value = params.get("Value")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class KeyValuePair(AbstractModel):
    r"""健值对

    """

    def __init__(self):
        r"""
        :param _Key: 健
        :type Key: str
        :param _Value: 值
        :type Value: str
        """
        self._Key = None
        self._Value = None

    @property
    def Key(self):
        r"""健
        :rtype: str
        """
        return self._Key

    @Key.setter
    def Key(self, Key):
        self._Key = Key

    @property
    def Value(self):
        r"""值
        :rtype: str
        """
        return self._Value

    @Value.setter
    def Value(self, Value):
        self._Value = Value


    def _deserialize(self, params):
        self._Key = params.get("Key")
        self._Value = params.get("Value")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class Label(AbstractModel):
    r"""保存string类型字段

    """

    def __init__(self):
        r"""
        :param _ID: 自定义字段编号
        :type ID: int
        :param _Name: 自定义字段名称/说明
        :type Name: str
        :param _Value: 字段值
        :type Value: str
        """
        self._ID = None
        self._Name = None
        self._Value = None

    @property
    def ID(self):
        r"""自定义字段编号
        :rtype: int
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID

    @property
    def Name(self):
        r"""自定义字段名称/说明
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def Value(self):
        r"""字段值
        :rtype: str
        """
        return self._Value

    @Value.setter
    def Value(self, Value):
        self._Value = Value


    def _deserialize(self, params):
        self._ID = params.get("ID")
        self._Name = params.get("Name")
        self._Value = params.get("Value")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class NodeDefine(AbstractModel):
    r"""探测节点

    """

    def __init__(self):
        r"""
        :param _Name: 节点名称
        :type Name: str
        :param _Code: 节点代码
        :type Code: str
        :param _Type: 节点类型
<li> 1 = IDC </li>
<li> 2 = LastMile </li>
<li> 3 = Mobile </li>
        :type Type: int
        :param _NetService: 网络服务商
        :type NetService: str
        :param _District: 区域
        :type District: str
        :param _City: 城市
        :type City: str
        :param _IPType: IP 类型
<li> 1 = IPv4 </li>
<li> 2 = IPv6 </li>
注意：此字段可能返回 null，表示取不到有效值。
        :type IPType: int
        :param _Location: 区域
<li> 1 = 中国大陆 </li>
<li> 2 = 港澳台 </li>
<li> 3 = 国外 </li>
注意：此字段可能返回 null，表示取不到有效值。
        :type Location: int
        :param _CodeType: 节点类型  如果为base 则为可用性拨测点，为空则为高级拨测点
注意：此字段可能返回 null，表示取不到有效值。
        :type CodeType: str
        :param _NodeDefineStatus: 节点状态：1-运行,2-下线
注意：此字段可能返回 null，表示取不到有效值。
        :type NodeDefineStatus: int
        """
        self._Name = None
        self._Code = None
        self._Type = None
        self._NetService = None
        self._District = None
        self._City = None
        self._IPType = None
        self._Location = None
        self._CodeType = None
        self._NodeDefineStatus = None

    @property
    def Name(self):
        r"""节点名称
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def Code(self):
        r"""节点代码
        :rtype: str
        """
        return self._Code

    @Code.setter
    def Code(self, Code):
        self._Code = Code

    @property
    def Type(self):
        r"""节点类型
<li> 1 = IDC </li>
<li> 2 = LastMile </li>
<li> 3 = Mobile </li>
        :rtype: int
        """
        return self._Type

    @Type.setter
    def Type(self, Type):
        self._Type = Type

    @property
    def NetService(self):
        r"""网络服务商
        :rtype: str
        """
        return self._NetService

    @NetService.setter
    def NetService(self, NetService):
        self._NetService = NetService

    @property
    def District(self):
        r"""区域
        :rtype: str
        """
        return self._District

    @District.setter
    def District(self, District):
        self._District = District

    @property
    def City(self):
        r"""城市
        :rtype: str
        """
        return self._City

    @City.setter
    def City(self, City):
        self._City = City

    @property
    def IPType(self):
        r"""IP 类型
<li> 1 = IPv4 </li>
<li> 2 = IPv6 </li>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: int
        """
        return self._IPType

    @IPType.setter
    def IPType(self, IPType):
        self._IPType = IPType

    @property
    def Location(self):
        r"""区域
<li> 1 = 中国大陆 </li>
<li> 2 = 港澳台 </li>
<li> 3 = 国外 </li>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: int
        """
        return self._Location

    @Location.setter
    def Location(self, Location):
        self._Location = Location

    @property
    def CodeType(self):
        r"""节点类型  如果为base 则为可用性拨测点，为空则为高级拨测点
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._CodeType

    @CodeType.setter
    def CodeType(self, CodeType):
        self._CodeType = CodeType

    @property
    def NodeDefineStatus(self):
        r"""节点状态：1-运行,2-下线
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: int
        """
        return self._NodeDefineStatus

    @NodeDefineStatus.setter
    def NodeDefineStatus(self, NodeDefineStatus):
        self._NodeDefineStatus = NodeDefineStatus


    def _deserialize(self, params):
        self._Name = params.get("Name")
        self._Code = params.get("Code")
        self._Type = params.get("Type")
        self._NetService = params.get("NetService")
        self._District = params.get("District")
        self._City = params.get("City")
        self._IPType = params.get("IPType")
        self._Location = params.get("Location")
        self._CodeType = params.get("CodeType")
        self._NodeDefineStatus = params.get("NodeDefineStatus")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class NodeDefineExt(AbstractModel):
    r"""探测节点

    """

    def __init__(self):
        r"""
        :param _Name: 节点名称
        :type Name: str
        :param _Code: 节点代码
        :type Code: str
        :param _Type: 节点类型
<li> 1 = IDC </li>
<li> 2 = LastMile </li>
<li> 3 = Mobile </li>
        :type Type: int
        :param _NetService: 网络服务商
        :type NetService: str
        :param _District: 区域
        :type District: str
        :param _City: 城市
        :type City: str
        :param _IPType: IP 类型
<li> 1 = IPv4 </li>
<li> 2 = IPv6 </li>
注意：此字段可能返回 null，表示取不到有效值。
        :type IPType: int
        :param _Location: 区域
<li> 1 = 中国大陆 </li>
<li> 2 = 港澳台 </li>
<li> 3 = 境外 </li>
注意：此字段可能返回 null，表示取不到有效值。
        :type Location: int
        :param _CodeType: 节点类型  如果为base 则为可用性拨测点，为空则为高级拨测点
注意：此字段可能返回 null，表示取不到有效值。
        :type CodeType: str
        :param _TaskTypes: 节点支持的任务类型。1: 页面性能 2: 文件上传 3: 文件下载 4: 端口性能 5: 网络质量 6: 音视频体验
注意：此字段可能返回 null，表示取不到有效值。
        :type TaskTypes: list of int
        """
        self._Name = None
        self._Code = None
        self._Type = None
        self._NetService = None
        self._District = None
        self._City = None
        self._IPType = None
        self._Location = None
        self._CodeType = None
        self._TaskTypes = None

    @property
    def Name(self):
        r"""节点名称
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def Code(self):
        r"""节点代码
        :rtype: str
        """
        return self._Code

    @Code.setter
    def Code(self, Code):
        self._Code = Code

    @property
    def Type(self):
        r"""节点类型
<li> 1 = IDC </li>
<li> 2 = LastMile </li>
<li> 3 = Mobile </li>
        :rtype: int
        """
        return self._Type

    @Type.setter
    def Type(self, Type):
        self._Type = Type

    @property
    def NetService(self):
        r"""网络服务商
        :rtype: str
        """
        return self._NetService

    @NetService.setter
    def NetService(self, NetService):
        self._NetService = NetService

    @property
    def District(self):
        r"""区域
        :rtype: str
        """
        return self._District

    @District.setter
    def District(self, District):
        self._District = District

    @property
    def City(self):
        r"""城市
        :rtype: str
        """
        return self._City

    @City.setter
    def City(self, City):
        self._City = City

    @property
    def IPType(self):
        r"""IP 类型
<li> 1 = IPv4 </li>
<li> 2 = IPv6 </li>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: int
        """
        return self._IPType

    @IPType.setter
    def IPType(self, IPType):
        self._IPType = IPType

    @property
    def Location(self):
        r"""区域
<li> 1 = 中国大陆 </li>
<li> 2 = 港澳台 </li>
<li> 3 = 境外 </li>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: int
        """
        return self._Location

    @Location.setter
    def Location(self, Location):
        self._Location = Location

    @property
    def CodeType(self):
        r"""节点类型  如果为base 则为可用性拨测点，为空则为高级拨测点
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._CodeType

    @CodeType.setter
    def CodeType(self, CodeType):
        self._CodeType = CodeType

    @property
    def TaskTypes(self):
        r"""节点支持的任务类型。1: 页面性能 2: 文件上传 3: 文件下载 4: 端口性能 5: 网络质量 6: 音视频体验
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of int
        """
        return self._TaskTypes

    @TaskTypes.setter
    def TaskTypes(self, TaskTypes):
        self._TaskTypes = TaskTypes


    def _deserialize(self, params):
        self._Name = params.get("Name")
        self._Code = params.get("Code")
        self._Type = params.get("Type")
        self._NetService = params.get("NetService")
        self._District = params.get("District")
        self._City = params.get("City")
        self._IPType = params.get("IPType")
        self._Location = params.get("Location")
        self._CodeType = params.get("CodeType")
        self._TaskTypes = params.get("TaskTypes")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class NodeInfoBase(AbstractModel):
    r"""Node节点基本信息，用于新建任务页面重构节点选择

    """

    def __init__(self):
        r"""
        :param _ID: 节点code
        :type ID: str
        :param _Content: 节点名称
        :type Content: str
        """
        self._ID = None
        self._Content = None

    @property
    def ID(self):
        r"""节点code
        :rtype: str
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID

    @property
    def Content(self):
        r"""节点名称
        :rtype: str
        """
        return self._Content

    @Content.setter
    def Content(self, Content):
        self._Content = Content


    def _deserialize(self, params):
        self._ID = params.get("ID")
        self._Content = params.get("Content")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class NodeLeaf(AbstractModel):
    r"""子节点。用于新建任务重构页面的节点选择

    """

    def __init__(self):
        r"""
        :param _ID: 子节点ID
        :type ID: str
        :param _Content: 子节点名称
        :type Content: str
        :param _Children: 节点列表
        :type Children: list of NodeInfoBase
        """
        self._ID = None
        self._Content = None
        self._Children = None

    @property
    def ID(self):
        r"""子节点ID
        :rtype: str
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID

    @property
    def Content(self):
        r"""子节点名称
        :rtype: str
        """
        return self._Content

    @Content.setter
    def Content(self, Content):
        self._Content = Content

    @property
    def Children(self):
        r"""节点列表
        :rtype: list of NodeInfoBase
        """
        return self._Children

    @Children.setter
    def Children(self, Children):
        self._Children = Children


    def _deserialize(self, params):
        self._ID = params.get("ID")
        self._Content = params.get("Content")
        if params.get("Children") is not None:
            self._Children = []
            for item in params.get("Children"):
                obj = NodeInfoBase()
                obj._deserialize(item)
                self._Children.append(obj)
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class NodeTree(AbstractModel):
    r"""拨测节点数（新建任务页面重构）

    """

    def __init__(self):
        r"""
        :param _ID: 节点ID
        :type ID: str
        :param _Content: 节点名称
        :type Content: str
        :param _Children: 子节点
        :type Children: list of NodeLeaf
        """
        self._ID = None
        self._Content = None
        self._Children = None

    @property
    def ID(self):
        r"""节点ID
        :rtype: str
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID

    @property
    def Content(self):
        r"""节点名称
        :rtype: str
        """
        return self._Content

    @Content.setter
    def Content(self, Content):
        self._Content = Content

    @property
    def Children(self):
        r"""子节点
        :rtype: list of NodeLeaf
        """
        return self._Children

    @Children.setter
    def Children(self, Children):
        self._Children = Children


    def _deserialize(self, params):
        self._ID = params.get("ID")
        self._Content = params.get("Content")
        if params.get("Children") is not None:
            self._Children = []
            for item in params.get("Children"):
                obj = NodeLeaf()
                obj._deserialize(item)
                self._Children.append(obj)
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ProbeTask(AbstractModel):
    r"""拨测任务

    """

    def __init__(self):
        r"""
        :param _Name: 任务名
注意：此字段可能返回 null，表示取不到有效值。
        :type Name: str
        :param _TaskId: 任务 ID
        :type TaskId: str
        :param _TaskType: 拨测类型
<li>1 = 页面浏览</li>
<li> 2 =文件上传 </li>
<li> 3 = 文件下载</li>
<li> 4 = 端口性能 </li>
<li> 5 = 网络质量 </li>
<li> 6 =流媒体 </li>

即时拨测只支持页面浏览，网络质量，文件下载
        :type TaskType: int
        :param _Nodes: 拨测节点列表
        :type Nodes: list of str
        :param _NodeIpType: 拨测任务所选的拨测点IP类型，0-不限，1-IPv4，2-IPv6
注意：此字段可能返回 null，表示取不到有效值。
        :type NodeIpType: int
        :param _Interval: 拨测间隔，单位为分钟
        :type Interval: int
        :param _Parameters: 拨测参数
        :type Parameters: str
        :param _Status: 任务状态
<li>1 = 创建中</li>
<li> 2 = 运行中 </li>
<li> 3 = 运行异常 </li>
<li> 4 = 暂停中 </li>
<li> 5 = 暂停异常 </li>
<li> 6 = 任务暂停 </li>
<li> 7 = 任务删除中 </li>
<li> 8 = 任务删除异常 </li>
<li> 9 = 任务删除</li>
<li> 10 = 定时任务暂停中 </li>
        :type Status: int
        :param _TargetAddress: 目标地址
        :type TargetAddress: str
        :param _PayMode: 付费模式
<li>1 = 试用版本</li>
<li> 2 = 付费版本 </li>
        :type PayMode: int
        :param _OrderState: 订单状态
<li>1 = 正常</li>
<li> 2 = 欠费 </li>
        :type OrderState: int
        :param _TaskCategory: 任务分类
<li>1 = PC</li>
<li> 2 = Mobile </li>
        :type TaskCategory: int
        :param _CreatedAt: 创建时间
        :type CreatedAt: str
        :param _Cron: 定时任务cron表达式
注意：此字段可能返回 null，表示取不到有效值。
        :type Cron: str
        :param _CronState: 定时任务启动状态
<li>1 = 定时任务表达式生效</li>
<li> 2 = 定时任务表达式未生效（一般为任务手动暂停）</li>
注意：此字段可能返回 null，表示取不到有效值。
        :type CronState: int
        :param _TagInfoList: 任务当前绑定的标签
注意：此字段可能返回 null，表示取不到有效值。
        :type TagInfoList: list of KeyValuePair
        :param _SubSyncFlag: 是否为同步账号
注意：此字段可能返回 null，表示取不到有效值。
        :type SubSyncFlag: int
        """
        self._Name = None
        self._TaskId = None
        self._TaskType = None
        self._Nodes = None
        self._NodeIpType = None
        self._Interval = None
        self._Parameters = None
        self._Status = None
        self._TargetAddress = None
        self._PayMode = None
        self._OrderState = None
        self._TaskCategory = None
        self._CreatedAt = None
        self._Cron = None
        self._CronState = None
        self._TagInfoList = None
        self._SubSyncFlag = None

    @property
    def Name(self):
        r"""任务名
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def TaskId(self):
        r"""任务 ID
        :rtype: str
        """
        return self._TaskId

    @TaskId.setter
    def TaskId(self, TaskId):
        self._TaskId = TaskId

    @property
    def TaskType(self):
        r"""拨测类型
<li>1 = 页面浏览</li>
<li> 2 =文件上传 </li>
<li> 3 = 文件下载</li>
<li> 4 = 端口性能 </li>
<li> 5 = 网络质量 </li>
<li> 6 =流媒体 </li>

即时拨测只支持页面浏览，网络质量，文件下载
        :rtype: int
        """
        return self._TaskType

    @TaskType.setter
    def TaskType(self, TaskType):
        self._TaskType = TaskType

    @property
    def Nodes(self):
        r"""拨测节点列表
        :rtype: list of str
        """
        return self._Nodes

    @Nodes.setter
    def Nodes(self, Nodes):
        self._Nodes = Nodes

    @property
    def NodeIpType(self):
        r"""拨测任务所选的拨测点IP类型，0-不限，1-IPv4，2-IPv6
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: int
        """
        return self._NodeIpType

    @NodeIpType.setter
    def NodeIpType(self, NodeIpType):
        self._NodeIpType = NodeIpType

    @property
    def Interval(self):
        r"""拨测间隔，单位为分钟
        :rtype: int
        """
        return self._Interval

    @Interval.setter
    def Interval(self, Interval):
        self._Interval = Interval

    @property
    def Parameters(self):
        r"""拨测参数
        :rtype: str
        """
        return self._Parameters

    @Parameters.setter
    def Parameters(self, Parameters):
        self._Parameters = Parameters

    @property
    def Status(self):
        r"""任务状态
<li>1 = 创建中</li>
<li> 2 = 运行中 </li>
<li> 3 = 运行异常 </li>
<li> 4 = 暂停中 </li>
<li> 5 = 暂停异常 </li>
<li> 6 = 任务暂停 </li>
<li> 7 = 任务删除中 </li>
<li> 8 = 任务删除异常 </li>
<li> 9 = 任务删除</li>
<li> 10 = 定时任务暂停中 </li>
        :rtype: int
        """
        return self._Status

    @Status.setter
    def Status(self, Status):
        self._Status = Status

    @property
    def TargetAddress(self):
        r"""目标地址
        :rtype: str
        """
        return self._TargetAddress

    @TargetAddress.setter
    def TargetAddress(self, TargetAddress):
        self._TargetAddress = TargetAddress

    @property
    def PayMode(self):
        r"""付费模式
<li>1 = 试用版本</li>
<li> 2 = 付费版本 </li>
        :rtype: int
        """
        return self._PayMode

    @PayMode.setter
    def PayMode(self, PayMode):
        self._PayMode = PayMode

    @property
    def OrderState(self):
        r"""订单状态
<li>1 = 正常</li>
<li> 2 = 欠费 </li>
        :rtype: int
        """
        return self._OrderState

    @OrderState.setter
    def OrderState(self, OrderState):
        self._OrderState = OrderState

    @property
    def TaskCategory(self):
        r"""任务分类
<li>1 = PC</li>
<li> 2 = Mobile </li>
        :rtype: int
        """
        return self._TaskCategory

    @TaskCategory.setter
    def TaskCategory(self, TaskCategory):
        self._TaskCategory = TaskCategory

    @property
    def CreatedAt(self):
        r"""创建时间
        :rtype: str
        """
        return self._CreatedAt

    @CreatedAt.setter
    def CreatedAt(self, CreatedAt):
        self._CreatedAt = CreatedAt

    @property
    def Cron(self):
        r"""定时任务cron表达式
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._Cron

    @Cron.setter
    def Cron(self, Cron):
        self._Cron = Cron

    @property
    def CronState(self):
        r"""定时任务启动状态
<li>1 = 定时任务表达式生效</li>
<li> 2 = 定时任务表达式未生效（一般为任务手动暂停）</li>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: int
        """
        return self._CronState

    @CronState.setter
    def CronState(self, CronState):
        self._CronState = CronState

    @property
    def TagInfoList(self):
        r"""任务当前绑定的标签
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of KeyValuePair
        """
        return self._TagInfoList

    @TagInfoList.setter
    def TagInfoList(self, TagInfoList):
        self._TagInfoList = TagInfoList

    @property
    def SubSyncFlag(self):
        r"""是否为同步账号
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: int
        """
        return self._SubSyncFlag

    @SubSyncFlag.setter
    def SubSyncFlag(self, SubSyncFlag):
        self._SubSyncFlag = SubSyncFlag


    def _deserialize(self, params):
        self._Name = params.get("Name")
        self._TaskId = params.get("TaskId")
        self._TaskType = params.get("TaskType")
        self._Nodes = params.get("Nodes")
        self._NodeIpType = params.get("NodeIpType")
        self._Interval = params.get("Interval")
        self._Parameters = params.get("Parameters")
        self._Status = params.get("Status")
        self._TargetAddress = params.get("TargetAddress")
        self._PayMode = params.get("PayMode")
        self._OrderState = params.get("OrderState")
        self._TaskCategory = params.get("TaskCategory")
        self._CreatedAt = params.get("CreatedAt")
        self._Cron = params.get("Cron")
        self._CronState = params.get("CronState")
        if params.get("TagInfoList") is not None:
            self._TagInfoList = []
            for item in params.get("TagInfoList"):
                obj = KeyValuePair()
                obj._deserialize(item)
                self._TagInfoList.append(obj)
        self._SubSyncFlag = params.get("SubSyncFlag")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ProbeTaskBasicConfiguration(AbstractModel):
    r"""拨测任务基础配置

    """

    def __init__(self):
        r"""
        :param _Name: 拨测任务名称
        :type Name: str
        :param _TargetAddress: 拨测目标地址
        :type TargetAddress: str
        """
        self._Name = None
        self._TargetAddress = None

    @property
    def Name(self):
        r"""拨测任务名称
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def TargetAddress(self):
        r"""拨测目标地址
        :rtype: str
        """
        return self._TargetAddress

    @TargetAddress.setter
    def TargetAddress(self, TargetAddress):
        self._TargetAddress = TargetAddress


    def _deserialize(self, params):
        self._Name = params.get("Name")
        self._TargetAddress = params.get("TargetAddress")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ResumeProbeTaskRequest(AbstractModel):
    r"""ResumeProbeTask请求参数结构体

    """

    def __init__(self):
        r"""
        :param _TaskIds: 任务 ID
        :type TaskIds: list of str
        """
        self._TaskIds = None

    @property
    def TaskIds(self):
        r"""任务 ID
        :rtype: list of str
        """
        return self._TaskIds

    @TaskIds.setter
    def TaskIds(self, TaskIds):
        self._TaskIds = TaskIds


    def _deserialize(self, params):
        self._TaskIds = params.get("TaskIds")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ResumeProbeTaskResponse(AbstractModel):
    r"""ResumeProbeTask返回参数结构体

    """

    def __init__(self):
        r"""
        :param _Total: 任务总量
        :type Total: int
        :param _SuccessCount: 任务成功量
注意：此字段可能返回 null，表示取不到有效值。
        :type SuccessCount: int
        :param _Results: 任务执行详情
注意：此字段可能返回 null，表示取不到有效值。
        :type Results: list of TaskResult
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._Total = None
        self._SuccessCount = None
        self._Results = None
        self._RequestId = None

    @property
    def Total(self):
        r"""任务总量
        :rtype: int
        """
        return self._Total

    @Total.setter
    def Total(self, Total):
        self._Total = Total

    @property
    def SuccessCount(self):
        r"""任务成功量
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: int
        """
        return self._SuccessCount

    @SuccessCount.setter
    def SuccessCount(self, SuccessCount):
        self._SuccessCount = SuccessCount

    @property
    def Results(self):
        r"""任务执行详情
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of TaskResult
        """
        return self._Results

    @Results.setter
    def Results(self, Results):
        self._Results = Results

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._Total = params.get("Total")
        self._SuccessCount = params.get("SuccessCount")
        if params.get("Results") is not None:
            self._Results = []
            for item in params.get("Results"):
                obj = TaskResult()
                obj._deserialize(item)
                self._Results.append(obj)
        self._RequestId = params.get("RequestId")


class SingleInstantTask(AbstractModel):
    r"""单个即时拨测任务信息

    """

    def __init__(self):
        r"""
        :param _TaskId: 任务ID
        :type TaskId: str
        :param _TargetAddress: 任务地址
        :type TargetAddress: str
        :param _TaskType: 任务类型
        :type TaskType: int
        :param _ProbeTime: 测试时间
        :type ProbeTime: int
        :param _Status: 任务状态
        :type Status: str
        :param _SuccessRate: 成功率
        :type SuccessRate: float
        :param _NodeCount: 节点数量
        :type NodeCount: int
        :param _TaskCategory: 节点类型
        :type TaskCategory: int
        """
        self._TaskId = None
        self._TargetAddress = None
        self._TaskType = None
        self._ProbeTime = None
        self._Status = None
        self._SuccessRate = None
        self._NodeCount = None
        self._TaskCategory = None

    @property
    def TaskId(self):
        r"""任务ID
        :rtype: str
        """
        return self._TaskId

    @TaskId.setter
    def TaskId(self, TaskId):
        self._TaskId = TaskId

    @property
    def TargetAddress(self):
        r"""任务地址
        :rtype: str
        """
        return self._TargetAddress

    @TargetAddress.setter
    def TargetAddress(self, TargetAddress):
        self._TargetAddress = TargetAddress

    @property
    def TaskType(self):
        r"""任务类型
        :rtype: int
        """
        return self._TaskType

    @TaskType.setter
    def TaskType(self, TaskType):
        self._TaskType = TaskType

    @property
    def ProbeTime(self):
        r"""测试时间
        :rtype: int
        """
        return self._ProbeTime

    @ProbeTime.setter
    def ProbeTime(self, ProbeTime):
        self._ProbeTime = ProbeTime

    @property
    def Status(self):
        r"""任务状态
        :rtype: str
        """
        return self._Status

    @Status.setter
    def Status(self, Status):
        self._Status = Status

    @property
    def SuccessRate(self):
        r"""成功率
        :rtype: float
        """
        return self._SuccessRate

    @SuccessRate.setter
    def SuccessRate(self, SuccessRate):
        self._SuccessRate = SuccessRate

    @property
    def NodeCount(self):
        r"""节点数量
        :rtype: int
        """
        return self._NodeCount

    @NodeCount.setter
    def NodeCount(self, NodeCount):
        self._NodeCount = NodeCount

    @property
    def TaskCategory(self):
        r"""节点类型
        :rtype: int
        """
        return self._TaskCategory

    @TaskCategory.setter
    def TaskCategory(self, TaskCategory):
        self._TaskCategory = TaskCategory


    def _deserialize(self, params):
        self._TaskId = params.get("TaskId")
        self._TargetAddress = params.get("TargetAddress")
        self._TaskType = params.get("TaskType")
        self._ProbeTime = params.get("ProbeTime")
        self._Status = params.get("Status")
        self._SuccessRate = params.get("SuccessRate")
        self._NodeCount = params.get("NodeCount")
        self._TaskCategory = params.get("TaskCategory")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class SuspendProbeTaskRequest(AbstractModel):
    r"""SuspendProbeTask请求参数结构体

    """

    def __init__(self):
        r"""
        :param _TaskIds: 任务 ID
        :type TaskIds: list of str
        """
        self._TaskIds = None

    @property
    def TaskIds(self):
        r"""任务 ID
        :rtype: list of str
        """
        return self._TaskIds

    @TaskIds.setter
    def TaskIds(self, TaskIds):
        self._TaskIds = TaskIds


    def _deserialize(self, params):
        self._TaskIds = params.get("TaskIds")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class SuspendProbeTaskResponse(AbstractModel):
    r"""SuspendProbeTask返回参数结构体

    """

    def __init__(self):
        r"""
        :param _Total: 任务总量
        :type Total: int
        :param _SuccessCount: 任务成功量
注意：此字段可能返回 null，表示取不到有效值。
        :type SuccessCount: int
        :param _Results: 任务执行结果
注意：此字段可能返回 null，表示取不到有效值。
        :type Results: list of TaskResult
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._Total = None
        self._SuccessCount = None
        self._Results = None
        self._RequestId = None

    @property
    def Total(self):
        r"""任务总量
        :rtype: int
        """
        return self._Total

    @Total.setter
    def Total(self, Total):
        self._Total = Total

    @property
    def SuccessCount(self):
        r"""任务成功量
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: int
        """
        return self._SuccessCount

    @SuccessCount.setter
    def SuccessCount(self, SuccessCount):
        self._SuccessCount = SuccessCount

    @property
    def Results(self):
        r"""任务执行结果
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of TaskResult
        """
        return self._Results

    @Results.setter
    def Results(self, Results):
        self._Results = Results

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._Total = params.get("Total")
        self._SuccessCount = params.get("SuccessCount")
        if params.get("Results") is not None:
            self._Results = []
            for item in params.get("Results"):
                obj = TaskResult()
                obj._deserialize(item)
                self._Results.append(obj)
        self._RequestId = params.get("RequestId")


class Tag(AbstractModel):
    r"""资源的标签，通过标签对资源进行划分用于支持细粒度的鉴权、分账等场景

    """

    def __init__(self):
        r"""
        :param _TagKey: key
        :type TagKey: str
        :param _TagValue: value
        :type TagValue: str
        """
        self._TagKey = None
        self._TagValue = None

    @property
    def TagKey(self):
        r"""key
        :rtype: str
        """
        return self._TagKey

    @TagKey.setter
    def TagKey(self, TagKey):
        self._TagKey = TagKey

    @property
    def TagValue(self):
        r"""value
        :rtype: str
        """
        return self._TagValue

    @TagValue.setter
    def TagValue(self, TagValue):
        self._TagValue = TagValue


    def _deserialize(self, params):
        self._TagKey = params.get("TagKey")
        self._TagValue = params.get("TagValue")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class TaskResult(AbstractModel):
    r"""任务执行结果

    """

    def __init__(self):
        r"""
        :param _TaskId: 任务 ID
        :type TaskId: str
        :param _Success: 是否成功
注意：此字段可能返回 null，表示取不到有效值。
        :type Success: bool
        :param _ErrorMessage: 错误信息
注意：此字段可能返回 null，表示取不到有效值。
        :type ErrorMessage: str
        """
        self._TaskId = None
        self._Success = None
        self._ErrorMessage = None

    @property
    def TaskId(self):
        r"""任务 ID
        :rtype: str
        """
        return self._TaskId

    @TaskId.setter
    def TaskId(self, TaskId):
        self._TaskId = TaskId

    @property
    def Success(self):
        r"""是否成功
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: bool
        """
        return self._Success

    @Success.setter
    def Success(self, Success):
        self._Success = Success

    @property
    def ErrorMessage(self):
        r"""错误信息
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._ErrorMessage

    @ErrorMessage.setter
    def ErrorMessage(self, ErrorMessage):
        self._ErrorMessage = ErrorMessage


    def _deserialize(self, params):
        self._TaskId = params.get("TaskId")
        self._Success = params.get("Success")
        self._ErrorMessage = params.get("ErrorMessage")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class UpdateProbeTaskAttributesRequest(AbstractModel):
    r"""UpdateProbeTaskAttributes请求参数结构体

    """

    def __init__(self):
        r"""
        :param _TaskId: 任务 ID
        :type TaskId: str
        :param _Name: 任务名，该参数为空时不作任何修改。
        :type Name: str
        """
        self._TaskId = None
        self._Name = None

    @property
    def TaskId(self):
        r"""任务 ID
        :rtype: str
        """
        return self._TaskId

    @TaskId.setter
    def TaskId(self, TaskId):
        self._TaskId = TaskId

    @property
    def Name(self):
        r"""任务名，该参数为空时不作任何修改。
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name


    def _deserialize(self, params):
        self._TaskId = params.get("TaskId")
        self._Name = params.get("Name")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class UpdateProbeTaskAttributesResponse(AbstractModel):
    r"""UpdateProbeTaskAttributes返回参数结构体

    """

    def __init__(self):
        r"""
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._RequestId = None

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._RequestId = params.get("RequestId")


class UpdateProbeTaskConfigurationListRequest(AbstractModel):
    r"""UpdateProbeTaskConfigurationList请求参数结构体

    """

    def __init__(self):
        r"""
        :param _TaskIds: 任务 ID，如task-n1wchki8
        :type TaskIds: list of str
        :param _Nodes: 拨测节点，如10001，详细地区运营商拨测编号请联系云拨测。
        :type Nodes: list of str
        :param _Interval: 拨测间隔，如30，单位为分钟。
        :type Interval: int
        :param _Parameters: 拨测参数，详细参数配置可参考云拨测官网文档。
        :type Parameters: str
        :param _Cron: 定时任务cron表达式
        :type Cron: str
        :param _ResourceIDs: 预付费套餐id
需要与taskId对应
        :type ResourceIDs: list of str
        :param _NodeIpType: 拨测节点的IP类型，0-不限，1-IPv4，2-IPv6
        :type NodeIpType: int
        :param _BatchTasks: 批量任务名-地址
        :type BatchTasks: list of ProbeTaskBasicConfiguration
        """
        self._TaskIds = None
        self._Nodes = None
        self._Interval = None
        self._Parameters = None
        self._Cron = None
        self._ResourceIDs = None
        self._NodeIpType = None
        self._BatchTasks = None

    @property
    def TaskIds(self):
        r"""任务 ID，如task-n1wchki8
        :rtype: list of str
        """
        return self._TaskIds

    @TaskIds.setter
    def TaskIds(self, TaskIds):
        self._TaskIds = TaskIds

    @property
    def Nodes(self):
        r"""拨测节点，如10001，详细地区运营商拨测编号请联系云拨测。
        :rtype: list of str
        """
        return self._Nodes

    @Nodes.setter
    def Nodes(self, Nodes):
        self._Nodes = Nodes

    @property
    def Interval(self):
        r"""拨测间隔，如30，单位为分钟。
        :rtype: int
        """
        return self._Interval

    @Interval.setter
    def Interval(self, Interval):
        self._Interval = Interval

    @property
    def Parameters(self):
        r"""拨测参数，详细参数配置可参考云拨测官网文档。
        :rtype: str
        """
        return self._Parameters

    @Parameters.setter
    def Parameters(self, Parameters):
        self._Parameters = Parameters

    @property
    def Cron(self):
        r"""定时任务cron表达式
        :rtype: str
        """
        return self._Cron

    @Cron.setter
    def Cron(self, Cron):
        self._Cron = Cron

    @property
    def ResourceIDs(self):
        r"""预付费套餐id
需要与taskId对应
        :rtype: list of str
        """
        return self._ResourceIDs

    @ResourceIDs.setter
    def ResourceIDs(self, ResourceIDs):
        self._ResourceIDs = ResourceIDs

    @property
    def NodeIpType(self):
        r"""拨测节点的IP类型，0-不限，1-IPv4，2-IPv6
        :rtype: int
        """
        return self._NodeIpType

    @NodeIpType.setter
    def NodeIpType(self, NodeIpType):
        self._NodeIpType = NodeIpType

    @property
    def BatchTasks(self):
        r"""批量任务名-地址
        :rtype: list of ProbeTaskBasicConfiguration
        """
        return self._BatchTasks

    @BatchTasks.setter
    def BatchTasks(self, BatchTasks):
        self._BatchTasks = BatchTasks


    def _deserialize(self, params):
        self._TaskIds = params.get("TaskIds")
        self._Nodes = params.get("Nodes")
        self._Interval = params.get("Interval")
        self._Parameters = params.get("Parameters")
        self._Cron = params.get("Cron")
        self._ResourceIDs = params.get("ResourceIDs")
        self._NodeIpType = params.get("NodeIpType")
        if params.get("BatchTasks") is not None:
            self._BatchTasks = []
            for item in params.get("BatchTasks"):
                obj = ProbeTaskBasicConfiguration()
                obj._deserialize(item)
                self._BatchTasks.append(obj)
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class UpdateProbeTaskConfigurationListResponse(AbstractModel):
    r"""UpdateProbeTaskConfigurationList返回参数结构体

    """

    def __init__(self):
        r"""
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._RequestId = None

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._RequestId = params.get("RequestId")