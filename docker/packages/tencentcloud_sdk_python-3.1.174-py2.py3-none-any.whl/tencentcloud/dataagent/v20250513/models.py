# -*- coding: utf8 -*-
# Copyright (c) 2017-2025 Tencent. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import warnings

from tencentcloud.common.abstract_model import AbstractModel


class AddChunkRequest(AbstractModel):
    r"""AddChunk请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceId: 实例ID
        :type InstanceId: str
        :param _FileId: 文件ID
        :type FileId: str
        :param _BeforeChunkId: 新增chunk的后面一个ChunkID。如果是空就是插到队尾。插入位置的下一个 chunkId。如果插到最前面，传入原切片的第一个。
        :type BeforeChunkId: str
        :param _InsertPos: 显式指定的位置,实际的位置。从 0 开始计算。0 代表插到最前面，chunk total 代表插到最后面。
        :type InsertPos: int
        :param _Content: chunk内容
        :type Content: str
        :param _AfterChunkId: 新 Chunk 插入到目标 Chunk ​之后的位置。插入位置的上一个 chunkId
        :type AfterChunkId: str
        :param _KnowledgeBaseId: 知识库id
        :type KnowledgeBaseId: str
        """
        self._InstanceId = None
        self._FileId = None
        self._BeforeChunkId = None
        self._InsertPos = None
        self._Content = None
        self._AfterChunkId = None
        self._KnowledgeBaseId = None

    @property
    def InstanceId(self):
        r"""实例ID
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId

    @property
    def FileId(self):
        r"""文件ID
        :rtype: str
        """
        return self._FileId

    @FileId.setter
    def FileId(self, FileId):
        self._FileId = FileId

    @property
    def BeforeChunkId(self):
        r"""新增chunk的后面一个ChunkID。如果是空就是插到队尾。插入位置的下一个 chunkId。如果插到最前面，传入原切片的第一个。
        :rtype: str
        """
        return self._BeforeChunkId

    @BeforeChunkId.setter
    def BeforeChunkId(self, BeforeChunkId):
        self._BeforeChunkId = BeforeChunkId

    @property
    def InsertPos(self):
        r"""显式指定的位置,实际的位置。从 0 开始计算。0 代表插到最前面，chunk total 代表插到最后面。
        :rtype: int
        """
        return self._InsertPos

    @InsertPos.setter
    def InsertPos(self, InsertPos):
        self._InsertPos = InsertPos

    @property
    def Content(self):
        r"""chunk内容
        :rtype: str
        """
        return self._Content

    @Content.setter
    def Content(self, Content):
        self._Content = Content

    @property
    def AfterChunkId(self):
        r"""新 Chunk 插入到目标 Chunk ​之后的位置。插入位置的上一个 chunkId
        :rtype: str
        """
        return self._AfterChunkId

    @AfterChunkId.setter
    def AfterChunkId(self, AfterChunkId):
        self._AfterChunkId = AfterChunkId

    @property
    def KnowledgeBaseId(self):
        r"""知识库id
        :rtype: str
        """
        return self._KnowledgeBaseId

    @KnowledgeBaseId.setter
    def KnowledgeBaseId(self, KnowledgeBaseId):
        self._KnowledgeBaseId = KnowledgeBaseId


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        self._FileId = params.get("FileId")
        self._BeforeChunkId = params.get("BeforeChunkId")
        self._InsertPos = params.get("InsertPos")
        self._Content = params.get("Content")
        self._AfterChunkId = params.get("AfterChunkId")
        self._KnowledgeBaseId = params.get("KnowledgeBaseId")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class AddChunkResponse(AbstractModel):
    r"""AddChunk返回参数结构体

    """

    def __init__(self):
        r"""
        :param _ChunkId: 新增的ChunkId
        :type ChunkId: str
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._ChunkId = None
        self._RequestId = None

    @property
    def ChunkId(self):
        r"""新增的ChunkId
        :rtype: str
        """
        return self._ChunkId

    @ChunkId.setter
    def ChunkId(self, ChunkId):
        self._ChunkId = ChunkId

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._ChunkId = params.get("ChunkId")
        self._RequestId = params.get("RequestId")


class AppendDocument(AbstractModel):
    r"""追加文件

    """

    def __init__(self):
        r"""
        :param _FileName: <p>文件名称</p>
        :type FileName: str
        :param _FileId: <p>文件id</p>
        :type FileId: str
        :param _FileUrl: <p>文件url</p>
        :type FileUrl: str
        :param _FileSize: <p>文件大小</p>
        :type FileSize: float
        """
        self._FileName = None
        self._FileId = None
        self._FileUrl = None
        self._FileSize = None

    @property
    def FileName(self):
        r"""<p>文件名称</p>
        :rtype: str
        """
        return self._FileName

    @FileName.setter
    def FileName(self, FileName):
        self._FileName = FileName

    @property
    def FileId(self):
        r"""<p>文件id</p>
        :rtype: str
        """
        return self._FileId

    @FileId.setter
    def FileId(self, FileId):
        self._FileId = FileId

    @property
    def FileUrl(self):
        r"""<p>文件url</p>
        :rtype: str
        """
        return self._FileUrl

    @FileUrl.setter
    def FileUrl(self, FileUrl):
        self._FileUrl = FileUrl

    @property
    def FileSize(self):
        r"""<p>文件大小</p>
        :rtype: float
        """
        return self._FileSize

    @FileSize.setter
    def FileSize(self, FileSize):
        self._FileSize = FileSize


    def _deserialize(self, params):
        self._FileName = params.get("FileName")
        self._FileId = params.get("FileId")
        self._FileUrl = params.get("FileUrl")
        self._FileSize = params.get("FileSize")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class AppendKnowledgeTaskRequest(AbstractModel):
    r"""AppendKnowledgeTask请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceId: <p>实例id</p>
        :type InstanceId: str
        :param _KnowledgeBaseId: <p>知识库id</p>
        :type KnowledgeBaseId: str
        :param _FileId: <p>文件id</p>
        :type FileId: str
        :param _Documents: <p>追加的文档列表</p>
        :type Documents: list of AppendDocument
        """
        self._InstanceId = None
        self._KnowledgeBaseId = None
        self._FileId = None
        self._Documents = None

    @property
    def InstanceId(self):
        r"""<p>实例id</p>
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId

    @property
    def KnowledgeBaseId(self):
        r"""<p>知识库id</p>
        :rtype: str
        """
        return self._KnowledgeBaseId

    @KnowledgeBaseId.setter
    def KnowledgeBaseId(self, KnowledgeBaseId):
        self._KnowledgeBaseId = KnowledgeBaseId

    @property
    def FileId(self):
        r"""<p>文件id</p>
        :rtype: str
        """
        return self._FileId

    @FileId.setter
    def FileId(self, FileId):
        self._FileId = FileId

    @property
    def Documents(self):
        r"""<p>追加的文档列表</p>
        :rtype: list of AppendDocument
        """
        return self._Documents

    @Documents.setter
    def Documents(self, Documents):
        self._Documents = Documents


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        self._KnowledgeBaseId = params.get("KnowledgeBaseId")
        self._FileId = params.get("FileId")
        if params.get("Documents") is not None:
            self._Documents = []
            for item in params.get("Documents"):
                obj = AppendDocument()
                obj._deserialize(item)
                self._Documents.append(obj)
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class AppendKnowledgeTaskResponse(AbstractModel):
    r"""AppendKnowledgeTask返回参数结构体

    """

    def __init__(self):
        r"""
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._RequestId = None

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._RequestId = params.get("RequestId")


class ChatAIRequest(AbstractModel):
    r"""ChatAI请求参数结构体

    """

    def __init__(self):
        r"""
        :param _SessionId: <p>会话ID</p>
        :type SessionId: str
        :param _InstanceId: <p>实例ID</p>
        :type InstanceId: str
        :param _Question: <p>问题内容</p>
        :type Question: str
        :param _Context: <p>上下文</p>
        :type Context: str
        :param _Model: <p>模型</p>
        :type Model: str
        :param _DeepThinking: <p>是否深度思考</p>
        :type DeepThinking: bool
        :param _DataSourceIds: <p>数据源id</p>
        :type DataSourceIds: list of str
        :param _AgentType: <p>agent类型</p>
        :type AgentType: str
        :param _OldRecordId: <p>需要重新生成答案的记录ID</p>
        :type OldRecordId: str
        :param _KnowledgeBaseIds: <p>知识库id列表</p>
        :type KnowledgeBaseIds: list of str
        :param _ArchVersion: <p>版本信息</p>
        :type ArchVersion: str
        """
        self._SessionId = None
        self._InstanceId = None
        self._Question = None
        self._Context = None
        self._Model = None
        self._DeepThinking = None
        self._DataSourceIds = None
        self._AgentType = None
        self._OldRecordId = None
        self._KnowledgeBaseIds = None
        self._ArchVersion = None

    @property
    def SessionId(self):
        r"""<p>会话ID</p>
        :rtype: str
        """
        return self._SessionId

    @SessionId.setter
    def SessionId(self, SessionId):
        self._SessionId = SessionId

    @property
    def InstanceId(self):
        r"""<p>实例ID</p>
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId

    @property
    def Question(self):
        r"""<p>问题内容</p>
        :rtype: str
        """
        return self._Question

    @Question.setter
    def Question(self, Question):
        self._Question = Question

    @property
    def Context(self):
        r"""<p>上下文</p>
        :rtype: str
        """
        return self._Context

    @Context.setter
    def Context(self, Context):
        self._Context = Context

    @property
    def Model(self):
        r"""<p>模型</p>
        :rtype: str
        """
        return self._Model

    @Model.setter
    def Model(self, Model):
        self._Model = Model

    @property
    def DeepThinking(self):
        r"""<p>是否深度思考</p>
        :rtype: bool
        """
        return self._DeepThinking

    @DeepThinking.setter
    def DeepThinking(self, DeepThinking):
        self._DeepThinking = DeepThinking

    @property
    def DataSourceIds(self):
        r"""<p>数据源id</p>
        :rtype: list of str
        """
        return self._DataSourceIds

    @DataSourceIds.setter
    def DataSourceIds(self, DataSourceIds):
        self._DataSourceIds = DataSourceIds

    @property
    def AgentType(self):
        r"""<p>agent类型</p>
        :rtype: str
        """
        return self._AgentType

    @AgentType.setter
    def AgentType(self, AgentType):
        self._AgentType = AgentType

    @property
    def OldRecordId(self):
        r"""<p>需要重新生成答案的记录ID</p>
        :rtype: str
        """
        return self._OldRecordId

    @OldRecordId.setter
    def OldRecordId(self, OldRecordId):
        self._OldRecordId = OldRecordId

    @property
    def KnowledgeBaseIds(self):
        r"""<p>知识库id列表</p>
        :rtype: list of str
        """
        return self._KnowledgeBaseIds

    @KnowledgeBaseIds.setter
    def KnowledgeBaseIds(self, KnowledgeBaseIds):
        self._KnowledgeBaseIds = KnowledgeBaseIds

    @property
    def ArchVersion(self):
        r"""<p>版本信息</p>
        :rtype: str
        """
        return self._ArchVersion

    @ArchVersion.setter
    def ArchVersion(self, ArchVersion):
        self._ArchVersion = ArchVersion


    def _deserialize(self, params):
        self._SessionId = params.get("SessionId")
        self._InstanceId = params.get("InstanceId")
        self._Question = params.get("Question")
        self._Context = params.get("Context")
        self._Model = params.get("Model")
        self._DeepThinking = params.get("DeepThinking")
        self._DataSourceIds = params.get("DataSourceIds")
        self._AgentType = params.get("AgentType")
        self._OldRecordId = params.get("OldRecordId")
        self._KnowledgeBaseIds = params.get("KnowledgeBaseIds")
        self._ArchVersion = params.get("ArchVersion")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ChatAIResponse(AbstractModel):
    r"""ChatAI返回参数结构体

    """

    def __init__(self):
        r"""
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。本接口为流式响应接口，当请求成功时，RequestId 会被放在 HTTP 响应的 Header "X-TC-RequestId" 中。
        :type RequestId: str
        """
        self._RequestId = None

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。本接口为流式响应接口，当请求成功时，RequestId 会被放在 HTTP 响应的 Header "X-TC-RequestId" 中。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._RequestId = params.get("RequestId")


class Chunk(AbstractModel):
    r"""文件分片

    """

    def __init__(self):
        r"""
        :param _Id: <p>切片ID</p>
        :type Id: str
        :param _Content: <p>切片内容</p>
        :type Content: str
        :param _Size: <p>切片的字数</p>
        :type Size: int
        :param _Summary: <p>切片概要</p>
        :type Summary: str
        :param _ChunkSource: <p>分段类型</p><p>枚举值：</p><ul><li>0： 自动分段</li><li>1： 新建分段</li></ul>
        :type ChunkSource: int
        """
        self._Id = None
        self._Content = None
        self._Size = None
        self._Summary = None
        self._ChunkSource = None

    @property
    def Id(self):
        r"""<p>切片ID</p>
        :rtype: str
        """
        return self._Id

    @Id.setter
    def Id(self, Id):
        self._Id = Id

    @property
    def Content(self):
        r"""<p>切片内容</p>
        :rtype: str
        """
        return self._Content

    @Content.setter
    def Content(self, Content):
        self._Content = Content

    @property
    def Size(self):
        r"""<p>切片的字数</p>
        :rtype: int
        """
        return self._Size

    @Size.setter
    def Size(self, Size):
        self._Size = Size

    @property
    def Summary(self):
        r"""<p>切片概要</p>
        :rtype: str
        """
        return self._Summary

    @Summary.setter
    def Summary(self, Summary):
        self._Summary = Summary

    @property
    def ChunkSource(self):
        r"""<p>分段类型</p><p>枚举值：</p><ul><li>0： 自动分段</li><li>1： 新建分段</li></ul>
        :rtype: int
        """
        return self._ChunkSource

    @ChunkSource.setter
    def ChunkSource(self, ChunkSource):
        self._ChunkSource = ChunkSource


    def _deserialize(self, params):
        self._Id = params.get("Id")
        self._Content = params.get("Content")
        self._Size = params.get("Size")
        self._Summary = params.get("Summary")
        self._ChunkSource = params.get("ChunkSource")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ColumnInfo(AbstractModel):
    r"""知识库文档表列信息

    """

    def __init__(self):
        r"""
        :param _Name: 列名称
        :type Name: str
        :param _Type: 列类型：int, bigint, double, date, datetime, string，decimal
        :type Type: str
        :param _Description: 列名称描述
        :type Description: str
        :param _Index: 列索引
        :type Index: int
        :param _OriginalName: 原始字段名称
        :type OriginalName: str
        """
        self._Name = None
        self._Type = None
        self._Description = None
        self._Index = None
        self._OriginalName = None

    @property
    def Name(self):
        r"""列名称
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def Type(self):
        r"""列类型：int, bigint, double, date, datetime, string，decimal
        :rtype: str
        """
        return self._Type

    @Type.setter
    def Type(self, Type):
        self._Type = Type

    @property
    def Description(self):
        r"""列名称描述
        :rtype: str
        """
        return self._Description

    @Description.setter
    def Description(self, Description):
        self._Description = Description

    @property
    def Index(self):
        r"""列索引
        :rtype: int
        """
        return self._Index

    @Index.setter
    def Index(self, Index):
        self._Index = Index

    @property
    def OriginalName(self):
        r"""原始字段名称
        :rtype: str
        """
        return self._OriginalName

    @OriginalName.setter
    def OriginalName(self, OriginalName):
        self._OriginalName = OriginalName


    def _deserialize(self, params):
        self._Name = params.get("Name")
        self._Type = params.get("Type")
        self._Description = params.get("Description")
        self._Index = params.get("Index")
        self._OriginalName = params.get("OriginalName")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class CosFileInfo(AbstractModel):
    r"""cos 文件信息

    """

    def __init__(self):
        r"""
        :param _FileName: 文件名称，包含后缀
        :type FileName: str
        :param _FileType: 文件类型，"PDF", "DOC", "DOCX", "XLS", "XLSX", "PPT", "PPTX", "MD", "TXT", "PNG", "JPG", "JPEG", "CSV"
        :type FileType: str
        :param _UserCosUrl: 用户文件的cosurl
        :type UserCosUrl: str
        """
        self._FileName = None
        self._FileType = None
        self._UserCosUrl = None

    @property
    def FileName(self):
        r"""文件名称，包含后缀
        :rtype: str
        """
        return self._FileName

    @FileName.setter
    def FileName(self, FileName):
        self._FileName = FileName

    @property
    def FileType(self):
        r"""文件类型，"PDF", "DOC", "DOCX", "XLS", "XLSX", "PPT", "PPTX", "MD", "TXT", "PNG", "JPG", "JPEG", "CSV"
        :rtype: str
        """
        return self._FileType

    @FileType.setter
    def FileType(self, FileType):
        self._FileType = FileType

    @property
    def UserCosUrl(self):
        r"""用户文件的cosurl
        :rtype: str
        """
        return self._UserCosUrl

    @UserCosUrl.setter
    def UserCosUrl(self, UserCosUrl):
        self._UserCosUrl = UserCosUrl


    def _deserialize(self, params):
        self._FileName = params.get("FileName")
        self._FileType = params.get("FileType")
        self._UserCosUrl = params.get("UserCosUrl")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class CreateDataAgentSessionRequest(AbstractModel):
    r"""CreateDataAgentSession请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceId: 实例ID
        :type InstanceId: str
        """
        self._InstanceId = None

    @property
    def InstanceId(self):
        r"""实例ID
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class CreateDataAgentSessionResponse(AbstractModel):
    r"""CreateDataAgentSession返回参数结构体

    """

    def __init__(self):
        r"""
        :param _SessionId: 会话
        :type SessionId: str
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._SessionId = None
        self._RequestId = None

    @property
    def SessionId(self):
        r"""会话
        :rtype: str
        """
        return self._SessionId

    @SessionId.setter
    def SessionId(self, SessionId):
        self._SessionId = SessionId

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._SessionId = params.get("SessionId")
        self._RequestId = params.get("RequestId")


class DeleteChunkRequest(AbstractModel):
    r"""DeleteChunk请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceId: 实例ID
        :type InstanceId: str
        :param _FileId: 文件ID
        :type FileId: str
        :param _ChunkIds: 切片ID
        :type ChunkIds: list of str
        :param _KnowledgeBaseId: 知识库id
        :type KnowledgeBaseId: str
        """
        self._InstanceId = None
        self._FileId = None
        self._ChunkIds = None
        self._KnowledgeBaseId = None

    @property
    def InstanceId(self):
        r"""实例ID
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId

    @property
    def FileId(self):
        r"""文件ID
        :rtype: str
        """
        return self._FileId

    @FileId.setter
    def FileId(self, FileId):
        self._FileId = FileId

    @property
    def ChunkIds(self):
        r"""切片ID
        :rtype: list of str
        """
        return self._ChunkIds

    @ChunkIds.setter
    def ChunkIds(self, ChunkIds):
        self._ChunkIds = ChunkIds

    @property
    def KnowledgeBaseId(self):
        r"""知识库id
        :rtype: str
        """
        return self._KnowledgeBaseId

    @KnowledgeBaseId.setter
    def KnowledgeBaseId(self, KnowledgeBaseId):
        self._KnowledgeBaseId = KnowledgeBaseId


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        self._FileId = params.get("FileId")
        self._ChunkIds = params.get("ChunkIds")
        self._KnowledgeBaseId = params.get("KnowledgeBaseId")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DeleteChunkResponse(AbstractModel):
    r"""DeleteChunk返回参数结构体

    """

    def __init__(self):
        r"""
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._RequestId = None

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._RequestId = params.get("RequestId")


class DeleteDataAgentSessionRequest(AbstractModel):
    r"""DeleteDataAgentSession请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceId: 实例ID
        :type InstanceId: str
        :param _SessionId: 会话ID
        :type SessionId: str
        :param _SessionIds: 批量删除 会话id 列表
        :type SessionIds: list of str
        """
        self._InstanceId = None
        self._SessionId = None
        self._SessionIds = None

    @property
    def InstanceId(self):
        r"""实例ID
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId

    @property
    def SessionId(self):
        r"""会话ID
        :rtype: str
        """
        return self._SessionId

    @SessionId.setter
    def SessionId(self, SessionId):
        self._SessionId = SessionId

    @property
    def SessionIds(self):
        r"""批量删除 会话id 列表
        :rtype: list of str
        """
        return self._SessionIds

    @SessionIds.setter
    def SessionIds(self, SessionIds):
        self._SessionIds = SessionIds


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        self._SessionId = params.get("SessionId")
        self._SessionIds = params.get("SessionIds")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DeleteDataAgentSessionResponse(AbstractModel):
    r"""DeleteDataAgentSession返回参数结构体

    """

    def __init__(self):
        r"""
        :param _SessionId: 删除的会话ID
        :type SessionId: str
        :param _SessionIds: 删除的会话ID列表
        :type SessionIds: list of str
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._SessionId = None
        self._SessionIds = None
        self._RequestId = None

    @property
    def SessionId(self):
        r"""删除的会话ID
        :rtype: str
        """
        return self._SessionId

    @SessionId.setter
    def SessionId(self, SessionId):
        self._SessionId = SessionId

    @property
    def SessionIds(self):
        r"""删除的会话ID列表
        :rtype: list of str
        """
        return self._SessionIds

    @SessionIds.setter
    def SessionIds(self, SessionIds):
        self._SessionIds = SessionIds

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._SessionId = params.get("SessionId")
        self._SessionIds = params.get("SessionIds")
        self._RequestId = params.get("RequestId")


class ExecuteAgentApiRequest(AbstractModel):
    r"""ExecuteAgentApi请求参数结构体

    """

    def __init__(self):
        r"""
        :param _RequestPath: <p>参数路径</p>
        :type RequestPath: str
        :param _RequestData: <p>参数值</p>
        :type RequestData: str
        :param _RequestType: <p>post还是get</p><p>枚举值：</p><ul><li>post： post请求</li><li>get： get请求</li></ul>
        :type RequestType: str
        """
        self._RequestPath = None
        self._RequestData = None
        self._RequestType = None

    @property
    def RequestPath(self):
        r"""<p>参数路径</p>
        :rtype: str
        """
        return self._RequestPath

    @RequestPath.setter
    def RequestPath(self, RequestPath):
        self._RequestPath = RequestPath

    @property
    def RequestData(self):
        r"""<p>参数值</p>
        :rtype: str
        """
        return self._RequestData

    @RequestData.setter
    def RequestData(self, RequestData):
        self._RequestData = RequestData

    @property
    def RequestType(self):
        r"""<p>post还是get</p><p>枚举值：</p><ul><li>post： post请求</li><li>get： get请求</li></ul>
        :rtype: str
        """
        return self._RequestType

    @RequestType.setter
    def RequestType(self, RequestType):
        self._RequestType = RequestType


    def _deserialize(self, params):
        self._RequestPath = params.get("RequestPath")
        self._RequestData = params.get("RequestData")
        self._RequestType = params.get("RequestType")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ExecuteAgentApiResponse(AbstractModel):
    r"""ExecuteAgentApi返回参数结构体

    """

    def __init__(self):
        r"""
        :param _RequestPath: <p>请求路径</p>
        :type RequestPath: str
        :param _AgentData: <p>返回的具体指</p>
        :type AgentData: str
        :param _ErrorMsg: <p>错误码信息</p>
        :type ErrorMsg: str
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._RequestPath = None
        self._AgentData = None
        self._ErrorMsg = None
        self._RequestId = None

    @property
    def RequestPath(self):
        r"""<p>请求路径</p>
        :rtype: str
        """
        return self._RequestPath

    @RequestPath.setter
    def RequestPath(self, RequestPath):
        self._RequestPath = RequestPath

    @property
    def AgentData(self):
        r"""<p>返回的具体指</p>
        :rtype: str
        """
        return self._AgentData

    @AgentData.setter
    def AgentData(self, AgentData):
        self._AgentData = AgentData

    @property
    def ErrorMsg(self):
        r"""<p>错误码信息</p>
        :rtype: str
        """
        return self._ErrorMsg

    @ErrorMsg.setter
    def ErrorMsg(self, ErrorMsg):
        self._ErrorMsg = ErrorMsg

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._RequestPath = params.get("RequestPath")
        self._AgentData = params.get("AgentData")
        self._ErrorMsg = params.get("ErrorMsg")
        self._RequestId = params.get("RequestId")


class ExecuteAgentApiV1Request(AbstractModel):
    r"""ExecuteAgentApiV1请求参数结构体

    """

    def __init__(self):
        r"""
        :param _RequestPath: <p>参数路径</p>
        :type RequestPath: str
        :param _RequestType: <p>post还是get</p><p>枚举值：</p><ul><li>post： post请求</li><li>get： get请求</li></ul>
        :type RequestType: str
        """
        self._RequestPath = None
        self._RequestType = None

    @property
    def RequestPath(self):
        r"""<p>参数路径</p>
        :rtype: str
        """
        return self._RequestPath

    @RequestPath.setter
    def RequestPath(self, RequestPath):
        self._RequestPath = RequestPath

    @property
    def RequestType(self):
        r"""<p>post还是get</p><p>枚举值：</p><ul><li>post： post请求</li><li>get： get请求</li></ul>
        :rtype: str
        """
        return self._RequestType

    @RequestType.setter
    def RequestType(self, RequestType):
        self._RequestType = RequestType


    def _deserialize(self, params):
        self._RequestPath = params.get("RequestPath")
        self._RequestType = params.get("RequestType")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ExecuteAgentApiV1Response(AbstractModel):
    r"""ExecuteAgentApiV1返回参数结构体

    """

    def __init__(self):
        r"""
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。本接口为流式响应接口，当请求成功时，RequestId 会被放在 HTTP 响应的 Header "X-TC-RequestId" 中。
        :type RequestId: str
        """
        self._RequestId = None

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。本接口为流式响应接口，当请求成功时，RequestId 会被放在 HTTP 响应的 Header "X-TC-RequestId" 中。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._RequestId = params.get("RequestId")


class FileInfo(AbstractModel):
    r"""知识库文件信息

    """

    def __init__(self):
        r"""
        :param _FileName: <p>文件名称</p>
        :type FileName: str
        :param _FileSize: <p>文件大小，字节</p>
        :type FileSize: float
        :param _Type: <p>文件类型,0=文本,1=表格，默认0</p>
        :type Type: int
        :param _FileId: <p>文件ID</p>
        :type FileId: str
        :param _Status: <p>状态，0：数据处理中  1：可用 -1：错误</p>
        :type Status: int
        :param _CreateUser: <p>操作者</p>
        :type CreateUser: str
        :param _CreateTime: <p>创建时间</p>
        :type CreateTime: str
        :param _UpdateTime: <p>更新时间</p>
        :type UpdateTime: str
        :param _ChunkConfig: <p>分片策略</p>
        :type ChunkConfig: :class:`tencentcloud.dataagent.v20250513.models.KnowledgeTaskConfig`
        :param _Source: <p>文件来源0=unknow,1=user_cos,2=local</p>
        :type Source: int
        :param _FileUrl: <p>文件url</p>
        :type FileUrl: str
        :param _IsShowCase: <p>是否官方示例，0=否，1=是</p>
        :type IsShowCase: int
        :param _DocumentSummary: <p>文档摘要</p>
        :type DocumentSummary: str
        :param _WebUrl: <p>网页地址</p>
        :type WebUrl: str
        :param _Capabilities: <p>文件能力标识列表</p>
        :type Capabilities: list of str
        :param _EnableGraphBuild: <p>0:关闭 1:开启图谱构建（入库时构建图谱），默认0</p>
        :type EnableGraphBuild: int
        :param _EnableTreeBuild: <p>0:关闭 1:开启树构建（入库时构建树），默认0</p>
        :type EnableTreeBuild: int
        :param _GraphBuildStatus: <p>图谱构建状态：null=未启用图谱; 0=待入库; 1=入库中; 2=入库成功; -1=入库失败（仅 EnableGraphBuild=1 时有意义）</p>
        :type GraphBuildStatus: int
        :param _TreeBuildStatus: <p>图谱构建状态：null=未启用图谱; 0=待入库; 1=入库中; 2=入库成功; -1=入库失败（仅 EnableGraphBuild=1 时有意义）</p>
        :type TreeBuildStatus: int
        """
        self._FileName = None
        self._FileSize = None
        self._Type = None
        self._FileId = None
        self._Status = None
        self._CreateUser = None
        self._CreateTime = None
        self._UpdateTime = None
        self._ChunkConfig = None
        self._Source = None
        self._FileUrl = None
        self._IsShowCase = None
        self._DocumentSummary = None
        self._WebUrl = None
        self._Capabilities = None
        self._EnableGraphBuild = None
        self._EnableTreeBuild = None
        self._GraphBuildStatus = None
        self._TreeBuildStatus = None

    @property
    def FileName(self):
        r"""<p>文件名称</p>
        :rtype: str
        """
        return self._FileName

    @FileName.setter
    def FileName(self, FileName):
        self._FileName = FileName

    @property
    def FileSize(self):
        r"""<p>文件大小，字节</p>
        :rtype: float
        """
        return self._FileSize

    @FileSize.setter
    def FileSize(self, FileSize):
        self._FileSize = FileSize

    @property
    def Type(self):
        r"""<p>文件类型,0=文本,1=表格，默认0</p>
        :rtype: int
        """
        return self._Type

    @Type.setter
    def Type(self, Type):
        self._Type = Type

    @property
    def FileId(self):
        r"""<p>文件ID</p>
        :rtype: str
        """
        return self._FileId

    @FileId.setter
    def FileId(self, FileId):
        self._FileId = FileId

    @property
    def Status(self):
        r"""<p>状态，0：数据处理中  1：可用 -1：错误</p>
        :rtype: int
        """
        return self._Status

    @Status.setter
    def Status(self, Status):
        self._Status = Status

    @property
    def CreateUser(self):
        r"""<p>操作者</p>
        :rtype: str
        """
        return self._CreateUser

    @CreateUser.setter
    def CreateUser(self, CreateUser):
        self._CreateUser = CreateUser

    @property
    def CreateTime(self):
        r"""<p>创建时间</p>
        :rtype: str
        """
        return self._CreateTime

    @CreateTime.setter
    def CreateTime(self, CreateTime):
        self._CreateTime = CreateTime

    @property
    def UpdateTime(self):
        r"""<p>更新时间</p>
        :rtype: str
        """
        return self._UpdateTime

    @UpdateTime.setter
    def UpdateTime(self, UpdateTime):
        self._UpdateTime = UpdateTime

    @property
    def ChunkConfig(self):
        r"""<p>分片策略</p>
        :rtype: :class:`tencentcloud.dataagent.v20250513.models.KnowledgeTaskConfig`
        """
        return self._ChunkConfig

    @ChunkConfig.setter
    def ChunkConfig(self, ChunkConfig):
        self._ChunkConfig = ChunkConfig

    @property
    def Source(self):
        r"""<p>文件来源0=unknow,1=user_cos,2=local</p>
        :rtype: int
        """
        return self._Source

    @Source.setter
    def Source(self, Source):
        self._Source = Source

    @property
    def FileUrl(self):
        r"""<p>文件url</p>
        :rtype: str
        """
        return self._FileUrl

    @FileUrl.setter
    def FileUrl(self, FileUrl):
        self._FileUrl = FileUrl

    @property
    def IsShowCase(self):
        r"""<p>是否官方示例，0=否，1=是</p>
        :rtype: int
        """
        return self._IsShowCase

    @IsShowCase.setter
    def IsShowCase(self, IsShowCase):
        self._IsShowCase = IsShowCase

    @property
    def DocumentSummary(self):
        r"""<p>文档摘要</p>
        :rtype: str
        """
        return self._DocumentSummary

    @DocumentSummary.setter
    def DocumentSummary(self, DocumentSummary):
        self._DocumentSummary = DocumentSummary

    @property
    def WebUrl(self):
        r"""<p>网页地址</p>
        :rtype: str
        """
        return self._WebUrl

    @WebUrl.setter
    def WebUrl(self, WebUrl):
        self._WebUrl = WebUrl

    @property
    def Capabilities(self):
        r"""<p>文件能力标识列表</p>
        :rtype: list of str
        """
        return self._Capabilities

    @Capabilities.setter
    def Capabilities(self, Capabilities):
        self._Capabilities = Capabilities

    @property
    def EnableGraphBuild(self):
        r"""<p>0:关闭 1:开启图谱构建（入库时构建图谱），默认0</p>
        :rtype: int
        """
        return self._EnableGraphBuild

    @EnableGraphBuild.setter
    def EnableGraphBuild(self, EnableGraphBuild):
        self._EnableGraphBuild = EnableGraphBuild

    @property
    def EnableTreeBuild(self):
        r"""<p>0:关闭 1:开启树构建（入库时构建树），默认0</p>
        :rtype: int
        """
        return self._EnableTreeBuild

    @EnableTreeBuild.setter
    def EnableTreeBuild(self, EnableTreeBuild):
        self._EnableTreeBuild = EnableTreeBuild

    @property
    def GraphBuildStatus(self):
        r"""<p>图谱构建状态：null=未启用图谱; 0=待入库; 1=入库中; 2=入库成功; -1=入库失败（仅 EnableGraphBuild=1 时有意义）</p>
        :rtype: int
        """
        return self._GraphBuildStatus

    @GraphBuildStatus.setter
    def GraphBuildStatus(self, GraphBuildStatus):
        self._GraphBuildStatus = GraphBuildStatus

    @property
    def TreeBuildStatus(self):
        r"""<p>图谱构建状态：null=未启用图谱; 0=待入库; 1=入库中; 2=入库成功; -1=入库失败（仅 EnableGraphBuild=1 时有意义）</p>
        :rtype: int
        """
        return self._TreeBuildStatus

    @TreeBuildStatus.setter
    def TreeBuildStatus(self, TreeBuildStatus):
        self._TreeBuildStatus = TreeBuildStatus


    def _deserialize(self, params):
        self._FileName = params.get("FileName")
        self._FileSize = params.get("FileSize")
        self._Type = params.get("Type")
        self._FileId = params.get("FileId")
        self._Status = params.get("Status")
        self._CreateUser = params.get("CreateUser")
        self._CreateTime = params.get("CreateTime")
        self._UpdateTime = params.get("UpdateTime")
        if params.get("ChunkConfig") is not None:
            self._ChunkConfig = KnowledgeTaskConfig()
            self._ChunkConfig._deserialize(params.get("ChunkConfig"))
        self._Source = params.get("Source")
        self._FileUrl = params.get("FileUrl")
        self._IsShowCase = params.get("IsShowCase")
        self._DocumentSummary = params.get("DocumentSummary")
        self._WebUrl = params.get("WebUrl")
        self._Capabilities = params.get("Capabilities")
        self._EnableGraphBuild = params.get("EnableGraphBuild")
        self._EnableTreeBuild = params.get("EnableTreeBuild")
        self._GraphBuildStatus = params.get("GraphBuildStatus")
        self._TreeBuildStatus = params.get("TreeBuildStatus")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class FileTaskStatus(AbstractModel):
    r"""文件任务状态

    """

    def __init__(self):
        r"""
        :param _FileId: <p>文件id</p>
        :type FileId: str
        :param _Status: <p>状态</p><p>枚举值：</p><ul><li>0： 处理中</li><li>1： 可用</li><li>-1： 错误</li></ul>
        :type Status: int
        :param _IsTerminated: <p>是否已拉取过状态</p><p>枚举值：</p><ul><li>0： 未被拉取过状态</li><li>1： 已被拉取过状态</li></ul>
        :type IsTerminated: int
        :param _ErrorMsg: <p>错误信息，状态-1时不为空</p>
        :type ErrorMsg: str
        """
        self._FileId = None
        self._Status = None
        self._IsTerminated = None
        self._ErrorMsg = None

    @property
    def FileId(self):
        r"""<p>文件id</p>
        :rtype: str
        """
        return self._FileId

    @FileId.setter
    def FileId(self, FileId):
        self._FileId = FileId

    @property
    def Status(self):
        r"""<p>状态</p><p>枚举值：</p><ul><li>0： 处理中</li><li>1： 可用</li><li>-1： 错误</li></ul>
        :rtype: int
        """
        return self._Status

    @Status.setter
    def Status(self, Status):
        self._Status = Status

    @property
    def IsTerminated(self):
        r"""<p>是否已拉取过状态</p><p>枚举值：</p><ul><li>0： 未被拉取过状态</li><li>1： 已被拉取过状态</li></ul>
        :rtype: int
        """
        return self._IsTerminated

    @IsTerminated.setter
    def IsTerminated(self, IsTerminated):
        self._IsTerminated = IsTerminated

    @property
    def ErrorMsg(self):
        r"""<p>错误信息，状态-1时不为空</p>
        :rtype: str
        """
        return self._ErrorMsg

    @ErrorMsg.setter
    def ErrorMsg(self, ErrorMsg):
        self._ErrorMsg = ErrorMsg


    def _deserialize(self, params):
        self._FileId = params.get("FileId")
        self._Status = params.get("Status")
        self._IsTerminated = params.get("IsTerminated")
        self._ErrorMsg = params.get("ErrorMsg")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class GetJobsByKnowledgeBaseIdRequest(AbstractModel):
    r"""GetJobsByKnowledgeBaseId请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceId: 实例ID
        :type InstanceId: str
        :param _KnowledgeBaseId: 知识库id
        :type KnowledgeBaseId: str
        """
        self._InstanceId = None
        self._KnowledgeBaseId = None

    @property
    def InstanceId(self):
        r"""实例ID
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId

    @property
    def KnowledgeBaseId(self):
        r"""知识库id
        :rtype: str
        """
        return self._KnowledgeBaseId

    @KnowledgeBaseId.setter
    def KnowledgeBaseId(self, KnowledgeBaseId):
        self._KnowledgeBaseId = KnowledgeBaseId


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        self._KnowledgeBaseId = params.get("KnowledgeBaseId")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class GetJobsByKnowledgeBaseIdResponse(AbstractModel):
    r"""GetJobsByKnowledgeBaseId返回参数结构体

    """

    def __init__(self):
        r"""
        :param _Jobs: 任务列表详情
        :type Jobs: list of UploadJob
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._Jobs = None
        self._RequestId = None

    @property
    def Jobs(self):
        r"""任务列表详情
        :rtype: list of UploadJob
        """
        return self._Jobs

    @Jobs.setter
    def Jobs(self, Jobs):
        self._Jobs = Jobs

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("Jobs") is not None:
            self._Jobs = []
            for item in params.get("Jobs"):
                obj = UploadJob()
                obj._deserialize(item)
                self._Jobs.append(obj)
        self._RequestId = params.get("RequestId")


class GetKnowledgeBaseFileListRequest(AbstractModel):
    r"""GetKnowledgeBaseFileList请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceId: 实例id
        :type InstanceId: str
        :param _Page: 默认 1 表示第一页，可以不填
        :type Page: int
        :param _PageSize: 默认 10 一页展示 10 条，可以不填
        :type PageSize: int
        :param _KnowledgeBaseId: 知识库id
        :type KnowledgeBaseId: str
        """
        self._InstanceId = None
        self._Page = None
        self._PageSize = None
        self._KnowledgeBaseId = None

    @property
    def InstanceId(self):
        r"""实例id
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId

    @property
    def Page(self):
        r"""默认 1 表示第一页，可以不填
        :rtype: int
        """
        return self._Page

    @Page.setter
    def Page(self, Page):
        self._Page = Page

    @property
    def PageSize(self):
        r"""默认 10 一页展示 10 条，可以不填
        :rtype: int
        """
        return self._PageSize

    @PageSize.setter
    def PageSize(self, PageSize):
        self._PageSize = PageSize

    @property
    def KnowledgeBaseId(self):
        r"""知识库id
        :rtype: str
        """
        return self._KnowledgeBaseId

    @KnowledgeBaseId.setter
    def KnowledgeBaseId(self, KnowledgeBaseId):
        self._KnowledgeBaseId = KnowledgeBaseId


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        self._Page = params.get("Page")
        self._PageSize = params.get("PageSize")
        self._KnowledgeBaseId = params.get("KnowledgeBaseId")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class GetKnowledgeBaseFileListResponse(AbstractModel):
    r"""GetKnowledgeBaseFileList返回参数结构体

    """

    def __init__(self):
        r"""
        :param _FileList: 文件信息列表
        :type FileList: list of FileInfo
        :param _Total: 文件信息总数
        :type Total: int
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._FileList = None
        self._Total = None
        self._RequestId = None

    @property
    def FileList(self):
        r"""文件信息列表
        :rtype: list of FileInfo
        """
        return self._FileList

    @FileList.setter
    def FileList(self, FileList):
        self._FileList = FileList

    @property
    def Total(self):
        r"""文件信息总数
        :rtype: int
        """
        return self._Total

    @Total.setter
    def Total(self, Total):
        self._Total = Total

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("FileList") is not None:
            self._FileList = []
            for item in params.get("FileList"):
                obj = FileInfo()
                obj._deserialize(item)
                self._FileList.append(obj)
        self._Total = params.get("Total")
        self._RequestId = params.get("RequestId")


class GetKnowledgeBaseListRequest(AbstractModel):
    r"""GetKnowledgeBaseList请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceId: 实例id
        :type InstanceId: str
        """
        self._InstanceId = None

    @property
    def InstanceId(self):
        r"""实例id
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class GetKnowledgeBaseListResponse(AbstractModel):
    r"""GetKnowledgeBaseList返回参数结构体

    """

    def __init__(self):
        r"""
        :param _KnowledgeBaseList: 用户实例所有知识库列表
        :type KnowledgeBaseList: list of KnowledgeBase
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._KnowledgeBaseList = None
        self._RequestId = None

    @property
    def KnowledgeBaseList(self):
        r"""用户实例所有知识库列表
        :rtype: list of KnowledgeBase
        """
        return self._KnowledgeBaseList

    @KnowledgeBaseList.setter
    def KnowledgeBaseList(self, KnowledgeBaseList):
        self._KnowledgeBaseList = KnowledgeBaseList

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("KnowledgeBaseList") is not None:
            self._KnowledgeBaseList = []
            for item in params.get("KnowledgeBaseList"):
                obj = KnowledgeBase()
                obj._deserialize(item)
                self._KnowledgeBaseList.append(obj)
        self._RequestId = params.get("RequestId")


class GetUploadJobDetailsRequest(AbstractModel):
    r"""GetUploadJobDetails请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceId: 实例ID
        :type InstanceId: str
        :param _JobId: 任务id
        :type JobId: str
        """
        self._InstanceId = None
        self._JobId = None

    @property
    def InstanceId(self):
        r"""实例ID
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId

    @property
    def JobId(self):
        r"""任务id
        :rtype: str
        """
        return self._JobId

    @JobId.setter
    def JobId(self, JobId):
        self._JobId = JobId


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        self._JobId = params.get("JobId")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class GetUploadJobDetailsResponse(AbstractModel):
    r"""GetUploadJobDetails返回参数结构体

    """

    def __init__(self):
        r"""
        :param _Job: 任务详情
        :type Job: :class:`tencentcloud.dataagent.v20250513.models.UploadJob`
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._Job = None
        self._RequestId = None

    @property
    def Job(self):
        r"""任务详情
        :rtype: :class:`tencentcloud.dataagent.v20250513.models.UploadJob`
        """
        return self._Job

    @Job.setter
    def Job(self, Job):
        self._Job = Job

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("Job") is not None:
            self._Job = UploadJob()
            self._Job._deserialize(params.get("Job"))
        self._RequestId = params.get("RequestId")


class GetUserInstanceListRequest(AbstractModel):
    r"""GetUserInstanceList请求参数结构体

    """


class GetUserInstanceListResponse(AbstractModel):
    r"""GetUserInstanceList返回参数结构体

    """

    def __init__(self):
        r"""
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._RequestId = None

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._RequestId = params.get("RequestId")


class KnowledgeBase(AbstractModel):
    r"""知识库信息

    """

    def __init__(self):
        r"""
        :param _KnowledgeBaseId: <p>知识库id</p>
        :type KnowledgeBaseId: str
        :param _KnowledgeBaseName: <p>知识库名称</p>
        :type KnowledgeBaseName: str
        :param _KnowledgeBaseDesc: <p>知识库描述</p>
        :type KnowledgeBaseDesc: str
        :param _Creator: <p>创建者subuin</p>
        :type Creator: str
        :param _CreateTime: <p>创建时间</p>
        :type CreateTime: str
        :param _FileNum: <p>文件数量</p>
        :type FileNum: int
        :param _DatasourceIds: <p>知识库关联的数据库列表，目前是只绑定一个数据源，数组预留拓展</p>
        :type DatasourceIds: list of str
        :param _Config: <p>知识库任务配置</p>
        :type Config: :class:`tencentcloud.dataagent.v20250513.models.KnowledgeTaskConfig`
        """
        self._KnowledgeBaseId = None
        self._KnowledgeBaseName = None
        self._KnowledgeBaseDesc = None
        self._Creator = None
        self._CreateTime = None
        self._FileNum = None
        self._DatasourceIds = None
        self._Config = None

    @property
    def KnowledgeBaseId(self):
        r"""<p>知识库id</p>
        :rtype: str
        """
        return self._KnowledgeBaseId

    @KnowledgeBaseId.setter
    def KnowledgeBaseId(self, KnowledgeBaseId):
        self._KnowledgeBaseId = KnowledgeBaseId

    @property
    def KnowledgeBaseName(self):
        r"""<p>知识库名称</p>
        :rtype: str
        """
        return self._KnowledgeBaseName

    @KnowledgeBaseName.setter
    def KnowledgeBaseName(self, KnowledgeBaseName):
        self._KnowledgeBaseName = KnowledgeBaseName

    @property
    def KnowledgeBaseDesc(self):
        r"""<p>知识库描述</p>
        :rtype: str
        """
        return self._KnowledgeBaseDesc

    @KnowledgeBaseDesc.setter
    def KnowledgeBaseDesc(self, KnowledgeBaseDesc):
        self._KnowledgeBaseDesc = KnowledgeBaseDesc

    @property
    def Creator(self):
        r"""<p>创建者subuin</p>
        :rtype: str
        """
        return self._Creator

    @Creator.setter
    def Creator(self, Creator):
        self._Creator = Creator

    @property
    def CreateTime(self):
        r"""<p>创建时间</p>
        :rtype: str
        """
        return self._CreateTime

    @CreateTime.setter
    def CreateTime(self, CreateTime):
        self._CreateTime = CreateTime

    @property
    def FileNum(self):
        r"""<p>文件数量</p>
        :rtype: int
        """
        return self._FileNum

    @FileNum.setter
    def FileNum(self, FileNum):
        self._FileNum = FileNum

    @property
    def DatasourceIds(self):
        r"""<p>知识库关联的数据库列表，目前是只绑定一个数据源，数组预留拓展</p>
        :rtype: list of str
        """
        return self._DatasourceIds

    @DatasourceIds.setter
    def DatasourceIds(self, DatasourceIds):
        self._DatasourceIds = DatasourceIds

    @property
    def Config(self):
        r"""<p>知识库任务配置</p>
        :rtype: :class:`tencentcloud.dataagent.v20250513.models.KnowledgeTaskConfig`
        """
        return self._Config

    @Config.setter
    def Config(self, Config):
        self._Config = Config


    def _deserialize(self, params):
        self._KnowledgeBaseId = params.get("KnowledgeBaseId")
        self._KnowledgeBaseName = params.get("KnowledgeBaseName")
        self._KnowledgeBaseDesc = params.get("KnowledgeBaseDesc")
        self._Creator = params.get("Creator")
        self._CreateTime = params.get("CreateTime")
        self._FileNum = params.get("FileNum")
        self._DatasourceIds = params.get("DatasourceIds")
        if params.get("Config") is not None:
            self._Config = KnowledgeTaskConfig()
            self._Config._deserialize(params.get("Config"))
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class KnowledgeTaskConfig(AbstractModel):
    r"""任务配置

    """

    def __init__(self):
        r"""
        :param _ChunkType: <p>切片类型  0:自定义切片，1：智能切片</p>
        :type ChunkType: int
        :param _MaxChunkSize: <p>/智能切片：最小值 1000，默认 4800 自定义切片：正整数即可,默认值 1000</p>
        :type MaxChunkSize: int
        :param _Delimiters: <p>切片分隔符,自定义切片使用：默认值为：[&quot;\n\n&quot;, &quot;\n&quot;, &quot;。&quot;, &quot;！&quot;, &quot;？&quot;, &quot;，&quot;, &quot;&quot;]</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type Delimiters: list of str
        :param _ChunkOverlap: <p>自定义切片使用:默认0 可重叠字符长度</p>
        :type ChunkOverlap: int
        :param _Columns: <p>表格类文档解析</p>
        :type Columns: list of ColumnInfo
        :param _Indexes: <p>带检索的索引列表</p>
        :type Indexes: list of int
        :param _GenDocSummary: <p>0：不生成文档摘要，1：生成文档概要。默认0，当取1时，GenParaSummary必须也为1</p>
        :type GenDocSummary: int
        :param _GenParaSummary: <p>0：不生成段落摘要，1：生成段落概要。默认0</p>
        :type GenParaSummary: int
        :param _EnableImageUnderstanding: <p>0：不开启图片理解，1：开启图片理解。默认1</p><p>取值范围：[1, 10000]</p><p>默认值：1</p>
        :type EnableImageUnderstanding: int
        :param _EnableExtractDb: <p>是否开启表格结构化提取</p><p>枚举值：</p><ul><li>0： 不开启表格提取</li><li>1： 开启表格提取</li></ul><p>默认值：1</p>
        :type EnableExtractDb: int
        :param _EnableGraphBuild: <p>0:关闭 1:开启图谱构建（入库时），默认0</p>
        :type EnableGraphBuild: int
        :param _EnableTreeBuild: <p>0:关闭 1:开启树构建（入库时），默认0</p>
        :type EnableTreeBuild: int
        """
        self._ChunkType = None
        self._MaxChunkSize = None
        self._Delimiters = None
        self._ChunkOverlap = None
        self._Columns = None
        self._Indexes = None
        self._GenDocSummary = None
        self._GenParaSummary = None
        self._EnableImageUnderstanding = None
        self._EnableExtractDb = None
        self._EnableGraphBuild = None
        self._EnableTreeBuild = None

    @property
    def ChunkType(self):
        r"""<p>切片类型  0:自定义切片，1：智能切片</p>
        :rtype: int
        """
        return self._ChunkType

    @ChunkType.setter
    def ChunkType(self, ChunkType):
        self._ChunkType = ChunkType

    @property
    def MaxChunkSize(self):
        r"""<p>/智能切片：最小值 1000，默认 4800 自定义切片：正整数即可,默认值 1000</p>
        :rtype: int
        """
        return self._MaxChunkSize

    @MaxChunkSize.setter
    def MaxChunkSize(self, MaxChunkSize):
        self._MaxChunkSize = MaxChunkSize

    @property
    def Delimiters(self):
        r"""<p>切片分隔符,自定义切片使用：默认值为：[&quot;\n\n&quot;, &quot;\n&quot;, &quot;。&quot;, &quot;！&quot;, &quot;？&quot;, &quot;，&quot;, &quot;&quot;]</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of str
        """
        return self._Delimiters

    @Delimiters.setter
    def Delimiters(self, Delimiters):
        self._Delimiters = Delimiters

    @property
    def ChunkOverlap(self):
        r"""<p>自定义切片使用:默认0 可重叠字符长度</p>
        :rtype: int
        """
        return self._ChunkOverlap

    @ChunkOverlap.setter
    def ChunkOverlap(self, ChunkOverlap):
        self._ChunkOverlap = ChunkOverlap

    @property
    def Columns(self):
        r"""<p>表格类文档解析</p>
        :rtype: list of ColumnInfo
        """
        return self._Columns

    @Columns.setter
    def Columns(self, Columns):
        self._Columns = Columns

    @property
    def Indexes(self):
        r"""<p>带检索的索引列表</p>
        :rtype: list of int
        """
        return self._Indexes

    @Indexes.setter
    def Indexes(self, Indexes):
        self._Indexes = Indexes

    @property
    def GenDocSummary(self):
        r"""<p>0：不生成文档摘要，1：生成文档概要。默认0，当取1时，GenParaSummary必须也为1</p>
        :rtype: int
        """
        return self._GenDocSummary

    @GenDocSummary.setter
    def GenDocSummary(self, GenDocSummary):
        self._GenDocSummary = GenDocSummary

    @property
    def GenParaSummary(self):
        r"""<p>0：不生成段落摘要，1：生成段落概要。默认0</p>
        :rtype: int
        """
        return self._GenParaSummary

    @GenParaSummary.setter
    def GenParaSummary(self, GenParaSummary):
        self._GenParaSummary = GenParaSummary

    @property
    def EnableImageUnderstanding(self):
        r"""<p>0：不开启图片理解，1：开启图片理解。默认1</p><p>取值范围：[1, 10000]</p><p>默认值：1</p>
        :rtype: int
        """
        return self._EnableImageUnderstanding

    @EnableImageUnderstanding.setter
    def EnableImageUnderstanding(self, EnableImageUnderstanding):
        self._EnableImageUnderstanding = EnableImageUnderstanding

    @property
    def EnableExtractDb(self):
        r"""<p>是否开启表格结构化提取</p><p>枚举值：</p><ul><li>0： 不开启表格提取</li><li>1： 开启表格提取</li></ul><p>默认值：1</p>
        :rtype: int
        """
        return self._EnableExtractDb

    @EnableExtractDb.setter
    def EnableExtractDb(self, EnableExtractDb):
        self._EnableExtractDb = EnableExtractDb

    @property
    def EnableGraphBuild(self):
        r"""<p>0:关闭 1:开启图谱构建（入库时），默认0</p>
        :rtype: int
        """
        return self._EnableGraphBuild

    @EnableGraphBuild.setter
    def EnableGraphBuild(self, EnableGraphBuild):
        self._EnableGraphBuild = EnableGraphBuild

    @property
    def EnableTreeBuild(self):
        r"""<p>0:关闭 1:开启树构建（入库时），默认0</p>
        :rtype: int
        """
        return self._EnableTreeBuild

    @EnableTreeBuild.setter
    def EnableTreeBuild(self, EnableTreeBuild):
        self._EnableTreeBuild = EnableTreeBuild


    def _deserialize(self, params):
        self._ChunkType = params.get("ChunkType")
        self._MaxChunkSize = params.get("MaxChunkSize")
        self._Delimiters = params.get("Delimiters")
        self._ChunkOverlap = params.get("ChunkOverlap")
        if params.get("Columns") is not None:
            self._Columns = []
            for item in params.get("Columns"):
                obj = ColumnInfo()
                obj._deserialize(item)
                self._Columns.append(obj)
        self._Indexes = params.get("Indexes")
        self._GenDocSummary = params.get("GenDocSummary")
        self._GenParaSummary = params.get("GenParaSummary")
        self._EnableImageUnderstanding = params.get("EnableImageUnderstanding")
        self._EnableExtractDb = params.get("EnableExtractDb")
        self._EnableGraphBuild = params.get("EnableGraphBuild")
        self._EnableTreeBuild = params.get("EnableTreeBuild")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ModelList(AbstractModel):
    r"""模型详情

    """

    def __init__(self):
        r"""
        :param _Model: <p>模型版本名称</p>
        :type Model: str
        :param _Vendor: <p>模型厂商</p>
        :type Vendor: str
        """
        self._Model = None
        self._Vendor = None

    @property
    def Model(self):
        r"""<p>模型版本名称</p>
        :rtype: str
        """
        return self._Model

    @Model.setter
    def Model(self, Model):
        self._Model = Model

    @property
    def Vendor(self):
        r"""<p>模型厂商</p>
        :rtype: str
        """
        return self._Vendor

    @Vendor.setter
    def Vendor(self, Vendor):
        self._Vendor = Vendor


    def _deserialize(self, params):
        self._Model = params.get("Model")
        self._Vendor = params.get("Vendor")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ModelUserAuthority(AbstractModel):
    r"""用户对象的权限

    """

    def __init__(self):
        r"""
        :param _InstanceId: 实例id
        :type InstanceId: str
        :param _Module: 模块，分为知识库knowledge、数据源datasource、自定义场景scene
        :type Module: str
        :param _CreatorUin: 对象创建者
        :type CreatorUin: str
        :param _ObjectId: 对象id,分为知识库id、数据源id、场景id
        :type ObjectId: str
        :param _UseScope: 作用范围：1仅自己使用，2指定用户，0全员
        :type UseScope: int
        :param _AuthorityUins: 可使用的用户列表
        :type AuthorityUins: list of str
        :param _CreateTime: 创建时间
        :type CreateTime: str
        :param _UpdateTime: 更新时间
        :type UpdateTime: str
        """
        self._InstanceId = None
        self._Module = None
        self._CreatorUin = None
        self._ObjectId = None
        self._UseScope = None
        self._AuthorityUins = None
        self._CreateTime = None
        self._UpdateTime = None

    @property
    def InstanceId(self):
        r"""实例id
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId

    @property
    def Module(self):
        r"""模块，分为知识库knowledge、数据源datasource、自定义场景scene
        :rtype: str
        """
        return self._Module

    @Module.setter
    def Module(self, Module):
        self._Module = Module

    @property
    def CreatorUin(self):
        r"""对象创建者
        :rtype: str
        """
        return self._CreatorUin

    @CreatorUin.setter
    def CreatorUin(self, CreatorUin):
        self._CreatorUin = CreatorUin

    @property
    def ObjectId(self):
        r"""对象id,分为知识库id、数据源id、场景id
        :rtype: str
        """
        return self._ObjectId

    @ObjectId.setter
    def ObjectId(self, ObjectId):
        self._ObjectId = ObjectId

    @property
    def UseScope(self):
        r"""作用范围：1仅自己使用，2指定用户，0全员
        :rtype: int
        """
        return self._UseScope

    @UseScope.setter
    def UseScope(self, UseScope):
        self._UseScope = UseScope

    @property
    def AuthorityUins(self):
        r"""可使用的用户列表
        :rtype: list of str
        """
        return self._AuthorityUins

    @AuthorityUins.setter
    def AuthorityUins(self, AuthorityUins):
        self._AuthorityUins = AuthorityUins

    @property
    def CreateTime(self):
        r"""创建时间
        :rtype: str
        """
        return self._CreateTime

    @CreateTime.setter
    def CreateTime(self, CreateTime):
        self._CreateTime = CreateTime

    @property
    def UpdateTime(self):
        r"""更新时间
        :rtype: str
        """
        return self._UpdateTime

    @UpdateTime.setter
    def UpdateTime(self, UpdateTime):
        self._UpdateTime = UpdateTime


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        self._Module = params.get("Module")
        self._CreatorUin = params.get("CreatorUin")
        self._ObjectId = params.get("ObjectId")
        self._UseScope = params.get("UseScope")
        self._AuthorityUins = params.get("AuthorityUins")
        self._CreateTime = params.get("CreateTime")
        self._UpdateTime = params.get("UpdateTime")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ModifyChunkRequest(AbstractModel):
    r"""ModifyChunk请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceId: <p>实例ID</p>
        :type InstanceId: str
        :param _FileId: <p>文件ID</p>
        :type FileId: str
        :param _ChunkId: <p>切片ID</p>
        :type ChunkId: str
        :param _Content: <p>编辑后的文本</p>
        :type Content: str
        :param _Summary: <p>分段概要</p>
        :type Summary: str
        :param _KnowledgeBaseId: <p>知识库id</p>
        :type KnowledgeBaseId: str
        """
        self._InstanceId = None
        self._FileId = None
        self._ChunkId = None
        self._Content = None
        self._Summary = None
        self._KnowledgeBaseId = None

    @property
    def InstanceId(self):
        r"""<p>实例ID</p>
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId

    @property
    def FileId(self):
        r"""<p>文件ID</p>
        :rtype: str
        """
        return self._FileId

    @FileId.setter
    def FileId(self, FileId):
        self._FileId = FileId

    @property
    def ChunkId(self):
        r"""<p>切片ID</p>
        :rtype: str
        """
        return self._ChunkId

    @ChunkId.setter
    def ChunkId(self, ChunkId):
        self._ChunkId = ChunkId

    @property
    def Content(self):
        r"""<p>编辑后的文本</p>
        :rtype: str
        """
        return self._Content

    @Content.setter
    def Content(self, Content):
        self._Content = Content

    @property
    def Summary(self):
        r"""<p>分段概要</p>
        :rtype: str
        """
        return self._Summary

    @Summary.setter
    def Summary(self, Summary):
        self._Summary = Summary

    @property
    def KnowledgeBaseId(self):
        r"""<p>知识库id</p>
        :rtype: str
        """
        return self._KnowledgeBaseId

    @KnowledgeBaseId.setter
    def KnowledgeBaseId(self, KnowledgeBaseId):
        self._KnowledgeBaseId = KnowledgeBaseId


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        self._FileId = params.get("FileId")
        self._ChunkId = params.get("ChunkId")
        self._Content = params.get("Content")
        self._Summary = params.get("Summary")
        self._KnowledgeBaseId = params.get("KnowledgeBaseId")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ModifyChunkResponse(AbstractModel):
    r"""ModifyChunk返回参数结构体

    """

    def __init__(self):
        r"""
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._RequestId = None

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._RequestId = params.get("RequestId")


class ModifyKnowledgeBaseRequest(AbstractModel):
    r"""ModifyKnowledgeBase请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceId: <p>实例id</p>
        :type InstanceId: str
        :param _OperateType: <p>操作类型：Create，Update，Delete</p>
        :type OperateType: str
        :param _KnowledgeBaseId: <p>知识库id，update和delete时必填</p>
        :type KnowledgeBaseId: str
        :param _KnowledgeBaseName: <p>知识库名称，create和update时必填。只允许字母、数字、汉字、下划线</p>
        :type KnowledgeBaseName: str
        :param _KnowledgeBaseDesc: <p>知识库描述，create和update时必填</p>
        :type KnowledgeBaseDesc: str
        :param _UseScope: <p>1仅自己使用，2指定用户，0全员</p>
        :type UseScope: int
        :param _AuthorityUins: <p>可使用用户列表</p>
        :type AuthorityUins: list of str
        :param _Config: <p>知识库任务配置</p>
        :type Config: :class:`tencentcloud.dataagent.v20250513.models.KnowledgeTaskConfig`
        """
        self._InstanceId = None
        self._OperateType = None
        self._KnowledgeBaseId = None
        self._KnowledgeBaseName = None
        self._KnowledgeBaseDesc = None
        self._UseScope = None
        self._AuthorityUins = None
        self._Config = None

    @property
    def InstanceId(self):
        r"""<p>实例id</p>
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId

    @property
    def OperateType(self):
        r"""<p>操作类型：Create，Update，Delete</p>
        :rtype: str
        """
        return self._OperateType

    @OperateType.setter
    def OperateType(self, OperateType):
        self._OperateType = OperateType

    @property
    def KnowledgeBaseId(self):
        r"""<p>知识库id，update和delete时必填</p>
        :rtype: str
        """
        return self._KnowledgeBaseId

    @KnowledgeBaseId.setter
    def KnowledgeBaseId(self, KnowledgeBaseId):
        self._KnowledgeBaseId = KnowledgeBaseId

    @property
    def KnowledgeBaseName(self):
        r"""<p>知识库名称，create和update时必填。只允许字母、数字、汉字、下划线</p>
        :rtype: str
        """
        return self._KnowledgeBaseName

    @KnowledgeBaseName.setter
    def KnowledgeBaseName(self, KnowledgeBaseName):
        self._KnowledgeBaseName = KnowledgeBaseName

    @property
    def KnowledgeBaseDesc(self):
        r"""<p>知识库描述，create和update时必填</p>
        :rtype: str
        """
        return self._KnowledgeBaseDesc

    @KnowledgeBaseDesc.setter
    def KnowledgeBaseDesc(self, KnowledgeBaseDesc):
        self._KnowledgeBaseDesc = KnowledgeBaseDesc

    @property
    def UseScope(self):
        r"""<p>1仅自己使用，2指定用户，0全员</p>
        :rtype: int
        """
        return self._UseScope

    @UseScope.setter
    def UseScope(self, UseScope):
        self._UseScope = UseScope

    @property
    def AuthorityUins(self):
        r"""<p>可使用用户列表</p>
        :rtype: list of str
        """
        return self._AuthorityUins

    @AuthorityUins.setter
    def AuthorityUins(self, AuthorityUins):
        self._AuthorityUins = AuthorityUins

    @property
    def Config(self):
        r"""<p>知识库任务配置</p>
        :rtype: :class:`tencentcloud.dataagent.v20250513.models.KnowledgeTaskConfig`
        """
        return self._Config

    @Config.setter
    def Config(self, Config):
        self._Config = Config


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        self._OperateType = params.get("OperateType")
        self._KnowledgeBaseId = params.get("KnowledgeBaseId")
        self._KnowledgeBaseName = params.get("KnowledgeBaseName")
        self._KnowledgeBaseDesc = params.get("KnowledgeBaseDesc")
        self._UseScope = params.get("UseScope")
        self._AuthorityUins = params.get("AuthorityUins")
        if params.get("Config") is not None:
            self._Config = KnowledgeTaskConfig()
            self._Config._deserialize(params.get("Config"))
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ModifyKnowledgeBaseResponse(AbstractModel):
    r"""ModifyKnowledgeBase返回参数结构体

    """

    def __init__(self):
        r"""
        :param _KnowledgeBaseId: <p>知识库id</p>
        :type KnowledgeBaseId: str
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._KnowledgeBaseId = None
        self._RequestId = None

    @property
    def KnowledgeBaseId(self):
        r"""<p>知识库id</p>
        :rtype: str
        """
        return self._KnowledgeBaseId

    @KnowledgeBaseId.setter
    def KnowledgeBaseId(self, KnowledgeBaseId):
        self._KnowledgeBaseId = KnowledgeBaseId

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._KnowledgeBaseId = params.get("KnowledgeBaseId")
        self._RequestId = params.get("RequestId")


class ModifyUserAuthorityRequest(AbstractModel):
    r"""ModifyUserAuthority请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceId: 实例ID
        :type InstanceId: str
        :param _Module: 分为知识库knowledge、数据源datasource、自定义场景scene
        :type Module: str
        :param _ObjectId: 对象id,分为知识库id、数据源id、场景id
        :type ObjectId: str
        :param _UseScope: 作用范围：1仅自己使用，2指定用户，0全员
        :type UseScope: int
        :param _AuthorityUins: 可使用的用户列表，UseScope=0/1,取值为[]
        :type AuthorityUins: list of str
        """
        self._InstanceId = None
        self._Module = None
        self._ObjectId = None
        self._UseScope = None
        self._AuthorityUins = None

    @property
    def InstanceId(self):
        r"""实例ID
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId

    @property
    def Module(self):
        r"""分为知识库knowledge、数据源datasource、自定义场景scene
        :rtype: str
        """
        return self._Module

    @Module.setter
    def Module(self, Module):
        self._Module = Module

    @property
    def ObjectId(self):
        r"""对象id,分为知识库id、数据源id、场景id
        :rtype: str
        """
        return self._ObjectId

    @ObjectId.setter
    def ObjectId(self, ObjectId):
        self._ObjectId = ObjectId

    @property
    def UseScope(self):
        r"""作用范围：1仅自己使用，2指定用户，0全员
        :rtype: int
        """
        return self._UseScope

    @UseScope.setter
    def UseScope(self, UseScope):
        self._UseScope = UseScope

    @property
    def AuthorityUins(self):
        r"""可使用的用户列表，UseScope=0/1,取值为[]
        :rtype: list of str
        """
        return self._AuthorityUins

    @AuthorityUins.setter
    def AuthorityUins(self, AuthorityUins):
        self._AuthorityUins = AuthorityUins


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        self._Module = params.get("Module")
        self._ObjectId = params.get("ObjectId")
        self._UseScope = params.get("UseScope")
        self._AuthorityUins = params.get("AuthorityUins")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ModifyUserAuthorityResponse(AbstractModel):
    r"""ModifyUserAuthority返回参数结构体

    """

    def __init__(self):
        r"""
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._RequestId = None

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._RequestId = params.get("RequestId")


class QueryChunkListRequest(AbstractModel):
    r"""QueryChunkList请求参数结构体

    """

    def __init__(self):
        r"""
        :param _Page: <p>表示第一页</p>
        :type Page: int
        :param _PageSize: <p>默认一页展示 10 条</p>
        :type PageSize: int
        :param _KnowledgeBaseId: <p>知识库id</p>
        :type KnowledgeBaseId: str
        """
        self._Page = None
        self._PageSize = None
        self._KnowledgeBaseId = None

    @property
    def Page(self):
        r"""<p>表示第一页</p>
        :rtype: int
        """
        return self._Page

    @Page.setter
    def Page(self, Page):
        self._Page = Page

    @property
    def PageSize(self):
        r"""<p>默认一页展示 10 条</p>
        :rtype: int
        """
        return self._PageSize

    @PageSize.setter
    def PageSize(self, PageSize):
        self._PageSize = PageSize

    @property
    def KnowledgeBaseId(self):
        r"""<p>知识库id</p>
        :rtype: str
        """
        return self._KnowledgeBaseId

    @KnowledgeBaseId.setter
    def KnowledgeBaseId(self, KnowledgeBaseId):
        self._KnowledgeBaseId = KnowledgeBaseId


    def _deserialize(self, params):
        self._Page = params.get("Page")
        self._PageSize = params.get("PageSize")
        self._KnowledgeBaseId = params.get("KnowledgeBaseId")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class QueryChunkListResponse(AbstractModel):
    r"""QueryChunkList返回参数结构体

    """

    def __init__(self):
        r"""
        :param _Total: <p>总数</p>
        :type Total: int
        :param _AutoTotal: <p>文档的自动分段数</p>
        :type AutoTotal: int
        :param _ManualTotal: <p>文档的手动新建分段数</p>
        :type ManualTotal: int
        :param _Chunks: <p>分片信息</p>
        :type Chunks: list of Chunk
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._Total = None
        self._AutoTotal = None
        self._ManualTotal = None
        self._Chunks = None
        self._RequestId = None

    @property
    def Total(self):
        r"""<p>总数</p>
        :rtype: int
        """
        return self._Total

    @Total.setter
    def Total(self, Total):
        self._Total = Total

    @property
    def AutoTotal(self):
        r"""<p>文档的自动分段数</p>
        :rtype: int
        """
        return self._AutoTotal

    @AutoTotal.setter
    def AutoTotal(self, AutoTotal):
        self._AutoTotal = AutoTotal

    @property
    def ManualTotal(self):
        r"""<p>文档的手动新建分段数</p>
        :rtype: int
        """
        return self._ManualTotal

    @ManualTotal.setter
    def ManualTotal(self, ManualTotal):
        self._ManualTotal = ManualTotal

    @property
    def Chunks(self):
        r"""<p>分片信息</p>
        :rtype: list of Chunk
        """
        return self._Chunks

    @Chunks.setter
    def Chunks(self, Chunks):
        self._Chunks = Chunks

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._Total = params.get("Total")
        self._AutoTotal = params.get("AutoTotal")
        self._ManualTotal = params.get("ManualTotal")
        if params.get("Chunks") is not None:
            self._Chunks = []
            for item in params.get("Chunks"):
                obj = Chunk()
                obj._deserialize(item)
                self._Chunks.append(obj)
        self._RequestId = params.get("RequestId")


class QueryKnowledgeTaskRequest(AbstractModel):
    r"""QueryKnowledgeTask请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceId: <p>实例id</p>
        :type InstanceId: str
        :param _KnowledgeBaseId: <p>知识库id</p>
        :type KnowledgeBaseId: str
        :param _FileIds: <p>文件id列表</p>
        :type FileIds: list of str
        """
        self._InstanceId = None
        self._KnowledgeBaseId = None
        self._FileIds = None

    @property
    def InstanceId(self):
        r"""<p>实例id</p>
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId

    @property
    def KnowledgeBaseId(self):
        r"""<p>知识库id</p>
        :rtype: str
        """
        return self._KnowledgeBaseId

    @KnowledgeBaseId.setter
    def KnowledgeBaseId(self, KnowledgeBaseId):
        self._KnowledgeBaseId = KnowledgeBaseId

    @property
    def FileIds(self):
        r"""<p>文件id列表</p>
        :rtype: list of str
        """
        return self._FileIds

    @FileIds.setter
    def FileIds(self, FileIds):
        self._FileIds = FileIds


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        self._KnowledgeBaseId = params.get("KnowledgeBaseId")
        self._FileIds = params.get("FileIds")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class QueryKnowledgeTaskResponse(AbstractModel):
    r"""QueryKnowledgeTask返回参数结构体

    """

    def __init__(self):
        r"""
        :param _FileList: <p>文档任务详情对象</p>
        :type FileList: list of FileTaskStatus
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._FileList = None
        self._RequestId = None

    @property
    def FileList(self):
        r"""<p>文档任务详情对象</p>
        :rtype: list of FileTaskStatus
        """
        return self._FileList

    @FileList.setter
    def FileList(self, FileList):
        self._FileList = FileList

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("FileList") is not None:
            self._FileList = []
            for item in params.get("FileList"):
                obj = FileTaskStatus()
                obj._deserialize(item)
                self._FileList.append(obj)
        self._RequestId = params.get("RequestId")


class QueryModelsRequest(AbstractModel):
    r"""QueryModels请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceId: <p>实例id</p>
        :type InstanceId: str
        """
        self._InstanceId = None

    @property
    def InstanceId(self):
        r"""<p>实例id</p>
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class QueryModelsResponse(AbstractModel):
    r"""QueryModels返回参数结构体

    """

    def __init__(self):
        r"""
        :param _Models: <p>模型列表</p>
        :type Models: list of ModelList
        :param _Status: <p>200成功，500失败</p>
        :type Status: int
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._Models = None
        self._Status = None
        self._RequestId = None

    @property
    def Models(self):
        r"""<p>模型列表</p>
        :rtype: list of ModelList
        """
        return self._Models

    @Models.setter
    def Models(self, Models):
        self._Models = Models

    @property
    def Status(self):
        r"""<p>200成功，500失败</p>
        :rtype: int
        """
        return self._Status

    @Status.setter
    def Status(self, Status):
        self._Status = Status

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("Models") is not None:
            self._Models = []
            for item in params.get("Models"):
                obj = ModelList()
                obj._deserialize(item)
                self._Models.append(obj)
        self._Status = params.get("Status")
        self._RequestId = params.get("RequestId")


class QueryUserAuthorityRequest(AbstractModel):
    r"""QueryUserAuthority请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceId: 实例ID
        :type InstanceId: str
        :param _Module: 分为知识库knowledge、数据源datasource、自定义场景scene
        :type Module: str
        :param _ObjectId: 对象id,分为知识库id、数据源id、场景id
        :type ObjectId: str
        """
        self._InstanceId = None
        self._Module = None
        self._ObjectId = None

    @property
    def InstanceId(self):
        r"""实例ID
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId

    @property
    def Module(self):
        r"""分为知识库knowledge、数据源datasource、自定义场景scene
        :rtype: str
        """
        return self._Module

    @Module.setter
    def Module(self, Module):
        self._Module = Module

    @property
    def ObjectId(self):
        r"""对象id,分为知识库id、数据源id、场景id
        :rtype: str
        """
        return self._ObjectId

    @ObjectId.setter
    def ObjectId(self, ObjectId):
        self._ObjectId = ObjectId


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        self._Module = params.get("Module")
        self._ObjectId = params.get("ObjectId")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class QueryUserAuthorityResponse(AbstractModel):
    r"""QueryUserAuthority返回参数结构体

    """

    def __init__(self):
        r"""
        :param _ModelUserAuthority: 对象权限信息
        :type ModelUserAuthority: :class:`tencentcloud.dataagent.v20250513.models.ModelUserAuthority`
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._ModelUserAuthority = None
        self._RequestId = None

    @property
    def ModelUserAuthority(self):
        r"""对象权限信息
        :rtype: :class:`tencentcloud.dataagent.v20250513.models.ModelUserAuthority`
        """
        return self._ModelUserAuthority

    @ModelUserAuthority.setter
    def ModelUserAuthority(self, ModelUserAuthority):
        self._ModelUserAuthority = ModelUserAuthority

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("ModelUserAuthority") is not None:
            self._ModelUserAuthority = ModelUserAuthority()
            self._ModelUserAuthority._deserialize(params.get("ModelUserAuthority"))
        self._RequestId = params.get("RequestId")


class QueryUserSessionDetailRequest(AbstractModel):
    r"""QueryUserSessionDetail请求参数结构体

    """

    def __init__(self):
        r"""
        :param _SessionId: <p>会话id</p>
        :type SessionId: str
        :param _Limit: <p>分页参数</p>
        :type Limit: int
        :param _Offset: <p>偏移量</p>
        :type Offset: int
        :param _InstanceId: <p>实例id</p>
        :type InstanceId: str
        """
        self._SessionId = None
        self._Limit = None
        self._Offset = None
        self._InstanceId = None

    @property
    def SessionId(self):
        r"""<p>会话id</p>
        :rtype: str
        """
        return self._SessionId

    @SessionId.setter
    def SessionId(self, SessionId):
        self._SessionId = SessionId

    @property
    def Limit(self):
        r"""<p>分页参数</p>
        :rtype: int
        """
        return self._Limit

    @Limit.setter
    def Limit(self, Limit):
        self._Limit = Limit

    @property
    def Offset(self):
        r"""<p>偏移量</p>
        :rtype: int
        """
        return self._Offset

    @Offset.setter
    def Offset(self, Offset):
        self._Offset = Offset

    @property
    def InstanceId(self):
        r"""<p>实例id</p>
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId


    def _deserialize(self, params):
        self._SessionId = params.get("SessionId")
        self._Limit = params.get("Limit")
        self._Offset = params.get("Offset")
        self._InstanceId = params.get("InstanceId")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class QueryUserSessionDetailResponse(AbstractModel):
    r"""QueryUserSessionDetail返回参数结构体

    """

    def __init__(self):
        r"""
        :param _SubAccountUin: <p>用户 Id</p>
        :type SubAccountUin: str
        :param _SessionId: <p>会话id</p>
        :type SessionId: str
        :param _RecordList: <p>会话详情数组</p>
        :type RecordList: list of RecordList
        :param _TotalCount: <p>记录总数</p>
        :type TotalCount: int
        :param _RunRecord: <p>运行中的聊天请求, 返回为json字符串</p>
        :type RunRecord: str
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._SubAccountUin = None
        self._SessionId = None
        self._RecordList = None
        self._TotalCount = None
        self._RunRecord = None
        self._RequestId = None

    @property
    def SubAccountUin(self):
        r"""<p>用户 Id</p>
        :rtype: str
        """
        return self._SubAccountUin

    @SubAccountUin.setter
    def SubAccountUin(self, SubAccountUin):
        self._SubAccountUin = SubAccountUin

    @property
    def SessionId(self):
        r"""<p>会话id</p>
        :rtype: str
        """
        return self._SessionId

    @SessionId.setter
    def SessionId(self, SessionId):
        self._SessionId = SessionId

    @property
    def RecordList(self):
        r"""<p>会话详情数组</p>
        :rtype: list of RecordList
        """
        return self._RecordList

    @RecordList.setter
    def RecordList(self, RecordList):
        self._RecordList = RecordList

    @property
    def TotalCount(self):
        r"""<p>记录总数</p>
        :rtype: int
        """
        return self._TotalCount

    @TotalCount.setter
    def TotalCount(self, TotalCount):
        self._TotalCount = TotalCount

    @property
    def RunRecord(self):
        r"""<p>运行中的聊天请求, 返回为json字符串</p>
        :rtype: str
        """
        return self._RunRecord

    @RunRecord.setter
    def RunRecord(self, RunRecord):
        self._RunRecord = RunRecord

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._SubAccountUin = params.get("SubAccountUin")
        self._SessionId = params.get("SessionId")
        if params.get("RecordList") is not None:
            self._RecordList = []
            for item in params.get("RecordList"):
                obj = RecordList()
                obj._deserialize(item)
                self._RecordList.append(obj)
        self._TotalCount = params.get("TotalCount")
        self._RunRecord = params.get("RunRecord")
        self._RequestId = params.get("RequestId")


class RecordList(AbstractModel):
    r"""记录列表

    """

    def __init__(self):
        r"""
        :param _Context: <p>会话上下文</p>
        :type Context: str
        :param _RecordId: <p>记录id</p>
        :type RecordId: str
        :param _TraceId: <p>追踪id</p>
        :type TraceId: str
        :param _SessionId: <p>会话id</p>
        :type SessionId: str
        :param _Question: <p>问题</p>
        :type Question: str
        :param _Answer: <p>回答</p>
        :type Answer: str
        :param _Feedback: <p>0-否定反馈, 1-肯定反馈</p>
        :type Feedback: int
        :param _ErrorContext: <p>错误信息</p>
        :type ErrorContext: str
        :param _CreateTime: <p>创建时间</p>
        :type CreateTime: str
        :param _UpdateTime: <p>更新时间</p>
        :type UpdateTime: str
        :param _Model: <p>模型信息</p>
        :type Model: str
        """
        self._Context = None
        self._RecordId = None
        self._TraceId = None
        self._SessionId = None
        self._Question = None
        self._Answer = None
        self._Feedback = None
        self._ErrorContext = None
        self._CreateTime = None
        self._UpdateTime = None
        self._Model = None

    @property
    def Context(self):
        r"""<p>会话上下文</p>
        :rtype: str
        """
        return self._Context

    @Context.setter
    def Context(self, Context):
        self._Context = Context

    @property
    def RecordId(self):
        r"""<p>记录id</p>
        :rtype: str
        """
        return self._RecordId

    @RecordId.setter
    def RecordId(self, RecordId):
        self._RecordId = RecordId

    @property
    def TraceId(self):
        r"""<p>追踪id</p>
        :rtype: str
        """
        return self._TraceId

    @TraceId.setter
    def TraceId(self, TraceId):
        self._TraceId = TraceId

    @property
    def SessionId(self):
        r"""<p>会话id</p>
        :rtype: str
        """
        return self._SessionId

    @SessionId.setter
    def SessionId(self, SessionId):
        self._SessionId = SessionId

    @property
    def Question(self):
        r"""<p>问题</p>
        :rtype: str
        """
        return self._Question

    @Question.setter
    def Question(self, Question):
        self._Question = Question

    @property
    def Answer(self):
        r"""<p>回答</p>
        :rtype: str
        """
        return self._Answer

    @Answer.setter
    def Answer(self, Answer):
        self._Answer = Answer

    @property
    def Feedback(self):
        r"""<p>0-否定反馈, 1-肯定反馈</p>
        :rtype: int
        """
        return self._Feedback

    @Feedback.setter
    def Feedback(self, Feedback):
        self._Feedback = Feedback

    @property
    def ErrorContext(self):
        r"""<p>错误信息</p>
        :rtype: str
        """
        return self._ErrorContext

    @ErrorContext.setter
    def ErrorContext(self, ErrorContext):
        self._ErrorContext = ErrorContext

    @property
    def CreateTime(self):
        r"""<p>创建时间</p>
        :rtype: str
        """
        return self._CreateTime

    @CreateTime.setter
    def CreateTime(self, CreateTime):
        self._CreateTime = CreateTime

    @property
    def UpdateTime(self):
        r"""<p>更新时间</p>
        :rtype: str
        """
        return self._UpdateTime

    @UpdateTime.setter
    def UpdateTime(self, UpdateTime):
        self._UpdateTime = UpdateTime

    @property
    def Model(self):
        r"""<p>模型信息</p>
        :rtype: str
        """
        return self._Model

    @Model.setter
    def Model(self, Model):
        self._Model = Model


    def _deserialize(self, params):
        self._Context = params.get("Context")
        self._RecordId = params.get("RecordId")
        self._TraceId = params.get("TraceId")
        self._SessionId = params.get("SessionId")
        self._Question = params.get("Question")
        self._Answer = params.get("Answer")
        self._Feedback = params.get("Feedback")
        self._ErrorContext = params.get("ErrorContext")
        self._CreateTime = params.get("CreateTime")
        self._UpdateTime = params.get("UpdateTime")
        self._Model = params.get("Model")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class StopChatAIRequest(AbstractModel):
    r"""StopChatAI请求参数结构体

    """

    def __init__(self):
        r"""
        :param _SessionId: 会话ID
        :type SessionId: str
        :param _InstanceId: 实例ID
        :type InstanceId: str
        """
        self._SessionId = None
        self._InstanceId = None

    @property
    def SessionId(self):
        r"""会话ID
        :rtype: str
        """
        return self._SessionId

    @SessionId.setter
    def SessionId(self, SessionId):
        self._SessionId = SessionId

    @property
    def InstanceId(self):
        r"""实例ID
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId


    def _deserialize(self, params):
        self._SessionId = params.get("SessionId")
        self._InstanceId = params.get("InstanceId")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class StopChatAIResponse(AbstractModel):
    r"""StopChatAI返回参数结构体

    """

    def __init__(self):
        r"""
        :param _SessionId: 会话
        :type SessionId: str
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._SessionId = None
        self._RequestId = None

    @property
    def SessionId(self):
        r"""会话
        :rtype: str
        """
        return self._SessionId

    @SessionId.setter
    def SessionId(self, SessionId):
        self._SessionId = SessionId

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._SessionId = params.get("SessionId")
        self._RequestId = params.get("RequestId")


class UploadAndCommitFileRequest(AbstractModel):
    r"""UploadAndCommitFile请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceId: 实例id
        :type InstanceId: str
        :param _CosFiles: 上传文件列表
        :type CosFiles: list of CosFileInfo
        :param _KnowledgeBaseId: 知识库id
        :type KnowledgeBaseId: str
        """
        self._InstanceId = None
        self._CosFiles = None
        self._KnowledgeBaseId = None

    @property
    def InstanceId(self):
        r"""实例id
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId

    @property
    def CosFiles(self):
        r"""上传文件列表
        :rtype: list of CosFileInfo
        """
        return self._CosFiles

    @CosFiles.setter
    def CosFiles(self, CosFiles):
        self._CosFiles = CosFiles

    @property
    def KnowledgeBaseId(self):
        r"""知识库id
        :rtype: str
        """
        return self._KnowledgeBaseId

    @KnowledgeBaseId.setter
    def KnowledgeBaseId(self, KnowledgeBaseId):
        self._KnowledgeBaseId = KnowledgeBaseId


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        if params.get("CosFiles") is not None:
            self._CosFiles = []
            for item in params.get("CosFiles"):
                obj = CosFileInfo()
                obj._deserialize(item)
                self._CosFiles.append(obj)
        self._KnowledgeBaseId = params.get("KnowledgeBaseId")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class UploadAndCommitFileResponse(AbstractModel):
    r"""UploadAndCommitFile返回参数结构体

    """

    def __init__(self):
        r"""
        :param _JobId: 上传任务
        :type JobId: str
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._JobId = None
        self._RequestId = None

    @property
    def JobId(self):
        r"""上传任务
        :rtype: str
        """
        return self._JobId

    @JobId.setter
    def JobId(self, JobId):
        self._JobId = JobId

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._JobId = params.get("JobId")
        self._RequestId = params.get("RequestId")


class UploadJob(AbstractModel):
    r"""上传任务

    """

    def __init__(self):
        r"""
        :param _Id: id
        :type Id: int
        :param _JobId: 任务id
        :type JobId: str
        :param _InstanceId: 实例id
        :type InstanceId: str
        :param _KnowledgeBaseId: 知识库id
        :type KnowledgeBaseId: str
        :param _Uin: uin
        :type Uin: str
        :param _SubUin: subuin
        :type SubUin: str
        :param _Status: Pending、FileUploading、
FileParsing、
Success、
Failed 
	
        :type Status: str
        :param _CreateTime: 任务创建时间
        :type CreateTime: str
        :param _UpdateTime: 任务更新时间
        :type UpdateTime: str
        :param _Message: 错误信息
        :type Message: str
        """
        self._Id = None
        self._JobId = None
        self._InstanceId = None
        self._KnowledgeBaseId = None
        self._Uin = None
        self._SubUin = None
        self._Status = None
        self._CreateTime = None
        self._UpdateTime = None
        self._Message = None

    @property
    def Id(self):
        r"""id
        :rtype: int
        """
        return self._Id

    @Id.setter
    def Id(self, Id):
        self._Id = Id

    @property
    def JobId(self):
        r"""任务id
        :rtype: str
        """
        return self._JobId

    @JobId.setter
    def JobId(self, JobId):
        self._JobId = JobId

    @property
    def InstanceId(self):
        r"""实例id
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId

    @property
    def KnowledgeBaseId(self):
        r"""知识库id
        :rtype: str
        """
        return self._KnowledgeBaseId

    @KnowledgeBaseId.setter
    def KnowledgeBaseId(self, KnowledgeBaseId):
        self._KnowledgeBaseId = KnowledgeBaseId

    @property
    def Uin(self):
        r"""uin
        :rtype: str
        """
        return self._Uin

    @Uin.setter
    def Uin(self, Uin):
        self._Uin = Uin

    @property
    def SubUin(self):
        r"""subuin
        :rtype: str
        """
        return self._SubUin

    @SubUin.setter
    def SubUin(self, SubUin):
        self._SubUin = SubUin

    @property
    def Status(self):
        r"""Pending、FileUploading、
FileParsing、
Success、
Failed 
	
        :rtype: str
        """
        return self._Status

    @Status.setter
    def Status(self, Status):
        self._Status = Status

    @property
    def CreateTime(self):
        r"""任务创建时间
        :rtype: str
        """
        return self._CreateTime

    @CreateTime.setter
    def CreateTime(self, CreateTime):
        self._CreateTime = CreateTime

    @property
    def UpdateTime(self):
        r"""任务更新时间
        :rtype: str
        """
        return self._UpdateTime

    @UpdateTime.setter
    def UpdateTime(self, UpdateTime):
        self._UpdateTime = UpdateTime

    @property
    def Message(self):
        r"""错误信息
        :rtype: str
        """
        return self._Message

    @Message.setter
    def Message(self, Message):
        self._Message = Message


    def _deserialize(self, params):
        self._Id = params.get("Id")
        self._JobId = params.get("JobId")
        self._InstanceId = params.get("InstanceId")
        self._KnowledgeBaseId = params.get("KnowledgeBaseId")
        self._Uin = params.get("Uin")
        self._SubUin = params.get("SubUin")
        self._Status = params.get("Status")
        self._CreateTime = params.get("CreateTime")
        self._UpdateTime = params.get("UpdateTime")
        self._Message = params.get("Message")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        