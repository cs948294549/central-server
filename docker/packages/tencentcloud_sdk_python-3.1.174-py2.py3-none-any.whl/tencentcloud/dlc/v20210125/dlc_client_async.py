# -*- coding: utf8 -*-
# Copyright (c) 2017-2025 Tencent. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.



from tencentcloud.common.abstract_client_async import AbstractClient
from tencentcloud.dlc.v20210125 import models
from typing import Dict


class DlcClient(AbstractClient):
    _apiVersion = '2021-01-25'
    _endpoint = 'dlc.tencentcloudapi.com'
    _service = 'dlc'

    async def AddDMSPartitions(
            self,
            request: models.AddDMSPartitionsRequest,
            opts: Dict = None,
    ) -> models.AddDMSPartitionsResponse:
        """
        DMS元数据新增分区
        """
        
        kwargs = {}
        kwargs["action"] = "AddDMSPartitions"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.AddDMSPartitionsResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def AddDeployment(
            self,
            request: models.AddDeploymentRequest,
            opts: Dict = None,
    ) -> models.AddDeploymentResponse:
        """
        为已有推理服务新增部署
        """
        
        kwargs = {}
        kwargs["action"] = "AddDeployment"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.AddDeploymentResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def AddOptimizerEngines(
            self,
            request: models.AddOptimizerEnginesRequest,
            opts: Dict = None,
    ) -> models.AddOptimizerEnginesResponse:
        """
        添加数据优化资源
        """
        
        kwargs = {}
        kwargs["action"] = "AddOptimizerEngines"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.AddOptimizerEnginesResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def AddUsersToWorkGroup(
            self,
            request: models.AddUsersToWorkGroupRequest,
            opts: Dict = None,
    ) -> models.AddUsersToWorkGroupResponse:
        """
        添加用户到工作组
        """
        
        kwargs = {}
        kwargs["action"] = "AddUsersToWorkGroup"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.AddUsersToWorkGroupResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def AlterDMSDatabase(
            self,
            request: models.AlterDMSDatabaseRequest,
            opts: Dict = None,
    ) -> models.AlterDMSDatabaseResponse:
        """
        DMS元数据更新库
        """
        
        kwargs = {}
        kwargs["action"] = "AlterDMSDatabase"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.AlterDMSDatabaseResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def AlterDMSPartition(
            self,
            request: models.AlterDMSPartitionRequest,
            opts: Dict = None,
    ) -> models.AlterDMSPartitionResponse:
        """
        DMS元数据更新分区
        """
        
        kwargs = {}
        kwargs["action"] = "AlterDMSPartition"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.AlterDMSPartitionResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def AlterDMSTable(
            self,
            request: models.AlterDMSTableRequest,
            opts: Dict = None,
    ) -> models.AlterDMSTableResponse:
        """
        DMS元数据更新表
        """
        
        kwargs = {}
        kwargs["action"] = "AlterDMSTable"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.AlterDMSTableResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def AlterTableComment(
            self,
            request: models.AlterTableCommentRequest,
            opts: Dict = None,
    ) -> models.AlterTableCommentResponse:
        """
        修改表备注
        """
        
        kwargs = {}
        kwargs["action"] = "AlterTableComment"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.AlterTableCommentResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def AssignMangedTableProperties(
            self,
            request: models.AssignMangedTablePropertiesRequest,
            opts: Dict = None,
    ) -> models.AssignMangedTablePropertiesResponse:
        """
        分配原生表表属性
        """
        
        kwargs = {}
        kwargs["action"] = "AssignMangedTableProperties"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.AssignMangedTablePropertiesResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def AssociateDatasourceHouse(
            self,
            request: models.AssociateDatasourceHouseRequest,
            opts: Dict = None,
    ) -> models.AssociateDatasourceHouseResponse:
        """
        绑定数据源和队列
        """
        
        kwargs = {}
        kwargs["action"] = "AssociateDatasourceHouse"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.AssociateDatasourceHouseResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def AttachDataMaskPolicy(
            self,
            request: models.AttachDataMaskPolicyRequest,
            opts: Dict = None,
    ) -> models.AttachDataMaskPolicyResponse:
        """
        绑定数据脱敏策略
        """
        
        kwargs = {}
        kwargs["action"] = "AttachDataMaskPolicy"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.AttachDataMaskPolicyResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def AttachUserPolicy(
            self,
            request: models.AttachUserPolicyRequest,
            opts: Dict = None,
    ) -> models.AttachUserPolicyResponse:
        """
        绑定鉴权策略到用户
        """
        
        kwargs = {}
        kwargs["action"] = "AttachUserPolicy"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.AttachUserPolicyResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def AttachWorkGroupPolicy(
            self,
            request: models.AttachWorkGroupPolicyRequest,
            opts: Dict = None,
    ) -> models.AttachWorkGroupPolicyResponse:
        """
        绑定鉴权策略到工作组
        """
        
        kwargs = {}
        kwargs["action"] = "AttachWorkGroupPolicy"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.AttachWorkGroupPolicyResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def BindApiKey(
            self,
            request: models.BindApiKeyRequest,
            opts: Dict = None,
    ) -> models.BindApiKeyResponse:
        """
        绑定 API Key 到推理服务
        """
        
        kwargs = {}
        kwargs["action"] = "BindApiKey"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.BindApiKeyResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def BindWorkGroupsToUser(
            self,
            request: models.BindWorkGroupsToUserRequest,
            opts: Dict = None,
    ) -> models.BindWorkGroupsToUserResponse:
        """
        绑定工作组到用户
        """
        
        kwargs = {}
        kwargs["action"] = "BindWorkGroupsToUser"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.BindWorkGroupsToUserResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CancelNotebookSessionStatement(
            self,
            request: models.CancelNotebookSessionStatementRequest,
            opts: Dict = None,
    ) -> models.CancelNotebookSessionStatementResponse:
        """
        本接口（CancelNotebookSessionStatement）用于取消session中执行的任务
        """
        
        kwargs = {}
        kwargs["action"] = "CancelNotebookSessionStatement"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CancelNotebookSessionStatementResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CancelNotebookSessionStatementBatch(
            self,
            request: models.CancelNotebookSessionStatementBatchRequest,
            opts: Dict = None,
    ) -> models.CancelNotebookSessionStatementBatchResponse:
        """
        本接口（CancelNotebookSessionStatementBatch）用于批量取消Session 中执行的任务
        """
        
        kwargs = {}
        kwargs["action"] = "CancelNotebookSessionStatementBatch"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CancelNotebookSessionStatementBatchResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CancelRayJob(
            self,
            request: models.CancelRayJobRequest,
            opts: Dict = None,
    ) -> models.CancelRayJobResponse:
        """
        根据任务ID取消正在运行的Ray任务
        """
        
        kwargs = {}
        kwargs["action"] = "CancelRayJob"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CancelRayJobResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CancelSparkSessionBatchSQL(
            self,
            request: models.CancelSparkSessionBatchSQLRequest,
            opts: Dict = None,
    ) -> models.CancelSparkSessionBatchSQLResponse:
        """
        本接口（CancelSparkSessionBatchSQL）用于取消Spark SQL批任务。
        """
        
        kwargs = {}
        kwargs["action"] = "CancelSparkSessionBatchSQL"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CancelSparkSessionBatchSQLResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CancelTask(
            self,
            request: models.CancelTaskRequest,
            opts: Dict = None,
    ) -> models.CancelTaskResponse:
        """
        本接口（CancelTask），用于取消任务
        """
        
        kwargs = {}
        kwargs["action"] = "CancelTask"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CancelTaskResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CancelTasks(
            self,
            request: models.CancelTasksRequest,
            opts: Dict = None,
    ) -> models.CancelTasksResponse:
        """
        批量取消任务
        """
        
        kwargs = {}
        kwargs["action"] = "CancelTasks"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CancelTasksResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CancelTrainingJobInstance(
            self,
            request: models.CancelTrainingJobInstanceRequest,
            opts: Dict = None,
    ) -> models.CancelTrainingJobInstanceResponse:
        """
        暂停（取消）实例
        """
        
        kwargs = {}
        kwargs["action"] = "CancelTrainingJobInstance"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CancelTrainingJobInstanceResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CheckApiKeyName(
            self,
            request: models.CheckApiKeyNameRequest,
            opts: Dict = None,
    ) -> models.CheckApiKeyNameResponse:
        """
        检查 API Key 名称是否重复
        """
        
        kwargs = {}
        kwargs["action"] = "CheckApiKeyName"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CheckApiKeyNameResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CheckDataEngineConfigPairsValidity(
            self,
            request: models.CheckDataEngineConfigPairsValidityRequest,
            opts: Dict = None,
    ) -> models.CheckDataEngineConfigPairsValidityResponse:
        """
        本接口（CheckDataEngineConfigPairsValidity）用于检查引擎用户自定义参数的有效性
        """
        
        kwargs = {}
        kwargs["action"] = "CheckDataEngineConfigPairsValidity"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CheckDataEngineConfigPairsValidityResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CheckDataEngineImageCanBeRollback(
            self,
            request: models.CheckDataEngineImageCanBeRollbackRequest,
            opts: Dict = None,
    ) -> models.CheckDataEngineImageCanBeRollbackResponse:
        """
        本接口（CheckDataEngineImageCanBeRollback）用于查看集群是否能回滚。
        """
        
        kwargs = {}
        kwargs["action"] = "CheckDataEngineImageCanBeRollback"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CheckDataEngineImageCanBeRollbackResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CheckDataEngineImageCanBeUpgrade(
            self,
            request: models.CheckDataEngineImageCanBeUpgradeRequest,
            opts: Dict = None,
    ) -> models.CheckDataEngineImageCanBeUpgradeResponse:
        """
        本接口（CheckDataEngineImageCanBeUpgrade）用于查看集群镜像是否能够升级。
        """
        
        kwargs = {}
        kwargs["action"] = "CheckDataEngineImageCanBeUpgrade"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CheckDataEngineImageCanBeUpgradeResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CheckJobSpecName(
            self,
            request: models.CheckJobSpecNameRequest,
            opts: Dict = None,
    ) -> models.CheckJobSpecNameResponse:
        """
        训练作业配置与普通 RayJob 配置共用 job_spec 表及 (appId, name) 唯一命名空间，重名检查统一挂在本接口，供两类前端表单复用
        """
        
        kwargs = {}
        kwargs["action"] = "CheckJobSpecName"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CheckJobSpecNameResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CheckLockMetaData(
            self,
            request: models.CheckLockMetaDataRequest,
            opts: Dict = None,
    ) -> models.CheckLockMetaDataResponse:
        """
        元数据锁检查
        """
        
        kwargs = {}
        kwargs["action"] = "CheckLockMetaData"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CheckLockMetaDataResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CheckModelIdentifier(
            self,
            request: models.CheckModelIdentifierRequest,
            opts: Dict = None,
    ) -> models.CheckModelIdentifierResponse:
        """
        检查模型标识符是否重复
        """
        
        kwargs = {}
        kwargs["action"] = "CheckModelIdentifier"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CheckModelIdentifierResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CheckModifyPartition(
            self,
            request: models.CheckModifyPartitionRequest,
            opts: Dict = None,
    ) -> models.CheckModifyPartitionResponse:
        """
        变配校验：判断用户的目标配置是否可以执行变配。校验逻辑：对于缩容场景（目标值 < 当前值），检查 default 队列的 min 值是否足够承受缩容差值。
        """
        
        kwargs = {}
        kwargs["action"] = "CheckModifyPartition"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CheckModifyPartitionResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CheckQueueName(
            self,
            request: models.CheckQueueNameRequest,
            opts: Dict = None,
    ) -> models.CheckQueueNameResponse:
        """
        资源队列名称合法性检测：校验队列名称是否合法，包括非空校验、格式校验（以小写字母开头，只允许小写字母、数字和连字符，长度1~11）和同分区下重名校验。
        """
        
        kwargs = {}
        kwargs["action"] = "CheckQueueName"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CheckQueueNameResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CheckResourceName(
            self,
            request: models.CheckResourceNameRequest,
            opts: Dict = None,
    ) -> models.CheckResourceNameResponse:
        """
        校验资源名称合法性
        """
        
        kwargs = {}
        kwargs["action"] = "CheckResourceName"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CheckResourceNameResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CheckServiceName(
            self,
            request: models.CheckServiceNameRequest,
            opts: Dict = None,
    ) -> models.CheckServiceNameResponse:
        """
        检查推理服务名称是否重复
        """
        
        kwargs = {}
        kwargs["action"] = "CheckServiceName"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CheckServiceNameResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CopyJobSpec(
            self,
            request: models.CopyJobSpecRequest,
            opts: Dict = None,
    ) -> models.CopyJobSpecResponse:
        """
        复制一份已有的作业配置
        """
        
        kwargs = {}
        kwargs["action"] = "CopyJobSpec"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CopyJobSpecResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateApiKey(
            self,
            request: models.CreateApiKeyRequest,
            opts: Dict = None,
    ) -> models.CreateApiKeyResponse:
        """
        创建 API Key
        """
        
        kwargs = {}
        kwargs["action"] = "CreateApiKey"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateApiKeyResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateBenchmarkTask(
            self,
            request: models.CreateBenchmarkTaskRequest,
            opts: Dict = None,
    ) -> models.CreateBenchmarkTaskResponse:
        """
        创建性能评测任务
        """
        
        kwargs = {}
        kwargs["action"] = "CreateBenchmarkTask"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateBenchmarkTaskResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateCHDFSBindingProduct(
            self,
            request: models.CreateCHDFSBindingProductRequest,
            opts: Dict = None,
    ) -> models.CreateCHDFSBindingProductResponse:
        """
        此接口（CreateCHDFSBindingProduct）用于创建元数据加速桶和产品绑定关系
        """
        
        kwargs = {}
        kwargs["action"] = "CreateCHDFSBindingProduct"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateCHDFSBindingProductResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateClusterGroup(
            self,
            request: models.CreateClusterGroupRequest,
            opts: Dict = None,
    ) -> models.CreateClusterGroupResponse:
        """
        创建集群组
        """
        
        kwargs = {}
        kwargs["action"] = "CreateClusterGroup"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateClusterGroupResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateDMSDatabase(
            self,
            request: models.CreateDMSDatabaseRequest,
            opts: Dict = None,
    ) -> models.CreateDMSDatabaseResponse:
        """
        DMS元数据创建库
        """
        
        kwargs = {}
        kwargs["action"] = "CreateDMSDatabase"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateDMSDatabaseResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateDMSTable(
            self,
            request: models.CreateDMSTableRequest,
            opts: Dict = None,
    ) -> models.CreateDMSTableResponse:
        """
        DMS元数据创建表
        """
        
        kwargs = {}
        kwargs["action"] = "CreateDMSTable"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateDMSTableResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateDataEngine(
            self,
            request: models.CreateDataEngineRequest,
            opts: Dict = None,
    ) -> models.CreateDataEngineResponse:
        """
        为用户创建数据引擎
        """
        
        kwargs = {}
        kwargs["action"] = "CreateDataEngine"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateDataEngineResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateDataMaskStrategy(
            self,
            request: models.CreateDataMaskStrategyRequest,
            opts: Dict = None,
    ) -> models.CreateDataMaskStrategyResponse:
        """
        创建数据脱敏策略
        """
        
        kwargs = {}
        kwargs["action"] = "CreateDataMaskStrategy"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateDataMaskStrategyResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateDatabase(
            self,
            request: models.CreateDatabaseRequest,
            opts: Dict = None,
    ) -> models.CreateDatabaseResponse:
        """
        本接口（CreateDatabase）用于生成建库SQL语句。
        """
        
        kwargs = {}
        kwargs["action"] = "CreateDatabase"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateDatabaseResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateDatasourceConnection(
            self,
            request: models.CreateDatasourceConnectionRequest,
            opts: Dict = None,
    ) -> models.CreateDatasourceConnectionResponse:
        """
        创建数据源
        """
        
        kwargs = {}
        kwargs["action"] = "CreateDatasourceConnection"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateDatasourceConnectionResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateExportTask(
            self,
            request: models.CreateExportTaskRequest,
            opts: Dict = None,
    ) -> models.CreateExportTaskResponse:
        """
        该接口（CreateExportTask）用于创建导出任务
        """
        
        kwargs = {}
        kwargs["action"] = "CreateExportTask"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateExportTaskResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateImportTask(
            self,
            request: models.CreateImportTaskRequest,
            opts: Dict = None,
    ) -> models.CreateImportTaskResponse:
        """
        该接口（CreateImportTask）用于创建导入任务
        """
        
        kwargs = {}
        kwargs["action"] = "CreateImportTask"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateImportTaskResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateInferenceModel(
            self,
            request: models.CreateInferenceModelRequest,
            opts: Dict = None,
    ) -> models.CreateInferenceModelResponse:
        """
        创建推理模型（模型上传）
        """
        
        kwargs = {}
        kwargs["action"] = "CreateInferenceModel"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateInferenceModelResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateInferenceService(
            self,
            request: models.CreateInferenceServiceRequest,
            opts: Dict = None,
    ) -> models.CreateInferenceServiceResponse:
        """
        创建推理服务（含默认部署）
        """
        
        kwargs = {}
        kwargs["action"] = "CreateInferenceService"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateInferenceServiceResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateInternalTable(
            self,
            request: models.CreateInternalTableRequest,
            opts: Dict = None,
    ) -> models.CreateInternalTableResponse:
        """
        创建托管存储内表（该接口已废弃）
        """
        
        kwargs = {}
        kwargs["action"] = "CreateInternalTable"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateInternalTableResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateJobSpec(
            self,
            request: models.CreateJobSpecRequest,
            opts: Dict = None,
    ) -> models.CreateJobSpecResponse:
        """
        创建作业配置
        """
        
        kwargs = {}
        kwargs["action"] = "CreateJobSpec"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateJobSpecResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateLab(
            self,
            request: models.CreateLabRequest,
            opts: Dict = None,
    ) -> models.CreateLabResponse:
        """
        创建实验室
        """
        
        kwargs = {}
        kwargs["action"] = "CreateLab"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateLabResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateMetaDatabase(
            self,
            request: models.CreateMetaDatabaseRequest,
            opts: Dict = None,
    ) -> models.CreateMetaDatabaseResponse:
        """
        本接口（CreateMetaDatabase）用于创建元数据库
        """
        
        kwargs = {}
        kwargs["action"] = "CreateMetaDatabase"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateMetaDatabaseResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateMlflowServer(
            self,
            request: models.CreateMlflowServerRequest,
            opts: Dict = None,
    ) -> models.CreateMlflowServerResponse:
        """
        创建 MlFlow Server
        """
        
        kwargs = {}
        kwargs["action"] = "CreateMlflowServer"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateMlflowServerResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateModelVersion(
            self,
            request: models.CreateModelVersionRequest,
            opts: Dict = None,
    ) -> models.CreateModelVersionResponse:
        """
        创建模型新版本
        """
        
        kwargs = {}
        kwargs["action"] = "CreateModelVersion"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateModelVersionResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateNotebookSession(
            self,
            request: models.CreateNotebookSessionRequest,
            opts: Dict = None,
    ) -> models.CreateNotebookSessionResponse:
        """
        本接口（CreateNotebookSession）用于创建交互式session（notebook）
        """
        
        kwargs = {}
        kwargs["action"] = "CreateNotebookSession"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateNotebookSessionResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateNotebookSessionStatement(
            self,
            request: models.CreateNotebookSessionStatementRequest,
            opts: Dict = None,
    ) -> models.CreateNotebookSessionStatementResponse:
        """
        本接口（CreateNotebookSessionStatement）用于在session中执行代码片段
        """
        
        kwargs = {}
        kwargs["action"] = "CreateNotebookSessionStatement"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateNotebookSessionStatementResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateNotebookSessionStatementSupportBatchSQL(
            self,
            request: models.CreateNotebookSessionStatementSupportBatchSQLRequest,
            opts: Dict = None,
    ) -> models.CreateNotebookSessionStatementSupportBatchSQLResponse:
        """
        本接口（CreateNotebookSessionStatementSupportBatchSQL）用于创建交互式session并执行SQL任务
        """
        
        kwargs = {}
        kwargs["action"] = "CreateNotebookSessionStatementSupportBatchSQL"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateNotebookSessionStatementSupportBatchSQLResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreatePartition(
            self,
            request: models.CreatePartitionRequest,
            opts: Dict = None,
    ) -> models.CreatePartitionResponse:
        """
        新增资源包
        """
        
        kwargs = {}
        kwargs["action"] = "CreatePartition"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreatePartitionResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreatePartitionQueue(
            self,
            request: models.CreatePartitionQueueRequest,
            opts: Dict = None,
    ) -> models.CreatePartitionQueueResponse:
        """
        新增资源队列：在指定分区下创建一个新的资源队列，支持设置队列名称、描述、资源规格列表和队列类型。
        """
        
        kwargs = {}
        kwargs["action"] = "CreatePartitionQueue"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreatePartitionQueueResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateRayCluster(
            self,
            request: models.CreateRayClusterRequest,
            opts: Dict = None,
    ) -> models.CreateRayClusterResponse:
        """
        创建集群
        """
        
        kwargs = {}
        kwargs["action"] = "CreateRayCluster"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateRayClusterResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateResourceConfig(
            self,
            request: models.CreateResourceConfigRequest,
            opts: Dict = None,
    ) -> models.CreateResourceConfigResponse:
        """
        创建资源配置模板
        """
        
        kwargs = {}
        kwargs["action"] = "CreateResourceConfig"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateResourceConfigResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateResultDownload(
            self,
            request: models.CreateResultDownloadRequest,
            opts: Dict = None,
    ) -> models.CreateResultDownloadResponse:
        """
        创建查询结果下载任务
        """
        
        kwargs = {}
        kwargs["action"] = "CreateResultDownload"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateResultDownloadResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateScript(
            self,
            request: models.CreateScriptRequest,
            opts: Dict = None,
    ) -> models.CreateScriptResponse:
        """
        该接口（CreateScript）用于创建sql脚本。
        """
        
        kwargs = {}
        kwargs["action"] = "CreateScript"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateScriptResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateSparkApp(
            self,
            request: models.CreateSparkAppRequest,
            opts: Dict = None,
    ) -> models.CreateSparkAppResponse:
        """
        创建spark作业
        """
        
        kwargs = {}
        kwargs["action"] = "CreateSparkApp"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateSparkAppResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateSparkAppForTDLC(
            self,
            request: models.CreateSparkAppForTDLCRequest,
            opts: Dict = None,
    ) -> models.CreateSparkAppForTDLCResponse:
        """
        创建tdlc spark作业
        """
        
        kwargs = {}
        kwargs["action"] = "CreateSparkAppForTDLC"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateSparkAppForTDLCResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateSparkAppTask(
            self,
            request: models.CreateSparkAppTaskRequest,
            opts: Dict = None,
    ) -> models.CreateSparkAppTaskResponse:
        """
        启动Spark作业
        """
        
        kwargs = {}
        kwargs["action"] = "CreateSparkAppTask"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateSparkAppTaskResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateSparkSessionBatchSQL(
            self,
            request: models.CreateSparkSessionBatchSQLRequest,
            opts: Dict = None,
    ) -> models.CreateSparkSessionBatchSQLResponse:
        """
        本接口（CreateSparkSessionBatchSQL）用于向Spark作业引擎提交Spark SQL批任务。
        """
        
        kwargs = {}
        kwargs["action"] = "CreateSparkSessionBatchSQL"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateSparkSessionBatchSQLResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateSparkSubmitTask(
            self,
            request: models.CreateSparkSubmitTaskRequest,
            opts: Dict = None,
    ) -> models.CreateSparkSubmitTaskResponse:
        """
        本接口（CreateSparkSubmitTask）用于提交SparkSbumit批流任务。
        """
        
        kwargs = {}
        kwargs["action"] = "CreateSparkSubmitTask"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateSparkSubmitTaskResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateStandardEngineResourceGroup(
            self,
            request: models.CreateStandardEngineResourceGroupRequest,
            opts: Dict = None,
    ) -> models.CreateStandardEngineResourceGroupResponse:
        """
        创建标准引擎资源组
        """
        
        kwargs = {}
        kwargs["action"] = "CreateStandardEngineResourceGroup"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateStandardEngineResourceGroupResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateStoreLocation(
            self,
            request: models.CreateStoreLocationRequest,
            opts: Dict = None,
    ) -> models.CreateStoreLocationResponse:
        """
        该接口（CreateStoreLocation）新增或覆盖计算结果存储位置。
        """
        
        kwargs = {}
        kwargs["action"] = "CreateStoreLocation"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateStoreLocationResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateTable(
            self,
            request: models.CreateTableRequest,
            opts: Dict = None,
    ) -> models.CreateTableResponse:
        """
        本接口（CreateTable）用于生成建表SQL。
        """
        
        kwargs = {}
        kwargs["action"] = "CreateTable"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateTableResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateTask(
            self,
            request: models.CreateTaskRequest,
            opts: Dict = None,
    ) -> models.CreateTaskResponse:
        """
        本接口（CreateTask）用于创建并执行SQL任务。（推荐使用CreateTasks接口）
        """
        
        kwargs = {}
        kwargs["action"] = "CreateTask"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateTaskResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateTasks(
            self,
            request: models.CreateTasksRequest,
            opts: Dict = None,
    ) -> models.CreateTasksResponse:
        """
        本接口（CreateTasks），用于批量创建并执行SQL任务
        """
        
        kwargs = {}
        kwargs["action"] = "CreateTasks"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateTasksResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateTasksInOrder(
            self,
            request: models.CreateTasksInOrderRequest,
            opts: Dict = None,
    ) -> models.CreateTasksInOrderResponse:
        """
        废弃接口，申请下线

        按顺序创建任务（已经废弃，后期不再维护，请使用接口CreateTasks）
        """
        
        kwargs = {}
        kwargs["action"] = "CreateTasksInOrder"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateTasksInOrderResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateTcIcebergTable(
            self,
            request: models.CreateTcIcebergTableRequest,
            opts: Dict = None,
    ) -> models.CreateTcIcebergTableResponse:
        """
        创建TIceberg表
        """
        
        kwargs = {}
        kwargs["action"] = "CreateTcIcebergTable"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateTcIcebergTableResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateTrainingJobInstance(
            self,
            request: models.CreateTrainingJobInstanceRequest,
            opts: Dict = None,
    ) -> models.CreateTrainingJobInstanceResponse:
        """
        基于配置创建实例并提交 RayJob
        """
        
        kwargs = {}
        kwargs["action"] = "CreateTrainingJobInstance"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateTrainingJobInstanceResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateUser(
            self,
            request: models.CreateUserRequest,
            opts: Dict = None,
    ) -> models.CreateUserResponse:
        """
        创建用户
        """
        
        kwargs = {}
        kwargs["action"] = "CreateUser"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateUserResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateUserRole(
            self,
            request: models.CreateUserRoleRequest,
            opts: Dict = None,
    ) -> models.CreateUserRoleResponse:
        """
        创建用户角色
        """
        
        kwargs = {}
        kwargs["action"] = "CreateUserRole"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateUserRoleResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateUserVpcConnection(
            self,
            request: models.CreateUserVpcConnectionRequest,
            opts: Dict = None,
    ) -> models.CreateUserVpcConnectionResponse:
        """
        创建用户vpc连接到指定引擎网络
        """
        
        kwargs = {}
        kwargs["action"] = "CreateUserVpcConnection"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateUserVpcConnectionResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateWorkGroup(
            self,
            request: models.CreateWorkGroupRequest,
            opts: Dict = None,
    ) -> models.CreateWorkGroupResponse:
        """
        创建工作组
        """
        
        kwargs = {}
        kwargs["action"] = "CreateWorkGroup"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateWorkGroupResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DeleteApiKey(
            self,
            request: models.DeleteApiKeyRequest,
            opts: Dict = None,
    ) -> models.DeleteApiKeyResponse:
        """
        删除 API Key
        """
        
        kwargs = {}
        kwargs["action"] = "DeleteApiKey"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DeleteApiKeyResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DeleteBenchmarkTask(
            self,
            request: models.DeleteBenchmarkTaskRequest,
            opts: Dict = None,
    ) -> models.DeleteBenchmarkTaskResponse:
        """
        删除性能评测任务
        """
        
        kwargs = {}
        kwargs["action"] = "DeleteBenchmarkTask"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DeleteBenchmarkTaskResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DeleteCHDFSBindingProduct(
            self,
            request: models.DeleteCHDFSBindingProductRequest,
            opts: Dict = None,
    ) -> models.DeleteCHDFSBindingProductResponse:
        """
        此接口（DeleteCHDFSBindingProduct）用于删除元数据加速桶和产品绑定关系
        """
        
        kwargs = {}
        kwargs["action"] = "DeleteCHDFSBindingProduct"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DeleteCHDFSBindingProductResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DeleteClusterGroup(
            self,
            request: models.DeleteClusterGroupRequest,
            opts: Dict = None,
    ) -> models.DeleteClusterGroupResponse:
        """
        删除集群组
        """
        
        kwargs = {}
        kwargs["action"] = "DeleteClusterGroup"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DeleteClusterGroupResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DeleteDataEngine(
            self,
            request: models.DeleteDataEngineRequest,
            opts: Dict = None,
    ) -> models.DeleteDataEngineResponse:
        """
        删除数据引擎
        """
        
        kwargs = {}
        kwargs["action"] = "DeleteDataEngine"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DeleteDataEngineResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DeleteDataMaskStrategy(
            self,
            request: models.DeleteDataMaskStrategyRequest,
            opts: Dict = None,
    ) -> models.DeleteDataMaskStrategyResponse:
        """
        删除数据脱敏策略
        """
        
        kwargs = {}
        kwargs["action"] = "DeleteDataMaskStrategy"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DeleteDataMaskStrategyResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DeleteDeployment(
            self,
            request: models.DeleteDeploymentRequest,
            opts: Dict = None,
    ) -> models.DeleteDeploymentResponse:
        """
        删除指定部署
        """
        
        kwargs = {}
        kwargs["action"] = "DeleteDeployment"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DeleteDeploymentResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DeleteInferenceService(
            self,
            request: models.DeleteInferenceServiceRequest,
            opts: Dict = None,
    ) -> models.DeleteInferenceServiceResponse:
        """
        删除推理服务（含所有部署）
        """
        
        kwargs = {}
        kwargs["action"] = "DeleteInferenceService"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DeleteInferenceServiceResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DeleteJobSpec(
            self,
            request: models.DeleteJobSpecRequest,
            opts: Dict = None,
    ) -> models.DeleteJobSpecResponse:
        """
        根据配置ID删除作业配置
        """
        
        kwargs = {}
        kwargs["action"] = "DeleteJobSpec"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DeleteJobSpecResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DeleteLab(
            self,
            request: models.DeleteLabRequest,
            opts: Dict = None,
    ) -> models.DeleteLabResponse:
        """
        删除数据实验室
        """
        
        kwargs = {}
        kwargs["action"] = "DeleteLab"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DeleteLabResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DeleteMetaDatabase(
            self,
            request: models.DeleteMetaDatabaseRequest,
            opts: Dict = None,
    ) -> models.DeleteMetaDatabaseResponse:
        """
        本接口（DeleteMetaDatabase）用于一键删除元数据库
        """
        
        kwargs = {}
        kwargs["action"] = "DeleteMetaDatabase"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DeleteMetaDatabaseResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DeleteMlflowServer(
            self,
            request: models.DeleteMlflowServerRequest,
            opts: Dict = None,
    ) -> models.DeleteMlflowServerResponse:
        """
        删除 MlFlow Server 请求
        """
        
        kwargs = {}
        kwargs["action"] = "DeleteMlflowServer"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DeleteMlflowServerResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DeleteModel(
            self,
            request: models.DeleteModelRequest,
            opts: Dict = None,
    ) -> models.DeleteModelResponse:
        """
        删除模型及其所有版本（平台托管模型同时删除 COS 文件，用户自带桶仅删除元数据）
        """
        
        kwargs = {}
        kwargs["action"] = "DeleteModel"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DeleteModelResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DeleteModelVersion(
            self,
            request: models.DeleteModelVersionRequest,
            opts: Dict = None,
    ) -> models.DeleteModelVersionResponse:
        """
        删除模型版本（平台托管模型同时删除 COS 文件，用户自带桶仅删除元数据）
        """
        
        kwargs = {}
        kwargs["action"] = "DeleteModelVersion"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DeleteModelVersionResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DeleteNativeSparkSession(
            self,
            request: models.DeleteNativeSparkSessionRequest,
            opts: Dict = None,
    ) -> models.DeleteNativeSparkSessionResponse:
        """
        根据spark session名称销毁eg spark session
        """
        
        kwargs = {}
        kwargs["action"] = "DeleteNativeSparkSession"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DeleteNativeSparkSessionResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DeleteNotebookSession(
            self,
            request: models.DeleteNotebookSessionRequest,
            opts: Dict = None,
    ) -> models.DeleteNotebookSessionResponse:
        """
        本接口（DeleteNotebookSession）用于删除交互式session（notebook）
        """
        
        kwargs = {}
        kwargs["action"] = "DeleteNotebookSession"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DeleteNotebookSessionResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DeletePartitionQueue(
            self,
            request: models.DeletePartitionQueueRequest,
            opts: Dict = None,
    ) -> models.DeletePartitionQueueResponse:
        """
        删除资源队列
        """
        
        kwargs = {}
        kwargs["action"] = "DeletePartitionQueue"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DeletePartitionQueueResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DeleteRayCluster(
            self,
            request: models.DeleteRayClusterRequest,
            opts: Dict = None,
    ) -> models.DeleteRayClusterResponse:
        """
        删除集群
        """
        
        kwargs = {}
        kwargs["action"] = "DeleteRayCluster"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DeleteRayClusterResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DeleteRayJob(
            self,
            request: models.DeleteRayJobRequest,
            opts: Dict = None,
    ) -> models.DeleteRayJobResponse:
        """
        根据任务ID删除Ray任务
        """
        
        kwargs = {}
        kwargs["action"] = "DeleteRayJob"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DeleteRayJobResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DeleteResourceConfig(
            self,
            request: models.DeleteResourceConfigRequest,
            opts: Dict = None,
    ) -> models.DeleteResourceConfigResponse:
        """
        删除资源配置模板
        """
        
        kwargs = {}
        kwargs["action"] = "DeleteResourceConfig"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DeleteResourceConfigResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DeleteScript(
            self,
            request: models.DeleteScriptRequest,
            opts: Dict = None,
    ) -> models.DeleteScriptResponse:
        """
        该接口（DeleteScript）用于删除sql脚本。
        """
        
        kwargs = {}
        kwargs["action"] = "DeleteScript"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DeleteScriptResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DeleteSparkApp(
            self,
            request: models.DeleteSparkAppRequest,
            opts: Dict = None,
    ) -> models.DeleteSparkAppResponse:
        """
        删除spark作业
        """
        
        kwargs = {}
        kwargs["action"] = "DeleteSparkApp"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DeleteSparkAppResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DeleteStandardEngineResourceGroup(
            self,
            request: models.DeleteStandardEngineResourceGroupRequest,
            opts: Dict = None,
    ) -> models.DeleteStandardEngineResourceGroupResponse:
        """
        删除标准引擎资源组
        """
        
        kwargs = {}
        kwargs["action"] = "DeleteStandardEngineResourceGroup"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DeleteStandardEngineResourceGroupResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DeleteTable(
            self,
            request: models.DeleteTableRequest,
            opts: Dict = None,
    ) -> models.DeleteTableResponse:
        """
        删除表
        """
        
        kwargs = {}
        kwargs["action"] = "DeleteTable"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DeleteTableResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DeleteThirdPartyAccessUser(
            self,
            request: models.DeleteThirdPartyAccessUserRequest,
            opts: Dict = None,
    ) -> models.DeleteThirdPartyAccessUserResponse:
        """
        本接口（RegisterThirdPartyAccessUser）用于移除第三方平台访问
        """
        
        kwargs = {}
        kwargs["action"] = "DeleteThirdPartyAccessUser"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DeleteThirdPartyAccessUserResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DeleteTrainingJobInstance(
            self,
            request: models.DeleteTrainingJobInstanceRequest,
            opts: Dict = None,
    ) -> models.DeleteTrainingJobInstanceResponse:
        """
        删除训练作业实例（软删除本地元数据，仅终态实例可删除）
        """
        
        kwargs = {}
        kwargs["action"] = "DeleteTrainingJobInstance"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DeleteTrainingJobInstanceResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DeleteTrainingJobSpec(
            self,
            request: models.DeleteTrainingJobSpecRequest,
            opts: Dict = None,
    ) -> models.DeleteTrainingJobSpecResponse:
        """
        删除训练作业配置
        """
        
        kwargs = {}
        kwargs["action"] = "DeleteTrainingJobSpec"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DeleteTrainingJobSpecResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DeleteUser(
            self,
            request: models.DeleteUserRequest,
            opts: Dict = None,
    ) -> models.DeleteUserResponse:
        """
        删除用户
        """
        
        kwargs = {}
        kwargs["action"] = "DeleteUser"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DeleteUserResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DeleteUserVpcConnection(
            self,
            request: models.DeleteUserVpcConnectionRequest,
            opts: Dict = None,
    ) -> models.DeleteUserVpcConnectionResponse:
        """
        删除用户vpc到引擎网络的连接
        """
        
        kwargs = {}
        kwargs["action"] = "DeleteUserVpcConnection"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DeleteUserVpcConnectionResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DeleteUsersFromWorkGroup(
            self,
            request: models.DeleteUsersFromWorkGroupRequest,
            opts: Dict = None,
    ) -> models.DeleteUsersFromWorkGroupResponse:
        """
        从工作组中删除用户
        """
        
        kwargs = {}
        kwargs["action"] = "DeleteUsersFromWorkGroup"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DeleteUsersFromWorkGroupResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DeleteWorkGroup(
            self,
            request: models.DeleteWorkGroupRequest,
            opts: Dict = None,
    ) -> models.DeleteWorkGroupResponse:
        """
        删除工作组
        """
        
        kwargs = {}
        kwargs["action"] = "DeleteWorkGroup"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DeleteWorkGroupResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeAdvancedStoreLocation(
            self,
            request: models.DescribeAdvancedStoreLocationRequest,
            opts: Dict = None,
    ) -> models.DescribeAdvancedStoreLocationResponse:
        """
        查询sql查询界面高级设置
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeAdvancedStoreLocation"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeAdvancedStoreLocationResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeBindablePrometheus(
            self,
            request: models.DescribeBindablePrometheusRequest,
            opts: Dict = None,
    ) -> models.DescribeBindablePrometheusResponse:
        """
        查询 TKE 集群可绑定的托管 Prometheus 实例列表。若 TKE 已绑定，返回 Bound=true 与 BoundInstance；若未绑定，返回 Bound=false 与候选列表 Instances（同 VPC 实例前置）。
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeBindablePrometheus"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeBindablePrometheusResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeClsTopics(
            self,
            request: models.DescribeClsTopicsRequest,
            opts: Dict = None,
    ) -> models.DescribeClsTopicsResponse:
        """
        查询 CLS 日志主题列表：TopicName 走模糊匹配，TopicId 走精确匹配，两者均可为空；分页返回。
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeClsTopics"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeClsTopicsResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeClusterEventLogSwitch(
            self,
            request: models.DescribeClusterEventLogSwitchRequest,
            opts: Dict = None,
    ) -> models.DescribeClusterEventLogSwitchResponse:
        """
        查询指定 TKE 集群是否开启了事件日志。已开启时同时返回关联的 CLS 日志集 ID、日志主题 ID 与主题所在地域。
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeClusterEventLogSwitch"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeClusterEventLogSwitchResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeClusterGroup(
            self,
            request: models.DescribeClusterGroupRequest,
            opts: Dict = None,
    ) -> models.DescribeClusterGroupResponse:
        """
        根据集群组 ID 获取集群组详情。支持通过 IncludeDeleted 参数控制是否返回已软删除的记录（用于悬挂 cluster 回显场景）。
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeClusterGroup"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeClusterGroupResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeClusterGroupClusters(
            self,
            request: models.DescribeClusterGroupClustersRequest,
            opts: Dict = None,
    ) -> models.DescribeClusterGroupClustersResponse:
        """
        计算组关联 cluster 使用情况响应
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeClusterGroupClusters"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeClusterGroupClustersResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeClusterMonitorInfos(
            self,
            request: models.DescribeClusterMonitorInfosRequest,
            opts: Dict = None,
    ) -> models.DescribeClusterMonitorInfosResponse:
        """
        查询任务监控指标信息
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeClusterMonitorInfos"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeClusterMonitorInfosResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeDLCCatalogAccess(
            self,
            request: models.DescribeDLCCatalogAccessRequest,
            opts: Dict = None,
    ) -> models.DescribeDLCCatalogAccessResponse:
        """
        查询DLC Catalog授权列表
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeDLCCatalogAccess"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeDLCCatalogAccessResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeDMSDatabase(
            self,
            request: models.DescribeDMSDatabaseRequest,
            opts: Dict = None,
    ) -> models.DescribeDMSDatabaseResponse:
        """
        DMS元数据获取库
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeDMSDatabase"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeDMSDatabaseResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeDMSPartitions(
            self,
            request: models.DescribeDMSPartitionsRequest,
            opts: Dict = None,
    ) -> models.DescribeDMSPartitionsResponse:
        """
        DMS元数据获取分区
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeDMSPartitions"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeDMSPartitionsResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeDMSTable(
            self,
            request: models.DescribeDMSTableRequest,
            opts: Dict = None,
    ) -> models.DescribeDMSTableResponse:
        """
        DMS元数据获取表
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeDMSTable"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeDMSTableResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeDMSTables(
            self,
            request: models.DescribeDMSTablesRequest,
            opts: Dict = None,
    ) -> models.DescribeDMSTablesResponse:
        """
        DMS元数据获取表列表
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeDMSTables"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeDMSTablesResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeDataEngine(
            self,
            request: models.DescribeDataEngineRequest,
            opts: Dict = None,
    ) -> models.DescribeDataEngineResponse:
        """
        本接口根据名称用于获取数据引擎详细信息
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeDataEngine"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeDataEngineResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeDataEngineEvents(
            self,
            request: models.DescribeDataEngineEventsRequest,
            opts: Dict = None,
    ) -> models.DescribeDataEngineEventsResponse:
        """
        查询数据引擎事件
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeDataEngineEvents"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeDataEngineEventsResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeDataEngineImageVersions(
            self,
            request: models.DescribeDataEngineImageVersionsRequest,
            opts: Dict = None,
    ) -> models.DescribeDataEngineImageVersionsResponse:
        """
        本接口（DescribeDataEngineImageVersions）用于获取独享集群大版本镜像列表。
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeDataEngineImageVersions"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeDataEngineImageVersionsResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeDataEnginePythonSparkImages(
            self,
            request: models.DescribeDataEnginePythonSparkImagesRequest,
            opts: Dict = None,
    ) -> models.DescribeDataEnginePythonSparkImagesResponse:
        """
        本接口（DescribeDataEnginePythonSparkImages）用于获取PYSPARK镜像列表
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeDataEnginePythonSparkImages"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeDataEnginePythonSparkImagesResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeDataEngineSessionParameters(
            self,
            request: models.DescribeDataEngineSessionParametersRequest,
            opts: Dict = None,
    ) -> models.DescribeDataEngineSessionParametersResponse:
        """
        本接口（DescribeDataEngineSessionParameters）用于获取指定小版本下的Session配置。
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeDataEngineSessionParameters"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeDataEngineSessionParametersResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeDataEngines(
            self,
            request: models.DescribeDataEnginesRequest,
            opts: Dict = None,
    ) -> models.DescribeDataEnginesResponse:
        """
        本接口（DescribeDataEngines）用于查询DataEngines信息列表.
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeDataEngines"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeDataEnginesResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeDataEnginesScaleDetail(
            self,
            request: models.DescribeDataEnginesScaleDetailRequest,
            opts: Dict = None,
    ) -> models.DescribeDataEnginesScaleDetailResponse:
        """
        查询引擎规格详情
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeDataEnginesScaleDetail"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeDataEnginesScaleDetailResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeDataMaskStrategies(
            self,
            request: models.DescribeDataMaskStrategiesRequest,
            opts: Dict = None,
    ) -> models.DescribeDataMaskStrategiesResponse:
        """
        查询数据脱敏列表接口
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeDataMaskStrategies"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeDataMaskStrategiesResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeDatabase(
            self,
            request: models.DescribeDatabaseRequest,
            opts: Dict = None,
    ) -> models.DescribeDatabaseResponse:
        """
        本接口（DescribeDatabase）,查询数据库详细信息
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeDatabase"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeDatabaseResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeDatabases(
            self,
            request: models.DescribeDatabasesRequest,
            opts: Dict = None,
    ) -> models.DescribeDatabasesResponse:
        """
        本接口（DescribeDatabases）用于查询数据库列表。
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeDatabases"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeDatabasesResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeDatasourceConnection(
            self,
            request: models.DescribeDatasourceConnectionRequest,
            opts: Dict = None,
    ) -> models.DescribeDatasourceConnectionResponse:
        """
        本接口（DescribeDatasourceConnection）用于查询数据源信息
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeDatasourceConnection"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeDatasourceConnectionResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeEmrClusterInfo(
            self,
            request: models.DescribeEmrClusterInfoRequest,
            opts: Dict = None,
    ) -> models.DescribeEmrClusterInfoResponse:
        """
        按 EMR 集群 ID 精确查询单个 EMR 集群的详细信息，包含 VPC、COS Bucket、关联 TKE 集群 ID、资源用量等。
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeEmrClusterInfo"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeEmrClusterInfoResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeEngineNetworks(
            self,
            request: models.DescribeEngineNetworksRequest,
            opts: Dict = None,
    ) -> models.DescribeEngineNetworksResponse:
        """
        查询引擎网络信息
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeEngineNetworks"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeEngineNetworksResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeEngineNodeSpec(
            self,
            request: models.DescribeEngineNodeSpecRequest,
            opts: Dict = None,
    ) -> models.DescribeEngineNodeSpecResponse:
        """
        查询引擎可用的节点规格
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeEngineNodeSpec"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeEngineNodeSpecResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeEngineUsageInfo(
            self,
            request: models.DescribeEngineUsageInfoRequest,
            opts: Dict = None,
    ) -> models.DescribeEngineUsageInfoResponse:
        """
        本接口根据引擎ID查询数据引擎资源使用情况
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeEngineUsageInfo"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeEngineUsageInfoResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeFlowDetailList(
            self,
            request: models.DescribeFlowDetailListRequest,
            opts: Dict = None,
    ) -> models.DescribeFlowDetailListResponse:
        """
        分页查询指定分区的流程详情列表，包含每个流程的基本信息和活动列表
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeFlowDetailList"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeFlowDetailListResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeFlowList(
            self,
            request: models.DescribeFlowListRequest,
            opts: Dict = None,
    ) -> models.DescribeFlowListResponse:
        """
        查询指定分区的流程列表
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeFlowList"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeFlowListResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeForbiddenTablePro(
            self,
            request: models.DescribeForbiddenTableProRequest,
            opts: Dict = None,
    ) -> models.DescribeForbiddenTableProResponse:
        """
        本接口（DescribeForbiddenTablePro）用于查询被禁用的表属性列表（新）
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeForbiddenTablePro"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeForbiddenTableProResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeLakeFsDirSummary(
            self,
            request: models.DescribeLakeFsDirSummaryRequest,
            opts: Dict = None,
    ) -> models.DescribeLakeFsDirSummaryResponse:
        """
        查询托管存储指定目录的Summary
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeLakeFsDirSummary"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeLakeFsDirSummaryResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeLakeFsInfo(
            self,
            request: models.DescribeLakeFsInfoRequest,
            opts: Dict = None,
    ) -> models.DescribeLakeFsInfoResponse:
        """
        查询用户的托管存储信息
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeLakeFsInfo"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeLakeFsInfoResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeLakeFsTaskResult(
            self,
            request: models.DescribeLakeFsTaskResultRequest,
            opts: Dict = None,
    ) -> models.DescribeLakeFsTaskResultResponse:
        """
        获取LakeFs上task执行结果访问信息
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeLakeFsTaskResult"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeLakeFsTaskResultResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeMCPSubUin(
            self,
            request: models.DescribeMCPSubUinRequest,
            opts: Dict = None,
    ) -> models.DescribeMCPSubUinResponse:
        """
        获取账户子账户信息
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeMCPSubUin"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeMCPSubUinResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeMCPTask(
            self,
            request: models.DescribeMCPTaskRequest,
            opts: Dict = None,
    ) -> models.DescribeMCPTaskResponse:
        """
        该接口（DescribeTasks）用于查询任务列表
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeMCPTask"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeMCPTaskResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeMCPTaskResult(
            self,
            request: models.DescribeMCPTaskResultRequest,
            opts: Dict = None,
    ) -> models.DescribeMCPTaskResultResponse:
        """
        获取任务结果查询
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeMCPTaskResult"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeMCPTaskResultResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeMlFlowConfig(
            self,
            request: models.DescribeMlFlowConfigRequest,
            opts: Dict = None,
    ) -> models.DescribeMlFlowConfigResponse:
        """
        查询训练实例的 MLflow 接入配置。
        MlFlowMode 表示接入的 mlflow 模式，支持 local=Sidecar / remote=已有 Server / none=不启用。云上默认为 remote。
        MlFlowUrl 表示访问的 MLflow URL。
        RunID, ExperimentID 对应MLflow 实验追踪用的参数 RunID, ExperimentID
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeMlFlowConfig"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeMlFlowConfigResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeMlflowServer(
            self,
            request: models.DescribeMlflowServerRequest,
            opts: Dict = None,
    ) -> models.DescribeMlflowServerResponse:
        """
        查询 MlFlow Server 状态
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeMlflowServer"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeMlflowServerResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeMlflowServerEvents(
            self,
            request: models.DescribeMlflowServerEventsRequest,
            opts: Dict = None,
    ) -> models.DescribeMlflowServerEventsResponse:
        """
        查询 MlFlow Server K8s 事件
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeMlflowServerEvents"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeMlflowServerEventsResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeMlflowServerPods(
            self,
            request: models.DescribeMlflowServerPodsRequest,
            opts: Dict = None,
    ) -> models.DescribeMlflowServerPodsResponse:
        """
        MlFlow Server Pod 列表响应
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeMlflowServerPods"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeMlflowServerPodsResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeModelEngines(
            self,
            request: models.DescribeModelEnginesRequest,
            opts: Dict = None,
    ) -> models.DescribeModelEnginesResponse:
        """
        根据模型 UID 查询该模型可选的推理引擎列表。后端自动根据模型的 SupportedEngines 声明或 ModelType 进行引擎过滤
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeModelEngines"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeModelEnginesResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeModelTaskOptions(
            self,
            request: models.DescribeModelTaskOptionsRequest,
            opts: Dict = None,
    ) -> models.DescribeModelTaskOptionsResponse:
        """
        查询指定模型类型下可选的任务类型列表。
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeModelTaskOptions"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeModelTaskOptionsResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeNativeSparkSessions(
            self,
            request: models.DescribeNativeSparkSessionsRequest,
            opts: Dict = None,
    ) -> models.DescribeNativeSparkSessionsResponse:
        """
        根据资源组获取spark session列表
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeNativeSparkSessions"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeNativeSparkSessionsResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeNetworkConnections(
            self,
            request: models.DescribeNetworkConnectionsRequest,
            opts: Dict = None,
    ) -> models.DescribeNetworkConnectionsResponse:
        """
        查询网络配置列表
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeNetworkConnections"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeNetworkConnectionsResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeNotebookSession(
            self,
            request: models.DescribeNotebookSessionRequest,
            opts: Dict = None,
    ) -> models.DescribeNotebookSessionResponse:
        """
        本接口（DescribeNotebookSession）用于查询交互式 session详情信息
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeNotebookSession"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeNotebookSessionResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeNotebookSessionLog(
            self,
            request: models.DescribeNotebookSessionLogRequest,
            opts: Dict = None,
    ) -> models.DescribeNotebookSessionLogResponse:
        """
        本接口（DescribeNotebookSessionLog）用于查询交互式 session日志
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeNotebookSessionLog"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeNotebookSessionLogResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeNotebookSessionStatement(
            self,
            request: models.DescribeNotebookSessionStatementRequest,
            opts: Dict = None,
    ) -> models.DescribeNotebookSessionStatementResponse:
        """
        本接口（DescribeNotebookSessionStatement）用于查询session 中执行任务的详情
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeNotebookSessionStatement"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeNotebookSessionStatementResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeNotebookSessionStatementSqlResult(
            self,
            request: models.DescribeNotebookSessionStatementSqlResultRequest,
            opts: Dict = None,
    ) -> models.DescribeNotebookSessionStatementSqlResultResponse:
        """
        本接口（DescribeNotebookSessionStatementSqlResult）用于获取statement运行结果。
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeNotebookSessionStatementSqlResult"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeNotebookSessionStatementSqlResultResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeNotebookSessionStatements(
            self,
            request: models.DescribeNotebookSessionStatementsRequest,
            opts: Dict = None,
    ) -> models.DescribeNotebookSessionStatementsResponse:
        """
        本接口（DescribeNotebookSessionStatements）用于查询Session中执行的任务列表
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeNotebookSessionStatements"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeNotebookSessionStatementsResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeNotebookSessions(
            self,
            request: models.DescribeNotebookSessionsRequest,
            opts: Dict = None,
    ) -> models.DescribeNotebookSessionsResponse:
        """
        本接口（DescribeNotebookSessions）用于查询交互式 session列表
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeNotebookSessions"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeNotebookSessionsResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeOtherCHDFSBindingList(
            self,
            request: models.DescribeOtherCHDFSBindingListRequest,
            opts: Dict = None,
    ) -> models.DescribeOtherCHDFSBindingListResponse:
        """
        此接口（DescribeOtherCHDFSBindingList）用于查询其他产品元数据加速桶绑定列表
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeOtherCHDFSBindingList"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeOtherCHDFSBindingListResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribePartitionDetail(
            self,
            request: models.DescribePartitionDetailRequest,
            opts: Dict = None,
    ) -> models.DescribePartitionDetailResponse:
        """
        获取指定资源分区详情
        """
        
        kwargs = {}
        kwargs["action"] = "DescribePartitionDetail"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribePartitionDetailResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribePartitionQueues(
            self,
            request: models.DescribePartitionQueuesRequest,
            opts: Dict = None,
    ) -> models.DescribePartitionQueuesResponse:
        """
        查询指定分区的所有队列列表
        """
        
        kwargs = {}
        kwargs["action"] = "DescribePartitionQueues"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribePartitionQueuesResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribePartitions(
            self,
            request: models.DescribePartitionsRequest,
            opts: Dict = None,
    ) -> models.DescribePartitionsResponse:
        """
        获取分区列表信息
        """
        
        kwargs = {}
        kwargs["action"] = "DescribePartitions"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribePartitionsResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribePostTrainingPreset(
            self,
            request: models.DescribePostTrainingPresetRequest,
            opts: Dict = None,
    ) -> models.DescribePostTrainingPresetResponse:
        """
        获取零代码后训练的推荐参数和资源规格配置
        """
        
        kwargs = {}
        kwargs["action"] = "DescribePostTrainingPreset"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribePostTrainingPresetResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeRecommendedParams(
            self,
            request: models.DescribeRecommendedParamsRequest,
            opts: Dict = None,
    ) -> models.DescribeRecommendedParamsResponse:
        """
        获取推荐的高级参数
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeRecommendedParams"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeRecommendedParamsResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeResourceGroupUsageInfo(
            self,
            request: models.DescribeResourceGroupUsageInfoRequest,
            opts: Dict = None,
    ) -> models.DescribeResourceGroupUsageInfoResponse:
        """
        本接口根据资源组ID查询资源组CU使用情况
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeResourceGroupUsageInfo"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeResourceGroupUsageInfoResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeResultDownload(
            self,
            request: models.DescribeResultDownloadRequest,
            opts: Dict = None,
    ) -> models.DescribeResultDownloadResponse:
        """
        查询结果下载任务
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeResultDownload"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeResultDownloadResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeSaleRegions(
            self,
            request: models.DescribeSaleRegionsRequest,
            opts: Dict = None,
    ) -> models.DescribeSaleRegionsResponse:
        """
        查询可售卖的地域列表，仅返回状态为AVAILABLE的地域
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeSaleRegions"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeSaleRegionsResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeSaleResourceInfo(
            self,
            request: models.DescribeSaleResourceInfoRequest,
            opts: Dict = None,
    ) -> models.DescribeSaleResourceInfoResponse:
        """
        查询当前地域可售卖的资源规格、最大配额，以及库存情况。StatusCategory 与 DescribePartitionAvailableQuota 数据同源，将实时可新增数量映射为库存分级；当请求 Region 与资源池实际部署地域不一致，或服务 cold-start 快照尚未就绪时，StatusCategory 为 null。
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeSaleResourceInfo"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeSaleResourceInfoResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeScripts(
            self,
            request: models.DescribeScriptsRequest,
            opts: Dict = None,
    ) -> models.DescribeScriptsResponse:
        """
        该接口（DescribeScripts）用于查询SQL脚本列表
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeScripts"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeScriptsResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeSessionImageVersion(
            self,
            request: models.DescribeSessionImageVersionRequest,
            opts: Dict = None,
    ) -> models.DescribeSessionImageVersionResponse:
        """
        获取指定大版本下所有小版本的所有内置镜像
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeSessionImageVersion"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeSessionImageVersionResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeSparkAppJob(
            self,
            request: models.DescribeSparkAppJobRequest,
            opts: Dict = None,
    ) -> models.DescribeSparkAppJobResponse:
        """
        查询spark作业信息
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeSparkAppJob"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeSparkAppJobResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeSparkAppJobs(
            self,
            request: models.DescribeSparkAppJobsRequest,
            opts: Dict = None,
    ) -> models.DescribeSparkAppJobsResponse:
        """
        查询spark作业列表
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeSparkAppJobs"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeSparkAppJobsResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeSparkAppTasks(
            self,
            request: models.DescribeSparkAppTasksRequest,
            opts: Dict = None,
    ) -> models.DescribeSparkAppTasksResponse:
        """
        查询Spark作业的运行任务列表
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeSparkAppTasks"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeSparkAppTasksResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeSparkSessionBatchSQL(
            self,
            request: models.DescribeSparkSessionBatchSQLRequest,
            opts: Dict = None,
    ) -> models.DescribeSparkSessionBatchSQLResponse:
        """
        本接口（DescribeSparkSessionBatchSQL）用于查询Spark SQL批任务运行状态
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeSparkSessionBatchSQL"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeSparkSessionBatchSQLResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeSparkSessionBatchSQLCost(
            self,
            request: models.DescribeSparkSessionBatchSQLCostRequest,
            opts: Dict = None,
    ) -> models.DescribeSparkSessionBatchSQLCostResponse:
        """
        本接口（DescribeSparkSessionBatchSQLCost）用于查询Spark SQL批任务消耗
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeSparkSessionBatchSQLCost"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeSparkSessionBatchSQLCostResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeSparkSessionBatchSqlLog(
            self,
            request: models.DescribeSparkSessionBatchSqlLogRequest,
            opts: Dict = None,
    ) -> models.DescribeSparkSessionBatchSqlLogResponse:
        """
        本接口（DescribeSparkSessionBatchSqlLog）用于查询Spark SQL批任务日志
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeSparkSessionBatchSqlLog"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeSparkSessionBatchSqlLogResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeStandardEngineResourceGroupConfigInfo(
            self,
            request: models.DescribeStandardEngineResourceGroupConfigInfoRequest,
            opts: Dict = None,
    ) -> models.DescribeStandardEngineResourceGroupConfigInfoResponse:
        """
        查询标准引擎资源组信息
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeStandardEngineResourceGroupConfigInfo"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeStandardEngineResourceGroupConfigInfoResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeStandardEngineResourceGroups(
            self,
            request: models.DescribeStandardEngineResourceGroupsRequest,
            opts: Dict = None,
    ) -> models.DescribeStandardEngineResourceGroupsResponse:
        """
        查询标准引擎资源组信息
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeStandardEngineResourceGroups"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeStandardEngineResourceGroupsResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeStoreLocation(
            self,
            request: models.DescribeStoreLocationRequest,
            opts: Dict = None,
    ) -> models.DescribeStoreLocationResponse:
        """
        查询计算结果存储位置。
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeStoreLocation"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeStoreLocationResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeSubUserAccessPolicy(
            self,
            request: models.DescribeSubUserAccessPolicyRequest,
            opts: Dict = None,
    ) -> models.DescribeSubUserAccessPolicyResponse:
        """
        本接口（DescribeSubUserAccessPolicy）用于开通了第三方平台访问的用户，查询其子用户的访问策略
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeSubUserAccessPolicy"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeSubUserAccessPolicyResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeTCLakeMetaInstance(
            self,
            request: models.DescribeTCLakeMetaInstanceRequest,
            opts: Dict = None,
    ) -> models.DescribeTCLakeMetaInstanceResponse:
        """
        是否成功开通TCLake
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeTCLakeMetaInstance"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeTCLakeMetaInstanceResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeTable(
            self,
            request: models.DescribeTableRequest,
            opts: Dict = None,
    ) -> models.DescribeTableResponse:
        """
        本接口（DescribeTable），用于查询单个表的详细信息。
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeTable"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeTableResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeTablePartitions(
            self,
            request: models.DescribeTablePartitionsRequest,
            opts: Dict = None,
    ) -> models.DescribeTablePartitionsResponse:
        """
        本接口（DescribeTablePartitions）用于查询数据表分区信息
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeTablePartitions"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeTablePartitionsResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeTables(
            self,
            request: models.DescribeTablesRequest,
            opts: Dict = None,
    ) -> models.DescribeTablesResponse:
        """
        本接口（DescribeTables）用于查询数据表列表。
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeTables"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeTablesResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeTablesName(
            self,
            request: models.DescribeTablesNameRequest,
            opts: Dict = None,
    ) -> models.DescribeTablesNameResponse:
        """
        本接口（DescribeTables）用于查询数据表名称列表
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeTablesName"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeTablesNameResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeTaskDetail(
            self,
            request: models.DescribeTaskDetailRequest,
            opts: Dict = None,
    ) -> models.DescribeTaskDetailResponse:
        """
        该接口（DescribeTaskDetail）用于查询历史任务详情
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeTaskDetail"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeTaskDetailResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeTaskList(
            self,
            request: models.DescribeTaskListRequest,
            opts: Dict = None,
    ) -> models.DescribeTaskListResponse:
        """
        该接口（DescribleTasks）用于查询任务列表
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeTaskList"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeTaskListResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeTaskLog(
            self,
            request: models.DescribeTaskLogRequest,
            opts: Dict = None,
    ) -> models.DescribeTaskLogResponse:
        """
        本接口（DescribeTaskLog）用于获取spark 作业任务日志详情
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeTaskLog"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeTaskLogResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeTaskMonitorInfos(
            self,
            request: models.DescribeTaskMonitorInfosRequest,
            opts: Dict = None,
    ) -> models.DescribeTaskMonitorInfosResponse:
        """
        查询任务监控指标信息
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeTaskMonitorInfos"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeTaskMonitorInfosResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeTaskResourceUsage(
            self,
            request: models.DescribeTaskResourceUsageRequest,
            opts: Dict = None,
    ) -> models.DescribeTaskResourceUsageResponse:
        """
        返回任务洞察资源用量
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeTaskResourceUsage"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeTaskResourceUsageResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeTaskResult(
            self,
            request: models.DescribeTaskResultRequest,
            opts: Dict = None,
    ) -> models.DescribeTaskResultResponse:
        """
        查询任务结果，仅支持30天以内的任务查询结果，且返回数据大小超过近50M会进行截断。
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeTaskResult"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeTaskResultResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeTasks(
            self,
            request: models.DescribeTasksRequest,
            opts: Dict = None,
    ) -> models.DescribeTasksResponse:
        """
        该接口（DescribeTasks）用于查询任务列表
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeTasks"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeTasksResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeTasksAnalysis(
            self,
            request: models.DescribeTasksAnalysisRequest,
            opts: Dict = None,
    ) -> models.DescribeTasksAnalysisResponse:
        """
        该接口用于洞察分析列表
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeTasksAnalysis"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeTasksAnalysisResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeTasksCostInfo(
            self,
            request: models.DescribeTasksCostInfoRequest,
            opts: Dict = None,
    ) -> models.DescribeTasksCostInfoResponse:
        """
        该接口（DescribeTasksCostInfo）用于查询任务消耗
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeTasksCostInfo"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeTasksCostInfoResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeTasksOverview(
            self,
            request: models.DescribeTasksOverviewRequest,
            opts: Dict = None,
    ) -> models.DescribeTasksOverviewResponse:
        """
        查看任务概览页
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeTasksOverview"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeTasksOverviewResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeThirdPartyAccessUser(
            self,
            request: models.DescribeThirdPartyAccessUserRequest,
            opts: Dict = None,
    ) -> models.DescribeThirdPartyAccessUserResponse:
        """
        本接口（RegisterThirdPartyAccessUser）查询开通第三方平台访问的用户信息
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeThirdPartyAccessUser"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeThirdPartyAccessUserResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeTkeClusterImportInfo(
            self,
            request: models.DescribeTkeClusterImportInfoRequest,
            opts: Dict = None,
    ) -> models.DescribeTkeClusterImportInfoResponse:
        """
        按 EMR 集群 ID 查询已导入的 TKE 集群详情，返回 tke_cluster 表中该条导入记录的核心字段，并对 LoadBalancerId / PrometheusInstanceId / ContainerLogTopicId 三个 ID 分别回查腾讯云 API 获取对应名称一并返回。名称查询失败或查不到时对应字段返回空字符串，不影响主接口返回。
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeTkeClusterImportInfo"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeTkeClusterImportInfoResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeTrainingCheckpoints(
            self,
            request: models.DescribeTrainingCheckpointsRequest,
            opts: Dict = None,
    ) -> models.DescribeTrainingCheckpointsResponse:
        """
        列出训练实例 Checkpoint 文件列表的响应
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeTrainingCheckpoints"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeTrainingCheckpointsResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeTrainingJobInstance(
            self,
            request: models.DescribeTrainingJobInstanceRequest,
            opts: Dict = None,
    ) -> models.DescribeTrainingJobInstanceResponse:
        """
        查询训练实例详情
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeTrainingJobInstance"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeTrainingJobInstanceResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeTrainingJobSpec(
            self,
            request: models.DescribeTrainingJobSpecRequest,
            opts: Dict = None,
    ) -> models.DescribeTrainingJobSpecResponse:
        """
        获取训练作业配置详情
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeTrainingJobSpec"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeTrainingJobSpecResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeUDFPolicy(
            self,
            request: models.DescribeUDFPolicyRequest,
            opts: Dict = None,
    ) -> models.DescribeUDFPolicyResponse:
        """
        获取UDF权限信息
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeUDFPolicy"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeUDFPolicyResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeUpdatableDataEngines(
            self,
            request: models.DescribeUpdatableDataEnginesRequest,
            opts: Dict = None,
    ) -> models.DescribeUpdatableDataEnginesResponse:
        """
        查询可更新配置的引擎列表
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeUpdatableDataEngines"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeUpdatableDataEnginesResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeUserDataEngineConfig(
            self,
            request: models.DescribeUserDataEngineConfigRequest,
            opts: Dict = None,
    ) -> models.DescribeUserDataEngineConfigResponse:
        """
        查询用户自定义引擎参数
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeUserDataEngineConfig"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeUserDataEngineConfigResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeUserInfo(
            self,
            request: models.DescribeUserInfoRequest,
            opts: Dict = None,
    ) -> models.DescribeUserInfoResponse:
        """
        获取用户详细信息
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeUserInfo"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeUserInfoResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeUserRegisterTime(
            self,
            request: models.DescribeUserRegisterTimeRequest,
            opts: Dict = None,
    ) -> models.DescribeUserRegisterTimeResponse:
        """
        该接口（DescribeUserRegisterTime）用于查询当前用户注册时间，并判断是否是老用户。
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeUserRegisterTime"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeUserRegisterTimeResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeUserRoles(
            self,
            request: models.DescribeUserRolesRequest,
            opts: Dict = None,
    ) -> models.DescribeUserRolesResponse:
        """
        列举用户角色信息
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeUserRoles"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeUserRolesResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeUserType(
            self,
            request: models.DescribeUserTypeRequest,
            opts: Dict = None,
    ) -> models.DescribeUserTypeResponse:
        """
        获取用户类型
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeUserType"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeUserTypeResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeUserVpcConnection(
            self,
            request: models.DescribeUserVpcConnectionRequest,
            opts: Dict = None,
    ) -> models.DescribeUserVpcConnectionResponse:
        """
        查询用户vpc到引擎网络的连接
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeUserVpcConnection"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeUserVpcConnectionResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeUsers(
            self,
            request: models.DescribeUsersRequest,
            opts: Dict = None,
    ) -> models.DescribeUsersResponse:
        """
        获取用户列表信息
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeUsers"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeUsersResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeViews(
            self,
            request: models.DescribeViewsRequest,
            opts: Dict = None,
    ) -> models.DescribeViewsResponse:
        """
        本接口（DescribeViews）用于查询数据视图列表。
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeViews"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeViewsResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeWorkGroupInfo(
            self,
            request: models.DescribeWorkGroupInfoRequest,
            opts: Dict = None,
    ) -> models.DescribeWorkGroupInfoResponse:
        """
        获取工作组详细信息
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeWorkGroupInfo"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeWorkGroupInfoResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeWorkGroups(
            self,
            request: models.DescribeWorkGroupsRequest,
            opts: Dict = None,
    ) -> models.DescribeWorkGroupsResponse:
        """
        获取工作组列表
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeWorkGroups"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeWorkGroupsResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DetachUserPolicy(
            self,
            request: models.DetachUserPolicyRequest,
            opts: Dict = None,
    ) -> models.DetachUserPolicyResponse:
        """
        解绑用户鉴权策略
        """
        
        kwargs = {}
        kwargs["action"] = "DetachUserPolicy"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DetachUserPolicyResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DetachWorkGroupPolicy(
            self,
            request: models.DetachWorkGroupPolicyRequest,
            opts: Dict = None,
    ) -> models.DetachWorkGroupPolicyResponse:
        """
        解绑工作组鉴权策略
        """
        
        kwargs = {}
        kwargs["action"] = "DetachWorkGroupPolicy"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DetachWorkGroupPolicyResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DropDMSDatabase(
            self,
            request: models.DropDMSDatabaseRequest,
            opts: Dict = None,
    ) -> models.DropDMSDatabaseResponse:
        """
        DMS元数据删除库
        """
        
        kwargs = {}
        kwargs["action"] = "DropDMSDatabase"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DropDMSDatabaseResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DropDMSPartitions(
            self,
            request: models.DropDMSPartitionsRequest,
            opts: Dict = None,
    ) -> models.DropDMSPartitionsResponse:
        """
        DMS元数据删除分区
        """
        
        kwargs = {}
        kwargs["action"] = "DropDMSPartitions"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DropDMSPartitionsResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DropDMSTable(
            self,
            request: models.DropDMSTableRequest,
            opts: Dict = None,
    ) -> models.DropDMSTableResponse:
        """
        DMS元数据删除表
        """
        
        kwargs = {}
        kwargs["action"] = "DropDMSTable"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DropDMSTableResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def GenerateCreateMangedTableSql(
            self,
            request: models.GenerateCreateMangedTableSqlRequest,
            opts: Dict = None,
    ) -> models.GenerateCreateMangedTableSqlResponse:
        """
        生成创建托管表语句
        """
        
        kwargs = {}
        kwargs["action"] = "GenerateCreateMangedTableSql"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.GenerateCreateMangedTableSqlResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def GenerateInternalTable(
            self,
            request: models.GenerateInternalTableRequest,
            opts: Dict = None,
    ) -> models.GenerateInternalTableResponse:
        """
        建表
        """
        
        kwargs = {}
        kwargs["action"] = "GenerateInternalTable"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.GenerateInternalTableResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def GetExampleDetail(
            self,
            request: models.GetExampleDetailRequest,
            opts: Dict = None,
    ) -> models.GetExampleDetailResponse:
        """
        根据 exampleId 获取单个案例详情
        """
        
        kwargs = {}
        kwargs["action"] = "GetExampleDetail"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.GetExampleDetailResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def GetInferenceModel(
            self,
            request: models.GetInferenceModelRequest,
            opts: Dict = None,
    ) -> models.GetInferenceModelResponse:
        """
        获取单个模型详情
        """
        
        kwargs = {}
        kwargs["action"] = "GetInferenceModel"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.GetInferenceModelResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def GetInferenceService(
            self,
            request: models.GetInferenceServiceRequest,
            opts: Dict = None,
    ) -> models.GetInferenceServiceResponse:
        """
        获取单个推理服务详情
        """
        
        kwargs = {}
        kwargs["action"] = "GetInferenceService"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.GetInferenceServiceResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def GetJobSpec(
            self,
            request: models.GetJobSpecRequest,
            opts: Dict = None,
    ) -> models.GetJobSpecResponse:
        """
        根据配置ID获取作业配置详情
        """
        
        kwargs = {}
        kwargs["action"] = "GetJobSpec"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.GetJobSpecResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def GetLabDetail(
            self,
            request: models.GetLabDetailRequest,
            opts: Dict = None,
    ) -> models.GetLabDetailResponse:
        """
        获取实验室详情
        """
        
        kwargs = {}
        kwargs["action"] = "GetLabDetail"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.GetLabDetailResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def GetLabEvent(
            self,
            request: models.GetLabEventRequest,
            opts: Dict = None,
    ) -> models.GetLabEventResponse:
        """
        获取实验室的事件流（基于 K8s Event + CLS 日志）
        """
        
        kwargs = {}
        kwargs["action"] = "GetLabEvent"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.GetLabEventResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def GetLabHistory(
            self,
            request: models.GetLabHistoryRequest,
            opts: Dict = None,
    ) -> models.GetLabHistoryResponse:
        """
        获取实验室的状态变更历史记录
        """
        
        kwargs = {}
        kwargs["action"] = "GetLabHistory"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.GetLabHistoryResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def GetLabPodYaml(
            self,
            request: models.GetLabPodYamlRequest,
            opts: Dict = None,
    ) -> models.GetLabPodYamlResponse:
        """
        获取数据实验室Pod的YAML内容
        """
        
        kwargs = {}
        kwargs["action"] = "GetLabPodYaml"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.GetLabPodYamlResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def GetLabPods(
            self,
            request: models.GetLabPodsRequest,
            opts: Dict = None,
    ) -> models.GetLabPodsResponse:
        """
        获取数据实验室的Pod列表
        """
        
        kwargs = {}
        kwargs["action"] = "GetLabPods"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.GetLabPodsResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def GetLabServiceUrls(
            self,
            request: models.GetLabServiceUrlsRequest,
            opts: Dict = None,
    ) -> models.GetLabServiceUrlsResponse:
        """
        获取实验室ide访问地址
        """
        
        kwargs = {}
        kwargs["action"] = "GetLabServiceUrls"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.GetLabServiceUrlsResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def GetLabYaml(
            self,
            request: models.GetLabYamlRequest,
            opts: Dict = None,
    ) -> models.GetLabYamlResponse:
        """
        获取数据实验室对应的RayCluster YAML内容
        """
        
        kwargs = {}
        kwargs["action"] = "GetLabYaml"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.GetLabYamlResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def GetModelConfig(
            self,
            request: models.GetModelConfigRequest,
            opts: Dict = None,
    ) -> models.GetModelConfigResponse:
        """
        获取模型 config.json 配置（默认最新版本）
        """
        
        kwargs = {}
        kwargs["action"] = "GetModelConfig"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.GetModelConfigResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def GetModelFiles(
            self,
            request: models.GetModelFilesRequest,
            opts: Dict = None,
    ) -> models.GetModelFilesResponse:
        """
        获取模型文件树（默认最新版本）
        """
        
        kwargs = {}
        kwargs["action"] = "GetModelFiles"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.GetModelFilesResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def GetModelReadme(
            self,
            request: models.GetModelReadmeRequest,
            opts: Dict = None,
    ) -> models.GetModelReadmeResponse:
        """
        获取模型 README 信息（默认最新版本）
        """
        
        kwargs = {}
        kwargs["action"] = "GetModelReadme"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.GetModelReadmeResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def GetOptimizerPolicy(
            self,
            request: models.GetOptimizerPolicyRequest,
            opts: Dict = None,
    ) -> models.GetOptimizerPolicyResponse:
        """
        GetOptimizerPolicy
        """
        
        kwargs = {}
        kwargs["action"] = "GetOptimizerPolicy"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.GetOptimizerPolicyResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def GetRayCluster(
            self,
            request: models.GetRayClusterRequest,
            opts: Dict = None,
    ) -> models.GetRayClusterResponse:
        """
        获取Ray集群详情请求
        """
        
        kwargs = {}
        kwargs["action"] = "GetRayCluster"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.GetRayClusterResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def GetRayClusterEvent(
            self,
            request: models.GetRayClusterEventRequest,
            opts: Dict = None,
    ) -> models.GetRayClusterEventResponse:
        """
        获取Ray集群的事件流（基于 K8s Event + CLS 日志）
        """
        
        kwargs = {}
        kwargs["action"] = "GetRayClusterEvent"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.GetRayClusterEventResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def GetRayClusterHistory(
            self,
            request: models.GetRayClusterHistoryRequest,
            opts: Dict = None,
    ) -> models.GetRayClusterHistoryResponse:
        """
        获取集群状态历史
        """
        
        kwargs = {}
        kwargs["action"] = "GetRayClusterHistory"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.GetRayClusterHistoryResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def GetRayClusterPodYaml(
            self,
            request: models.GetRayClusterPodYamlRequest,
            opts: Dict = None,
    ) -> models.GetRayClusterPodYamlResponse:
        """
        获取集群Pod的YAML内容
        """
        
        kwargs = {}
        kwargs["action"] = "GetRayClusterPodYaml"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.GetRayClusterPodYamlResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def GetRayClusterPods(
            self,
            request: models.GetRayClusterPodsRequest,
            opts: Dict = None,
    ) -> models.GetRayClusterPodsResponse:
        """
        获取集群的Pod列表
        """
        
        kwargs = {}
        kwargs["action"] = "GetRayClusterPods"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.GetRayClusterPodsResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def GetRayClusterYaml(
            self,
            request: models.GetRayClusterYamlRequest,
            opts: Dict = None,
    ) -> models.GetRayClusterYamlResponse:
        """
        获取RayCluster的YAML内容
        """
        
        kwargs = {}
        kwargs["action"] = "GetRayClusterYaml"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.GetRayClusterYamlResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def GetRayJob(
            self,
            request: models.GetRayJobRequest,
            opts: Dict = None,
    ) -> models.GetRayJobResponse:
        """
        根据任务ID获取Ray任务详情
        """
        
        kwargs = {}
        kwargs["action"] = "GetRayJob"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.GetRayJobResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def GetRayJobEvent(
            self,
            request: models.GetRayJobEventRequest,
            opts: Dict = None,
    ) -> models.GetRayJobEventResponse:
        """
        通过 ResourceManager 调用 CLS SearchLog API 查询作业相关日志。不返回总数，使用 Context 进行翻页，ListOver 标识是否还有更多数据。
        """
        
        kwargs = {}
        kwargs["action"] = "GetRayJobEvent"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.GetRayJobEventResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def GetRayJobHistory(
            self,
            request: models.GetRayJobHistoryRequest,
            opts: Dict = None,
    ) -> models.GetRayJobHistoryResponse:
        """
        根据任务ID获取Ray任务的历史执行记录
        """
        
        kwargs = {}
        kwargs["action"] = "GetRayJobHistory"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.GetRayJobHistoryResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def GetRayJobPodYaml(
            self,
            request: models.GetRayJobPodYamlRequest,
            opts: Dict = None,
    ) -> models.GetRayJobPodYamlResponse:
        """
        获取Pod的YAML内容
        """
        
        kwargs = {}
        kwargs["action"] = "GetRayJobPodYaml"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.GetRayJobPodYamlResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def GetRayJobPods(
            self,
            request: models.GetRayJobPodsRequest,
            opts: Dict = None,
    ) -> models.GetRayJobPodsResponse:
        """
        获取作业的Pod列表
        """
        
        kwargs = {}
        kwargs["action"] = "GetRayJobPods"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.GetRayJobPodsResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def GetRayJobYaml(
            self,
            request: models.GetRayJobYamlRequest,
            opts: Dict = None,
    ) -> models.GetRayJobYamlResponse:
        """
        获取RayJob的YAML内容
        """
        
        kwargs = {}
        kwargs["action"] = "GetRayJobYaml"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.GetRayJobYamlResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def GetResourceConfig(
            self,
            request: models.GetResourceConfigRequest,
            opts: Dict = None,
    ) -> models.GetResourceConfigResponse:
        """
        获取资源配置模板详情
        """
        
        kwargs = {}
        kwargs["action"] = "GetResourceConfig"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.GetResourceConfigResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def GrantDLCCatalogAccess(
            self,
            request: models.GrantDLCCatalogAccessRequest,
            opts: Dict = None,
    ) -> models.GrantDLCCatalogAccessResponse:
        """
        授权访问DLC Catalog
        """
        
        kwargs = {}
        kwargs["action"] = "GrantDLCCatalogAccess"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.GrantDLCCatalogAccessResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ImportExternalCluster(
            self,
            request: models.ImportExternalClusterRequest,
            opts: Dict = None,
    ) -> models.ImportExternalClusterResponse:
        """
        通过 ClusterType 区分两种导入模式：TKE（直接导入裸 TKE 集群，ClusterId 为 TKE 集群 ID）或 EMR（通过 EMR 集群导入，ClusterId 为 EMR 集群 ID，底层会关联查询对应的 TKE 集群 ID 一并落库）。两种模式均将 TKE 集群 ID 存入 tke_cluster 表。接口是异步的，返回的 WorkflowId 可用于轮询注册进度；ResourcePoolId / ResourcePoolCode 为资源池的唯一标识。
        """
        
        kwargs = {}
        kwargs["action"] = "ImportExternalCluster"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ImportExternalClusterResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ImportTkeCluster(
            self,
            request: models.ImportTkeClusterRequest,
            opts: Dict = None,
    ) -> models.ImportTkeClusterResponse:
        """
        将用户在控制台选择的 EMR-TKE 集群及配套的 COS Bucket、Prometheus 实例、负载均衡、容器日志主题等资源，注册为 DLC 的外部资源池（EXTERNAL_TKE）。接口是异步的，返回的 WorkflowId 可用于轮询注册进度；ResourcePoolId / ResourcePoolCode 为资源池的唯一标识。
        """
        
        kwargs = {}
        kwargs["action"] = "ImportTkeCluster"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ImportTkeClusterResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def InitializeTCLake(
            self,
            request: models.InitializeTCLakeRequest,
            opts: Dict = None,
    ) -> models.InitializeTCLakeResponse:
        """
        开通TCLake
        """
        
        kwargs = {}
        kwargs["action"] = "InitializeTCLake"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.InitializeTCLakeResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def LaunchStandardEngineResourceGroups(
            self,
            request: models.LaunchStandardEngineResourceGroupsRequest,
            opts: Dict = None,
    ) -> models.LaunchStandardEngineResourceGroupsResponse:
        """
        启动标准引擎资源组
        """
        
        kwargs = {}
        kwargs["action"] = "LaunchStandardEngineResourceGroups"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.LaunchStandardEngineResourceGroupsResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ListApiKeys(
            self,
            request: models.ListApiKeysRequest,
            opts: Dict = None,
    ) -> models.ListApiKeysResponse:
        """
        列出 API Key
        """
        
        kwargs = {}
        kwargs["action"] = "ListApiKeys"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ListApiKeysResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ListAvailableApiKeys(
            self,
            request: models.ListAvailableApiKeysRequest,
            opts: Dict = None,
    ) -> models.ListAvailableApiKeysResponse:
        """
        列出空闲 API Key（未绑定服务）
        """
        
        kwargs = {}
        kwargs["action"] = "ListAvailableApiKeys"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ListAvailableApiKeysResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ListBenchmarkSummary(
            self,
            request: models.ListBenchmarkSummaryRequest,
            opts: Dict = None,
    ) -> models.ListBenchmarkSummaryResponse:
        """
        查询评测排行榜（所有模型的评测汇总数据）
        """
        
        kwargs = {}
        kwargs["action"] = "ListBenchmarkSummary"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ListBenchmarkSummaryResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ListBenchmarkTasks(
            self,
            request: models.ListBenchmarkTasksRequest,
            opts: Dict = None,
    ) -> models.ListBenchmarkTasksResponse:
        """
        列出性能评测任务
        """
        
        kwargs = {}
        kwargs["action"] = "ListBenchmarkTasks"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ListBenchmarkTasksResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ListClusterGroups(
            self,
            request: models.ListClusterGroupsRequest,
            opts: Dict = None,
    ) -> models.ListClusterGroupsResponse:
        """
        列出所有集群组
        """
        
        kwargs = {}
        kwargs["action"] = "ListClusterGroups"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ListClusterGroupsResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ListDeploymentReplicas(
            self,
            request: models.ListDeploymentReplicasRequest,
            opts: Dict = None,
    ) -> models.ListDeploymentReplicasResponse:
        """
        列出部署的副本列表
        """
        
        kwargs = {}
        kwargs["action"] = "ListDeploymentReplicas"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ListDeploymentReplicasResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ListDeployments(
            self,
            request: models.ListDeploymentsRequest,
            opts: Dict = None,
    ) -> models.ListDeploymentsResponse:
        """
        列出推理服务的部署列表
        """
        
        kwargs = {}
        kwargs["action"] = "ListDeployments"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ListDeploymentsResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ListExampleCategories(
            self,
            request: models.ListExampleCategoriesRequest,
            opts: Dict = None,
    ) -> models.ListExampleCategoriesResponse:
        """
        获取所有案例分类
        """
        
        kwargs = {}
        kwargs["action"] = "ListExampleCategories"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ListExampleCategoriesResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ListExampleDifficulties(
            self,
            request: models.ListExampleDifficultiesRequest,
            opts: Dict = None,
    ) -> models.ListExampleDifficultiesResponse:
        """
        获取所有案例分类
        """
        
        kwargs = {}
        kwargs["action"] = "ListExampleDifficulties"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ListExampleDifficultiesResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ListExampleTags(
            self,
            request: models.ListExampleTagsRequest,
            opts: Dict = None,
    ) -> models.ListExampleTagsResponse:
        """
        返回标签去重列表，按出现频次从高到低排序。
        """
        
        kwargs = {}
        kwargs["action"] = "ListExampleTags"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ListExampleTagsResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ListExamples(
            self,
            request: models.ListExamplesRequest,
            opts: Dict = None,
    ) -> models.ListExamplesResponse:
        """
        案例列表
        """
        
        kwargs = {}
        kwargs["action"] = "ListExamples"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ListExamplesResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ListImages(
            self,
            request: models.ListImagesRequest,
            opts: Dict = None,
    ) -> models.ListImagesResponse:
        """
        列出所有镜像
        """
        
        kwargs = {}
        kwargs["action"] = "ListImages"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ListImagesResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ListInferenceEngines(
            self,
            request: models.ListInferenceEnginesRequest,
            opts: Dict = None,
    ) -> models.ListInferenceEnginesResponse:
        """
        列出推理引擎
        """
        
        kwargs = {}
        kwargs["action"] = "ListInferenceEngines"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ListInferenceEnginesResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ListInferenceModels(
            self,
            request: models.ListInferenceModelsRequest,
            opts: Dict = None,
    ) -> models.ListInferenceModelsResponse:
        """
        列出推理模型（支持关键词过滤 + 分页）
        """
        
        kwargs = {}
        kwargs["action"] = "ListInferenceModels"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ListInferenceModelsResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ListInferenceServices(
            self,
            request: models.ListInferenceServicesRequest,
            opts: Dict = None,
    ) -> models.ListInferenceServicesResponse:
        """
        列出推理服务（支持关键词和状态过滤 + 分页）
        """
        
        kwargs = {}
        kwargs["action"] = "ListInferenceServices"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ListInferenceServicesResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ListJobSpecs(
            self,
            request: models.ListJobSpecsRequest,
            opts: Dict = None,
    ) -> models.ListJobSpecsResponse:
        """
        分页查询作业配置列表
        """
        
        kwargs = {}
        kwargs["action"] = "ListJobSpecs"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ListJobSpecsResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ListJobsBySpec(
            self,
            request: models.ListJobsBySpecRequest,
            opts: Dict = None,
    ) -> models.ListJobsBySpecResponse:
        """
        分页查询某作业配置下产生的所有作业实例
        """
        
        kwargs = {}
        kwargs["action"] = "ListJobsBySpec"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ListJobsBySpecResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ListLabs(
            self,
            request: models.ListLabsRequest,
            opts: Dict = None,
    ) -> models.ListLabsResponse:
        """
        列出实验室列表
        """
        
        kwargs = {}
        kwargs["action"] = "ListLabs"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ListLabsResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ListMlflowServerTrainingInstances(
            self,
            request: models.ListMlflowServerTrainingInstancesRequest,
            opts: Dict = None,
    ) -> models.ListMlflowServerTrainingInstancesResponse:
        """
        查询 MlFlow Server 关联的训练实例列表
        """
        
        kwargs = {}
        kwargs["action"] = "ListMlflowServerTrainingInstances"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ListMlflowServerTrainingInstancesResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ListMlflowServers(
            self,
            request: models.ListMlflowServersRequest,
            opts: Dict = None,
    ) -> models.ListMlflowServersResponse:
        """
        列出 MlFlow Server
        """
        
        kwargs = {}
        kwargs["action"] = "ListMlflowServers"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ListMlflowServersResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ListModelVersions(
            self,
            request: models.ListModelVersionsRequest,
            opts: Dict = None,
    ) -> models.ListModelVersionsResponse:
        """
        列出模型所有版本
        """
        
        kwargs = {}
        kwargs["action"] = "ListModelVersions"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ListModelVersionsResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ListRayClusterJobs(
            self,
            request: models.ListRayClusterJobsRequest,
            opts: Dict = None,
    ) -> models.ListRayClusterJobsResponse:
        """
        查询指定 Ray 集群下提交的所有作业，分页返回。底层委托给 ListRayJobs，强制注入 ClusterId 作为过滤条件。
        """
        
        kwargs = {}
        kwargs["action"] = "ListRayClusterJobs"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ListRayClusterJobsResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ListRayClusters(
            self,
            request: models.ListRayClustersRequest,
            opts: Dict = None,
    ) -> models.ListRayClustersResponse:
        """
        列出所有集群
        """
        
        kwargs = {}
        kwargs["action"] = "ListRayClusters"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ListRayClustersResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ListRayJobs(
            self,
            request: models.ListRayJobsRequest,
            opts: Dict = None,
    ) -> models.ListRayJobsResponse:
        """
        根据集群ID列出所有Ray任务
        """
        
        kwargs = {}
        kwargs["action"] = "ListRayJobs"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ListRayJobsResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ListRegionLbs(
            self,
            request: models.ListRegionLbsRequest,
            opts: Dict = None,
    ) -> models.ListRegionLbsResponse:
        """
        列出用户在指定地域下的 CLB 负载均衡实例，返回实例 ID、名称与网络类型（OPEN/INTERNAL）。
        """
        
        kwargs = {}
        kwargs["action"] = "ListRegionLbs"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ListRegionLbsResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ListResourceConfigs(
            self,
            request: models.ListResourceConfigsRequest,
            opts: Dict = None,
    ) -> models.ListResourceConfigsResponse:
        """
        列出所有资源配置模板
        """
        
        kwargs = {}
        kwargs["action"] = "ListResourceConfigs"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ListResourceConfigsResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ListServiceApiKeys(
            self,
            request: models.ListServiceApiKeysRequest,
            opts: Dict = None,
    ) -> models.ListServiceApiKeysResponse:
        """
        列出指定推理服务绑定的 API Key
        """
        
        kwargs = {}
        kwargs["action"] = "ListServiceApiKeys"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ListServiceApiKeysResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ListTaskJobLogDetail(
            self,
            request: models.ListTaskJobLogDetailRequest,
            opts: Dict = None,
    ) -> models.ListTaskJobLogDetailResponse:
        """
        本接口（ListTaskJobLogDetail）用于获取spark 作业任务日志详情
        """
        
        kwargs = {}
        kwargs["action"] = "ListTaskJobLogDetail"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ListTaskJobLogDetailResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ListTaskJobLogName(
            self,
            request: models.ListTaskJobLogNameRequest,
            opts: Dict = None,
    ) -> models.ListTaskJobLogNameResponse:
        """
        本接口（ListTaskJobLogName）用于获取spark-jar日志名称列表
        """
        
        kwargs = {}
        kwargs["action"] = "ListTaskJobLogName"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ListTaskJobLogNameResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ListTkeCosBuckets(
            self,
            request: models.ListTkeCosBucketsRequest,
            opts: Dict = None,
    ) -> models.ListTkeCosBucketsResponse:
        """
        获取tke纳管cos列表
        """
        
        kwargs = {}
        kwargs["action"] = "ListTkeCosBuckets"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ListTkeCosBucketsResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ListTrainingJobInstance(
            self,
            request: models.ListTrainingJobInstanceRequest,
            opts: Dict = None,
    ) -> models.ListTrainingJobInstanceResponse:
        """
        列出训练作业实例
        """
        
        kwargs = {}
        kwargs["action"] = "ListTrainingJobInstance"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ListTrainingJobInstanceResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ListTrainingJobSpec(
            self,
            request: models.ListTrainingJobSpecRequest,
            opts: Dict = None,
    ) -> models.ListTrainingJobSpecResponse:
        """
        获取训练作业配置的列表。
        """
        
        kwargs = {}
        kwargs["action"] = "ListTrainingJobSpec"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ListTrainingJobSpecResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def LockMetaData(
            self,
            request: models.LockMetaDataRequest,
            opts: Dict = None,
    ) -> models.LockMetaDataResponse:
        """
        元数据锁
        """
        
        kwargs = {}
        kwargs["action"] = "LockMetaData"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.LockMetaDataResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ModifyAdvancedStoreLocation(
            self,
            request: models.ModifyAdvancedStoreLocationRequest,
            opts: Dict = None,
    ) -> models.ModifyAdvancedStoreLocationResponse:
        """
        修改sql查询界面高级设置。
        """
        
        kwargs = {}
        kwargs["action"] = "ModifyAdvancedStoreLocation"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ModifyAdvancedStoreLocationResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ModifyClusterPriority(
            self,
            request: models.ModifyClusterPriorityRequest,
            opts: Dict = None,
    ) -> models.ModifyClusterPriorityResponse:
        """
        修改集群的调度优先级（1-9，数字越大优先级越高）
        """
        
        kwargs = {}
        kwargs["action"] = "ModifyClusterPriority"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ModifyClusterPriorityResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ModifyDataEngineDescription(
            self,
            request: models.ModifyDataEngineDescriptionRequest,
            opts: Dict = None,
    ) -> models.ModifyDataEngineDescriptionResponse:
        """
        修改引擎描述信息
        """
        
        kwargs = {}
        kwargs["action"] = "ModifyDataEngineDescription"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ModifyDataEngineDescriptionResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ModifyGovernEventRule(
            self,
            request: models.ModifyGovernEventRuleRequest,
            opts: Dict = None,
    ) -> models.ModifyGovernEventRuleResponse:
        """
        修改数据治理事件阈值
        """
        
        kwargs = {}
        kwargs["action"] = "ModifyGovernEventRule"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ModifyGovernEventRuleResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ModifyLabPriority(
            self,
            request: models.ModifyLabPriorityRequest,
            opts: Dict = None,
    ) -> models.ModifyLabPriorityResponse:
        """
        修改实验室的调度优先级（1-9，数字越大优先级越高）
        """
        
        kwargs = {}
        kwargs["action"] = "ModifyLabPriority"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ModifyLabPriorityResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ModifyPartitionDescription(
            self,
            request: models.ModifyPartitionDescriptionRequest,
            opts: Dict = None,
    ) -> models.ModifyPartitionDescriptionResponse:
        """
        修改分区描述
        """
        
        kwargs = {}
        kwargs["action"] = "ModifyPartitionDescription"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ModifyPartitionDescriptionResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ModifyPartitionQueue(
            self,
            request: models.ModifyPartitionQueueRequest,
            opts: Dict = None,
    ) -> models.ModifyPartitionQueueResponse:
        """
        编辑资源队列：根据队列ID修改指定资源队列的名称、描述、资源规格列表和队列类型等信息。
        """
        
        kwargs = {}
        kwargs["action"] = "ModifyPartitionQueue"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ModifyPartitionQueueResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ModifySparkApp(
            self,
            request: models.ModifySparkAppRequest,
            opts: Dict = None,
    ) -> models.ModifySparkAppResponse:
        """
        更新spark作业
        """
        
        kwargs = {}
        kwargs["action"] = "ModifySparkApp"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ModifySparkAppResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ModifySparkAppBatch(
            self,
            request: models.ModifySparkAppBatchRequest,
            opts: Dict = None,
    ) -> models.ModifySparkAppBatchResponse:
        """
        本接口（ModifySparkAppBatch）用于批量修改Spark作业参数配置
        """
        
        kwargs = {}
        kwargs["action"] = "ModifySparkAppBatch"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ModifySparkAppBatchResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ModifySparkAppForTDLC(
            self,
            request: models.ModifySparkAppForTDLCRequest,
            opts: Dict = None,
    ) -> models.ModifySparkAppForTDLCResponse:
        """
        更新tdlc spark作业
        """
        
        kwargs = {}
        kwargs["action"] = "ModifySparkAppForTDLC"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ModifySparkAppForTDLCResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ModifyTrainingJobSpec(
            self,
            request: models.ModifyTrainingJobSpecRequest,
            opts: Dict = None,
    ) -> models.ModifyTrainingJobSpecResponse:
        """
        就地更新训练作业配置
        """
        
        kwargs = {}
        kwargs["action"] = "ModifyTrainingJobSpec"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ModifyTrainingJobSpecResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ModifyUser(
            self,
            request: models.ModifyUserRequest,
            opts: Dict = None,
    ) -> models.ModifyUserResponse:
        """
        修改用户信息
        """
        
        kwargs = {}
        kwargs["action"] = "ModifyUser"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ModifyUserResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ModifyUserType(
            self,
            request: models.ModifyUserTypeRequest,
            opts: Dict = None,
    ) -> models.ModifyUserTypeResponse:
        """
        修改用户类型。只有管理员用户能够调用该接口进行操作
        """
        
        kwargs = {}
        kwargs["action"] = "ModifyUserType"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ModifyUserTypeResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ModifyWorkGroup(
            self,
            request: models.ModifyWorkGroupRequest,
            opts: Dict = None,
    ) -> models.ModifyWorkGroupResponse:
        """
        修改工作组信息
        """
        
        kwargs = {}
        kwargs["action"] = "ModifyWorkGroup"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ModifyWorkGroupResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def PauseStandardEngineResourceGroups(
            self,
            request: models.PauseStandardEngineResourceGroupsRequest,
            opts: Dict = None,
    ) -> models.PauseStandardEngineResourceGroupsResponse:
        """
        暂停标准引擎session
        """
        
        kwargs = {}
        kwargs["action"] = "PauseStandardEngineResourceGroups"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.PauseStandardEngineResourceGroupsResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def QueryDashboardOverview(
            self,
            request: models.QueryDashboardOverviewRequest,
            opts: Dict = None,
    ) -> models.QueryDashboardOverviewResponse:
        """
        返回指定时间范围内所有推理服务的聚合 KPI 值。
        """
        
        kwargs = {}
        kwargs["action"] = "QueryDashboardOverview"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.QueryDashboardOverviewResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def QueryDashboardServiceList(
            self,
            request: models.QueryDashboardServiceListRequest,
            opts: Dict = None,
    ) -> models.QueryDashboardServiceListResponse:
        """
        查询监控大盘服务列表
        """
        
        kwargs = {}
        kwargs["action"] = "QueryDashboardServiceList"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.QueryDashboardServiceListResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def QueryInternalTableWarehouse(
            self,
            request: models.QueryInternalTableWarehouseRequest,
            opts: Dict = None,
    ) -> models.QueryInternalTableWarehouseResponse:
        """
        本接口（QueryInternalTableWarehouse）用于获取原生表warehouse路径
        """
        
        kwargs = {}
        kwargs["action"] = "QueryInternalTableWarehouse"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.QueryInternalTableWarehouseResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def QueryMonitorOverview(
            self,
            request: models.QueryMonitorOverviewRequest,
            opts: Dict = None,
    ) -> models.QueryMonitorOverviewResponse:
        """
        查询监控概览数据（瞬时值）
        """
        
        kwargs = {}
        kwargs["action"] = "QueryMonitorOverview"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.QueryMonitorOverviewResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def QueryResult(
            self,
            request: models.QueryResultRequest,
            opts: Dict = None,
    ) -> models.QueryResultResponse:
        """
        获取任务结果查询
        """
        
        kwargs = {}
        kwargs["action"] = "QueryResult"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.QueryResultResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def QueryTaskCostDetail(
            self,
            request: models.QueryTaskCostDetailRequest,
            opts: Dict = None,
    ) -> models.QueryTaskCostDetailResponse:
        """
        该接口（QueryTaskCostDetail）用于查询任务消耗明细
        """
        
        kwargs = {}
        kwargs["action"] = "QueryTaskCostDetail"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.QueryTaskCostDetailResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def RegisterThirdPartyAccessUser(
            self,
            request: models.RegisterThirdPartyAccessUserRequest,
            opts: Dict = None,
    ) -> models.RegisterThirdPartyAccessUserResponse:
        """
        本接口（RegisterThirdPartyAccessUser）用于开通第三方平台访问
        """
        
        kwargs = {}
        kwargs["action"] = "RegisterThirdPartyAccessUser"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.RegisterThirdPartyAccessUserResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def RenewDataEngine(
            self,
            request: models.RenewDataEngineRequest,
            opts: Dict = None,
    ) -> models.RenewDataEngineResponse:
        """
        续费数据引擎
        """
        
        kwargs = {}
        kwargs["action"] = "RenewDataEngine"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.RenewDataEngineResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ReportHeartbeatMetaData(
            self,
            request: models.ReportHeartbeatMetaDataRequest,
            opts: Dict = None,
    ) -> models.ReportHeartbeatMetaDataResponse:
        """
        上报元数据心跳
        """
        
        kwargs = {}
        kwargs["action"] = "ReportHeartbeatMetaData"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ReportHeartbeatMetaDataResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def RerunBenchmarkTask(
            self,
            request: models.RerunBenchmarkTaskRequest,
            opts: Dict = None,
    ) -> models.RerunBenchmarkTaskResponse:
        """
        重新运行性能评测任务
        """
        
        kwargs = {}
        kwargs["action"] = "RerunBenchmarkTask"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.RerunBenchmarkTaskResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def RestartDataEngine(
            self,
            request: models.RestartDataEngineRequest,
            opts: Dict = None,
    ) -> models.RestartDataEngineResponse:
        """
        重启引擎
        """
        
        kwargs = {}
        kwargs["action"] = "RestartDataEngine"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.RestartDataEngineResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def RestartDeployment(
            self,
            request: models.RestartDeploymentRequest,
            opts: Dict = None,
    ) -> models.RestartDeploymentResponse:
        """
        再次运行部署（以当前配置重新部署）
        """
        
        kwargs = {}
        kwargs["action"] = "RestartDeployment"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.RestartDeploymentResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def RestartInferenceService(
            self,
            request: models.RestartInferenceServiceRequest,
            opts: Dict = None,
    ) -> models.RestartInferenceServiceResponse:
        """
        重启推理服务（操作所有部署）。
        """
        
        kwargs = {}
        kwargs["action"] = "RestartInferenceService"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.RestartInferenceServiceResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ResumeTrainingJobInstance(
            self,
            request: models.ResumeTrainingJobInstanceRequest,
            opts: Dict = None,
    ) -> models.ResumeTrainingJobInstanceResponse:
        """
        断点续训（克隆实例）
        """
        
        kwargs = {}
        kwargs["action"] = "ResumeTrainingJobInstance"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ResumeTrainingJobInstanceResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def RevokeDLCCatalogAccess(
            self,
            request: models.RevokeDLCCatalogAccessRequest,
            opts: Dict = None,
    ) -> models.RevokeDLCCatalogAccessResponse:
        """
        撤销DLC Catalog访问权限
        """
        
        kwargs = {}
        kwargs["action"] = "RevokeDLCCatalogAccess"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.RevokeDLCCatalogAccessResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def RollbackDataEngineImage(
            self,
            request: models.RollbackDataEngineImageRequest,
            opts: Dict = None,
    ) -> models.RollbackDataEngineImageResponse:
        """
        回滚引擎镜像版本
        """
        
        kwargs = {}
        kwargs["action"] = "RollbackDataEngineImage"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.RollbackDataEngineImageResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def RunJobSpec(
            self,
            request: models.RunJobSpecRequest,
            opts: Dict = None,
    ) -> models.RunJobSpecResponse:
        """
        基于指定作业配置提交一次作业实例
        """
        
        kwargs = {}
        kwargs["action"] = "RunJobSpec"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.RunJobSpecResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def SetOptimizerPolicy(
            self,
            request: models.SetOptimizerPolicyRequest,
            opts: Dict = None,
    ) -> models.SetOptimizerPolicyResponse:
        """
        设置优化策略的接口
        """
        
        kwargs = {}
        kwargs["action"] = "SetOptimizerPolicy"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.SetOptimizerPolicyResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def StartLab(
            self,
            request: models.StartLabRequest,
            opts: Dict = None,
    ) -> models.StartLabResponse:
        """
        启动实验室
        """
        
        kwargs = {}
        kwargs["action"] = "StartLab"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.StartLabResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def StartMlflowServer(
            self,
            request: models.StartMlflowServerRequest,
            opts: Dict = None,
    ) -> models.StartMlflowServerResponse:
        """
        启动 MlFlow Server（apply K8s 资源，幂等可重试）
        """
        
        kwargs = {}
        kwargs["action"] = "StartMlflowServer"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.StartMlflowServerResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def StartRayCluster(
            self,
            request: models.StartRayClusterRequest,
            opts: Dict = None,
    ) -> models.StartRayClusterResponse:
        """
        启动集群
        """
        
        kwargs = {}
        kwargs["action"] = "StartRayCluster"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.StartRayClusterResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def StopBenchmarkTask(
            self,
            request: models.StopBenchmarkTaskRequest,
            opts: Dict = None,
    ) -> models.StopBenchmarkTaskResponse:
        """
        停止性能评测任务
        """
        
        kwargs = {}
        kwargs["action"] = "StopBenchmarkTask"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.StopBenchmarkTaskResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def StopDeployment(
            self,
            request: models.StopDeploymentRequest,
            opts: Dict = None,
    ) -> models.StopDeploymentResponse:
        """
        停止部署
        """
        
        kwargs = {}
        kwargs["action"] = "StopDeployment"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.StopDeploymentResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def StopInferenceService(
            self,
            request: models.StopInferenceServiceRequest,
            opts: Dict = None,
    ) -> models.StopInferenceServiceResponse:
        """
        停止推理服务（操作所有部署）。
        """
        
        kwargs = {}
        kwargs["action"] = "StopInferenceService"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.StopInferenceServiceResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def StopLab(
            self,
            request: models.StopLabRequest,
            opts: Dict = None,
    ) -> models.StopLabResponse:
        """
        停止实验室
        """
        
        kwargs = {}
        kwargs["action"] = "StopLab"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.StopLabResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def StopMlflowServer(
            self,
            request: models.StopMlflowServerRequest,
            opts: Dict = None,
    ) -> models.StopMlflowServerResponse:
        """
        停止 MlFlow Server
        """
        
        kwargs = {}
        kwargs["action"] = "StopMlflowServer"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.StopMlflowServerResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def StopRayCluster(
            self,
            request: models.StopRayClusterRequest,
            opts: Dict = None,
    ) -> models.StopRayClusterResponse:
        """
        停止集群
        """
        
        kwargs = {}
        kwargs["action"] = "StopRayCluster"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.StopRayClusterResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def SubmitTrainingJob(
            self,
            request: models.SubmitTrainingJobRequest,
            opts: Dict = None,
    ) -> models.SubmitTrainingJobResponse:
        """
        断点续训（克隆实例）
        """
        
        kwargs = {}
        kwargs["action"] = "SubmitTrainingJob"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.SubmitTrainingJobResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def SuspendResumeDataEngine(
            self,
            request: models.SuspendResumeDataEngineRequest,
            opts: Dict = None,
    ) -> models.SuspendResumeDataEngineResponse:
        """
        本接口用于控制挂起或启动数据引擎
        """
        
        kwargs = {}
        kwargs["action"] = "SuspendResumeDataEngine"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.SuspendResumeDataEngineResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def SwitchDataEngine(
            self,
            request: models.SwitchDataEngineRequest,
            opts: Dict = None,
    ) -> models.SwitchDataEngineResponse:
        """
        切换主备集群
        """
        
        kwargs = {}
        kwargs["action"] = "SwitchDataEngine"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.SwitchDataEngineResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def SwitchDataEngineImage(
            self,
            request: models.SwitchDataEngineImageRequest,
            opts: Dict = None,
    ) -> models.SwitchDataEngineImageResponse:
        """
        切换引擎镜像版本
        """
        
        kwargs = {}
        kwargs["action"] = "SwitchDataEngineImage"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.SwitchDataEngineImageResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def UnbindWorkGroupsFromUser(
            self,
            request: models.UnbindWorkGroupsFromUserRequest,
            opts: Dict = None,
    ) -> models.UnbindWorkGroupsFromUserResponse:
        """
        解绑用户上的用户组
        """
        
        kwargs = {}
        kwargs["action"] = "UnbindWorkGroupsFromUser"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.UnbindWorkGroupsFromUserResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def UnboundDatasourceHouse(
            self,
            request: models.UnboundDatasourceHouseRequest,
            opts: Dict = None,
    ) -> models.UnboundDatasourceHouseResponse:
        """
        解绑数据源与队列
        """
        
        kwargs = {}
        kwargs["action"] = "UnboundDatasourceHouse"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.UnboundDatasourceHouseResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def UnlockMetaData(
            self,
            request: models.UnlockMetaDataRequest,
            opts: Dict = None,
    ) -> models.UnlockMetaDataResponse:
        """
        元数据解锁
        """
        
        kwargs = {}
        kwargs["action"] = "UnlockMetaData"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.UnlockMetaDataResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def UpdateApiKeyStatus(
            self,
            request: models.UpdateApiKeyStatusRequest,
            opts: Dict = None,
    ) -> models.UpdateApiKeyStatusResponse:
        """
        更新 API Key 状态
        """
        
        kwargs = {}
        kwargs["action"] = "UpdateApiKeyStatus"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.UpdateApiKeyStatusResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def UpdateClusterGroup(
            self,
            request: models.UpdateClusterGroupRequest,
            opts: Dict = None,
    ) -> models.UpdateClusterGroupResponse:
        """
        更新集群组
        """
        
        kwargs = {}
        kwargs["action"] = "UpdateClusterGroup"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.UpdateClusterGroupResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def UpdateDataEngine(
            self,
            request: models.UpdateDataEngineRequest,
            opts: Dict = None,
    ) -> models.UpdateDataEngineResponse:
        """
        本接口用于更新数据引擎配置
        """
        
        kwargs = {}
        kwargs["action"] = "UpdateDataEngine"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.UpdateDataEngineResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def UpdateDataEngineConfig(
            self,
            request: models.UpdateDataEngineConfigRequest,
            opts: Dict = None,
    ) -> models.UpdateDataEngineConfigResponse:
        """
        用户某种操作，触发引擎配置修改
        """
        
        kwargs = {}
        kwargs["action"] = "UpdateDataEngineConfig"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.UpdateDataEngineConfigResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def UpdateDataMaskStrategy(
            self,
            request: models.UpdateDataMaskStrategyRequest,
            opts: Dict = None,
    ) -> models.UpdateDataMaskStrategyResponse:
        """
        更新数据脱敏策略
        """
        
        kwargs = {}
        kwargs["action"] = "UpdateDataMaskStrategy"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.UpdateDataMaskStrategyResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def UpdateDeployment(
            self,
            request: models.UpdateDeploymentRequest,
            opts: Dict = None,
    ) -> models.UpdateDeploymentResponse:
        """
        更新部署配置
        """
        
        kwargs = {}
        kwargs["action"] = "UpdateDeployment"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.UpdateDeploymentResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def UpdateEngineResourceGroupNetworkConfigInfo(
            self,
            request: models.UpdateEngineResourceGroupNetworkConfigInfoRequest,
            opts: Dict = None,
    ) -> models.UpdateEngineResourceGroupNetworkConfigInfoResponse:
        """
        更新标准引擎资源组网络配置信息
        """
        
        kwargs = {}
        kwargs["action"] = "UpdateEngineResourceGroupNetworkConfigInfo"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.UpdateEngineResourceGroupNetworkConfigInfoResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def UpdateInferenceModel(
            self,
            request: models.UpdateInferenceModelRequest,
            opts: Dict = None,
    ) -> models.UpdateInferenceModelResponse:
        """
        更新推理模型（编辑标签、描述、参数量）
        """
        
        kwargs = {}
        kwargs["action"] = "UpdateInferenceModel"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.UpdateInferenceModelResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def UpdateJobSpec(
            self,
            request: models.UpdateJobSpecRequest,
            opts: Dict = None,
    ) -> models.UpdateJobSpecResponse:
        """
        更新已有作业配置的字段
        """
        
        kwargs = {}
        kwargs["action"] = "UpdateJobSpec"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.UpdateJobSpecResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def UpdateJobSpecPriority(
            self,
            request: models.UpdateJobSpecPriorityRequest,
            opts: Dict = None,
    ) -> models.UpdateJobSpecPriorityResponse:
        """
        修改作业配置的调度优先级（1-9，数字越大优先级越高）
        """
        
        kwargs = {}
        kwargs["action"] = "UpdateJobSpecPriority"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.UpdateJobSpecPriorityResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def UpdateLab(
            self,
            request: models.UpdateLabRequest,
            opts: Dict = None,
    ) -> models.UpdateLabResponse:
        """
        更新实验室配置：仅在 CREATED / STOPPED / FAILED 终态可用；变更落 MySQL，下次 Start 按新 spec 创建 K8s 资源
        """
        
        kwargs = {}
        kwargs["action"] = "UpdateLab"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.UpdateLabResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def UpdateNetworkConnection(
            self,
            request: models.UpdateNetworkConnectionRequest,
            opts: Dict = None,
    ) -> models.UpdateNetworkConnectionResponse:
        """
        更新网络配置
        """
        
        kwargs = {}
        kwargs["action"] = "UpdateNetworkConnection"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.UpdateNetworkConnectionResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def UpdateRayCluster(
            self,
            request: models.UpdateRayClusterRequest,
            opts: Dict = None,
    ) -> models.UpdateRayClusterResponse:
        """
        更新集群配置：仅在 CREATED / STOPPED / FAILED 终态可用；变更落 MySQL，下次 Start 按新 spec 创建 K8s 资源
        """
        
        kwargs = {}
        kwargs["action"] = "UpdateRayCluster"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.UpdateRayClusterResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def UpdateRayJobPriority(
            self,
            request: models.UpdateRayJobPriorityRequest,
            opts: Dict = None,
    ) -> models.UpdateRayJobPriorityResponse:
        """
        更新处于 SUBMITTED/PENDING 状态的作业的优先级。仅 SUBMITTED/PENDING 状态的作业允许调整优先级。内部通过调用 Neutrino 的 UpdateJobConfig 接口更新 ENVIRONMENT 配置中的 priority 字段。
        """
        
        kwargs = {}
        kwargs["action"] = "UpdateRayJobPriority"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.UpdateRayJobPriorityResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def UpdateResourceConfig(
            self,
            request: models.UpdateResourceConfigRequest,
            opts: Dict = None,
    ) -> models.UpdateResourceConfigResponse:
        """
        更新资源配置模板
        """
        
        kwargs = {}
        kwargs["action"] = "UpdateResourceConfig"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.UpdateResourceConfigResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def UpdateRowFilter(
            self,
            request: models.UpdateRowFilterRequest,
            opts: Dict = None,
    ) -> models.UpdateRowFilterResponse:
        """
        此接口用于更新行过滤规则。注意只能更新过滤规则，不能更新规格对象catalog，database和table。
        """
        
        kwargs = {}
        kwargs["action"] = "UpdateRowFilter"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.UpdateRowFilterResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def UpdateServiceAuthConfig(
            self,
            request: models.UpdateServiceAuthConfigRequest,
            opts: Dict = None,
    ) -> models.UpdateServiceAuthConfigResponse:
        """
        更新推理服务的 API-Key 鉴权配置（启用/停用）
        """
        
        kwargs = {}
        kwargs["action"] = "UpdateServiceAuthConfig"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.UpdateServiceAuthConfigResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def UpdateStandardEngineResourceGroupBaseInfo(
            self,
            request: models.UpdateStandardEngineResourceGroupBaseInfoRequest,
            opts: Dict = None,
    ) -> models.UpdateStandardEngineResourceGroupBaseInfoResponse:
        """
        更新标准引擎资源组基础信息
        """
        
        kwargs = {}
        kwargs["action"] = "UpdateStandardEngineResourceGroupBaseInfo"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.UpdateStandardEngineResourceGroupBaseInfoResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def UpdateStandardEngineResourceGroupConfigInfo(
            self,
            request: models.UpdateStandardEngineResourceGroupConfigInfoRequest,
            opts: Dict = None,
    ) -> models.UpdateStandardEngineResourceGroupConfigInfoResponse:
        """
        更新标准引擎资源组基础信息
        """
        
        kwargs = {}
        kwargs["action"] = "UpdateStandardEngineResourceGroupConfigInfo"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.UpdateStandardEngineResourceGroupConfigInfoResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def UpdateStandardEngineResourceGroupResourceInfo(
            self,
            request: models.UpdateStandardEngineResourceGroupResourceInfoRequest,
            opts: Dict = None,
    ) -> models.UpdateStandardEngineResourceGroupResourceInfoResponse:
        """
        更新标准引擎资源组基础信息
        """
        
        kwargs = {}
        kwargs["action"] = "UpdateStandardEngineResourceGroupResourceInfo"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.UpdateStandardEngineResourceGroupResourceInfoResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def UpdateUDFPolicy(
            self,
            request: models.UpdateUDFPolicyRequest,
            opts: Dict = None,
    ) -> models.UpdateUDFPolicyResponse:
        """
        UDP权限修改
        """
        
        kwargs = {}
        kwargs["action"] = "UpdateUDFPolicy"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.UpdateUDFPolicyResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def UpdateUserDataEngineConfig(
            self,
            request: models.UpdateUserDataEngineConfigRequest,
            opts: Dict = None,
    ) -> models.UpdateUserDataEngineConfigResponse:
        """
        修改用户引擎自定义配置
        """
        
        kwargs = {}
        kwargs["action"] = "UpdateUserDataEngineConfig"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.UpdateUserDataEngineConfigResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def UpgradeDataEngineImage(
            self,
            request: models.UpgradeDataEngineImageRequest,
            opts: Dict = None,
    ) -> models.UpgradeDataEngineImageResponse:
        """
        升级引擎镜像
        """
        
        kwargs = {}
        kwargs["action"] = "UpgradeDataEngineImage"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.UpgradeDataEngineImageResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)