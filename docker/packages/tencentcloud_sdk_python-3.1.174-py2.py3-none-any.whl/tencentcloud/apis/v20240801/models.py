# -*- coding: utf8 -*-
# Copyright (c) 2017-2025 Tencent. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import warnings

from tencentcloud.common.abstract_model import AbstractModel


class AgentAppMcpServerDTO(AbstractModel):
    r"""关联的mcp服务配置

    """

    def __init__(self):
        r"""
        :param _ID: <p>mcp server id</p>
        :type ID: str
        :param _NeedAuth: <p>是否需要鉴权（已废弃，请勿使用）</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type NeedAuth: bool
        :param _AgentCredentialID: <p>凭据代填的ID（已废弃，请勿使用）</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type AgentCredentialID: str
        :param _SSEResourceIdentifier: <p>应用为OAuth2认证时，sse模式请求mcp时的资源标识</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type SSEResourceIdentifier: str
        :param _StreamableResourceIdentifier: <p>应用为OAuth2认证时，streamable模式请求mcp时的资源标识</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type StreamableResourceIdentifier: str
        """
        self._ID = None
        self._NeedAuth = None
        self._AgentCredentialID = None
        self._SSEResourceIdentifier = None
        self._StreamableResourceIdentifier = None

    @property
    def ID(self):
        r"""<p>mcp server id</p>
        :rtype: str
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID

    @property
    def NeedAuth(self):
        warnings.warn("parameter `NeedAuth` is deprecated", DeprecationWarning) 

        r"""<p>是否需要鉴权（已废弃，请勿使用）</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: bool
        """
        return self._NeedAuth

    @NeedAuth.setter
    def NeedAuth(self, NeedAuth):
        warnings.warn("parameter `NeedAuth` is deprecated", DeprecationWarning) 

        self._NeedAuth = NeedAuth

    @property
    def AgentCredentialID(self):
        warnings.warn("parameter `AgentCredentialID` is deprecated", DeprecationWarning) 

        r"""<p>凭据代填的ID（已废弃，请勿使用）</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._AgentCredentialID

    @AgentCredentialID.setter
    def AgentCredentialID(self, AgentCredentialID):
        warnings.warn("parameter `AgentCredentialID` is deprecated", DeprecationWarning) 

        self._AgentCredentialID = AgentCredentialID

    @property
    def SSEResourceIdentifier(self):
        r"""<p>应用为OAuth2认证时，sse模式请求mcp时的资源标识</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._SSEResourceIdentifier

    @SSEResourceIdentifier.setter
    def SSEResourceIdentifier(self, SSEResourceIdentifier):
        self._SSEResourceIdentifier = SSEResourceIdentifier

    @property
    def StreamableResourceIdentifier(self):
        r"""<p>应用为OAuth2认证时，streamable模式请求mcp时的资源标识</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._StreamableResourceIdentifier

    @StreamableResourceIdentifier.setter
    def StreamableResourceIdentifier(self, StreamableResourceIdentifier):
        self._StreamableResourceIdentifier = StreamableResourceIdentifier


    def _deserialize(self, params):
        self._ID = params.get("ID")
        self._NeedAuth = params.get("NeedAuth")
        self._AgentCredentialID = params.get("AgentCredentialID")
        self._SSEResourceIdentifier = params.get("SSEResourceIdentifier")
        self._StreamableResourceIdentifier = params.get("StreamableResourceIdentifier")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class AgentAppMcpServerVO(AbstractModel):
    r"""应用关联的mcp响应

    """

    def __init__(self):
        r"""
        :param _ID: 绑定ID
        :type ID: str
        :param _NeedAuth: 需要认证
        :type NeedAuth: bool
        :param _AgentCredentialID: 凭据ID
        :type AgentCredentialID: str
        :param _AgentCredentialVO: 凭据详情
        :type AgentCredentialVO: :class:`tencentcloud.apis.v20240801.models.DescribeAgentCredentialResp`
        :param _McpServerVO: mcp详情
        :type McpServerVO: :class:`tencentcloud.apis.v20240801.models.DescribeMcpServerResponseVO`
        :param _RelateTime: 关联时间
        :type RelateTime: str
        :param _SSEResourceIdentifier: 应用为OAuth2认证时，sse模式请求mcp时的资源标识
注意：此字段可能返回 null，表示取不到有效值。
        :type SSEResourceIdentifier: str
        :param _StreamableResourceIdentifier: 应用为OAuth2认证时，streamable模式请求mcp时的资源标识
注意：此字段可能返回 null，表示取不到有效值。
        :type StreamableResourceIdentifier: str
        :param _AgentAppID: 应用ID
注意：此字段可能返回 null，表示取不到有效值。
        :type AgentAppID: str
        :param _McpServerID: mcp ID
注意：此字段可能返回 null，表示取不到有效值。
        :type McpServerID: str
        """
        self._ID = None
        self._NeedAuth = None
        self._AgentCredentialID = None
        self._AgentCredentialVO = None
        self._McpServerVO = None
        self._RelateTime = None
        self._SSEResourceIdentifier = None
        self._StreamableResourceIdentifier = None
        self._AgentAppID = None
        self._McpServerID = None

    @property
    def ID(self):
        r"""绑定ID
        :rtype: str
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID

    @property
    def NeedAuth(self):
        r"""需要认证
        :rtype: bool
        """
        return self._NeedAuth

    @NeedAuth.setter
    def NeedAuth(self, NeedAuth):
        self._NeedAuth = NeedAuth

    @property
    def AgentCredentialID(self):
        r"""凭据ID
        :rtype: str
        """
        return self._AgentCredentialID

    @AgentCredentialID.setter
    def AgentCredentialID(self, AgentCredentialID):
        self._AgentCredentialID = AgentCredentialID

    @property
    def AgentCredentialVO(self):
        r"""凭据详情
        :rtype: :class:`tencentcloud.apis.v20240801.models.DescribeAgentCredentialResp`
        """
        return self._AgentCredentialVO

    @AgentCredentialVO.setter
    def AgentCredentialVO(self, AgentCredentialVO):
        self._AgentCredentialVO = AgentCredentialVO

    @property
    def McpServerVO(self):
        r"""mcp详情
        :rtype: :class:`tencentcloud.apis.v20240801.models.DescribeMcpServerResponseVO`
        """
        return self._McpServerVO

    @McpServerVO.setter
    def McpServerVO(self, McpServerVO):
        self._McpServerVO = McpServerVO

    @property
    def RelateTime(self):
        r"""关联时间
        :rtype: str
        """
        return self._RelateTime

    @RelateTime.setter
    def RelateTime(self, RelateTime):
        self._RelateTime = RelateTime

    @property
    def SSEResourceIdentifier(self):
        r"""应用为OAuth2认证时，sse模式请求mcp时的资源标识
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._SSEResourceIdentifier

    @SSEResourceIdentifier.setter
    def SSEResourceIdentifier(self, SSEResourceIdentifier):
        self._SSEResourceIdentifier = SSEResourceIdentifier

    @property
    def StreamableResourceIdentifier(self):
        r"""应用为OAuth2认证时，streamable模式请求mcp时的资源标识
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._StreamableResourceIdentifier

    @StreamableResourceIdentifier.setter
    def StreamableResourceIdentifier(self, StreamableResourceIdentifier):
        self._StreamableResourceIdentifier = StreamableResourceIdentifier

    @property
    def AgentAppID(self):
        r"""应用ID
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._AgentAppID

    @AgentAppID.setter
    def AgentAppID(self, AgentAppID):
        self._AgentAppID = AgentAppID

    @property
    def McpServerID(self):
        r"""mcp ID
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._McpServerID

    @McpServerID.setter
    def McpServerID(self, McpServerID):
        self._McpServerID = McpServerID


    def _deserialize(self, params):
        self._ID = params.get("ID")
        self._NeedAuth = params.get("NeedAuth")
        self._AgentCredentialID = params.get("AgentCredentialID")
        if params.get("AgentCredentialVO") is not None:
            self._AgentCredentialVO = DescribeAgentCredentialResp()
            self._AgentCredentialVO._deserialize(params.get("AgentCredentialVO"))
        if params.get("McpServerVO") is not None:
            self._McpServerVO = DescribeMcpServerResponseVO()
            self._McpServerVO._deserialize(params.get("McpServerVO"))
        self._RelateTime = params.get("RelateTime")
        self._SSEResourceIdentifier = params.get("SSEResourceIdentifier")
        self._StreamableResourceIdentifier = params.get("StreamableResourceIdentifier")
        self._AgentAppID = params.get("AgentAppID")
        self._McpServerID = params.get("McpServerID")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class AgentAppModelServiceDTO(AbstractModel):
    r"""应用绑定模型服务入参

    """

    def __init__(self):
        r"""
        :param _ID: 模型服务ID
        :type ID: str
        :param _InvokeLimitConfigStatus: 是否开启流量控制
        :type InvokeLimitConfigStatus: bool
        :param _InvokeLimitConfig: 流量控制
        :type InvokeLimitConfig: :class:`tencentcloud.apis.v20240801.models.InvokeLimitConfigDTO`
        :param _TokenLimitStatus: 是否开启token控制
        :type TokenLimitStatus: bool
        :param _TokenLimitConfig: token控制
        :type TokenLimitConfig: :class:`tencentcloud.apis.v20240801.models.TokenLimitConfigDTO`
        """
        self._ID = None
        self._InvokeLimitConfigStatus = None
        self._InvokeLimitConfig = None
        self._TokenLimitStatus = None
        self._TokenLimitConfig = None

    @property
    def ID(self):
        r"""模型服务ID
        :rtype: str
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID

    @property
    def InvokeLimitConfigStatus(self):
        r"""是否开启流量控制
        :rtype: bool
        """
        return self._InvokeLimitConfigStatus

    @InvokeLimitConfigStatus.setter
    def InvokeLimitConfigStatus(self, InvokeLimitConfigStatus):
        self._InvokeLimitConfigStatus = InvokeLimitConfigStatus

    @property
    def InvokeLimitConfig(self):
        r"""流量控制
        :rtype: :class:`tencentcloud.apis.v20240801.models.InvokeLimitConfigDTO`
        """
        return self._InvokeLimitConfig

    @InvokeLimitConfig.setter
    def InvokeLimitConfig(self, InvokeLimitConfig):
        self._InvokeLimitConfig = InvokeLimitConfig

    @property
    def TokenLimitStatus(self):
        r"""是否开启token控制
        :rtype: bool
        """
        return self._TokenLimitStatus

    @TokenLimitStatus.setter
    def TokenLimitStatus(self, TokenLimitStatus):
        self._TokenLimitStatus = TokenLimitStatus

    @property
    def TokenLimitConfig(self):
        r"""token控制
        :rtype: :class:`tencentcloud.apis.v20240801.models.TokenLimitConfigDTO`
        """
        return self._TokenLimitConfig

    @TokenLimitConfig.setter
    def TokenLimitConfig(self, TokenLimitConfig):
        self._TokenLimitConfig = TokenLimitConfig


    def _deserialize(self, params):
        self._ID = params.get("ID")
        self._InvokeLimitConfigStatus = params.get("InvokeLimitConfigStatus")
        if params.get("InvokeLimitConfig") is not None:
            self._InvokeLimitConfig = InvokeLimitConfigDTO()
            self._InvokeLimitConfig._deserialize(params.get("InvokeLimitConfig"))
        self._TokenLimitStatus = params.get("TokenLimitStatus")
        if params.get("TokenLimitConfig") is not None:
            self._TokenLimitConfig = TokenLimitConfigDTO()
            self._TokenLimitConfig._deserialize(params.get("TokenLimitConfig"))
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class AgentAppSecretKeyVO(AbstractModel):
    r"""secretKey的出参

    """

    def __init__(self):
        r"""
        :param _SecretID: secret id
        :type SecretID: str
        :param _SecretKey: secret key
        :type SecretKey: str
        """
        self._SecretID = None
        self._SecretKey = None

    @property
    def SecretID(self):
        r"""secret id
        :rtype: str
        """
        return self._SecretID

    @SecretID.setter
    def SecretID(self, SecretID):
        self._SecretID = SecretID

    @property
    def SecretKey(self):
        r"""secret key
        :rtype: str
        """
        return self._SecretKey

    @SecretKey.setter
    def SecretKey(self, SecretKey):
        self._SecretKey = SecretKey


    def _deserialize(self, params):
        self._SecretID = params.get("SecretID")
        self._SecretKey = params.get("SecretKey")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class AgentAppServiceDTO(AbstractModel):
    r"""Agent应用关联的服务配置

    """

    def __init__(self):
        r"""
        :param _ID: <p>ID</p>
        :type ID: str
        :param _InvokeLimitConfigStatus: <p>是否限流</p>
        :type InvokeLimitConfigStatus: bool
        :param _InvokeLimitConfig: <p>限流配置</p>
        :type InvokeLimitConfig: :class:`tencentcloud.apis.v20240801.models.InvokeLimitConfigDTO`
        :param _NeedAuth: <p>是否要认证（已废弃，请勿使用）</p>
        :type NeedAuth: bool
        :param _AgentCredentialID: <p>凭据ID（已废弃，请勿使用）</p>
        :type AgentCredentialID: str
        """
        self._ID = None
        self._InvokeLimitConfigStatus = None
        self._InvokeLimitConfig = None
        self._NeedAuth = None
        self._AgentCredentialID = None

    @property
    def ID(self):
        r"""<p>ID</p>
        :rtype: str
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID

    @property
    def InvokeLimitConfigStatus(self):
        r"""<p>是否限流</p>
        :rtype: bool
        """
        return self._InvokeLimitConfigStatus

    @InvokeLimitConfigStatus.setter
    def InvokeLimitConfigStatus(self, InvokeLimitConfigStatus):
        self._InvokeLimitConfigStatus = InvokeLimitConfigStatus

    @property
    def InvokeLimitConfig(self):
        r"""<p>限流配置</p>
        :rtype: :class:`tencentcloud.apis.v20240801.models.InvokeLimitConfigDTO`
        """
        return self._InvokeLimitConfig

    @InvokeLimitConfig.setter
    def InvokeLimitConfig(self, InvokeLimitConfig):
        self._InvokeLimitConfig = InvokeLimitConfig

    @property
    def NeedAuth(self):
        warnings.warn("parameter `NeedAuth` is deprecated", DeprecationWarning) 

        r"""<p>是否要认证（已废弃，请勿使用）</p>
        :rtype: bool
        """
        return self._NeedAuth

    @NeedAuth.setter
    def NeedAuth(self, NeedAuth):
        warnings.warn("parameter `NeedAuth` is deprecated", DeprecationWarning) 

        self._NeedAuth = NeedAuth

    @property
    def AgentCredentialID(self):
        warnings.warn("parameter `AgentCredentialID` is deprecated", DeprecationWarning) 

        r"""<p>凭据ID（已废弃，请勿使用）</p>
        :rtype: str
        """
        return self._AgentCredentialID

    @AgentCredentialID.setter
    def AgentCredentialID(self, AgentCredentialID):
        warnings.warn("parameter `AgentCredentialID` is deprecated", DeprecationWarning) 

        self._AgentCredentialID = AgentCredentialID


    def _deserialize(self, params):
        self._ID = params.get("ID")
        self._InvokeLimitConfigStatus = params.get("InvokeLimitConfigStatus")
        if params.get("InvokeLimitConfig") is not None:
            self._InvokeLimitConfig = InvokeLimitConfigDTO()
            self._InvokeLimitConfig._deserialize(params.get("InvokeLimitConfig"))
        self._NeedAuth = params.get("NeedAuth")
        self._AgentCredentialID = params.get("AgentCredentialID")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class AgentAppServiceVO(AbstractModel):
    r"""应用API详情

    """

    def __init__(self):
        r"""
        :param _ID: <p>ID</p>
        :type ID: str
        :param _AgentAppID: <p>应用ID</p>
        :type AgentAppID: str
        :param _ServiceID: <p>服务ID</p>
        :type ServiceID: str
        :param _InvokeLimitConfigStatus: <p>是否限流</p>
        :type InvokeLimitConfigStatus: bool
        :param _InvokeLimitConfig: <p>限流配置</p>
        :type InvokeLimitConfig: :class:`tencentcloud.apis.v20240801.models.InvokeLimitConfigDTO`
        :param _ServiceVO: <p>服务详情</p>
        :type ServiceVO: :class:`tencentcloud.apis.v20240801.models.ServiceVO`
        :param _RelateTime: <p>关联时间</p>
        :type RelateTime: str
        :param _NeedAuth: <p>是否需要认证</p>
        :type NeedAuth: bool
        :param _AgentCredentialID: <p>凭据ID</p>
        :type AgentCredentialID: str
        :param _AgentCredentialVO: <p>凭据详情</p>
        :type AgentCredentialVO: :class:`tencentcloud.apis.v20240801.models.DescribeAgentCredentialResp`
        """
        self._ID = None
        self._AgentAppID = None
        self._ServiceID = None
        self._InvokeLimitConfigStatus = None
        self._InvokeLimitConfig = None
        self._ServiceVO = None
        self._RelateTime = None
        self._NeedAuth = None
        self._AgentCredentialID = None
        self._AgentCredentialVO = None

    @property
    def ID(self):
        r"""<p>ID</p>
        :rtype: str
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID

    @property
    def AgentAppID(self):
        r"""<p>应用ID</p>
        :rtype: str
        """
        return self._AgentAppID

    @AgentAppID.setter
    def AgentAppID(self, AgentAppID):
        self._AgentAppID = AgentAppID

    @property
    def ServiceID(self):
        r"""<p>服务ID</p>
        :rtype: str
        """
        return self._ServiceID

    @ServiceID.setter
    def ServiceID(self, ServiceID):
        self._ServiceID = ServiceID

    @property
    def InvokeLimitConfigStatus(self):
        r"""<p>是否限流</p>
        :rtype: bool
        """
        return self._InvokeLimitConfigStatus

    @InvokeLimitConfigStatus.setter
    def InvokeLimitConfigStatus(self, InvokeLimitConfigStatus):
        self._InvokeLimitConfigStatus = InvokeLimitConfigStatus

    @property
    def InvokeLimitConfig(self):
        r"""<p>限流配置</p>
        :rtype: :class:`tencentcloud.apis.v20240801.models.InvokeLimitConfigDTO`
        """
        return self._InvokeLimitConfig

    @InvokeLimitConfig.setter
    def InvokeLimitConfig(self, InvokeLimitConfig):
        self._InvokeLimitConfig = InvokeLimitConfig

    @property
    def ServiceVO(self):
        r"""<p>服务详情</p>
        :rtype: :class:`tencentcloud.apis.v20240801.models.ServiceVO`
        """
        return self._ServiceVO

    @ServiceVO.setter
    def ServiceVO(self, ServiceVO):
        self._ServiceVO = ServiceVO

    @property
    def RelateTime(self):
        r"""<p>关联时间</p>
        :rtype: str
        """
        return self._RelateTime

    @RelateTime.setter
    def RelateTime(self, RelateTime):
        self._RelateTime = RelateTime

    @property
    def NeedAuth(self):
        r"""<p>是否需要认证</p>
        :rtype: bool
        """
        return self._NeedAuth

    @NeedAuth.setter
    def NeedAuth(self, NeedAuth):
        self._NeedAuth = NeedAuth

    @property
    def AgentCredentialID(self):
        r"""<p>凭据ID</p>
        :rtype: str
        """
        return self._AgentCredentialID

    @AgentCredentialID.setter
    def AgentCredentialID(self, AgentCredentialID):
        self._AgentCredentialID = AgentCredentialID

    @property
    def AgentCredentialVO(self):
        r"""<p>凭据详情</p>
        :rtype: :class:`tencentcloud.apis.v20240801.models.DescribeAgentCredentialResp`
        """
        return self._AgentCredentialVO

    @AgentCredentialVO.setter
    def AgentCredentialVO(self, AgentCredentialVO):
        self._AgentCredentialVO = AgentCredentialVO


    def _deserialize(self, params):
        self._ID = params.get("ID")
        self._AgentAppID = params.get("AgentAppID")
        self._ServiceID = params.get("ServiceID")
        self._InvokeLimitConfigStatus = params.get("InvokeLimitConfigStatus")
        if params.get("InvokeLimitConfig") is not None:
            self._InvokeLimitConfig = InvokeLimitConfigDTO()
            self._InvokeLimitConfig._deserialize(params.get("InvokeLimitConfig"))
        if params.get("ServiceVO") is not None:
            self._ServiceVO = ServiceVO()
            self._ServiceVO._deserialize(params.get("ServiceVO"))
        self._RelateTime = params.get("RelateTime")
        self._NeedAuth = params.get("NeedAuth")
        self._AgentCredentialID = params.get("AgentCredentialID")
        if params.get("AgentCredentialVO") is not None:
            self._AgentCredentialVO = DescribeAgentCredentialResp()
            self._AgentCredentialVO._deserialize(params.get("AgentCredentialVO"))
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class AgentCredentialApiKeyDTO(AbstractModel):
    r"""API Key类型凭据

    """

    def __init__(self):
        r"""
        :param _Value: <p>API Key</p>
        :type Value: str
        """
        self._Value = None

    @property
    def Value(self):
        r"""<p>API Key</p>
        :rtype: str
        """
        return self._Value

    @Value.setter
    def Value(self, Value):
        self._Value = Value


    def _deserialize(self, params):
        self._Value = params.get("Value")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class AgentCredentialContentDTO(AbstractModel):
    r"""凭证内容

    """

    def __init__(self):
        r"""
        :param _STSSystem: <p>如果认证类型为sts时，该项必填</p>
        :type STSSystem: str
        :param _STSService: <p>如果认证类型为sts时，该项必填</p>
        :type STSService: str
        :param _Headers: <p>如果认证类型为reqKey时，该项必填</p>
        :type Headers: list of AgentCredentialContentHeaderDTO
        :param _ApiKeys: <p>如果认证类型为apiKey时，该项必填</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type ApiKeys: list of AgentCredentialApiKeyDTO
        :param _FaultTolerance: <p>容错策略，仅Type为apiKey时支持</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type FaultTolerance: :class:`tencentcloud.apis.v20240801.models.FaultToleranceDTO`
        """
        self._STSSystem = None
        self._STSService = None
        self._Headers = None
        self._ApiKeys = None
        self._FaultTolerance = None

    @property
    def STSSystem(self):
        r"""<p>如果认证类型为sts时，该项必填</p>
        :rtype: str
        """
        return self._STSSystem

    @STSSystem.setter
    def STSSystem(self, STSSystem):
        self._STSSystem = STSSystem

    @property
    def STSService(self):
        r"""<p>如果认证类型为sts时，该项必填</p>
        :rtype: str
        """
        return self._STSService

    @STSService.setter
    def STSService(self, STSService):
        self._STSService = STSService

    @property
    def Headers(self):
        r"""<p>如果认证类型为reqKey时，该项必填</p>
        :rtype: list of AgentCredentialContentHeaderDTO
        """
        return self._Headers

    @Headers.setter
    def Headers(self, Headers):
        self._Headers = Headers

    @property
    def ApiKeys(self):
        r"""<p>如果认证类型为apiKey时，该项必填</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of AgentCredentialApiKeyDTO
        """
        return self._ApiKeys

    @ApiKeys.setter
    def ApiKeys(self, ApiKeys):
        self._ApiKeys = ApiKeys

    @property
    def FaultTolerance(self):
        r"""<p>容错策略，仅Type为apiKey时支持</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: :class:`tencentcloud.apis.v20240801.models.FaultToleranceDTO`
        """
        return self._FaultTolerance

    @FaultTolerance.setter
    def FaultTolerance(self, FaultTolerance):
        self._FaultTolerance = FaultTolerance


    def _deserialize(self, params):
        self._STSSystem = params.get("STSSystem")
        self._STSService = params.get("STSService")
        if params.get("Headers") is not None:
            self._Headers = []
            for item in params.get("Headers"):
                obj = AgentCredentialContentHeaderDTO()
                obj._deserialize(item)
                self._Headers.append(obj)
        if params.get("ApiKeys") is not None:
            self._ApiKeys = []
            for item in params.get("ApiKeys"):
                obj = AgentCredentialApiKeyDTO()
                obj._deserialize(item)
                self._ApiKeys.append(obj)
        if params.get("FaultTolerance") is not None:
            self._FaultTolerance = FaultToleranceDTO()
            self._FaultTolerance._deserialize(params.get("FaultTolerance"))
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class AgentCredentialContentHeaderDTO(AbstractModel):
    r"""凭证内容头

    """

    def __init__(self):
        r"""
        :param _Key: 凭据header key
        :type Key: str
        :param _Value: 凭据header value
        :type Value: str
        """
        self._Key = None
        self._Value = None

    @property
    def Key(self):
        r"""凭据header key
        :rtype: str
        """
        return self._Key

    @Key.setter
    def Key(self, Key):
        self._Key = Key

    @property
    def Value(self):
        r"""凭据header value
        :rtype: str
        """
        return self._Value

    @Value.setter
    def Value(self, Value):
        self._Value = Value


    def _deserialize(self, params):
        self._Key = params.get("Key")
        self._Value = params.get("Value")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class BindMcpSecurityRuleDTO(AbstractModel):
    r"""BindMcpSecurityRuleDTO，替换之前的McpSecurityRule

    """

    def __init__(self):
        r"""
        :param _ID: 规则ID
        :type ID: str
        :param _Act: 处置动作
        :type Act: str
        """
        self._ID = None
        self._Act = None

    @property
    def ID(self):
        r"""规则ID
        :rtype: str
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID

    @property
    def Act(self):
        r"""处置动作
        :rtype: str
        """
        return self._Act

    @Act.setter
    def Act(self, Act):
        self._Act = Act


    def _deserialize(self, params):
        self._ID = params.get("ID")
        self._Act = params.get("Act")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class BindMcpSecurityRuleVO(AbstractModel):
    r"""BindMcpSecurityRuleVO，重新定义了之前的McpSecurityRulesVO

    """

    def __init__(self):
        r"""
        :param _ID: 规则ID
        :type ID: str
        :param _Type: 规则类型
        :type Type: str
        :param _Name: 规则名称
        :type Name: str
        :param _Description: 规则描述
        :type Description: str
        :param _RiskLevel: 风险等级
        :type RiskLevel: str
        :param _VersionNumber: 版本号
        :type VersionNumber: str
        :param _Act: 当前选择的处置动作
        :type Act: str
        :param _SupportActs: 支持的处置动作
        :type SupportActs: list of str
        :param _BodyType: 内容类型
        :type BodyType: str
        :param _IconType: icon类型
        :type IconType: str
        """
        self._ID = None
        self._Type = None
        self._Name = None
        self._Description = None
        self._RiskLevel = None
        self._VersionNumber = None
        self._Act = None
        self._SupportActs = None
        self._BodyType = None
        self._IconType = None

    @property
    def ID(self):
        r"""规则ID
        :rtype: str
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID

    @property
    def Type(self):
        r"""规则类型
        :rtype: str
        """
        return self._Type

    @Type.setter
    def Type(self, Type):
        self._Type = Type

    @property
    def Name(self):
        r"""规则名称
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def Description(self):
        r"""规则描述
        :rtype: str
        """
        return self._Description

    @Description.setter
    def Description(self, Description):
        self._Description = Description

    @property
    def RiskLevel(self):
        r"""风险等级
        :rtype: str
        """
        return self._RiskLevel

    @RiskLevel.setter
    def RiskLevel(self, RiskLevel):
        self._RiskLevel = RiskLevel

    @property
    def VersionNumber(self):
        r"""版本号
        :rtype: str
        """
        return self._VersionNumber

    @VersionNumber.setter
    def VersionNumber(self, VersionNumber):
        self._VersionNumber = VersionNumber

    @property
    def Act(self):
        r"""当前选择的处置动作
        :rtype: str
        """
        return self._Act

    @Act.setter
    def Act(self, Act):
        self._Act = Act

    @property
    def SupportActs(self):
        r"""支持的处置动作
        :rtype: list of str
        """
        return self._SupportActs

    @SupportActs.setter
    def SupportActs(self, SupportActs):
        self._SupportActs = SupportActs

    @property
    def BodyType(self):
        r"""内容类型
        :rtype: str
        """
        return self._BodyType

    @BodyType.setter
    def BodyType(self, BodyType):
        self._BodyType = BodyType

    @property
    def IconType(self):
        r"""icon类型
        :rtype: str
        """
        return self._IconType

    @IconType.setter
    def IconType(self, IconType):
        self._IconType = IconType


    def _deserialize(self, params):
        self._ID = params.get("ID")
        self._Type = params.get("Type")
        self._Name = params.get("Name")
        self._Description = params.get("Description")
        self._RiskLevel = params.get("RiskLevel")
        self._VersionNumber = params.get("VersionNumber")
        self._Act = params.get("Act")
        self._SupportActs = params.get("SupportActs")
        self._BodyType = params.get("BodyType")
        self._IconType = params.get("IconType")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class CompoundCondition(AbstractModel):
    r"""匹配条件

    """

    def __init__(self):
        r"""
        :param _Enable: <p>是否启用</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type Enable: bool
        :param _Rules: <p>匹配信息</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type Rules: list of SimpleCondition
        """
        self._Enable = None
        self._Rules = None

    @property
    def Enable(self):
        r"""<p>是否启用</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: bool
        """
        return self._Enable

    @Enable.setter
    def Enable(self, Enable):
        self._Enable = Enable

    @property
    def Rules(self):
        r"""<p>匹配信息</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of SimpleCondition
        """
        return self._Rules

    @Rules.setter
    def Rules(self, Rules):
        self._Rules = Rules


    def _deserialize(self, params):
        self._Enable = params.get("Enable")
        if params.get("Rules") is not None:
            self._Rules = []
            for item in params.get("Rules"):
                obj = SimpleCondition()
                obj._deserialize(item)
                self._Rules.append(obj)
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class CreateAgentAppMcpServersRequest(AbstractModel):
    r"""CreateAgentAppMcpServers请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceID: 实例ID
        :type InstanceID: str
        :param _ID: 应用ID
        :type ID: str
        :param _McpServers: 关联的mcp server
        :type McpServers: list of AgentAppMcpServerDTO
        """
        self._InstanceID = None
        self._ID = None
        self._McpServers = None

    @property
    def InstanceID(self):
        r"""实例ID
        :rtype: str
        """
        return self._InstanceID

    @InstanceID.setter
    def InstanceID(self, InstanceID):
        self._InstanceID = InstanceID

    @property
    def ID(self):
        r"""应用ID
        :rtype: str
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID

    @property
    def McpServers(self):
        r"""关联的mcp server
        :rtype: list of AgentAppMcpServerDTO
        """
        return self._McpServers

    @McpServers.setter
    def McpServers(self, McpServers):
        self._McpServers = McpServers


    def _deserialize(self, params):
        self._InstanceID = params.get("InstanceID")
        self._ID = params.get("ID")
        if params.get("McpServers") is not None:
            self._McpServers = []
            for item in params.get("McpServers"):
                obj = AgentAppMcpServerDTO()
                obj._deserialize(item)
                self._McpServers.append(obj)
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class CreateAgentAppMcpServersResponse(AbstractModel):
    r"""CreateAgentAppMcpServers返回参数结构体

    """

    def __init__(self):
        r"""
        :param _Data: app id
        :type Data: :class:`tencentcloud.apis.v20240801.models.ResultIDVO`
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._Data = None
        self._RequestId = None

    @property
    def Data(self):
        r"""app id
        :rtype: :class:`tencentcloud.apis.v20240801.models.ResultIDVO`
        """
        return self._Data

    @Data.setter
    def Data(self, Data):
        self._Data = Data

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("Data") is not None:
            self._Data = ResultIDVO()
            self._Data._deserialize(params.get("Data"))
        self._RequestId = params.get("RequestId")


class CreateAgentAppModelServicesRequest(AbstractModel):
    r"""CreateAgentAppModelServices请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceID: 实例ID
        :type InstanceID: str
        :param _ID: 应用ID
        :type ID: str
        :param _ModelServices: 关联的model service
        :type ModelServices: list of AgentAppModelServiceDTO
        """
        self._InstanceID = None
        self._ID = None
        self._ModelServices = None

    @property
    def InstanceID(self):
        r"""实例ID
        :rtype: str
        """
        return self._InstanceID

    @InstanceID.setter
    def InstanceID(self, InstanceID):
        self._InstanceID = InstanceID

    @property
    def ID(self):
        r"""应用ID
        :rtype: str
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID

    @property
    def ModelServices(self):
        r"""关联的model service
        :rtype: list of AgentAppModelServiceDTO
        """
        return self._ModelServices

    @ModelServices.setter
    def ModelServices(self, ModelServices):
        self._ModelServices = ModelServices


    def _deserialize(self, params):
        self._InstanceID = params.get("InstanceID")
        self._ID = params.get("ID")
        if params.get("ModelServices") is not None:
            self._ModelServices = []
            for item in params.get("ModelServices"):
                obj = AgentAppModelServiceDTO()
                obj._deserialize(item)
                self._ModelServices.append(obj)
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class CreateAgentAppModelServicesResponse(AbstractModel):
    r"""CreateAgentAppModelServices返回参数结构体

    """

    def __init__(self):
        r"""
        :param _Data: app id
        :type Data: :class:`tencentcloud.apis.v20240801.models.ResultIDVO`
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._Data = None
        self._RequestId = None

    @property
    def Data(self):
        r"""app id
        :rtype: :class:`tencentcloud.apis.v20240801.models.ResultIDVO`
        """
        return self._Data

    @Data.setter
    def Data(self, Data):
        self._Data = Data

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("Data") is not None:
            self._Data = ResultIDVO()
            self._Data._deserialize(params.get("Data"))
        self._RequestId = params.get("RequestId")


class CreateAgentAppRequest(AbstractModel):
    r"""CreateAgentApp请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceID: <p>实例ID</p>
        :type InstanceID: str
        :param _Name: <p>名称</p>
        :type Name: str
        :param _AuthType: <p>认证类型</p>
        :type AuthType: str
        :param _OAuth2ResourceServerID: <p>OAuth2资源服务器ID</p>
        :type OAuth2ResourceServerID: str
        :param _Description: <p>描述</p>
        :type Description: str
        :param _ConnectorIDs: <p>API认证列表</p>
        :type ConnectorIDs: list of str
        """
        self._InstanceID = None
        self._Name = None
        self._AuthType = None
        self._OAuth2ResourceServerID = None
        self._Description = None
        self._ConnectorIDs = None

    @property
    def InstanceID(self):
        r"""<p>实例ID</p>
        :rtype: str
        """
        return self._InstanceID

    @InstanceID.setter
    def InstanceID(self, InstanceID):
        self._InstanceID = InstanceID

    @property
    def Name(self):
        r"""<p>名称</p>
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def AuthType(self):
        r"""<p>认证类型</p>
        :rtype: str
        """
        return self._AuthType

    @AuthType.setter
    def AuthType(self, AuthType):
        self._AuthType = AuthType

    @property
    def OAuth2ResourceServerID(self):
        r"""<p>OAuth2资源服务器ID</p>
        :rtype: str
        """
        return self._OAuth2ResourceServerID

    @OAuth2ResourceServerID.setter
    def OAuth2ResourceServerID(self, OAuth2ResourceServerID):
        self._OAuth2ResourceServerID = OAuth2ResourceServerID

    @property
    def Description(self):
        r"""<p>描述</p>
        :rtype: str
        """
        return self._Description

    @Description.setter
    def Description(self, Description):
        self._Description = Description

    @property
    def ConnectorIDs(self):
        r"""<p>API认证列表</p>
        :rtype: list of str
        """
        return self._ConnectorIDs

    @ConnectorIDs.setter
    def ConnectorIDs(self, ConnectorIDs):
        self._ConnectorIDs = ConnectorIDs


    def _deserialize(self, params):
        self._InstanceID = params.get("InstanceID")
        self._Name = params.get("Name")
        self._AuthType = params.get("AuthType")
        self._OAuth2ResourceServerID = params.get("OAuth2ResourceServerID")
        self._Description = params.get("Description")
        self._ConnectorIDs = params.get("ConnectorIDs")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class CreateAgentAppResp(AbstractModel):
    r"""创建Agent应用的返回值，根据创建的AuthType，返回ApiKey或者SecretKey

    """

    def __init__(self):
        r"""
        :param _ID: app id 
        :type ID: str
        :param _ApiKey: 如果authType为apiKey时，返回该字段
        :type ApiKey: str
        :param _SecretKey: 如果authType为secretKey时，返回该字段
        :type SecretKey: str
        :param _SecretID: 如果authType为secretKey时，返回该字段
        :type SecretID: str
        """
        self._ID = None
        self._ApiKey = None
        self._SecretKey = None
        self._SecretID = None

    @property
    def ID(self):
        r"""app id 
        :rtype: str
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID

    @property
    def ApiKey(self):
        r"""如果authType为apiKey时，返回该字段
        :rtype: str
        """
        return self._ApiKey

    @ApiKey.setter
    def ApiKey(self, ApiKey):
        self._ApiKey = ApiKey

    @property
    def SecretKey(self):
        r"""如果authType为secretKey时，返回该字段
        :rtype: str
        """
        return self._SecretKey

    @SecretKey.setter
    def SecretKey(self, SecretKey):
        self._SecretKey = SecretKey

    @property
    def SecretID(self):
        r"""如果authType为secretKey时，返回该字段
        :rtype: str
        """
        return self._SecretID

    @SecretID.setter
    def SecretID(self, SecretID):
        self._SecretID = SecretID


    def _deserialize(self, params):
        self._ID = params.get("ID")
        self._ApiKey = params.get("ApiKey")
        self._SecretKey = params.get("SecretKey")
        self._SecretID = params.get("SecretID")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class CreateAgentAppResponse(AbstractModel):
    r"""CreateAgentApp返回参数结构体

    """

    def __init__(self):
        r"""
        :param _Data: <p>app id</p>
        :type Data: :class:`tencentcloud.apis.v20240801.models.CreateAgentAppResp`
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._Data = None
        self._RequestId = None

    @property
    def Data(self):
        r"""<p>app id</p>
        :rtype: :class:`tencentcloud.apis.v20240801.models.CreateAgentAppResp`
        """
        return self._Data

    @Data.setter
    def Data(self, Data):
        self._Data = Data

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("Data") is not None:
            self._Data = CreateAgentAppResp()
            self._Data._deserialize(params.get("Data"))
        self._RequestId = params.get("RequestId")


class CreateAgentAppServicesRequest(AbstractModel):
    r"""CreateAgentAppServices请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceID: <p>实例ID</p>
        :type InstanceID: str
        :param _ID: <p>应用ID</p>
        :type ID: str
        :param _Services: <p>服务详情</p>
        :type Services: list of AgentAppServiceDTO
        """
        self._InstanceID = None
        self._ID = None
        self._Services = None

    @property
    def InstanceID(self):
        r"""<p>实例ID</p>
        :rtype: str
        """
        return self._InstanceID

    @InstanceID.setter
    def InstanceID(self, InstanceID):
        self._InstanceID = InstanceID

    @property
    def ID(self):
        r"""<p>应用ID</p>
        :rtype: str
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID

    @property
    def Services(self):
        r"""<p>服务详情</p>
        :rtype: list of AgentAppServiceDTO
        """
        return self._Services

    @Services.setter
    def Services(self, Services):
        self._Services = Services


    def _deserialize(self, params):
        self._InstanceID = params.get("InstanceID")
        self._ID = params.get("ID")
        if params.get("Services") is not None:
            self._Services = []
            for item in params.get("Services"):
                obj = AgentAppServiceDTO()
                obj._deserialize(item)
                self._Services.append(obj)
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class CreateAgentAppServicesResponse(AbstractModel):
    r"""CreateAgentAppServices返回参数结构体

    """

    def __init__(self):
        r"""
        :param _Data: <p>app id</p>
        :type Data: :class:`tencentcloud.apis.v20240801.models.ResultIDVO`
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._Data = None
        self._RequestId = None

    @property
    def Data(self):
        r"""<p>app id</p>
        :rtype: :class:`tencentcloud.apis.v20240801.models.ResultIDVO`
        """
        return self._Data

    @Data.setter
    def Data(self, Data):
        self._Data = Data

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("Data") is not None:
            self._Data = ResultIDVO()
            self._Data._deserialize(params.get("Data"))
        self._RequestId = params.get("RequestId")


class CreateAgentCredentialRequest(AbstractModel):
    r"""CreateAgentCredential请求参数结构体

    """


class CreateAgentCredentialResponse(AbstractModel):
    r"""CreateAgentCredential返回参数结构体

    """

    def __init__(self):
        r"""
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._RequestId = None

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._RequestId = params.get("RequestId")


class CreateMcpServerRequest(AbstractModel):
    r"""CreateMcpServer请求参数结构体

    """

    def __init__(self):
        r"""
        :param _Mode: <p>模式：proxy代理模式； wrap封装模式；</p>
        :type Mode: str
        :param _McpVersion: <p>版本号：2024-11-05 2025-03-26</p>
        :type McpVersion: str
        :param _InstanceID: <p>实例ID</p>
        :type InstanceID: str
        :param _Name: <p>名称</p>
        :type Name: str
        :param _Description: <p>描述</p>
        :type Description: str
        :param _WrapServices: <p>封装服务列表</p>
        :type WrapServices: list of str
        :param _TargetSelect: <p>负载方式，robin random consistentHash</p>
        :type TargetSelect: str
        :param _TargetHosts: <p>目标服务器</p>
        :type TargetHosts: list of TargetHostDTO
        :param _HttpProtocolType: <p>后端协议：http https</p>
        :type HttpProtocolType: str
        :param _CheckTargetCertsError: <p>证书检查</p>
        :type CheckTargetCertsError: bool
        :param _TargetPath: <p>目标路径</p>
        :type TargetPath: str
        :param _InvokeLimitConfigStatus: <p>流量控制开启状态</p>
        :type InvokeLimitConfigStatus: bool
        :param _InvokeLimitConfig: <p>流量控制配置</p>
        :type InvokeLimitConfig: :class:`tencentcloud.apis.v20240801.models.InvokeLimitConfigDTO`
        :param _IpWhiteStatus: <p>IP白名单开启状态</p>
        :type IpWhiteStatus: bool
        :param _IpWhiteConfig: <p>IP白名单配置</p>
        :type IpWhiteConfig: :class:`tencentcloud.apis.v20240801.models.IpConfig`
        :param _IpBlackStatus: <p>IP黑名单开启状态</p>
        :type IpBlackStatus: bool
        :param _IpBlackConfig: <p>IP黑名单配置</p>
        :type IpBlackConfig: :class:`tencentcloud.apis.v20240801.models.IpConfig`
        :param _CustomHttpHost: <p>自定义host</p>
        :type CustomHttpHost: str
        :param _HttpHostType: <p>Http 请求host类型：useRequestHost 保持源请求；host targetHost 修正为源站host；  customHost 自定义host</p>
        :type HttpHostType: str
        :param _Timeout: <p>请求的超时时间</p>
        :type Timeout: int
        :param _McpSecurityRules: <p>安全规则集</p>
        :type McpSecurityRules: list of McpSecurityRule
        :param _ToolConfigs: <p>工具集配置（openapi时或许用的是）</p>
        :type ToolConfigs: list of ToolConfigDTO
        :param _WrapPaasID: <p>封装的API分组ID</p>
        :type WrapPaasID: str
        :param _PluginConfigs: <p>插件配置</p>
        :type PluginConfigs: list of PluginConfigDTO
        :param _IgnoreHealthCheck: <p>是否忽略健康检查</p>
        :type IgnoreHealthCheck: bool
        :param _CredentialID: <p>凭据ID</p>
        :type CredentialID: str
        :param _Domain: <p>访问域名</p>
        :type Domain: str
        :param _RequestProtocolType: <p>访问协议</p><p>枚举值：</p><ul><li>http： http</li><li>https： https</li></ul>
        :type RequestProtocolType: str
        """
        self._Mode = None
        self._McpVersion = None
        self._InstanceID = None
        self._Name = None
        self._Description = None
        self._WrapServices = None
        self._TargetSelect = None
        self._TargetHosts = None
        self._HttpProtocolType = None
        self._CheckTargetCertsError = None
        self._TargetPath = None
        self._InvokeLimitConfigStatus = None
        self._InvokeLimitConfig = None
        self._IpWhiteStatus = None
        self._IpWhiteConfig = None
        self._IpBlackStatus = None
        self._IpBlackConfig = None
        self._CustomHttpHost = None
        self._HttpHostType = None
        self._Timeout = None
        self._McpSecurityRules = None
        self._ToolConfigs = None
        self._WrapPaasID = None
        self._PluginConfigs = None
        self._IgnoreHealthCheck = None
        self._CredentialID = None
        self._Domain = None
        self._RequestProtocolType = None

    @property
    def Mode(self):
        r"""<p>模式：proxy代理模式； wrap封装模式；</p>
        :rtype: str
        """
        return self._Mode

    @Mode.setter
    def Mode(self, Mode):
        self._Mode = Mode

    @property
    def McpVersion(self):
        r"""<p>版本号：2024-11-05 2025-03-26</p>
        :rtype: str
        """
        return self._McpVersion

    @McpVersion.setter
    def McpVersion(self, McpVersion):
        self._McpVersion = McpVersion

    @property
    def InstanceID(self):
        r"""<p>实例ID</p>
        :rtype: str
        """
        return self._InstanceID

    @InstanceID.setter
    def InstanceID(self, InstanceID):
        self._InstanceID = InstanceID

    @property
    def Name(self):
        r"""<p>名称</p>
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def Description(self):
        r"""<p>描述</p>
        :rtype: str
        """
        return self._Description

    @Description.setter
    def Description(self, Description):
        self._Description = Description

    @property
    def WrapServices(self):
        r"""<p>封装服务列表</p>
        :rtype: list of str
        """
        return self._WrapServices

    @WrapServices.setter
    def WrapServices(self, WrapServices):
        self._WrapServices = WrapServices

    @property
    def TargetSelect(self):
        r"""<p>负载方式，robin random consistentHash</p>
        :rtype: str
        """
        return self._TargetSelect

    @TargetSelect.setter
    def TargetSelect(self, TargetSelect):
        self._TargetSelect = TargetSelect

    @property
    def TargetHosts(self):
        r"""<p>目标服务器</p>
        :rtype: list of TargetHostDTO
        """
        return self._TargetHosts

    @TargetHosts.setter
    def TargetHosts(self, TargetHosts):
        self._TargetHosts = TargetHosts

    @property
    def HttpProtocolType(self):
        r"""<p>后端协议：http https</p>
        :rtype: str
        """
        return self._HttpProtocolType

    @HttpProtocolType.setter
    def HttpProtocolType(self, HttpProtocolType):
        self._HttpProtocolType = HttpProtocolType

    @property
    def CheckTargetCertsError(self):
        r"""<p>证书检查</p>
        :rtype: bool
        """
        return self._CheckTargetCertsError

    @CheckTargetCertsError.setter
    def CheckTargetCertsError(self, CheckTargetCertsError):
        self._CheckTargetCertsError = CheckTargetCertsError

    @property
    def TargetPath(self):
        r"""<p>目标路径</p>
        :rtype: str
        """
        return self._TargetPath

    @TargetPath.setter
    def TargetPath(self, TargetPath):
        self._TargetPath = TargetPath

    @property
    def InvokeLimitConfigStatus(self):
        r"""<p>流量控制开启状态</p>
        :rtype: bool
        """
        return self._InvokeLimitConfigStatus

    @InvokeLimitConfigStatus.setter
    def InvokeLimitConfigStatus(self, InvokeLimitConfigStatus):
        self._InvokeLimitConfigStatus = InvokeLimitConfigStatus

    @property
    def InvokeLimitConfig(self):
        r"""<p>流量控制配置</p>
        :rtype: :class:`tencentcloud.apis.v20240801.models.InvokeLimitConfigDTO`
        """
        return self._InvokeLimitConfig

    @InvokeLimitConfig.setter
    def InvokeLimitConfig(self, InvokeLimitConfig):
        self._InvokeLimitConfig = InvokeLimitConfig

    @property
    def IpWhiteStatus(self):
        r"""<p>IP白名单开启状态</p>
        :rtype: bool
        """
        return self._IpWhiteStatus

    @IpWhiteStatus.setter
    def IpWhiteStatus(self, IpWhiteStatus):
        self._IpWhiteStatus = IpWhiteStatus

    @property
    def IpWhiteConfig(self):
        r"""<p>IP白名单配置</p>
        :rtype: :class:`tencentcloud.apis.v20240801.models.IpConfig`
        """
        return self._IpWhiteConfig

    @IpWhiteConfig.setter
    def IpWhiteConfig(self, IpWhiteConfig):
        self._IpWhiteConfig = IpWhiteConfig

    @property
    def IpBlackStatus(self):
        r"""<p>IP黑名单开启状态</p>
        :rtype: bool
        """
        return self._IpBlackStatus

    @IpBlackStatus.setter
    def IpBlackStatus(self, IpBlackStatus):
        self._IpBlackStatus = IpBlackStatus

    @property
    def IpBlackConfig(self):
        r"""<p>IP黑名单配置</p>
        :rtype: :class:`tencentcloud.apis.v20240801.models.IpConfig`
        """
        return self._IpBlackConfig

    @IpBlackConfig.setter
    def IpBlackConfig(self, IpBlackConfig):
        self._IpBlackConfig = IpBlackConfig

    @property
    def CustomHttpHost(self):
        r"""<p>自定义host</p>
        :rtype: str
        """
        return self._CustomHttpHost

    @CustomHttpHost.setter
    def CustomHttpHost(self, CustomHttpHost):
        self._CustomHttpHost = CustomHttpHost

    @property
    def HttpHostType(self):
        r"""<p>Http 请求host类型：useRequestHost 保持源请求；host targetHost 修正为源站host；  customHost 自定义host</p>
        :rtype: str
        """
        return self._HttpHostType

    @HttpHostType.setter
    def HttpHostType(self, HttpHostType):
        self._HttpHostType = HttpHostType

    @property
    def Timeout(self):
        r"""<p>请求的超时时间</p>
        :rtype: int
        """
        return self._Timeout

    @Timeout.setter
    def Timeout(self, Timeout):
        self._Timeout = Timeout

    @property
    def McpSecurityRules(self):
        r"""<p>安全规则集</p>
        :rtype: list of McpSecurityRule
        """
        return self._McpSecurityRules

    @McpSecurityRules.setter
    def McpSecurityRules(self, McpSecurityRules):
        self._McpSecurityRules = McpSecurityRules

    @property
    def ToolConfigs(self):
        r"""<p>工具集配置（openapi时或许用的是）</p>
        :rtype: list of ToolConfigDTO
        """
        return self._ToolConfigs

    @ToolConfigs.setter
    def ToolConfigs(self, ToolConfigs):
        self._ToolConfigs = ToolConfigs

    @property
    def WrapPaasID(self):
        r"""<p>封装的API分组ID</p>
        :rtype: str
        """
        return self._WrapPaasID

    @WrapPaasID.setter
    def WrapPaasID(self, WrapPaasID):
        self._WrapPaasID = WrapPaasID

    @property
    def PluginConfigs(self):
        r"""<p>插件配置</p>
        :rtype: list of PluginConfigDTO
        """
        return self._PluginConfigs

    @PluginConfigs.setter
    def PluginConfigs(self, PluginConfigs):
        self._PluginConfigs = PluginConfigs

    @property
    def IgnoreHealthCheck(self):
        r"""<p>是否忽略健康检查</p>
        :rtype: bool
        """
        return self._IgnoreHealthCheck

    @IgnoreHealthCheck.setter
    def IgnoreHealthCheck(self, IgnoreHealthCheck):
        self._IgnoreHealthCheck = IgnoreHealthCheck

    @property
    def CredentialID(self):
        r"""<p>凭据ID</p>
        :rtype: str
        """
        return self._CredentialID

    @CredentialID.setter
    def CredentialID(self, CredentialID):
        self._CredentialID = CredentialID

    @property
    def Domain(self):
        r"""<p>访问域名</p>
        :rtype: str
        """
        return self._Domain

    @Domain.setter
    def Domain(self, Domain):
        self._Domain = Domain

    @property
    def RequestProtocolType(self):
        r"""<p>访问协议</p><p>枚举值：</p><ul><li>http： http</li><li>https： https</li></ul>
        :rtype: str
        """
        return self._RequestProtocolType

    @RequestProtocolType.setter
    def RequestProtocolType(self, RequestProtocolType):
        self._RequestProtocolType = RequestProtocolType


    def _deserialize(self, params):
        self._Mode = params.get("Mode")
        self._McpVersion = params.get("McpVersion")
        self._InstanceID = params.get("InstanceID")
        self._Name = params.get("Name")
        self._Description = params.get("Description")
        self._WrapServices = params.get("WrapServices")
        self._TargetSelect = params.get("TargetSelect")
        if params.get("TargetHosts") is not None:
            self._TargetHosts = []
            for item in params.get("TargetHosts"):
                obj = TargetHostDTO()
                obj._deserialize(item)
                self._TargetHosts.append(obj)
        self._HttpProtocolType = params.get("HttpProtocolType")
        self._CheckTargetCertsError = params.get("CheckTargetCertsError")
        self._TargetPath = params.get("TargetPath")
        self._InvokeLimitConfigStatus = params.get("InvokeLimitConfigStatus")
        if params.get("InvokeLimitConfig") is not None:
            self._InvokeLimitConfig = InvokeLimitConfigDTO()
            self._InvokeLimitConfig._deserialize(params.get("InvokeLimitConfig"))
        self._IpWhiteStatus = params.get("IpWhiteStatus")
        if params.get("IpWhiteConfig") is not None:
            self._IpWhiteConfig = IpConfig()
            self._IpWhiteConfig._deserialize(params.get("IpWhiteConfig"))
        self._IpBlackStatus = params.get("IpBlackStatus")
        if params.get("IpBlackConfig") is not None:
            self._IpBlackConfig = IpConfig()
            self._IpBlackConfig._deserialize(params.get("IpBlackConfig"))
        self._CustomHttpHost = params.get("CustomHttpHost")
        self._HttpHostType = params.get("HttpHostType")
        self._Timeout = params.get("Timeout")
        if params.get("McpSecurityRules") is not None:
            self._McpSecurityRules = []
            for item in params.get("McpSecurityRules"):
                obj = McpSecurityRule()
                obj._deserialize(item)
                self._McpSecurityRules.append(obj)
        if params.get("ToolConfigs") is not None:
            self._ToolConfigs = []
            for item in params.get("ToolConfigs"):
                obj = ToolConfigDTO()
                obj._deserialize(item)
                self._ToolConfigs.append(obj)
        self._WrapPaasID = params.get("WrapPaasID")
        if params.get("PluginConfigs") is not None:
            self._PluginConfigs = []
            for item in params.get("PluginConfigs"):
                obj = PluginConfigDTO()
                obj._deserialize(item)
                self._PluginConfigs.append(obj)
        self._IgnoreHealthCheck = params.get("IgnoreHealthCheck")
        self._CredentialID = params.get("CredentialID")
        self._Domain = params.get("Domain")
        self._RequestProtocolType = params.get("RequestProtocolType")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class CreateMcpServerResponse(AbstractModel):
    r"""CreateMcpServer返回参数结构体

    """

    def __init__(self):
        r"""
        :param _Data: <p>mcp server ID</p>
        :type Data: :class:`tencentcloud.apis.v20240801.models.ResultIDVO`
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._Data = None
        self._RequestId = None

    @property
    def Data(self):
        r"""<p>mcp server ID</p>
        :rtype: :class:`tencentcloud.apis.v20240801.models.ResultIDVO`
        """
        return self._Data

    @Data.setter
    def Data(self, Data):
        self._Data = Data

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("Data") is not None:
            self._Data = ResultIDVO()
            self._Data._deserialize(params.get("Data"))
        self._RequestId = params.get("RequestId")


class CreateModelRequest(AbstractModel):
    r"""CreateModel请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceID: <p>实例</p>
        :type InstanceID: str
        :param _Name: <p>模型名称</p>
        :type Name: str
        :param _HttpProtocolType: <p>协议类型：http/https</p>
        :type HttpProtocolType: str
        :param _TargetPath: <p>目标路径</p>
        :type TargetPath: str
        :param _TargetHosts: <p>目标服务器</p>
        :type TargetHosts: list of TargetHostDTO
        :param _CredentialID: <p>凭据ID</p>
        :type CredentialID: str
        :param _CheckTargetCertsError: <p>https时，是否检查证书合法</p>
        :type CheckTargetCertsError: bool
        :param _HttpProtocolVersion: <p>http协议版本：1.1/2.0</p>
        :type HttpProtocolVersion: str
        :param _ModelID: <p>model ID</p>
        :type ModelID: str
        :param _Description: <p>描述</p>
        :type Description: str
        """
        self._InstanceID = None
        self._Name = None
        self._HttpProtocolType = None
        self._TargetPath = None
        self._TargetHosts = None
        self._CredentialID = None
        self._CheckTargetCertsError = None
        self._HttpProtocolVersion = None
        self._ModelID = None
        self._Description = None

    @property
    def InstanceID(self):
        r"""<p>实例</p>
        :rtype: str
        """
        return self._InstanceID

    @InstanceID.setter
    def InstanceID(self, InstanceID):
        self._InstanceID = InstanceID

    @property
    def Name(self):
        r"""<p>模型名称</p>
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def HttpProtocolType(self):
        r"""<p>协议类型：http/https</p>
        :rtype: str
        """
        return self._HttpProtocolType

    @HttpProtocolType.setter
    def HttpProtocolType(self, HttpProtocolType):
        self._HttpProtocolType = HttpProtocolType

    @property
    def TargetPath(self):
        r"""<p>目标路径</p>
        :rtype: str
        """
        return self._TargetPath

    @TargetPath.setter
    def TargetPath(self, TargetPath):
        self._TargetPath = TargetPath

    @property
    def TargetHosts(self):
        r"""<p>目标服务器</p>
        :rtype: list of TargetHostDTO
        """
        return self._TargetHosts

    @TargetHosts.setter
    def TargetHosts(self, TargetHosts):
        self._TargetHosts = TargetHosts

    @property
    def CredentialID(self):
        r"""<p>凭据ID</p>
        :rtype: str
        """
        return self._CredentialID

    @CredentialID.setter
    def CredentialID(self, CredentialID):
        self._CredentialID = CredentialID

    @property
    def CheckTargetCertsError(self):
        r"""<p>https时，是否检查证书合法</p>
        :rtype: bool
        """
        return self._CheckTargetCertsError

    @CheckTargetCertsError.setter
    def CheckTargetCertsError(self, CheckTargetCertsError):
        self._CheckTargetCertsError = CheckTargetCertsError

    @property
    def HttpProtocolVersion(self):
        r"""<p>http协议版本：1.1/2.0</p>
        :rtype: str
        """
        return self._HttpProtocolVersion

    @HttpProtocolVersion.setter
    def HttpProtocolVersion(self, HttpProtocolVersion):
        self._HttpProtocolVersion = HttpProtocolVersion

    @property
    def ModelID(self):
        r"""<p>model ID</p>
        :rtype: str
        """
        return self._ModelID

    @ModelID.setter
    def ModelID(self, ModelID):
        self._ModelID = ModelID

    @property
    def Description(self):
        r"""<p>描述</p>
        :rtype: str
        """
        return self._Description

    @Description.setter
    def Description(self, Description):
        self._Description = Description


    def _deserialize(self, params):
        self._InstanceID = params.get("InstanceID")
        self._Name = params.get("Name")
        self._HttpProtocolType = params.get("HttpProtocolType")
        self._TargetPath = params.get("TargetPath")
        if params.get("TargetHosts") is not None:
            self._TargetHosts = []
            for item in params.get("TargetHosts"):
                obj = TargetHostDTO()
                obj._deserialize(item)
                self._TargetHosts.append(obj)
        self._CredentialID = params.get("CredentialID")
        self._CheckTargetCertsError = params.get("CheckTargetCertsError")
        self._HttpProtocolVersion = params.get("HttpProtocolVersion")
        self._ModelID = params.get("ModelID")
        self._Description = params.get("Description")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class CreateModelResponse(AbstractModel):
    r"""CreateModel返回参数结构体

    """

    def __init__(self):
        r"""
        :param _Data: <p>结果集</p>
        :type Data: :class:`tencentcloud.apis.v20240801.models.ResultIDVO`
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._Data = None
        self._RequestId = None

    @property
    def Data(self):
        r"""<p>结果集</p>
        :rtype: :class:`tencentcloud.apis.v20240801.models.ResultIDVO`
        """
        return self._Data

    @Data.setter
    def Data(self, Data):
        self._Data = Data

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("Data") is not None:
            self._Data = ResultIDVO()
            self._Data._deserialize(params.get("Data"))
        self._RequestId = params.get("RequestId")


class CreateModelServiceRequest(AbstractModel):
    r"""CreateModelService请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceID: <p>实例</p>
        :type InstanceID: str
        :param _Name: <p>模型服务名称</p>
        :type Name: str
        :param _Description: <p>描述</p>
        :type Description: str
        :param _PubPath: <p>访问路径</p>
        :type PubPath: str
        :param _TargetModels: <p>模型ID列表</p>
        :type TargetModels: list of TargetModelDTO
        :param _PathMatchType: <p>路径匹配类型: prefix 前缀匹配(不送默认); absolute 绝对匹配; regex正则匹配;</p>
        :type PathMatchType: str
        :param _InvokeLimitConfigStatus: <p>是否开启限流</p>
        :type InvokeLimitConfigStatus: bool
        :param _InvokeLimitConfig: <p>限流配置</p>
        :type InvokeLimitConfig: :class:`tencentcloud.apis.v20240801.models.InvokeLimitConfigDTO`
        :param _TokenLimitStatus: <p>是否开启token控制</p>
        :type TokenLimitStatus: bool
        :param _TokenLimitConfig: <p>token控制</p>
        :type TokenLimitConfig: :class:`tencentcloud.apis.v20240801.models.TokenLimitConfigDTO`
        :param _TmsStatus: <p>是否开启内容安全</p>
        :type TmsStatus: bool
        :param _TmsConfig: <p>内容安全配置</p>
        :type TmsConfig: :class:`tencentcloud.apis.v20240801.models.TmsConfigDTO`
        :param _IpWhiteStatus: <p>是否开启IP白名单</p>
        :type IpWhiteStatus: bool
        :param _IpWhiteList: <p>IP白名单</p>
        :type IpWhiteList: list of str
        :param _IpBlackList: <p>IP黑名单</p>
        :type IpBlackList: list of str
        :param _PluginConfigs: <p>插件配置</p>
        :type PluginConfigs: list of PluginConfigDTO
        :param _Timeout: <p>超时配置，秒</p>
        :type Timeout: int
        :param _PromptModerateStatus: <p>是否开启提示词安全检测</p>
        :type PromptModerateStatus: bool
        :param _PromptModerateConfig: <p>提示词安全检测配置</p>
        :type PromptModerateConfig: :class:`tencentcloud.apis.v20240801.models.PromptModerateConfigDTO`
        :param _SensitiveDataCheckStatus: <p>是否开启敏感数据检测</p>
        :type SensitiveDataCheckStatus: bool
        :param _SensitiveDataCheckConfig: <p>敏感数据检测配置</p>
        :type SensitiveDataCheckConfig: :class:`tencentcloud.apis.v20240801.models.SensitiveDataCheckConfigDTO`
        :param _TargetSelect: <p>负载方式</p><p>枚举值：</p><ul><li>random： 随机</li><li>consistentHash： 会话保持</li></ul>
        :type TargetSelect: str
        :param _FindHostKeyMethod: <p>会话判断方式</p><p>枚举值：</p><ul><li>fromClientIP： 客户端IP</li><li>fromHeader： 通过header值</li><li>autoDetect： 自动探测</li></ul>
        :type FindHostKeyMethod: str
        :param _HostKeyHeaderName: <p>会话判定方式为fromHeader时会话的header名称</p>
        :type HostKeyHeaderName: str
        :param _FallbackStatus: <p>是否启用Fallback模型</p>
        :type FallbackStatus: bool
        :param _FallbackModels: <p>Fallback模型配置</p>
        :type FallbackModels: list of TargetModelDTO
        :param _ModelProtocol: <p>模型协议</p>
        :type ModelProtocol: str
        :param _RawCustomModelProtocolConfig: <p>自定义模型协议配置</p>
        :type RawCustomModelProtocolConfig: str
        :param _RouteStrategy: <p>路由策略</p><p>枚举值：</p><ul><li>weight： 权重</li><li>taskComplexity： 任务复杂度</li><li>tokenLength： token长度</li></ul>
        :type RouteStrategy: str
        :param _TokenLengthRoute: <p>token长度路由策略</p>
        :type TokenLengthRoute: list of TokenLengthRouteDTO
        :param _TaskComplexityRoute: <p>任务复杂度路由策略</p>
        :type TaskComplexityRoute: :class:`tencentcloud.apis.v20240801.models.TaskComplexityRouteDTO`
        :param _Domain: <p>访问域名</p>
        :type Domain: str
        :param _RequestProtocolType: <p>访问协议</p>
        :type RequestProtocolType: str
        """
        self._InstanceID = None
        self._Name = None
        self._Description = None
        self._PubPath = None
        self._TargetModels = None
        self._PathMatchType = None
        self._InvokeLimitConfigStatus = None
        self._InvokeLimitConfig = None
        self._TokenLimitStatus = None
        self._TokenLimitConfig = None
        self._TmsStatus = None
        self._TmsConfig = None
        self._IpWhiteStatus = None
        self._IpWhiteList = None
        self._IpBlackList = None
        self._PluginConfigs = None
        self._Timeout = None
        self._PromptModerateStatus = None
        self._PromptModerateConfig = None
        self._SensitiveDataCheckStatus = None
        self._SensitiveDataCheckConfig = None
        self._TargetSelect = None
        self._FindHostKeyMethod = None
        self._HostKeyHeaderName = None
        self._FallbackStatus = None
        self._FallbackModels = None
        self._ModelProtocol = None
        self._RawCustomModelProtocolConfig = None
        self._RouteStrategy = None
        self._TokenLengthRoute = None
        self._TaskComplexityRoute = None
        self._Domain = None
        self._RequestProtocolType = None

    @property
    def InstanceID(self):
        r"""<p>实例</p>
        :rtype: str
        """
        return self._InstanceID

    @InstanceID.setter
    def InstanceID(self, InstanceID):
        self._InstanceID = InstanceID

    @property
    def Name(self):
        r"""<p>模型服务名称</p>
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def Description(self):
        r"""<p>描述</p>
        :rtype: str
        """
        return self._Description

    @Description.setter
    def Description(self, Description):
        self._Description = Description

    @property
    def PubPath(self):
        r"""<p>访问路径</p>
        :rtype: str
        """
        return self._PubPath

    @PubPath.setter
    def PubPath(self, PubPath):
        self._PubPath = PubPath

    @property
    def TargetModels(self):
        r"""<p>模型ID列表</p>
        :rtype: list of TargetModelDTO
        """
        return self._TargetModels

    @TargetModels.setter
    def TargetModels(self, TargetModels):
        self._TargetModels = TargetModels

    @property
    def PathMatchType(self):
        r"""<p>路径匹配类型: prefix 前缀匹配(不送默认); absolute 绝对匹配; regex正则匹配;</p>
        :rtype: str
        """
        return self._PathMatchType

    @PathMatchType.setter
    def PathMatchType(self, PathMatchType):
        self._PathMatchType = PathMatchType

    @property
    def InvokeLimitConfigStatus(self):
        r"""<p>是否开启限流</p>
        :rtype: bool
        """
        return self._InvokeLimitConfigStatus

    @InvokeLimitConfigStatus.setter
    def InvokeLimitConfigStatus(self, InvokeLimitConfigStatus):
        self._InvokeLimitConfigStatus = InvokeLimitConfigStatus

    @property
    def InvokeLimitConfig(self):
        r"""<p>限流配置</p>
        :rtype: :class:`tencentcloud.apis.v20240801.models.InvokeLimitConfigDTO`
        """
        return self._InvokeLimitConfig

    @InvokeLimitConfig.setter
    def InvokeLimitConfig(self, InvokeLimitConfig):
        self._InvokeLimitConfig = InvokeLimitConfig

    @property
    def TokenLimitStatus(self):
        r"""<p>是否开启token控制</p>
        :rtype: bool
        """
        return self._TokenLimitStatus

    @TokenLimitStatus.setter
    def TokenLimitStatus(self, TokenLimitStatus):
        self._TokenLimitStatus = TokenLimitStatus

    @property
    def TokenLimitConfig(self):
        r"""<p>token控制</p>
        :rtype: :class:`tencentcloud.apis.v20240801.models.TokenLimitConfigDTO`
        """
        return self._TokenLimitConfig

    @TokenLimitConfig.setter
    def TokenLimitConfig(self, TokenLimitConfig):
        self._TokenLimitConfig = TokenLimitConfig

    @property
    def TmsStatus(self):
        r"""<p>是否开启内容安全</p>
        :rtype: bool
        """
        return self._TmsStatus

    @TmsStatus.setter
    def TmsStatus(self, TmsStatus):
        self._TmsStatus = TmsStatus

    @property
    def TmsConfig(self):
        r"""<p>内容安全配置</p>
        :rtype: :class:`tencentcloud.apis.v20240801.models.TmsConfigDTO`
        """
        return self._TmsConfig

    @TmsConfig.setter
    def TmsConfig(self, TmsConfig):
        self._TmsConfig = TmsConfig

    @property
    def IpWhiteStatus(self):
        r"""<p>是否开启IP白名单</p>
        :rtype: bool
        """
        return self._IpWhiteStatus

    @IpWhiteStatus.setter
    def IpWhiteStatus(self, IpWhiteStatus):
        self._IpWhiteStatus = IpWhiteStatus

    @property
    def IpWhiteList(self):
        r"""<p>IP白名单</p>
        :rtype: list of str
        """
        return self._IpWhiteList

    @IpWhiteList.setter
    def IpWhiteList(self, IpWhiteList):
        self._IpWhiteList = IpWhiteList

    @property
    def IpBlackList(self):
        r"""<p>IP黑名单</p>
        :rtype: list of str
        """
        return self._IpBlackList

    @IpBlackList.setter
    def IpBlackList(self, IpBlackList):
        self._IpBlackList = IpBlackList

    @property
    def PluginConfigs(self):
        r"""<p>插件配置</p>
        :rtype: list of PluginConfigDTO
        """
        return self._PluginConfigs

    @PluginConfigs.setter
    def PluginConfigs(self, PluginConfigs):
        self._PluginConfigs = PluginConfigs

    @property
    def Timeout(self):
        r"""<p>超时配置，秒</p>
        :rtype: int
        """
        return self._Timeout

    @Timeout.setter
    def Timeout(self, Timeout):
        self._Timeout = Timeout

    @property
    def PromptModerateStatus(self):
        r"""<p>是否开启提示词安全检测</p>
        :rtype: bool
        """
        return self._PromptModerateStatus

    @PromptModerateStatus.setter
    def PromptModerateStatus(self, PromptModerateStatus):
        self._PromptModerateStatus = PromptModerateStatus

    @property
    def PromptModerateConfig(self):
        r"""<p>提示词安全检测配置</p>
        :rtype: :class:`tencentcloud.apis.v20240801.models.PromptModerateConfigDTO`
        """
        return self._PromptModerateConfig

    @PromptModerateConfig.setter
    def PromptModerateConfig(self, PromptModerateConfig):
        self._PromptModerateConfig = PromptModerateConfig

    @property
    def SensitiveDataCheckStatus(self):
        r"""<p>是否开启敏感数据检测</p>
        :rtype: bool
        """
        return self._SensitiveDataCheckStatus

    @SensitiveDataCheckStatus.setter
    def SensitiveDataCheckStatus(self, SensitiveDataCheckStatus):
        self._SensitiveDataCheckStatus = SensitiveDataCheckStatus

    @property
    def SensitiveDataCheckConfig(self):
        r"""<p>敏感数据检测配置</p>
        :rtype: :class:`tencentcloud.apis.v20240801.models.SensitiveDataCheckConfigDTO`
        """
        return self._SensitiveDataCheckConfig

    @SensitiveDataCheckConfig.setter
    def SensitiveDataCheckConfig(self, SensitiveDataCheckConfig):
        self._SensitiveDataCheckConfig = SensitiveDataCheckConfig

    @property
    def TargetSelect(self):
        r"""<p>负载方式</p><p>枚举值：</p><ul><li>random： 随机</li><li>consistentHash： 会话保持</li></ul>
        :rtype: str
        """
        return self._TargetSelect

    @TargetSelect.setter
    def TargetSelect(self, TargetSelect):
        self._TargetSelect = TargetSelect

    @property
    def FindHostKeyMethod(self):
        r"""<p>会话判断方式</p><p>枚举值：</p><ul><li>fromClientIP： 客户端IP</li><li>fromHeader： 通过header值</li><li>autoDetect： 自动探测</li></ul>
        :rtype: str
        """
        return self._FindHostKeyMethod

    @FindHostKeyMethod.setter
    def FindHostKeyMethod(self, FindHostKeyMethod):
        self._FindHostKeyMethod = FindHostKeyMethod

    @property
    def HostKeyHeaderName(self):
        r"""<p>会话判定方式为fromHeader时会话的header名称</p>
        :rtype: str
        """
        return self._HostKeyHeaderName

    @HostKeyHeaderName.setter
    def HostKeyHeaderName(self, HostKeyHeaderName):
        self._HostKeyHeaderName = HostKeyHeaderName

    @property
    def FallbackStatus(self):
        r"""<p>是否启用Fallback模型</p>
        :rtype: bool
        """
        return self._FallbackStatus

    @FallbackStatus.setter
    def FallbackStatus(self, FallbackStatus):
        self._FallbackStatus = FallbackStatus

    @property
    def FallbackModels(self):
        r"""<p>Fallback模型配置</p>
        :rtype: list of TargetModelDTO
        """
        return self._FallbackModels

    @FallbackModels.setter
    def FallbackModels(self, FallbackModels):
        self._FallbackModels = FallbackModels

    @property
    def ModelProtocol(self):
        r"""<p>模型协议</p>
        :rtype: str
        """
        return self._ModelProtocol

    @ModelProtocol.setter
    def ModelProtocol(self, ModelProtocol):
        self._ModelProtocol = ModelProtocol

    @property
    def RawCustomModelProtocolConfig(self):
        r"""<p>自定义模型协议配置</p>
        :rtype: str
        """
        return self._RawCustomModelProtocolConfig

    @RawCustomModelProtocolConfig.setter
    def RawCustomModelProtocolConfig(self, RawCustomModelProtocolConfig):
        self._RawCustomModelProtocolConfig = RawCustomModelProtocolConfig

    @property
    def RouteStrategy(self):
        r"""<p>路由策略</p><p>枚举值：</p><ul><li>weight： 权重</li><li>taskComplexity： 任务复杂度</li><li>tokenLength： token长度</li></ul>
        :rtype: str
        """
        return self._RouteStrategy

    @RouteStrategy.setter
    def RouteStrategy(self, RouteStrategy):
        self._RouteStrategy = RouteStrategy

    @property
    def TokenLengthRoute(self):
        r"""<p>token长度路由策略</p>
        :rtype: list of TokenLengthRouteDTO
        """
        return self._TokenLengthRoute

    @TokenLengthRoute.setter
    def TokenLengthRoute(self, TokenLengthRoute):
        self._TokenLengthRoute = TokenLengthRoute

    @property
    def TaskComplexityRoute(self):
        r"""<p>任务复杂度路由策略</p>
        :rtype: :class:`tencentcloud.apis.v20240801.models.TaskComplexityRouteDTO`
        """
        return self._TaskComplexityRoute

    @TaskComplexityRoute.setter
    def TaskComplexityRoute(self, TaskComplexityRoute):
        self._TaskComplexityRoute = TaskComplexityRoute

    @property
    def Domain(self):
        r"""<p>访问域名</p>
        :rtype: str
        """
        return self._Domain

    @Domain.setter
    def Domain(self, Domain):
        self._Domain = Domain

    @property
    def RequestProtocolType(self):
        r"""<p>访问协议</p>
        :rtype: str
        """
        return self._RequestProtocolType

    @RequestProtocolType.setter
    def RequestProtocolType(self, RequestProtocolType):
        self._RequestProtocolType = RequestProtocolType


    def _deserialize(self, params):
        self._InstanceID = params.get("InstanceID")
        self._Name = params.get("Name")
        self._Description = params.get("Description")
        self._PubPath = params.get("PubPath")
        if params.get("TargetModels") is not None:
            self._TargetModels = []
            for item in params.get("TargetModels"):
                obj = TargetModelDTO()
                obj._deserialize(item)
                self._TargetModels.append(obj)
        self._PathMatchType = params.get("PathMatchType")
        self._InvokeLimitConfigStatus = params.get("InvokeLimitConfigStatus")
        if params.get("InvokeLimitConfig") is not None:
            self._InvokeLimitConfig = InvokeLimitConfigDTO()
            self._InvokeLimitConfig._deserialize(params.get("InvokeLimitConfig"))
        self._TokenLimitStatus = params.get("TokenLimitStatus")
        if params.get("TokenLimitConfig") is not None:
            self._TokenLimitConfig = TokenLimitConfigDTO()
            self._TokenLimitConfig._deserialize(params.get("TokenLimitConfig"))
        self._TmsStatus = params.get("TmsStatus")
        if params.get("TmsConfig") is not None:
            self._TmsConfig = TmsConfigDTO()
            self._TmsConfig._deserialize(params.get("TmsConfig"))
        self._IpWhiteStatus = params.get("IpWhiteStatus")
        self._IpWhiteList = params.get("IpWhiteList")
        self._IpBlackList = params.get("IpBlackList")
        if params.get("PluginConfigs") is not None:
            self._PluginConfigs = []
            for item in params.get("PluginConfigs"):
                obj = PluginConfigDTO()
                obj._deserialize(item)
                self._PluginConfigs.append(obj)
        self._Timeout = params.get("Timeout")
        self._PromptModerateStatus = params.get("PromptModerateStatus")
        if params.get("PromptModerateConfig") is not None:
            self._PromptModerateConfig = PromptModerateConfigDTO()
            self._PromptModerateConfig._deserialize(params.get("PromptModerateConfig"))
        self._SensitiveDataCheckStatus = params.get("SensitiveDataCheckStatus")
        if params.get("SensitiveDataCheckConfig") is not None:
            self._SensitiveDataCheckConfig = SensitiveDataCheckConfigDTO()
            self._SensitiveDataCheckConfig._deserialize(params.get("SensitiveDataCheckConfig"))
        self._TargetSelect = params.get("TargetSelect")
        self._FindHostKeyMethod = params.get("FindHostKeyMethod")
        self._HostKeyHeaderName = params.get("HostKeyHeaderName")
        self._FallbackStatus = params.get("FallbackStatus")
        if params.get("FallbackModels") is not None:
            self._FallbackModels = []
            for item in params.get("FallbackModels"):
                obj = TargetModelDTO()
                obj._deserialize(item)
                self._FallbackModels.append(obj)
        self._ModelProtocol = params.get("ModelProtocol")
        self._RawCustomModelProtocolConfig = params.get("RawCustomModelProtocolConfig")
        self._RouteStrategy = params.get("RouteStrategy")
        if params.get("TokenLengthRoute") is not None:
            self._TokenLengthRoute = []
            for item in params.get("TokenLengthRoute"):
                obj = TokenLengthRouteDTO()
                obj._deserialize(item)
                self._TokenLengthRoute.append(obj)
        if params.get("TaskComplexityRoute") is not None:
            self._TaskComplexityRoute = TaskComplexityRouteDTO()
            self._TaskComplexityRoute._deserialize(params.get("TaskComplexityRoute"))
        self._Domain = params.get("Domain")
        self._RequestProtocolType = params.get("RequestProtocolType")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class CreateModelServiceResponse(AbstractModel):
    r"""CreateModelService返回参数结构体

    """

    def __init__(self):
        r"""
        :param _Data: <p>结果集</p>
        :type Data: :class:`tencentcloud.apis.v20240801.models.ResultIDVO`
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._Data = None
        self._RequestId = None

    @property
    def Data(self):
        r"""<p>结果集</p>
        :rtype: :class:`tencentcloud.apis.v20240801.models.ResultIDVO`
        """
        return self._Data

    @Data.setter
    def Data(self, Data):
        self._Data = Data

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("Data") is not None:
            self._Data = ResultIDVO()
            self._Data._deserialize(params.get("Data"))
        self._RequestId = params.get("RequestId")


class CreateServiceRequest(AbstractModel):
    r"""CreateService请求参数结构体

    """


class CreateServiceResponse(AbstractModel):
    r"""CreateService返回参数结构体

    """

    def __init__(self):
        r"""
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._RequestId = None

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._RequestId = params.get("RequestId")


class CustomMatch(AbstractModel):
    r"""自定义匹配条件

    """

    def __init__(self):
        r"""
        :param _HeadersMatch: <p>请求头  匹配条件</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type HeadersMatch: :class:`tencentcloud.apis.v20240801.models.CompoundCondition`
        :param _QueryMatch: <p>请求参数 匹配条件</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type QueryMatch: :class:`tencentcloud.apis.v20240801.models.CompoundCondition`
        """
        self._HeadersMatch = None
        self._QueryMatch = None

    @property
    def HeadersMatch(self):
        r"""<p>请求头  匹配条件</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: :class:`tencentcloud.apis.v20240801.models.CompoundCondition`
        """
        return self._HeadersMatch

    @HeadersMatch.setter
    def HeadersMatch(self, HeadersMatch):
        self._HeadersMatch = HeadersMatch

    @property
    def QueryMatch(self):
        r"""<p>请求参数 匹配条件</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: :class:`tencentcloud.apis.v20240801.models.CompoundCondition`
        """
        return self._QueryMatch

    @QueryMatch.setter
    def QueryMatch(self, QueryMatch):
        self._QueryMatch = QueryMatch


    def _deserialize(self, params):
        if params.get("HeadersMatch") is not None:
            self._HeadersMatch = CompoundCondition()
            self._HeadersMatch._deserialize(params.get("HeadersMatch"))
        if params.get("QueryMatch") is not None:
            self._QueryMatch = CompoundCondition()
            self._QueryMatch._deserialize(params.get("QueryMatch"))
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DeleteAgentAppMcpServersRequest(AbstractModel):
    r"""DeleteAgentAppMcpServers请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceID: 实例ID
        :type InstanceID: str
        :param _ID: 应用ID
        :type ID: str
        :param _McpServerIDs: mcp server id数组
        :type McpServerIDs: list of str
        """
        self._InstanceID = None
        self._ID = None
        self._McpServerIDs = None

    @property
    def InstanceID(self):
        r"""实例ID
        :rtype: str
        """
        return self._InstanceID

    @InstanceID.setter
    def InstanceID(self, InstanceID):
        self._InstanceID = InstanceID

    @property
    def ID(self):
        r"""应用ID
        :rtype: str
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID

    @property
    def McpServerIDs(self):
        r"""mcp server id数组
        :rtype: list of str
        """
        return self._McpServerIDs

    @McpServerIDs.setter
    def McpServerIDs(self, McpServerIDs):
        self._McpServerIDs = McpServerIDs


    def _deserialize(self, params):
        self._InstanceID = params.get("InstanceID")
        self._ID = params.get("ID")
        self._McpServerIDs = params.get("McpServerIDs")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DeleteAgentAppMcpServersResponse(AbstractModel):
    r"""DeleteAgentAppMcpServers返回参数结构体

    """

    def __init__(self):
        r"""
        :param _Data: app id
        :type Data: :class:`tencentcloud.apis.v20240801.models.ResultIDVO`
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._Data = None
        self._RequestId = None

    @property
    def Data(self):
        r"""app id
        :rtype: :class:`tencentcloud.apis.v20240801.models.ResultIDVO`
        """
        return self._Data

    @Data.setter
    def Data(self, Data):
        self._Data = Data

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("Data") is not None:
            self._Data = ResultIDVO()
            self._Data._deserialize(params.get("Data"))
        self._RequestId = params.get("RequestId")


class DeleteAgentAppModelServicesRequest(AbstractModel):
    r"""DeleteAgentAppModelServices请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceID: 实例ID
        :type InstanceID: str
        :param _ID: 应用ID
        :type ID: str
        :param _ModelServiceIDs: 关联的model service id
        :type ModelServiceIDs: list of str
        """
        self._InstanceID = None
        self._ID = None
        self._ModelServiceIDs = None

    @property
    def InstanceID(self):
        r"""实例ID
        :rtype: str
        """
        return self._InstanceID

    @InstanceID.setter
    def InstanceID(self, InstanceID):
        self._InstanceID = InstanceID

    @property
    def ID(self):
        r"""应用ID
        :rtype: str
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID

    @property
    def ModelServiceIDs(self):
        r"""关联的model service id
        :rtype: list of str
        """
        return self._ModelServiceIDs

    @ModelServiceIDs.setter
    def ModelServiceIDs(self, ModelServiceIDs):
        self._ModelServiceIDs = ModelServiceIDs


    def _deserialize(self, params):
        self._InstanceID = params.get("InstanceID")
        self._ID = params.get("ID")
        self._ModelServiceIDs = params.get("ModelServiceIDs")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DeleteAgentAppModelServicesResponse(AbstractModel):
    r"""DeleteAgentAppModelServices返回参数结构体

    """

    def __init__(self):
        r"""
        :param _Data: app id
        :type Data: :class:`tencentcloud.apis.v20240801.models.ResultIDVO`
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._Data = None
        self._RequestId = None

    @property
    def Data(self):
        r"""app id
        :rtype: :class:`tencentcloud.apis.v20240801.models.ResultIDVO`
        """
        return self._Data

    @Data.setter
    def Data(self, Data):
        self._Data = Data

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("Data") is not None:
            self._Data = ResultIDVO()
            self._Data._deserialize(params.get("Data"))
        self._RequestId = params.get("RequestId")


class DeleteAgentAppRequest(AbstractModel):
    r"""DeleteAgentApp请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceID: 实例ID
        :type InstanceID: str
        :param _ID: 应用ID
        :type ID: str
        """
        self._InstanceID = None
        self._ID = None

    @property
    def InstanceID(self):
        r"""实例ID
        :rtype: str
        """
        return self._InstanceID

    @InstanceID.setter
    def InstanceID(self, InstanceID):
        self._InstanceID = InstanceID

    @property
    def ID(self):
        r"""应用ID
        :rtype: str
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID


    def _deserialize(self, params):
        self._InstanceID = params.get("InstanceID")
        self._ID = params.get("ID")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DeleteAgentAppResponse(AbstractModel):
    r"""DeleteAgentApp返回参数结构体

    """

    def __init__(self):
        r"""
        :param _Data: app id
        :type Data: :class:`tencentcloud.apis.v20240801.models.ResultIDVO`
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._Data = None
        self._RequestId = None

    @property
    def Data(self):
        r"""app id
        :rtype: :class:`tencentcloud.apis.v20240801.models.ResultIDVO`
        """
        return self._Data

    @Data.setter
    def Data(self, Data):
        self._Data = Data

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("Data") is not None:
            self._Data = ResultIDVO()
            self._Data._deserialize(params.get("Data"))
        self._RequestId = params.get("RequestId")


class DeleteAgentAppServicesRequest(AbstractModel):
    r"""DeleteAgentAppServices请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceID: <p>实例ID</p>
        :type InstanceID: str
        :param _ID: <p>应用ID</p>
        :type ID: str
        :param _ServiceIDs: <p>服务IDs</p>
        :type ServiceIDs: list of str
        """
        self._InstanceID = None
        self._ID = None
        self._ServiceIDs = None

    @property
    def InstanceID(self):
        r"""<p>实例ID</p>
        :rtype: str
        """
        return self._InstanceID

    @InstanceID.setter
    def InstanceID(self, InstanceID):
        self._InstanceID = InstanceID

    @property
    def ID(self):
        r"""<p>应用ID</p>
        :rtype: str
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID

    @property
    def ServiceIDs(self):
        r"""<p>服务IDs</p>
        :rtype: list of str
        """
        return self._ServiceIDs

    @ServiceIDs.setter
    def ServiceIDs(self, ServiceIDs):
        self._ServiceIDs = ServiceIDs


    def _deserialize(self, params):
        self._InstanceID = params.get("InstanceID")
        self._ID = params.get("ID")
        self._ServiceIDs = params.get("ServiceIDs")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DeleteAgentAppServicesResponse(AbstractModel):
    r"""DeleteAgentAppServices返回参数结构体

    """

    def __init__(self):
        r"""
        :param _Data: <p>app id</p>
        :type Data: :class:`tencentcloud.apis.v20240801.models.ResultIDVO`
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._Data = None
        self._RequestId = None

    @property
    def Data(self):
        r"""<p>app id</p>
        :rtype: :class:`tencentcloud.apis.v20240801.models.ResultIDVO`
        """
        return self._Data

    @Data.setter
    def Data(self, Data):
        self._Data = Data

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("Data") is not None:
            self._Data = ResultIDVO()
            self._Data._deserialize(params.get("Data"))
        self._RequestId = params.get("RequestId")


class DeleteAgentCredentialRequest(AbstractModel):
    r"""DeleteAgentCredential请求参数结构体

    """


class DeleteAgentCredentialResponse(AbstractModel):
    r"""DeleteAgentCredential返回参数结构体

    """

    def __init__(self):
        r"""
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._RequestId = None

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._RequestId = params.get("RequestId")


class DeleteMcpServerRequest(AbstractModel):
    r"""DeleteMcpServer请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceID: 实例ID
        :type InstanceID: str
        :param _ID: mcp server ID
        :type ID: str
        """
        self._InstanceID = None
        self._ID = None

    @property
    def InstanceID(self):
        r"""实例ID
        :rtype: str
        """
        return self._InstanceID

    @InstanceID.setter
    def InstanceID(self, InstanceID):
        self._InstanceID = InstanceID

    @property
    def ID(self):
        r"""mcp server ID
        :rtype: str
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID


    def _deserialize(self, params):
        self._InstanceID = params.get("InstanceID")
        self._ID = params.get("ID")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DeleteMcpServerResponse(AbstractModel):
    r"""DeleteMcpServer返回参数结构体

    """

    def __init__(self):
        r"""
        :param _Data: mcp server ID
        :type Data: :class:`tencentcloud.apis.v20240801.models.ResultIDVO`
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._Data = None
        self._RequestId = None

    @property
    def Data(self):
        r"""mcp server ID
        :rtype: :class:`tencentcloud.apis.v20240801.models.ResultIDVO`
        """
        return self._Data

    @Data.setter
    def Data(self, Data):
        self._Data = Data

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("Data") is not None:
            self._Data = ResultIDVO()
            self._Data._deserialize(params.get("Data"))
        self._RequestId = params.get("RequestId")


class DeleteModelRequest(AbstractModel):
    r"""DeleteModel请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceID: 实例
        :type InstanceID: str
        :param _IDs: 模型ID数组
        :type IDs: list of str
        """
        self._InstanceID = None
        self._IDs = None

    @property
    def InstanceID(self):
        r"""实例
        :rtype: str
        """
        return self._InstanceID

    @InstanceID.setter
    def InstanceID(self, InstanceID):
        self._InstanceID = InstanceID

    @property
    def IDs(self):
        r"""模型ID数组
        :rtype: list of str
        """
        return self._IDs

    @IDs.setter
    def IDs(self, IDs):
        self._IDs = IDs


    def _deserialize(self, params):
        self._InstanceID = params.get("InstanceID")
        self._IDs = params.get("IDs")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DeleteModelResponse(AbstractModel):
    r"""DeleteModel返回参数结构体

    """

    def __init__(self):
        r"""
        :param _Data: 结果集
        :type Data: :class:`tencentcloud.apis.v20240801.models.ResultIDsVO`
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._Data = None
        self._RequestId = None

    @property
    def Data(self):
        r"""结果集
        :rtype: :class:`tencentcloud.apis.v20240801.models.ResultIDsVO`
        """
        return self._Data

    @Data.setter
    def Data(self, Data):
        self._Data = Data

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("Data") is not None:
            self._Data = ResultIDsVO()
            self._Data._deserialize(params.get("Data"))
        self._RequestId = params.get("RequestId")


class DeleteModelServiceRequest(AbstractModel):
    r"""DeleteModelService请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceID: 实例
        :type InstanceID: str
        :param _ID: 模型服务ID
        :type ID: str
        """
        self._InstanceID = None
        self._ID = None

    @property
    def InstanceID(self):
        r"""实例
        :rtype: str
        """
        return self._InstanceID

    @InstanceID.setter
    def InstanceID(self, InstanceID):
        self._InstanceID = InstanceID

    @property
    def ID(self):
        r"""模型服务ID
        :rtype: str
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID


    def _deserialize(self, params):
        self._InstanceID = params.get("InstanceID")
        self._ID = params.get("ID")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DeleteModelServiceResponse(AbstractModel):
    r"""DeleteModelService返回参数结构体

    """

    def __init__(self):
        r"""
        :param _Data: 结果集
        :type Data: :class:`tencentcloud.apis.v20240801.models.ResultIDVO`
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._Data = None
        self._RequestId = None

    @property
    def Data(self):
        r"""结果集
        :rtype: :class:`tencentcloud.apis.v20240801.models.ResultIDVO`
        """
        return self._Data

    @Data.setter
    def Data(self, Data):
        self._Data = Data

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("Data") is not None:
            self._Data = ResultIDVO()
            self._Data._deserialize(params.get("Data"))
        self._RequestId = params.get("RequestId")


class DeleteServiceRequest(AbstractModel):
    r"""DeleteService请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceID: <p>实例ID</p>
        :type InstanceID: str
        :param _ID: <p>业务ID</p>
        :type ID: str
        """
        self._InstanceID = None
        self._ID = None

    @property
    def InstanceID(self):
        r"""<p>实例ID</p>
        :rtype: str
        """
        return self._InstanceID

    @InstanceID.setter
    def InstanceID(self, InstanceID):
        self._InstanceID = InstanceID

    @property
    def ID(self):
        r"""<p>业务ID</p>
        :rtype: str
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID


    def _deserialize(self, params):
        self._InstanceID = params.get("InstanceID")
        self._ID = params.get("ID")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DeleteServiceResponse(AbstractModel):
    r"""DeleteService返回参数结构体

    """

    def __init__(self):
        r"""
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._RequestId = None

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._RequestId = params.get("RequestId")


class DescribeAgentAppMcpServersRequest(AbstractModel):
    r"""DescribeAgentAppMcpServers请求参数结构体

    """

    def __init__(self):
        r"""
        :param _Limit: 分页大小
        :type Limit: int
        :param _Offset: 分页偏移量
        :type Offset: int
        :param _InstanceID: 实例ID
        :type InstanceID: str
        :param _AgentAppIDs: 应用ID
        :type AgentAppIDs: list of str
        :param _McpServerIDs: 关联的mcp
        :type McpServerIDs: list of str
        :param _AgentCredentialIDs: 凭据ID
        :type AgentCredentialIDs: list of str
        :param _Keyword: 关键词
        :type Keyword: str
        """
        self._Limit = None
        self._Offset = None
        self._InstanceID = None
        self._AgentAppIDs = None
        self._McpServerIDs = None
        self._AgentCredentialIDs = None
        self._Keyword = None

    @property
    def Limit(self):
        r"""分页大小
        :rtype: int
        """
        return self._Limit

    @Limit.setter
    def Limit(self, Limit):
        self._Limit = Limit

    @property
    def Offset(self):
        r"""分页偏移量
        :rtype: int
        """
        return self._Offset

    @Offset.setter
    def Offset(self, Offset):
        self._Offset = Offset

    @property
    def InstanceID(self):
        r"""实例ID
        :rtype: str
        """
        return self._InstanceID

    @InstanceID.setter
    def InstanceID(self, InstanceID):
        self._InstanceID = InstanceID

    @property
    def AgentAppIDs(self):
        r"""应用ID
        :rtype: list of str
        """
        return self._AgentAppIDs

    @AgentAppIDs.setter
    def AgentAppIDs(self, AgentAppIDs):
        self._AgentAppIDs = AgentAppIDs

    @property
    def McpServerIDs(self):
        r"""关联的mcp
        :rtype: list of str
        """
        return self._McpServerIDs

    @McpServerIDs.setter
    def McpServerIDs(self, McpServerIDs):
        self._McpServerIDs = McpServerIDs

    @property
    def AgentCredentialIDs(self):
        r"""凭据ID
        :rtype: list of str
        """
        return self._AgentCredentialIDs

    @AgentCredentialIDs.setter
    def AgentCredentialIDs(self, AgentCredentialIDs):
        self._AgentCredentialIDs = AgentCredentialIDs

    @property
    def Keyword(self):
        r"""关键词
        :rtype: str
        """
        return self._Keyword

    @Keyword.setter
    def Keyword(self, Keyword):
        self._Keyword = Keyword


    def _deserialize(self, params):
        self._Limit = params.get("Limit")
        self._Offset = params.get("Offset")
        self._InstanceID = params.get("InstanceID")
        self._AgentAppIDs = params.get("AgentAppIDs")
        self._McpServerIDs = params.get("McpServerIDs")
        self._AgentCredentialIDs = params.get("AgentCredentialIDs")
        self._Keyword = params.get("Keyword")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeAgentAppMcpServersResp(AbstractModel):
    r"""查询App mcpServer绑定列表响应

    """

    def __init__(self):
        r"""
        :param _Total: 条目总数
        :type Total: int
        :param _Items: 具体条目
        :type Items: list of AgentAppMcpServerVO
        """
        self._Total = None
        self._Items = None

    @property
    def Total(self):
        r"""条目总数
        :rtype: int
        """
        return self._Total

    @Total.setter
    def Total(self, Total):
        self._Total = Total

    @property
    def Items(self):
        r"""具体条目
        :rtype: list of AgentAppMcpServerVO
        """
        return self._Items

    @Items.setter
    def Items(self, Items):
        self._Items = Items


    def _deserialize(self, params):
        self._Total = params.get("Total")
        if params.get("Items") is not None:
            self._Items = []
            for item in params.get("Items"):
                obj = AgentAppMcpServerVO()
                obj._deserialize(item)
                self._Items.append(obj)
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeAgentAppMcpServersResponse(AbstractModel):
    r"""DescribeAgentAppMcpServers返回参数结构体

    """

    def __init__(self):
        r"""
        :param _Data: 列表
        :type Data: :class:`tencentcloud.apis.v20240801.models.DescribeAgentAppMcpServersResp`
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._Data = None
        self._RequestId = None

    @property
    def Data(self):
        r"""列表
        :rtype: :class:`tencentcloud.apis.v20240801.models.DescribeAgentAppMcpServersResp`
        """
        return self._Data

    @Data.setter
    def Data(self, Data):
        self._Data = Data

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("Data") is not None:
            self._Data = DescribeAgentAppMcpServersResp()
            self._Data._deserialize(params.get("Data"))
        self._RequestId = params.get("RequestId")


class DescribeAgentAppModelServicesRequest(AbstractModel):
    r"""DescribeAgentAppModelServices请求参数结构体

    """


class DescribeAgentAppModelServicesResponse(AbstractModel):
    r"""DescribeAgentAppModelServices返回参数结构体

    """

    def __init__(self):
        r"""
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._RequestId = None

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._RequestId = params.get("RequestId")


class DescribeAgentAppRequest(AbstractModel):
    r"""DescribeAgentApp请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceID: 实例ID
        :type InstanceID: str
        :param _ID: app id
        :type ID: str
        """
        self._InstanceID = None
        self._ID = None

    @property
    def InstanceID(self):
        r"""实例ID
        :rtype: str
        """
        return self._InstanceID

    @InstanceID.setter
    def InstanceID(self, InstanceID):
        self._InstanceID = InstanceID

    @property
    def ID(self):
        r"""app id
        :rtype: str
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID


    def _deserialize(self, params):
        self._InstanceID = params.get("InstanceID")
        self._ID = params.get("ID")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeAgentAppResp(AbstractModel):
    r"""查询app详情响应

    """

    def __init__(self):
        r"""
        :param _AppID: <p>租户appID</p>
        :type AppID: int
        :param _Uin: <p>租户ID</p>
        :type Uin: str
        :param _InstanceID: <p>实例ID</p>
        :type InstanceID: str
        :param _ID: <p>应用ID</p>
        :type ID: str
        :param _Name: <p>名称</p>
        :type Name: str
        :param _Description: <p>描述</p>
        :type Description: str
        :param _Status: <p>状态</p>
        :type Status: str
        :param _CreateTime: <p>创建时间</p>
        :type CreateTime: str
        :param _UpdateTime: <p>修改时间</p>
        :type UpdateTime: str
        :param _AuthType: <p>认证类型</p>
        :type AuthType: str
        :param _ApiKeys: <p>apiKeys列表，脱敏</p>
        :type ApiKeys: list of str
        :param _SecretKeys: <p>secretKey列表，脱敏</p>
        :type SecretKeys: list of AgentAppSecretKeyVO
        :param _OAuth2ResourceServerID: <p>OAuth2 Resource Server ID</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type OAuth2ResourceServerID: str
        :param _McpServersNum: <p>绑定mcpServer数量</p>
        :type McpServersNum: int
        :param _ModelServicesNum: <p>绑定的模型服务数量</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type ModelServicesNum: int
        :param _ConnectorIDs: <p>API认证列表</p>
        :type ConnectorIDs: list of str
        :param _ServicesNum: <p>关联API数量</p>
        :type ServicesNum: int
        """
        self._AppID = None
        self._Uin = None
        self._InstanceID = None
        self._ID = None
        self._Name = None
        self._Description = None
        self._Status = None
        self._CreateTime = None
        self._UpdateTime = None
        self._AuthType = None
        self._ApiKeys = None
        self._SecretKeys = None
        self._OAuth2ResourceServerID = None
        self._McpServersNum = None
        self._ModelServicesNum = None
        self._ConnectorIDs = None
        self._ServicesNum = None

    @property
    def AppID(self):
        r"""<p>租户appID</p>
        :rtype: int
        """
        return self._AppID

    @AppID.setter
    def AppID(self, AppID):
        self._AppID = AppID

    @property
    def Uin(self):
        r"""<p>租户ID</p>
        :rtype: str
        """
        return self._Uin

    @Uin.setter
    def Uin(self, Uin):
        self._Uin = Uin

    @property
    def InstanceID(self):
        r"""<p>实例ID</p>
        :rtype: str
        """
        return self._InstanceID

    @InstanceID.setter
    def InstanceID(self, InstanceID):
        self._InstanceID = InstanceID

    @property
    def ID(self):
        r"""<p>应用ID</p>
        :rtype: str
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID

    @property
    def Name(self):
        r"""<p>名称</p>
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def Description(self):
        r"""<p>描述</p>
        :rtype: str
        """
        return self._Description

    @Description.setter
    def Description(self, Description):
        self._Description = Description

    @property
    def Status(self):
        r"""<p>状态</p>
        :rtype: str
        """
        return self._Status

    @Status.setter
    def Status(self, Status):
        self._Status = Status

    @property
    def CreateTime(self):
        r"""<p>创建时间</p>
        :rtype: str
        """
        return self._CreateTime

    @CreateTime.setter
    def CreateTime(self, CreateTime):
        self._CreateTime = CreateTime

    @property
    def UpdateTime(self):
        r"""<p>修改时间</p>
        :rtype: str
        """
        return self._UpdateTime

    @UpdateTime.setter
    def UpdateTime(self, UpdateTime):
        self._UpdateTime = UpdateTime

    @property
    def AuthType(self):
        r"""<p>认证类型</p>
        :rtype: str
        """
        return self._AuthType

    @AuthType.setter
    def AuthType(self, AuthType):
        self._AuthType = AuthType

    @property
    def ApiKeys(self):
        r"""<p>apiKeys列表，脱敏</p>
        :rtype: list of str
        """
        return self._ApiKeys

    @ApiKeys.setter
    def ApiKeys(self, ApiKeys):
        self._ApiKeys = ApiKeys

    @property
    def SecretKeys(self):
        r"""<p>secretKey列表，脱敏</p>
        :rtype: list of AgentAppSecretKeyVO
        """
        return self._SecretKeys

    @SecretKeys.setter
    def SecretKeys(self, SecretKeys):
        self._SecretKeys = SecretKeys

    @property
    def OAuth2ResourceServerID(self):
        r"""<p>OAuth2 Resource Server ID</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._OAuth2ResourceServerID

    @OAuth2ResourceServerID.setter
    def OAuth2ResourceServerID(self, OAuth2ResourceServerID):
        self._OAuth2ResourceServerID = OAuth2ResourceServerID

    @property
    def McpServersNum(self):
        r"""<p>绑定mcpServer数量</p>
        :rtype: int
        """
        return self._McpServersNum

    @McpServersNum.setter
    def McpServersNum(self, McpServersNum):
        self._McpServersNum = McpServersNum

    @property
    def ModelServicesNum(self):
        r"""<p>绑定的模型服务数量</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: int
        """
        return self._ModelServicesNum

    @ModelServicesNum.setter
    def ModelServicesNum(self, ModelServicesNum):
        self._ModelServicesNum = ModelServicesNum

    @property
    def ConnectorIDs(self):
        r"""<p>API认证列表</p>
        :rtype: list of str
        """
        return self._ConnectorIDs

    @ConnectorIDs.setter
    def ConnectorIDs(self, ConnectorIDs):
        self._ConnectorIDs = ConnectorIDs

    @property
    def ServicesNum(self):
        r"""<p>关联API数量</p>
        :rtype: int
        """
        return self._ServicesNum

    @ServicesNum.setter
    def ServicesNum(self, ServicesNum):
        self._ServicesNum = ServicesNum


    def _deserialize(self, params):
        self._AppID = params.get("AppID")
        self._Uin = params.get("Uin")
        self._InstanceID = params.get("InstanceID")
        self._ID = params.get("ID")
        self._Name = params.get("Name")
        self._Description = params.get("Description")
        self._Status = params.get("Status")
        self._CreateTime = params.get("CreateTime")
        self._UpdateTime = params.get("UpdateTime")
        self._AuthType = params.get("AuthType")
        self._ApiKeys = params.get("ApiKeys")
        if params.get("SecretKeys") is not None:
            self._SecretKeys = []
            for item in params.get("SecretKeys"):
                obj = AgentAppSecretKeyVO()
                obj._deserialize(item)
                self._SecretKeys.append(obj)
        self._OAuth2ResourceServerID = params.get("OAuth2ResourceServerID")
        self._McpServersNum = params.get("McpServersNum")
        self._ModelServicesNum = params.get("ModelServicesNum")
        self._ConnectorIDs = params.get("ConnectorIDs")
        self._ServicesNum = params.get("ServicesNum")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeAgentAppResponse(AbstractModel):
    r"""DescribeAgentApp返回参数结构体

    """

    def __init__(self):
        r"""
        :param _Data: app详情
        :type Data: :class:`tencentcloud.apis.v20240801.models.DescribeAgentAppResp`
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._Data = None
        self._RequestId = None

    @property
    def Data(self):
        r"""app详情
        :rtype: :class:`tencentcloud.apis.v20240801.models.DescribeAgentAppResp`
        """
        return self._Data

    @Data.setter
    def Data(self, Data):
        self._Data = Data

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("Data") is not None:
            self._Data = DescribeAgentAppResp()
            self._Data._deserialize(params.get("Data"))
        self._RequestId = params.get("RequestId")


class DescribeAgentAppServicesRequest(AbstractModel):
    r"""DescribeAgentAppServices请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceID: <p>实例ID</p>
        :type InstanceID: str
        :param _Limit: <p>数据量</p>
        :type Limit: int
        :param _IDs: <p>IDs</p>
        :type IDs: list of str
        :param _AgentAppIDs: <p>应用IDs</p>
        :type AgentAppIDs: list of str
        :param _ServiceIDs: <p>服务IDs</p>
        :type ServiceIDs: list of str
        :param _Keyword: <p>关键字</p>
        :type Keyword: str
        :param _Offset: <p>偏移量</p>
        :type Offset: int
        :param _AgentCredentialExist: <p>是否有凭据</p>
        :type AgentCredentialExist: bool
        :param _AgentCredentialIDs: <p>凭据ID</p>
        :type AgentCredentialIDs: list of str
        """
        self._InstanceID = None
        self._Limit = None
        self._IDs = None
        self._AgentAppIDs = None
        self._ServiceIDs = None
        self._Keyword = None
        self._Offset = None
        self._AgentCredentialExist = None
        self._AgentCredentialIDs = None

    @property
    def InstanceID(self):
        r"""<p>实例ID</p>
        :rtype: str
        """
        return self._InstanceID

    @InstanceID.setter
    def InstanceID(self, InstanceID):
        self._InstanceID = InstanceID

    @property
    def Limit(self):
        r"""<p>数据量</p>
        :rtype: int
        """
        return self._Limit

    @Limit.setter
    def Limit(self, Limit):
        self._Limit = Limit

    @property
    def IDs(self):
        r"""<p>IDs</p>
        :rtype: list of str
        """
        return self._IDs

    @IDs.setter
    def IDs(self, IDs):
        self._IDs = IDs

    @property
    def AgentAppIDs(self):
        r"""<p>应用IDs</p>
        :rtype: list of str
        """
        return self._AgentAppIDs

    @AgentAppIDs.setter
    def AgentAppIDs(self, AgentAppIDs):
        self._AgentAppIDs = AgentAppIDs

    @property
    def ServiceIDs(self):
        r"""<p>服务IDs</p>
        :rtype: list of str
        """
        return self._ServiceIDs

    @ServiceIDs.setter
    def ServiceIDs(self, ServiceIDs):
        self._ServiceIDs = ServiceIDs

    @property
    def Keyword(self):
        r"""<p>关键字</p>
        :rtype: str
        """
        return self._Keyword

    @Keyword.setter
    def Keyword(self, Keyword):
        self._Keyword = Keyword

    @property
    def Offset(self):
        r"""<p>偏移量</p>
        :rtype: int
        """
        return self._Offset

    @Offset.setter
    def Offset(self, Offset):
        self._Offset = Offset

    @property
    def AgentCredentialExist(self):
        r"""<p>是否有凭据</p>
        :rtype: bool
        """
        return self._AgentCredentialExist

    @AgentCredentialExist.setter
    def AgentCredentialExist(self, AgentCredentialExist):
        self._AgentCredentialExist = AgentCredentialExist

    @property
    def AgentCredentialIDs(self):
        r"""<p>凭据ID</p>
        :rtype: list of str
        """
        return self._AgentCredentialIDs

    @AgentCredentialIDs.setter
    def AgentCredentialIDs(self, AgentCredentialIDs):
        self._AgentCredentialIDs = AgentCredentialIDs


    def _deserialize(self, params):
        self._InstanceID = params.get("InstanceID")
        self._Limit = params.get("Limit")
        self._IDs = params.get("IDs")
        self._AgentAppIDs = params.get("AgentAppIDs")
        self._ServiceIDs = params.get("ServiceIDs")
        self._Keyword = params.get("Keyword")
        self._Offset = params.get("Offset")
        self._AgentCredentialExist = params.get("AgentCredentialExist")
        self._AgentCredentialIDs = params.get("AgentCredentialIDs")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeAgentAppServicesResponse(AbstractModel):
    r"""DescribeAgentAppServices返回参数结构体

    """

    def __init__(self):
        r"""
        :param _Data: <p>app id</p>
        :type Data: :class:`tencentcloud.apis.v20240801.models.DescribeAgentAppServicesVO`
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._Data = None
        self._RequestId = None

    @property
    def Data(self):
        r"""<p>app id</p>
        :rtype: :class:`tencentcloud.apis.v20240801.models.DescribeAgentAppServicesVO`
        """
        return self._Data

    @Data.setter
    def Data(self, Data):
        self._Data = Data

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("Data") is not None:
            self._Data = DescribeAgentAppServicesVO()
            self._Data._deserialize(params.get("Data"))
        self._RequestId = params.get("RequestId")


class DescribeAgentAppServicesVO(AbstractModel):
    r"""应用服务查询

    """

    def __init__(self):
        r"""
        :param _Total: <p>总数</p>
        :type Total: int
        :param _Items: <p>数据列表</p>
        :type Items: list of AgentAppServiceVO
        """
        self._Total = None
        self._Items = None

    @property
    def Total(self):
        r"""<p>总数</p>
        :rtype: int
        """
        return self._Total

    @Total.setter
    def Total(self, Total):
        self._Total = Total

    @property
    def Items(self):
        r"""<p>数据列表</p>
        :rtype: list of AgentAppServiceVO
        """
        return self._Items

    @Items.setter
    def Items(self, Items):
        self._Items = Items


    def _deserialize(self, params):
        self._Total = params.get("Total")
        if params.get("Items") is not None:
            self._Items = []
            for item in params.get("Items"):
                obj = AgentAppServiceVO()
                obj._deserialize(item)
                self._Items.append(obj)
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeAgentAppsRequest(AbstractModel):
    r"""DescribeAgentApps请求参数结构体

    """

    def __init__(self):
        r"""
        :param _Limit: 分页大小
        :type Limit: int
        :param _Offset: 分页偏移量
        :type Offset: int
        :param _IDs: 服务ID数组
        :type IDs: list of str
        :param _InstanceID: 实例ID
        :type InstanceID: str
        :param _NotIDs: notID列表
        :type NotIDs: list of str
        :param _Status: 状态：normal正常状态，disabled下线状态
        :type Status: str
        :param _Keyword: 关键词
        :type Keyword: str
        :param _AuthType: 认证类型：apiKey，secretKey
        :type AuthType: str
        :param _Sort: 排序
        :type Sort: :class:`tencentcloud.apis.v20240801.models.DescribeAgentAppsSortDTO`
        :param _AgentCredentialID: 凭据ID
        :type AgentCredentialID: str
        """
        self._Limit = None
        self._Offset = None
        self._IDs = None
        self._InstanceID = None
        self._NotIDs = None
        self._Status = None
        self._Keyword = None
        self._AuthType = None
        self._Sort = None
        self._AgentCredentialID = None

    @property
    def Limit(self):
        r"""分页大小
        :rtype: int
        """
        return self._Limit

    @Limit.setter
    def Limit(self, Limit):
        self._Limit = Limit

    @property
    def Offset(self):
        r"""分页偏移量
        :rtype: int
        """
        return self._Offset

    @Offset.setter
    def Offset(self, Offset):
        self._Offset = Offset

    @property
    def IDs(self):
        r"""服务ID数组
        :rtype: list of str
        """
        return self._IDs

    @IDs.setter
    def IDs(self, IDs):
        self._IDs = IDs

    @property
    def InstanceID(self):
        r"""实例ID
        :rtype: str
        """
        return self._InstanceID

    @InstanceID.setter
    def InstanceID(self, InstanceID):
        self._InstanceID = InstanceID

    @property
    def NotIDs(self):
        r"""notID列表
        :rtype: list of str
        """
        return self._NotIDs

    @NotIDs.setter
    def NotIDs(self, NotIDs):
        self._NotIDs = NotIDs

    @property
    def Status(self):
        r"""状态：normal正常状态，disabled下线状态
        :rtype: str
        """
        return self._Status

    @Status.setter
    def Status(self, Status):
        self._Status = Status

    @property
    def Keyword(self):
        r"""关键词
        :rtype: str
        """
        return self._Keyword

    @Keyword.setter
    def Keyword(self, Keyword):
        self._Keyword = Keyword

    @property
    def AuthType(self):
        r"""认证类型：apiKey，secretKey
        :rtype: str
        """
        return self._AuthType

    @AuthType.setter
    def AuthType(self, AuthType):
        self._AuthType = AuthType

    @property
    def Sort(self):
        r"""排序
        :rtype: :class:`tencentcloud.apis.v20240801.models.DescribeAgentAppsSortDTO`
        """
        return self._Sort

    @Sort.setter
    def Sort(self, Sort):
        self._Sort = Sort

    @property
    def AgentCredentialID(self):
        r"""凭据ID
        :rtype: str
        """
        return self._AgentCredentialID

    @AgentCredentialID.setter
    def AgentCredentialID(self, AgentCredentialID):
        self._AgentCredentialID = AgentCredentialID


    def _deserialize(self, params):
        self._Limit = params.get("Limit")
        self._Offset = params.get("Offset")
        self._IDs = params.get("IDs")
        self._InstanceID = params.get("InstanceID")
        self._NotIDs = params.get("NotIDs")
        self._Status = params.get("Status")
        self._Keyword = params.get("Keyword")
        self._AuthType = params.get("AuthType")
        if params.get("Sort") is not None:
            self._Sort = DescribeAgentAppsSortDTO()
            self._Sort._deserialize(params.get("Sort"))
        self._AgentCredentialID = params.get("AgentCredentialID")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeAgentAppsResp(AbstractModel):
    r"""查询App列表响应

    """

    def __init__(self):
        r"""
        :param _Total: 条目总数
        :type Total: int
        :param _Items: 具体条目
        :type Items: list of DescribeAgentAppResp
        """
        self._Total = None
        self._Items = None

    @property
    def Total(self):
        r"""条目总数
        :rtype: int
        """
        return self._Total

    @Total.setter
    def Total(self, Total):
        self._Total = Total

    @property
    def Items(self):
        r"""具体条目
        :rtype: list of DescribeAgentAppResp
        """
        return self._Items

    @Items.setter
    def Items(self, Items):
        self._Items = Items


    def _deserialize(self, params):
        self._Total = params.get("Total")
        if params.get("Items") is not None:
            self._Items = []
            for item in params.get("Items"):
                obj = DescribeAgentAppResp()
                obj._deserialize(item)
                self._Items.append(obj)
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeAgentAppsResponse(AbstractModel):
    r"""DescribeAgentApps返回参数结构体

    """

    def __init__(self):
        r"""
        :param _Data: app列表
        :type Data: :class:`tencentcloud.apis.v20240801.models.DescribeAgentAppsResp`
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._Data = None
        self._RequestId = None

    @property
    def Data(self):
        r"""app列表
        :rtype: :class:`tencentcloud.apis.v20240801.models.DescribeAgentAppsResp`
        """
        return self._Data

    @Data.setter
    def Data(self, Data):
        self._Data = Data

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("Data") is not None:
            self._Data = DescribeAgentAppsResp()
            self._Data._deserialize(params.get("Data"))
        self._RequestId = params.get("RequestId")


class DescribeAgentAppsSortDTO(AbstractModel):
    r"""agentApp查询排序

    """

    def __init__(self):
        r"""
        :param _CreateTime: 创建时间
        :type CreateTime: int
        :param _UpdateTime: 修改时间
        :type UpdateTime: int
        :param _Name: 名称
        :type Name: int
        :param _Status: 状态
        :type Status: int
        """
        self._CreateTime = None
        self._UpdateTime = None
        self._Name = None
        self._Status = None

    @property
    def CreateTime(self):
        r"""创建时间
        :rtype: int
        """
        return self._CreateTime

    @CreateTime.setter
    def CreateTime(self, CreateTime):
        self._CreateTime = CreateTime

    @property
    def UpdateTime(self):
        r"""修改时间
        :rtype: int
        """
        return self._UpdateTime

    @UpdateTime.setter
    def UpdateTime(self, UpdateTime):
        self._UpdateTime = UpdateTime

    @property
    def Name(self):
        r"""名称
        :rtype: int
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def Status(self):
        r"""状态
        :rtype: int
        """
        return self._Status

    @Status.setter
    def Status(self, Status):
        self._Status = Status


    def _deserialize(self, params):
        self._CreateTime = params.get("CreateTime")
        self._UpdateTime = params.get("UpdateTime")
        self._Name = params.get("Name")
        self._Status = params.get("Status")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeAgentCredentialRequest(AbstractModel):
    r"""DescribeAgentCredential请求参数结构体

    """


class DescribeAgentCredentialResp(AbstractModel):
    r"""凭据详情响应

    """

    def __init__(self):
        r"""
        :param _AppID: <p>租户应用ID</p>
        :type AppID: int
        :param _Uin: <p>租户ID</p>
        :type Uin: str
        :param _InstanceID: <p>实例ID</p>
        :type InstanceID: str
        :param _ID: <p>凭据ID</p>
        :type ID: str
        :param _Name: <p>凭据名称</p>
        :type Name: str
        :param _Status: <p>状态</p>
        :type Status: str
        :param _RelateAgentAppNum: <p>关联应用数</p>
        :type RelateAgentAppNum: int
        :param _RelateMcpServerNum: <p>关联mcp数</p>
        :type RelateMcpServerNum: int
        :param _RelateModelNum: <p>关联模型数</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type RelateModelNum: int
        :param _RelateServiceNum: <p>关联服务数</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type RelateServiceNum: int
        :param _Content: <p>凭据内容</p>
        :type Content: :class:`tencentcloud.apis.v20240801.models.AgentCredentialContentDTO`
        :param _CreateTime: <p>创建时间</p>
        :type CreateTime: str
        :param _LastUpdateTime: <p>修改时间</p>
        :type LastUpdateTime: str
        :param _Type: <p>类型</p>
        :type Type: str
        """
        self._AppID = None
        self._Uin = None
        self._InstanceID = None
        self._ID = None
        self._Name = None
        self._Status = None
        self._RelateAgentAppNum = None
        self._RelateMcpServerNum = None
        self._RelateModelNum = None
        self._RelateServiceNum = None
        self._Content = None
        self._CreateTime = None
        self._LastUpdateTime = None
        self._Type = None

    @property
    def AppID(self):
        r"""<p>租户应用ID</p>
        :rtype: int
        """
        return self._AppID

    @AppID.setter
    def AppID(self, AppID):
        self._AppID = AppID

    @property
    def Uin(self):
        r"""<p>租户ID</p>
        :rtype: str
        """
        return self._Uin

    @Uin.setter
    def Uin(self, Uin):
        self._Uin = Uin

    @property
    def InstanceID(self):
        r"""<p>实例ID</p>
        :rtype: str
        """
        return self._InstanceID

    @InstanceID.setter
    def InstanceID(self, InstanceID):
        self._InstanceID = InstanceID

    @property
    def ID(self):
        r"""<p>凭据ID</p>
        :rtype: str
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID

    @property
    def Name(self):
        r"""<p>凭据名称</p>
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def Status(self):
        r"""<p>状态</p>
        :rtype: str
        """
        return self._Status

    @Status.setter
    def Status(self, Status):
        self._Status = Status

    @property
    def RelateAgentAppNum(self):
        warnings.warn("parameter `RelateAgentAppNum` is deprecated", DeprecationWarning) 

        r"""<p>关联应用数</p>
        :rtype: int
        """
        return self._RelateAgentAppNum

    @RelateAgentAppNum.setter
    def RelateAgentAppNum(self, RelateAgentAppNum):
        warnings.warn("parameter `RelateAgentAppNum` is deprecated", DeprecationWarning) 

        self._RelateAgentAppNum = RelateAgentAppNum

    @property
    def RelateMcpServerNum(self):
        r"""<p>关联mcp数</p>
        :rtype: int
        """
        return self._RelateMcpServerNum

    @RelateMcpServerNum.setter
    def RelateMcpServerNum(self, RelateMcpServerNum):
        self._RelateMcpServerNum = RelateMcpServerNum

    @property
    def RelateModelNum(self):
        r"""<p>关联模型数</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: int
        """
        return self._RelateModelNum

    @RelateModelNum.setter
    def RelateModelNum(self, RelateModelNum):
        self._RelateModelNum = RelateModelNum

    @property
    def RelateServiceNum(self):
        r"""<p>关联服务数</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: int
        """
        return self._RelateServiceNum

    @RelateServiceNum.setter
    def RelateServiceNum(self, RelateServiceNum):
        self._RelateServiceNum = RelateServiceNum

    @property
    def Content(self):
        r"""<p>凭据内容</p>
        :rtype: :class:`tencentcloud.apis.v20240801.models.AgentCredentialContentDTO`
        """
        return self._Content

    @Content.setter
    def Content(self, Content):
        self._Content = Content

    @property
    def CreateTime(self):
        r"""<p>创建时间</p>
        :rtype: str
        """
        return self._CreateTime

    @CreateTime.setter
    def CreateTime(self, CreateTime):
        self._CreateTime = CreateTime

    @property
    def LastUpdateTime(self):
        r"""<p>修改时间</p>
        :rtype: str
        """
        return self._LastUpdateTime

    @LastUpdateTime.setter
    def LastUpdateTime(self, LastUpdateTime):
        self._LastUpdateTime = LastUpdateTime

    @property
    def Type(self):
        r"""<p>类型</p>
        :rtype: str
        """
        return self._Type

    @Type.setter
    def Type(self, Type):
        self._Type = Type


    def _deserialize(self, params):
        self._AppID = params.get("AppID")
        self._Uin = params.get("Uin")
        self._InstanceID = params.get("InstanceID")
        self._ID = params.get("ID")
        self._Name = params.get("Name")
        self._Status = params.get("Status")
        self._RelateAgentAppNum = params.get("RelateAgentAppNum")
        self._RelateMcpServerNum = params.get("RelateMcpServerNum")
        self._RelateModelNum = params.get("RelateModelNum")
        self._RelateServiceNum = params.get("RelateServiceNum")
        if params.get("Content") is not None:
            self._Content = AgentCredentialContentDTO()
            self._Content._deserialize(params.get("Content"))
        self._CreateTime = params.get("CreateTime")
        self._LastUpdateTime = params.get("LastUpdateTime")
        self._Type = params.get("Type")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeAgentCredentialResponse(AbstractModel):
    r"""DescribeAgentCredential返回参数结构体

    """

    def __init__(self):
        r"""
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._RequestId = None

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._RequestId = params.get("RequestId")


class DescribeAgentCredentialsRequest(AbstractModel):
    r"""DescribeAgentCredentials请求参数结构体

    """


class DescribeAgentCredentialsResponse(AbstractModel):
    r"""DescribeAgentCredentials返回参数结构体

    """

    def __init__(self):
        r"""
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._RequestId = None

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._RequestId = params.get("RequestId")


class DescribeMcpServerRequest(AbstractModel):
    r"""DescribeMcpServer请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceID: 实例ID
        :type InstanceID: str
        :param _ID: mcp server ID
        :type ID: str
        """
        self._InstanceID = None
        self._ID = None

    @property
    def InstanceID(self):
        r"""实例ID
        :rtype: str
        """
        return self._InstanceID

    @InstanceID.setter
    def InstanceID(self, InstanceID):
        self._InstanceID = InstanceID

    @property
    def ID(self):
        r"""mcp server ID
        :rtype: str
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID


    def _deserialize(self, params):
        self._InstanceID = params.get("InstanceID")
        self._ID = params.get("ID")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeMcpServerResponse(AbstractModel):
    r"""DescribeMcpServer返回参数结构体

    """

    def __init__(self):
        r"""
        :param _Data: mcp server详情
        :type Data: :class:`tencentcloud.apis.v20240801.models.DescribeMcpServerResponseVO`
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._Data = None
        self._RequestId = None

    @property
    def Data(self):
        r"""mcp server详情
        :rtype: :class:`tencentcloud.apis.v20240801.models.DescribeMcpServerResponseVO`
        """
        return self._Data

    @Data.setter
    def Data(self, Data):
        self._Data = Data

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("Data") is not None:
            self._Data = DescribeMcpServerResponseVO()
            self._Data._deserialize(params.get("Data"))
        self._RequestId = params.get("RequestId")


class DescribeMcpServerResponseVO(AbstractModel):
    r"""DescribeMcpServerResponseVO

    """

    def __init__(self):
        r"""
        :param _InstanceID: <p>实例ID</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type InstanceID: str
        :param _Name: <p>名称</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type Name: str
        :param _Description: <p>描述</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type Description: str
        :param _LabelIDs: <p>标签ID数组</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type LabelIDs: list of str
        :param _CategoryIDs: <p>目录ID数组</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type CategoryIDs: list of str
        :param _TargetSelect: <p>负载方式，robin random consistentHash</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type TargetSelect: str
        :param _TargetHosts: <p>目标服务器</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type TargetHosts: list of TargetHostDTO
        :param _HttpProtocolType: <p>后端协议：http https</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type HttpProtocolType: str
        :param _CheckTargetCertsError: <p>证书检查</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type CheckTargetCertsError: bool
        :param _TargetPath: <p>目标路径</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type TargetPath: str
        :param _InvokeLimitConfigStatus: <p>流量控制状态</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type InvokeLimitConfigStatus: bool
        :param _InvokeLimitConfig: <p>流量控制配置</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type InvokeLimitConfig: :class:`tencentcloud.apis.v20240801.models.InvokeLimitConfigDTO`
        :param _IpWhiteStatus: <p>IP白名单开启状态</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type IpWhiteStatus: bool
        :param _IpWhiteConfig: <p>IP白名单配置</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type IpWhiteConfig: :class:`tencentcloud.apis.v20240801.models.IpConfig`
        :param _IpBlackStatus: <p>IP黑名单开启状态</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type IpBlackStatus: bool
        :param _IpBlackConfig: <p>IP黑名单配置</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type IpBlackConfig: :class:`tencentcloud.apis.v20240801.models.IpConfig`
        :param _ID: <p>mcp server ID</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type ID: str
        :param _Status: <p>状态</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type Status: str
        :param _Url: <p>预览地址</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type Url: str
        :param _App: <p>应用</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type App: :class:`tencentcloud.apis.v20240801.models.IDNameVO`
        :param _Catalogs: <p>目录</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type Catalogs: list of IDNameVO
        :param _Labels: <p>标签</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type Labels: list of IDNameVO
        :param _CreateTime: <p>创建时间</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type CreateTime: str
        :param _LastUpdateTime: <p>最后修改时间</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type LastUpdateTime: str
        :param _AppID: <p>用户appID</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type AppID: int
        :param _Uin: <p>用户ID</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type Uin: str
        :param _CustomHttpHost: <p>自定义host</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type CustomHttpHost: str
        :param _HttpHostType: <p>Http 请求host类型 useRequestHost 保持源请求host targetHost 修正为源站host  customHost 自定义host</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type HttpHostType: str
        :param _Timeout: <p>请求的超时时间</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type Timeout: int
        :param _Mode: <p>mcp server模式</p>
        :type Mode: str
        :param _McpVersion: <p>mcp version</p>
        :type McpVersion: str
        :param _WrapServices: <p>封装模式下绑定的服务ID列表</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type WrapServices: list of str
        :param _ToolNum: <p>工具数量</p>
        :type ToolNum: int
        :param _McpSecurityRulesVO: <p>安全规则集响应</p>
        :type McpSecurityRulesVO: list of McpSecurityRulesVO
        :param _ToolConfigs: <p>真实工具级别配置，实时拉取了tool/list做渲染的，如果tool/list不通，就拉不到。</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type ToolConfigs: list of ToolConfigVO
        :param _UrlObj: <p>访问URL</p>
        :type UrlObj: :class:`tencentcloud.apis.v20240801.models.McpUrlObj`
        :param _ToolMessage: <p>后端mcp服务是否正常</p>
        :type ToolMessage: str
        :param _Tools: <p>后端mcp服务的工具列表</p>
        :type Tools: list of McpTool
        :param _WrapPaasID: <p>封装的API分组ID</p>
        :type WrapPaasID: str
        :param _RelateAgentAppNum: <p>关联的agentApp数量</p>
        :type RelateAgentAppNum: int
        :param _PluginConfigs: <p>插件配置</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type PluginConfigs: list of PluginConfigDTO
        :param _IgnoreHealthCheck: <p>是否忽略健康检查</p>
        :type IgnoreHealthCheck: bool
        :param _CredentialID: <p>凭据ID</p>
        :type CredentialID: str
        :param _CredentialName: <p>凭据名称</p>
        :type CredentialName: str
        :param _Domain: <p>访问域名</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type Domain: str
        :param _RequestProtocolType: <p>访问协议</p><p>枚举值：</p><ul><li>http： http</li><li>https： https</li></ul>
注意：此字段可能返回 null，表示取不到有效值。
        :type RequestProtocolType: str
        """
        self._InstanceID = None
        self._Name = None
        self._Description = None
        self._LabelIDs = None
        self._CategoryIDs = None
        self._TargetSelect = None
        self._TargetHosts = None
        self._HttpProtocolType = None
        self._CheckTargetCertsError = None
        self._TargetPath = None
        self._InvokeLimitConfigStatus = None
        self._InvokeLimitConfig = None
        self._IpWhiteStatus = None
        self._IpWhiteConfig = None
        self._IpBlackStatus = None
        self._IpBlackConfig = None
        self._ID = None
        self._Status = None
        self._Url = None
        self._App = None
        self._Catalogs = None
        self._Labels = None
        self._CreateTime = None
        self._LastUpdateTime = None
        self._AppID = None
        self._Uin = None
        self._CustomHttpHost = None
        self._HttpHostType = None
        self._Timeout = None
        self._Mode = None
        self._McpVersion = None
        self._WrapServices = None
        self._ToolNum = None
        self._McpSecurityRulesVO = None
        self._ToolConfigs = None
        self._UrlObj = None
        self._ToolMessage = None
        self._Tools = None
        self._WrapPaasID = None
        self._RelateAgentAppNum = None
        self._PluginConfigs = None
        self._IgnoreHealthCheck = None
        self._CredentialID = None
        self._CredentialName = None
        self._Domain = None
        self._RequestProtocolType = None

    @property
    def InstanceID(self):
        r"""<p>实例ID</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._InstanceID

    @InstanceID.setter
    def InstanceID(self, InstanceID):
        self._InstanceID = InstanceID

    @property
    def Name(self):
        r"""<p>名称</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def Description(self):
        r"""<p>描述</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._Description

    @Description.setter
    def Description(self, Description):
        self._Description = Description

    @property
    def LabelIDs(self):
        r"""<p>标签ID数组</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of str
        """
        return self._LabelIDs

    @LabelIDs.setter
    def LabelIDs(self, LabelIDs):
        self._LabelIDs = LabelIDs

    @property
    def CategoryIDs(self):
        r"""<p>目录ID数组</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of str
        """
        return self._CategoryIDs

    @CategoryIDs.setter
    def CategoryIDs(self, CategoryIDs):
        self._CategoryIDs = CategoryIDs

    @property
    def TargetSelect(self):
        r"""<p>负载方式，robin random consistentHash</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._TargetSelect

    @TargetSelect.setter
    def TargetSelect(self, TargetSelect):
        self._TargetSelect = TargetSelect

    @property
    def TargetHosts(self):
        r"""<p>目标服务器</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of TargetHostDTO
        """
        return self._TargetHosts

    @TargetHosts.setter
    def TargetHosts(self, TargetHosts):
        self._TargetHosts = TargetHosts

    @property
    def HttpProtocolType(self):
        r"""<p>后端协议：http https</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._HttpProtocolType

    @HttpProtocolType.setter
    def HttpProtocolType(self, HttpProtocolType):
        self._HttpProtocolType = HttpProtocolType

    @property
    def CheckTargetCertsError(self):
        r"""<p>证书检查</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: bool
        """
        return self._CheckTargetCertsError

    @CheckTargetCertsError.setter
    def CheckTargetCertsError(self, CheckTargetCertsError):
        self._CheckTargetCertsError = CheckTargetCertsError

    @property
    def TargetPath(self):
        r"""<p>目标路径</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._TargetPath

    @TargetPath.setter
    def TargetPath(self, TargetPath):
        self._TargetPath = TargetPath

    @property
    def InvokeLimitConfigStatus(self):
        r"""<p>流量控制状态</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: bool
        """
        return self._InvokeLimitConfigStatus

    @InvokeLimitConfigStatus.setter
    def InvokeLimitConfigStatus(self, InvokeLimitConfigStatus):
        self._InvokeLimitConfigStatus = InvokeLimitConfigStatus

    @property
    def InvokeLimitConfig(self):
        r"""<p>流量控制配置</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: :class:`tencentcloud.apis.v20240801.models.InvokeLimitConfigDTO`
        """
        return self._InvokeLimitConfig

    @InvokeLimitConfig.setter
    def InvokeLimitConfig(self, InvokeLimitConfig):
        self._InvokeLimitConfig = InvokeLimitConfig

    @property
    def IpWhiteStatus(self):
        r"""<p>IP白名单开启状态</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: bool
        """
        return self._IpWhiteStatus

    @IpWhiteStatus.setter
    def IpWhiteStatus(self, IpWhiteStatus):
        self._IpWhiteStatus = IpWhiteStatus

    @property
    def IpWhiteConfig(self):
        r"""<p>IP白名单配置</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: :class:`tencentcloud.apis.v20240801.models.IpConfig`
        """
        return self._IpWhiteConfig

    @IpWhiteConfig.setter
    def IpWhiteConfig(self, IpWhiteConfig):
        self._IpWhiteConfig = IpWhiteConfig

    @property
    def IpBlackStatus(self):
        r"""<p>IP黑名单开启状态</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: bool
        """
        return self._IpBlackStatus

    @IpBlackStatus.setter
    def IpBlackStatus(self, IpBlackStatus):
        self._IpBlackStatus = IpBlackStatus

    @property
    def IpBlackConfig(self):
        r"""<p>IP黑名单配置</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: :class:`tencentcloud.apis.v20240801.models.IpConfig`
        """
        return self._IpBlackConfig

    @IpBlackConfig.setter
    def IpBlackConfig(self, IpBlackConfig):
        self._IpBlackConfig = IpBlackConfig

    @property
    def ID(self):
        r"""<p>mcp server ID</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID

    @property
    def Status(self):
        r"""<p>状态</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._Status

    @Status.setter
    def Status(self, Status):
        self._Status = Status

    @property
    def Url(self):
        r"""<p>预览地址</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._Url

    @Url.setter
    def Url(self, Url):
        self._Url = Url

    @property
    def App(self):
        r"""<p>应用</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: :class:`tencentcloud.apis.v20240801.models.IDNameVO`
        """
        return self._App

    @App.setter
    def App(self, App):
        self._App = App

    @property
    def Catalogs(self):
        r"""<p>目录</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of IDNameVO
        """
        return self._Catalogs

    @Catalogs.setter
    def Catalogs(self, Catalogs):
        self._Catalogs = Catalogs

    @property
    def Labels(self):
        r"""<p>标签</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of IDNameVO
        """
        return self._Labels

    @Labels.setter
    def Labels(self, Labels):
        self._Labels = Labels

    @property
    def CreateTime(self):
        r"""<p>创建时间</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._CreateTime

    @CreateTime.setter
    def CreateTime(self, CreateTime):
        self._CreateTime = CreateTime

    @property
    def LastUpdateTime(self):
        r"""<p>最后修改时间</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._LastUpdateTime

    @LastUpdateTime.setter
    def LastUpdateTime(self, LastUpdateTime):
        self._LastUpdateTime = LastUpdateTime

    @property
    def AppID(self):
        r"""<p>用户appID</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: int
        """
        return self._AppID

    @AppID.setter
    def AppID(self, AppID):
        self._AppID = AppID

    @property
    def Uin(self):
        r"""<p>用户ID</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._Uin

    @Uin.setter
    def Uin(self, Uin):
        self._Uin = Uin

    @property
    def CustomHttpHost(self):
        r"""<p>自定义host</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._CustomHttpHost

    @CustomHttpHost.setter
    def CustomHttpHost(self, CustomHttpHost):
        self._CustomHttpHost = CustomHttpHost

    @property
    def HttpHostType(self):
        r"""<p>Http 请求host类型 useRequestHost 保持源请求host targetHost 修正为源站host  customHost 自定义host</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._HttpHostType

    @HttpHostType.setter
    def HttpHostType(self, HttpHostType):
        self._HttpHostType = HttpHostType

    @property
    def Timeout(self):
        r"""<p>请求的超时时间</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: int
        """
        return self._Timeout

    @Timeout.setter
    def Timeout(self, Timeout):
        self._Timeout = Timeout

    @property
    def Mode(self):
        r"""<p>mcp server模式</p>
        :rtype: str
        """
        return self._Mode

    @Mode.setter
    def Mode(self, Mode):
        self._Mode = Mode

    @property
    def McpVersion(self):
        r"""<p>mcp version</p>
        :rtype: str
        """
        return self._McpVersion

    @McpVersion.setter
    def McpVersion(self, McpVersion):
        self._McpVersion = McpVersion

    @property
    def WrapServices(self):
        r"""<p>封装模式下绑定的服务ID列表</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of str
        """
        return self._WrapServices

    @WrapServices.setter
    def WrapServices(self, WrapServices):
        self._WrapServices = WrapServices

    @property
    def ToolNum(self):
        r"""<p>工具数量</p>
        :rtype: int
        """
        return self._ToolNum

    @ToolNum.setter
    def ToolNum(self, ToolNum):
        self._ToolNum = ToolNum

    @property
    def McpSecurityRulesVO(self):
        r"""<p>安全规则集响应</p>
        :rtype: list of McpSecurityRulesVO
        """
        return self._McpSecurityRulesVO

    @McpSecurityRulesVO.setter
    def McpSecurityRulesVO(self, McpSecurityRulesVO):
        self._McpSecurityRulesVO = McpSecurityRulesVO

    @property
    def ToolConfigs(self):
        r"""<p>真实工具级别配置，实时拉取了tool/list做渲染的，如果tool/list不通，就拉不到。</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of ToolConfigVO
        """
        return self._ToolConfigs

    @ToolConfigs.setter
    def ToolConfigs(self, ToolConfigs):
        self._ToolConfigs = ToolConfigs

    @property
    def UrlObj(self):
        r"""<p>访问URL</p>
        :rtype: :class:`tencentcloud.apis.v20240801.models.McpUrlObj`
        """
        return self._UrlObj

    @UrlObj.setter
    def UrlObj(self, UrlObj):
        self._UrlObj = UrlObj

    @property
    def ToolMessage(self):
        r"""<p>后端mcp服务是否正常</p>
        :rtype: str
        """
        return self._ToolMessage

    @ToolMessage.setter
    def ToolMessage(self, ToolMessage):
        self._ToolMessage = ToolMessage

    @property
    def Tools(self):
        r"""<p>后端mcp服务的工具列表</p>
        :rtype: list of McpTool
        """
        return self._Tools

    @Tools.setter
    def Tools(self, Tools):
        self._Tools = Tools

    @property
    def WrapPaasID(self):
        r"""<p>封装的API分组ID</p>
        :rtype: str
        """
        return self._WrapPaasID

    @WrapPaasID.setter
    def WrapPaasID(self, WrapPaasID):
        self._WrapPaasID = WrapPaasID

    @property
    def RelateAgentAppNum(self):
        r"""<p>关联的agentApp数量</p>
        :rtype: int
        """
        return self._RelateAgentAppNum

    @RelateAgentAppNum.setter
    def RelateAgentAppNum(self, RelateAgentAppNum):
        self._RelateAgentAppNum = RelateAgentAppNum

    @property
    def PluginConfigs(self):
        r"""<p>插件配置</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of PluginConfigDTO
        """
        return self._PluginConfigs

    @PluginConfigs.setter
    def PluginConfigs(self, PluginConfigs):
        self._PluginConfigs = PluginConfigs

    @property
    def IgnoreHealthCheck(self):
        r"""<p>是否忽略健康检查</p>
        :rtype: bool
        """
        return self._IgnoreHealthCheck

    @IgnoreHealthCheck.setter
    def IgnoreHealthCheck(self, IgnoreHealthCheck):
        self._IgnoreHealthCheck = IgnoreHealthCheck

    @property
    def CredentialID(self):
        r"""<p>凭据ID</p>
        :rtype: str
        """
        return self._CredentialID

    @CredentialID.setter
    def CredentialID(self, CredentialID):
        self._CredentialID = CredentialID

    @property
    def CredentialName(self):
        r"""<p>凭据名称</p>
        :rtype: str
        """
        return self._CredentialName

    @CredentialName.setter
    def CredentialName(self, CredentialName):
        self._CredentialName = CredentialName

    @property
    def Domain(self):
        r"""<p>访问域名</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._Domain

    @Domain.setter
    def Domain(self, Domain):
        self._Domain = Domain

    @property
    def RequestProtocolType(self):
        r"""<p>访问协议</p><p>枚举值：</p><ul><li>http： http</li><li>https： https</li></ul>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._RequestProtocolType

    @RequestProtocolType.setter
    def RequestProtocolType(self, RequestProtocolType):
        self._RequestProtocolType = RequestProtocolType


    def _deserialize(self, params):
        self._InstanceID = params.get("InstanceID")
        self._Name = params.get("Name")
        self._Description = params.get("Description")
        self._LabelIDs = params.get("LabelIDs")
        self._CategoryIDs = params.get("CategoryIDs")
        self._TargetSelect = params.get("TargetSelect")
        if params.get("TargetHosts") is not None:
            self._TargetHosts = []
            for item in params.get("TargetHosts"):
                obj = TargetHostDTO()
                obj._deserialize(item)
                self._TargetHosts.append(obj)
        self._HttpProtocolType = params.get("HttpProtocolType")
        self._CheckTargetCertsError = params.get("CheckTargetCertsError")
        self._TargetPath = params.get("TargetPath")
        self._InvokeLimitConfigStatus = params.get("InvokeLimitConfigStatus")
        if params.get("InvokeLimitConfig") is not None:
            self._InvokeLimitConfig = InvokeLimitConfigDTO()
            self._InvokeLimitConfig._deserialize(params.get("InvokeLimitConfig"))
        self._IpWhiteStatus = params.get("IpWhiteStatus")
        if params.get("IpWhiteConfig") is not None:
            self._IpWhiteConfig = IpConfig()
            self._IpWhiteConfig._deserialize(params.get("IpWhiteConfig"))
        self._IpBlackStatus = params.get("IpBlackStatus")
        if params.get("IpBlackConfig") is not None:
            self._IpBlackConfig = IpConfig()
            self._IpBlackConfig._deserialize(params.get("IpBlackConfig"))
        self._ID = params.get("ID")
        self._Status = params.get("Status")
        self._Url = params.get("Url")
        if params.get("App") is not None:
            self._App = IDNameVO()
            self._App._deserialize(params.get("App"))
        if params.get("Catalogs") is not None:
            self._Catalogs = []
            for item in params.get("Catalogs"):
                obj = IDNameVO()
                obj._deserialize(item)
                self._Catalogs.append(obj)
        if params.get("Labels") is not None:
            self._Labels = []
            for item in params.get("Labels"):
                obj = IDNameVO()
                obj._deserialize(item)
                self._Labels.append(obj)
        self._CreateTime = params.get("CreateTime")
        self._LastUpdateTime = params.get("LastUpdateTime")
        self._AppID = params.get("AppID")
        self._Uin = params.get("Uin")
        self._CustomHttpHost = params.get("CustomHttpHost")
        self._HttpHostType = params.get("HttpHostType")
        self._Timeout = params.get("Timeout")
        self._Mode = params.get("Mode")
        self._McpVersion = params.get("McpVersion")
        self._WrapServices = params.get("WrapServices")
        self._ToolNum = params.get("ToolNum")
        if params.get("McpSecurityRulesVO") is not None:
            self._McpSecurityRulesVO = []
            for item in params.get("McpSecurityRulesVO"):
                obj = McpSecurityRulesVO()
                obj._deserialize(item)
                self._McpSecurityRulesVO.append(obj)
        if params.get("ToolConfigs") is not None:
            self._ToolConfigs = []
            for item in params.get("ToolConfigs"):
                obj = ToolConfigVO()
                obj._deserialize(item)
                self._ToolConfigs.append(obj)
        if params.get("UrlObj") is not None:
            self._UrlObj = McpUrlObj()
            self._UrlObj._deserialize(params.get("UrlObj"))
        self._ToolMessage = params.get("ToolMessage")
        if params.get("Tools") is not None:
            self._Tools = []
            for item in params.get("Tools"):
                obj = McpTool()
                obj._deserialize(item)
                self._Tools.append(obj)
        self._WrapPaasID = params.get("WrapPaasID")
        self._RelateAgentAppNum = params.get("RelateAgentAppNum")
        if params.get("PluginConfigs") is not None:
            self._PluginConfigs = []
            for item in params.get("PluginConfigs"):
                obj = PluginConfigDTO()
                obj._deserialize(item)
                self._PluginConfigs.append(obj)
        self._IgnoreHealthCheck = params.get("IgnoreHealthCheck")
        self._CredentialID = params.get("CredentialID")
        self._CredentialName = params.get("CredentialName")
        self._Domain = params.get("Domain")
        self._RequestProtocolType = params.get("RequestProtocolType")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeMcpServersRequest(AbstractModel):
    r"""DescribeMcpServers请求参数结构体

    """

    def __init__(self):
        r"""
        :param _Limit: 分页大小
        :type Limit: int
        :param _Offset: 分页偏移量
        :type Offset: int
        :param _InstanceID: 实例ID
        :type InstanceID: str
        :param _Statuses: 状态数组：normal正常状态，disabled下线状态
        :type Statuses: list of str
        :param _Keyword: 关键词
        :type Keyword: str
        :param _IDs: 服务ID数组
        :type IDs: list of str
        :param _Modes: 模式：proxy代理模式； wrap封装模式；
        :type Modes: list of str
        :param _McpSecurityRuleID: 绑定的安全规则ID
        :type McpSecurityRuleID: str
        :param _McpSecurityRuleAct: 绑定安全规则的处置动作（填写时McpSecurityRuleID得必填）
        :type McpSecurityRuleAct: str
        :param _PluginID: 已绑定插件id
        :type PluginID: str
        """
        self._Limit = None
        self._Offset = None
        self._InstanceID = None
        self._Statuses = None
        self._Keyword = None
        self._IDs = None
        self._Modes = None
        self._McpSecurityRuleID = None
        self._McpSecurityRuleAct = None
        self._PluginID = None

    @property
    def Limit(self):
        r"""分页大小
        :rtype: int
        """
        return self._Limit

    @Limit.setter
    def Limit(self, Limit):
        self._Limit = Limit

    @property
    def Offset(self):
        r"""分页偏移量
        :rtype: int
        """
        return self._Offset

    @Offset.setter
    def Offset(self, Offset):
        self._Offset = Offset

    @property
    def InstanceID(self):
        r"""实例ID
        :rtype: str
        """
        return self._InstanceID

    @InstanceID.setter
    def InstanceID(self, InstanceID):
        self._InstanceID = InstanceID

    @property
    def Statuses(self):
        r"""状态数组：normal正常状态，disabled下线状态
        :rtype: list of str
        """
        return self._Statuses

    @Statuses.setter
    def Statuses(self, Statuses):
        self._Statuses = Statuses

    @property
    def Keyword(self):
        r"""关键词
        :rtype: str
        """
        return self._Keyword

    @Keyword.setter
    def Keyword(self, Keyword):
        self._Keyword = Keyword

    @property
    def IDs(self):
        r"""服务ID数组
        :rtype: list of str
        """
        return self._IDs

    @IDs.setter
    def IDs(self, IDs):
        self._IDs = IDs

    @property
    def Modes(self):
        r"""模式：proxy代理模式； wrap封装模式；
        :rtype: list of str
        """
        return self._Modes

    @Modes.setter
    def Modes(self, Modes):
        self._Modes = Modes

    @property
    def McpSecurityRuleID(self):
        r"""绑定的安全规则ID
        :rtype: str
        """
        return self._McpSecurityRuleID

    @McpSecurityRuleID.setter
    def McpSecurityRuleID(self, McpSecurityRuleID):
        self._McpSecurityRuleID = McpSecurityRuleID

    @property
    def McpSecurityRuleAct(self):
        r"""绑定安全规则的处置动作（填写时McpSecurityRuleID得必填）
        :rtype: str
        """
        return self._McpSecurityRuleAct

    @McpSecurityRuleAct.setter
    def McpSecurityRuleAct(self, McpSecurityRuleAct):
        self._McpSecurityRuleAct = McpSecurityRuleAct

    @property
    def PluginID(self):
        r"""已绑定插件id
        :rtype: str
        """
        return self._PluginID

    @PluginID.setter
    def PluginID(self, PluginID):
        self._PluginID = PluginID


    def _deserialize(self, params):
        self._Limit = params.get("Limit")
        self._Offset = params.get("Offset")
        self._InstanceID = params.get("InstanceID")
        self._Statuses = params.get("Statuses")
        self._Keyword = params.get("Keyword")
        self._IDs = params.get("IDs")
        self._Modes = params.get("Modes")
        self._McpSecurityRuleID = params.get("McpSecurityRuleID")
        self._McpSecurityRuleAct = params.get("McpSecurityRuleAct")
        self._PluginID = params.get("PluginID")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeMcpServersResponse(AbstractModel):
    r"""DescribeMcpServers返回参数结构体

    """

    def __init__(self):
        r"""
        :param _Data: mcp server列表
        :type Data: :class:`tencentcloud.apis.v20240801.models.DescribeMcpServersResponseVO`
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._Data = None
        self._RequestId = None

    @property
    def Data(self):
        r"""mcp server列表
        :rtype: :class:`tencentcloud.apis.v20240801.models.DescribeMcpServersResponseVO`
        """
        return self._Data

    @Data.setter
    def Data(self, Data):
        self._Data = Data

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("Data") is not None:
            self._Data = DescribeMcpServersResponseVO()
            self._Data._deserialize(params.get("Data"))
        self._RequestId = params.get("RequestId")


class DescribeMcpServersResponseVO(AbstractModel):
    r"""ServicesVO

    """

    def __init__(self):
        r"""
        :param _Total: 条目
注意：此字段可能返回 null，表示取不到有效值。
        :type Total: int
        :param _Items: 数组
注意：此字段可能返回 null，表示取不到有效值。
        :type Items: list of DescribeMcpServerResponseVO
        """
        self._Total = None
        self._Items = None

    @property
    def Total(self):
        r"""条目
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: int
        """
        return self._Total

    @Total.setter
    def Total(self, Total):
        self._Total = Total

    @property
    def Items(self):
        r"""数组
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of DescribeMcpServerResponseVO
        """
        return self._Items

    @Items.setter
    def Items(self, Items):
        self._Items = Items


    def _deserialize(self, params):
        self._Total = params.get("Total")
        if params.get("Items") is not None:
            self._Items = []
            for item in params.get("Items"):
                obj = DescribeMcpServerResponseVO()
                obj._deserialize(item)
                self._Items.append(obj)
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeModelRequest(AbstractModel):
    r"""DescribeModel请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceID: 实例
        :type InstanceID: str
        :param _ID: 模型ID
        :type ID: str
        """
        self._InstanceID = None
        self._ID = None

    @property
    def InstanceID(self):
        r"""实例
        :rtype: str
        """
        return self._InstanceID

    @InstanceID.setter
    def InstanceID(self, InstanceID):
        self._InstanceID = InstanceID

    @property
    def ID(self):
        r"""模型ID
        :rtype: str
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID


    def _deserialize(self, params):
        self._InstanceID = params.get("InstanceID")
        self._ID = params.get("ID")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeModelResponse(AbstractModel):
    r"""DescribeModel返回参数结构体

    """

    def __init__(self):
        r"""
        :param _Data: 结果集
        :type Data: :class:`tencentcloud.apis.v20240801.models.DescribeModelResponseVO`
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._Data = None
        self._RequestId = None

    @property
    def Data(self):
        r"""结果集
        :rtype: :class:`tencentcloud.apis.v20240801.models.DescribeModelResponseVO`
        """
        return self._Data

    @Data.setter
    def Data(self, Data):
        self._Data = Data

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("Data") is not None:
            self._Data = DescribeModelResponseVO()
            self._Data._deserialize(params.get("Data"))
        self._RequestId = params.get("RequestId")


class DescribeModelResponseVO(AbstractModel):
    r"""查询模型详情的响应

    """

    def __init__(self):
        r"""
        :param _AppID: <p>腾讯云AppID</p>
        :type AppID: int
        :param _Uin: <p>腾讯云Uin</p>
        :type Uin: str
        :param _InstanceID: <p>实例ID</p>
        :type InstanceID: str
        :param _ID: <p>模型ID</p>
        :type ID: str
        :param _Name: <p>模型名称</p>
        :type Name: str
        :param _CredentialID: <p>凭据ID</p>
        :type CredentialID: str
        :param _CredentialName: <p>凭据名称</p>
        :type CredentialName: str
        :param _HttpProtocolType: <p>http协议类型</p>
        :type HttpProtocolType: str
        :param _CheckTargetCertsError: <p>https时，是否校验目标证书</p>
        :type CheckTargetCertsError: bool
        :param _HttpProtocolVersion: <p>http协议版本：1.1/2.0</p>
        :type HttpProtocolVersion: str
        :param _TargetPath: <p>目标路径</p>
        :type TargetPath: str
        :param _TargetHosts: <p>目标器列表</p>
        :type TargetHosts: list of TargetHostDTO
        :param _ModelServiceCount: <p>被模型服务使用的个数</p>
        :type ModelServiceCount: int
        :param _CreateTime: <p>创建时间</p>
        :type CreateTime: str
        :param _LastUpdateTime: <p>最后修改时间</p>
        :type LastUpdateTime: str
        :param _ModelID: <p>model ID</p>
        :type ModelID: str
        :param _Description: <p>描述</p>
        :type Description: str
        """
        self._AppID = None
        self._Uin = None
        self._InstanceID = None
        self._ID = None
        self._Name = None
        self._CredentialID = None
        self._CredentialName = None
        self._HttpProtocolType = None
        self._CheckTargetCertsError = None
        self._HttpProtocolVersion = None
        self._TargetPath = None
        self._TargetHosts = None
        self._ModelServiceCount = None
        self._CreateTime = None
        self._LastUpdateTime = None
        self._ModelID = None
        self._Description = None

    @property
    def AppID(self):
        r"""<p>腾讯云AppID</p>
        :rtype: int
        """
        return self._AppID

    @AppID.setter
    def AppID(self, AppID):
        self._AppID = AppID

    @property
    def Uin(self):
        r"""<p>腾讯云Uin</p>
        :rtype: str
        """
        return self._Uin

    @Uin.setter
    def Uin(self, Uin):
        self._Uin = Uin

    @property
    def InstanceID(self):
        r"""<p>实例ID</p>
        :rtype: str
        """
        return self._InstanceID

    @InstanceID.setter
    def InstanceID(self, InstanceID):
        self._InstanceID = InstanceID

    @property
    def ID(self):
        r"""<p>模型ID</p>
        :rtype: str
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID

    @property
    def Name(self):
        r"""<p>模型名称</p>
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def CredentialID(self):
        r"""<p>凭据ID</p>
        :rtype: str
        """
        return self._CredentialID

    @CredentialID.setter
    def CredentialID(self, CredentialID):
        self._CredentialID = CredentialID

    @property
    def CredentialName(self):
        r"""<p>凭据名称</p>
        :rtype: str
        """
        return self._CredentialName

    @CredentialName.setter
    def CredentialName(self, CredentialName):
        self._CredentialName = CredentialName

    @property
    def HttpProtocolType(self):
        r"""<p>http协议类型</p>
        :rtype: str
        """
        return self._HttpProtocolType

    @HttpProtocolType.setter
    def HttpProtocolType(self, HttpProtocolType):
        self._HttpProtocolType = HttpProtocolType

    @property
    def CheckTargetCertsError(self):
        r"""<p>https时，是否校验目标证书</p>
        :rtype: bool
        """
        return self._CheckTargetCertsError

    @CheckTargetCertsError.setter
    def CheckTargetCertsError(self, CheckTargetCertsError):
        self._CheckTargetCertsError = CheckTargetCertsError

    @property
    def HttpProtocolVersion(self):
        r"""<p>http协议版本：1.1/2.0</p>
        :rtype: str
        """
        return self._HttpProtocolVersion

    @HttpProtocolVersion.setter
    def HttpProtocolVersion(self, HttpProtocolVersion):
        self._HttpProtocolVersion = HttpProtocolVersion

    @property
    def TargetPath(self):
        r"""<p>目标路径</p>
        :rtype: str
        """
        return self._TargetPath

    @TargetPath.setter
    def TargetPath(self, TargetPath):
        self._TargetPath = TargetPath

    @property
    def TargetHosts(self):
        r"""<p>目标器列表</p>
        :rtype: list of TargetHostDTO
        """
        return self._TargetHosts

    @TargetHosts.setter
    def TargetHosts(self, TargetHosts):
        self._TargetHosts = TargetHosts

    @property
    def ModelServiceCount(self):
        r"""<p>被模型服务使用的个数</p>
        :rtype: int
        """
        return self._ModelServiceCount

    @ModelServiceCount.setter
    def ModelServiceCount(self, ModelServiceCount):
        self._ModelServiceCount = ModelServiceCount

    @property
    def CreateTime(self):
        r"""<p>创建时间</p>
        :rtype: str
        """
        return self._CreateTime

    @CreateTime.setter
    def CreateTime(self, CreateTime):
        self._CreateTime = CreateTime

    @property
    def LastUpdateTime(self):
        r"""<p>最后修改时间</p>
        :rtype: str
        """
        return self._LastUpdateTime

    @LastUpdateTime.setter
    def LastUpdateTime(self, LastUpdateTime):
        self._LastUpdateTime = LastUpdateTime

    @property
    def ModelID(self):
        r"""<p>model ID</p>
        :rtype: str
        """
        return self._ModelID

    @ModelID.setter
    def ModelID(self, ModelID):
        self._ModelID = ModelID

    @property
    def Description(self):
        r"""<p>描述</p>
        :rtype: str
        """
        return self._Description

    @Description.setter
    def Description(self, Description):
        self._Description = Description


    def _deserialize(self, params):
        self._AppID = params.get("AppID")
        self._Uin = params.get("Uin")
        self._InstanceID = params.get("InstanceID")
        self._ID = params.get("ID")
        self._Name = params.get("Name")
        self._CredentialID = params.get("CredentialID")
        self._CredentialName = params.get("CredentialName")
        self._HttpProtocolType = params.get("HttpProtocolType")
        self._CheckTargetCertsError = params.get("CheckTargetCertsError")
        self._HttpProtocolVersion = params.get("HttpProtocolVersion")
        self._TargetPath = params.get("TargetPath")
        if params.get("TargetHosts") is not None:
            self._TargetHosts = []
            for item in params.get("TargetHosts"):
                obj = TargetHostDTO()
                obj._deserialize(item)
                self._TargetHosts.append(obj)
        self._ModelServiceCount = params.get("ModelServiceCount")
        self._CreateTime = params.get("CreateTime")
        self._LastUpdateTime = params.get("LastUpdateTime")
        self._ModelID = params.get("ModelID")
        self._Description = params.get("Description")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeModelServiceRequest(AbstractModel):
    r"""DescribeModelService请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceID: 实例
        :type InstanceID: str
        :param _ID: 模型服务ID
        :type ID: str
        """
        self._InstanceID = None
        self._ID = None

    @property
    def InstanceID(self):
        r"""实例
        :rtype: str
        """
        return self._InstanceID

    @InstanceID.setter
    def InstanceID(self, InstanceID):
        self._InstanceID = InstanceID

    @property
    def ID(self):
        r"""模型服务ID
        :rtype: str
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID


    def _deserialize(self, params):
        self._InstanceID = params.get("InstanceID")
        self._ID = params.get("ID")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeModelServiceResponse(AbstractModel):
    r"""DescribeModelService返回参数结构体

    """

    def __init__(self):
        r"""
        :param _Data: 结果集
        :type Data: :class:`tencentcloud.apis.v20240801.models.DescribeModelServiceResponseVO`
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._Data = None
        self._RequestId = None

    @property
    def Data(self):
        r"""结果集
        :rtype: :class:`tencentcloud.apis.v20240801.models.DescribeModelServiceResponseVO`
        """
        return self._Data

    @Data.setter
    def Data(self, Data):
        self._Data = Data

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("Data") is not None:
            self._Data = DescribeModelServiceResponseVO()
            self._Data._deserialize(params.get("Data"))
        self._RequestId = params.get("RequestId")


class DescribeModelServiceResponseVO(AbstractModel):
    r"""查询模型服务详情的响应

    """

    def __init__(self):
        r"""
        :param _AppID: <p>腾讯云AppID</p>
        :type AppID: int
        :param _Uin: <p>腾讯云Uin</p>
        :type Uin: str
        :param _InstanceID: <p>实例ID</p>
        :type InstanceID: str
        :param _ID: <p>模型ID</p>
        :type ID: str
        :param _Name: <p>模型名称</p>
        :type Name: str
        :param _Description: <p>描述</p>
        :type Description: str
        :param _PubPath: <p>访问路径</p>
        :type PubPath: str
        :param _PathMatchType: <p>路径匹配方式：absolute，prefix，regex</p>
        :type PathMatchType: str
        :param _TargetModels: <p>目标模型列表</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type TargetModels: list of TargetModelDTO
        :param _ModelNames: <p>模板模型的名称列表</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type ModelNames: list of str
        :param _InvokeLimitConfigStatus: <p>是否开启限流</p>
        :type InvokeLimitConfigStatus: bool
        :param _InvokeLimitConfig: <p>限流配置</p>
        :type InvokeLimitConfig: :class:`tencentcloud.apis.v20240801.models.InvokeLimitConfigDTO`
        :param _CreateTime: <p>创建时间</p>
        :type CreateTime: str
        :param _LastUpdateTime: <p>最后修改时间</p>
        :type LastUpdateTime: str
        :param _TokenLimitStatus: <p>是否开启token控制</p>
        :type TokenLimitStatus: bool
        :param _TokenLimitConfig: <p>token控制</p>
        :type TokenLimitConfig: :class:`tencentcloud.apis.v20240801.models.TokenLimitConfigDTO`
        :param _TmsStatus: <p>是否开启tms配置</p>
        :type TmsStatus: bool
        :param _TmsConfig: <p>tms配置</p>
        :type TmsConfig: :class:`tencentcloud.apis.v20240801.models.TmsConfigDTO`
        :param _IpWhiteStatus: <p>是否开启IP白名单</p>
        :type IpWhiteStatus: bool
        :param _IpWhiteList: <p>IP白名单列表</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type IpWhiteList: list of str
        :param _IpBlackStatus: <p>是否开启IP黑名单</p>
        :type IpBlackStatus: bool
        :param _IpBlackList: <p>IP黑名单列表</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type IpBlackList: list of str
        :param _PluginConfigs: <p>插件配置</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type PluginConfigs: list of PluginConfigDTO
        :param _Timeout: <p>超时配置，单位秒</p>
        :type Timeout: int
        :param _Status: <p>状态：normal，disabled</p>
        :type Status: str
        :param _RelateAgentAppNum: <p>关联应用数</p>
        :type RelateAgentAppNum: int
        :param _Url: <p>请求路径</p>
        :type Url: str
        :param _PromptModerateStatus: <p>是否开启提示词安全检测</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type PromptModerateStatus: bool
        :param _PromptModerateConfig: <p>提示词安全检测配置</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type PromptModerateConfig: :class:`tencentcloud.apis.v20240801.models.PromptModerateConfigDTO`
        :param _SensitiveDataCheckStatus: <p>是否开启敏感数据检测</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type SensitiveDataCheckStatus: bool
        :param _SensitiveDataCheckConfig: <p>敏感数据检测配置</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type SensitiveDataCheckConfig: :class:`tencentcloud.apis.v20240801.models.SensitiveDataCheckConfigDTO`
        :param _TargetSelect: <p>负载方式</p><p>枚举值：</p><ul><li>random： 随机</li><li>consistentHash： 会话保持</li></ul>
注意：此字段可能返回 null，表示取不到有效值。
        :type TargetSelect: str
        :param _FindHostKeyMethod: <p>会话判断方式</p><p>枚举值：</p><ul><li>fromClientIP： 从客户端IP判断</li><li>fromHeader： 从请求header判断</li><li>autoDetect： 自动探测</li></ul>
注意：此字段可能返回 null，表示取不到有效值。
        :type FindHostKeyMethod: str
        :param _HostKeyHeaderName: <p>会话判断header名称</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type HostKeyHeaderName: str
        :param _FallbackStatus: <p>是否开启备份模型</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type FallbackStatus: bool
        :param _FallbackModels: <p>备份模型</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type FallbackModels: list of TargetModelDTO
        :param _ModelProtocol: <p>模型类型</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type ModelProtocol: str
        :param _RawCustomModelProtocolConfig: <p>自定义模型协议配置</p>
        :type RawCustomModelProtocolConfig: str
        :param _RouteStrategy: <p>路由策略</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type RouteStrategy: str
        :param _TokenLengthRoute: <p>token长度路由配置</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type TokenLengthRoute: list of TokenLengthRouteDTO
        :param _TaskComplexityRoute: <p>任务复杂度路由配置</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type TaskComplexityRoute: :class:`tencentcloud.apis.v20240801.models.TaskComplexityRouteDTO`
        :param _Domain: <p>访问域名</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type Domain: str
        :param _RequestProtocolType: <p>访问协议</p><p>枚举值：</p><ul><li>http： http</li><li>https： https</li></ul>
注意：此字段可能返回 null，表示取不到有效值。
        :type RequestProtocolType: str
        """
        self._AppID = None
        self._Uin = None
        self._InstanceID = None
        self._ID = None
        self._Name = None
        self._Description = None
        self._PubPath = None
        self._PathMatchType = None
        self._TargetModels = None
        self._ModelNames = None
        self._InvokeLimitConfigStatus = None
        self._InvokeLimitConfig = None
        self._CreateTime = None
        self._LastUpdateTime = None
        self._TokenLimitStatus = None
        self._TokenLimitConfig = None
        self._TmsStatus = None
        self._TmsConfig = None
        self._IpWhiteStatus = None
        self._IpWhiteList = None
        self._IpBlackStatus = None
        self._IpBlackList = None
        self._PluginConfigs = None
        self._Timeout = None
        self._Status = None
        self._RelateAgentAppNum = None
        self._Url = None
        self._PromptModerateStatus = None
        self._PromptModerateConfig = None
        self._SensitiveDataCheckStatus = None
        self._SensitiveDataCheckConfig = None
        self._TargetSelect = None
        self._FindHostKeyMethod = None
        self._HostKeyHeaderName = None
        self._FallbackStatus = None
        self._FallbackModels = None
        self._ModelProtocol = None
        self._RawCustomModelProtocolConfig = None
        self._RouteStrategy = None
        self._TokenLengthRoute = None
        self._TaskComplexityRoute = None
        self._Domain = None
        self._RequestProtocolType = None

    @property
    def AppID(self):
        r"""<p>腾讯云AppID</p>
        :rtype: int
        """
        return self._AppID

    @AppID.setter
    def AppID(self, AppID):
        self._AppID = AppID

    @property
    def Uin(self):
        r"""<p>腾讯云Uin</p>
        :rtype: str
        """
        return self._Uin

    @Uin.setter
    def Uin(self, Uin):
        self._Uin = Uin

    @property
    def InstanceID(self):
        r"""<p>实例ID</p>
        :rtype: str
        """
        return self._InstanceID

    @InstanceID.setter
    def InstanceID(self, InstanceID):
        self._InstanceID = InstanceID

    @property
    def ID(self):
        r"""<p>模型ID</p>
        :rtype: str
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID

    @property
    def Name(self):
        r"""<p>模型名称</p>
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def Description(self):
        r"""<p>描述</p>
        :rtype: str
        """
        return self._Description

    @Description.setter
    def Description(self, Description):
        self._Description = Description

    @property
    def PubPath(self):
        r"""<p>访问路径</p>
        :rtype: str
        """
        return self._PubPath

    @PubPath.setter
    def PubPath(self, PubPath):
        self._PubPath = PubPath

    @property
    def PathMatchType(self):
        r"""<p>路径匹配方式：absolute，prefix，regex</p>
        :rtype: str
        """
        return self._PathMatchType

    @PathMatchType.setter
    def PathMatchType(self, PathMatchType):
        self._PathMatchType = PathMatchType

    @property
    def TargetModels(self):
        r"""<p>目标模型列表</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of TargetModelDTO
        """
        return self._TargetModels

    @TargetModels.setter
    def TargetModels(self, TargetModels):
        self._TargetModels = TargetModels

    @property
    def ModelNames(self):
        r"""<p>模板模型的名称列表</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of str
        """
        return self._ModelNames

    @ModelNames.setter
    def ModelNames(self, ModelNames):
        self._ModelNames = ModelNames

    @property
    def InvokeLimitConfigStatus(self):
        r"""<p>是否开启限流</p>
        :rtype: bool
        """
        return self._InvokeLimitConfigStatus

    @InvokeLimitConfigStatus.setter
    def InvokeLimitConfigStatus(self, InvokeLimitConfigStatus):
        self._InvokeLimitConfigStatus = InvokeLimitConfigStatus

    @property
    def InvokeLimitConfig(self):
        r"""<p>限流配置</p>
        :rtype: :class:`tencentcloud.apis.v20240801.models.InvokeLimitConfigDTO`
        """
        return self._InvokeLimitConfig

    @InvokeLimitConfig.setter
    def InvokeLimitConfig(self, InvokeLimitConfig):
        self._InvokeLimitConfig = InvokeLimitConfig

    @property
    def CreateTime(self):
        r"""<p>创建时间</p>
        :rtype: str
        """
        return self._CreateTime

    @CreateTime.setter
    def CreateTime(self, CreateTime):
        self._CreateTime = CreateTime

    @property
    def LastUpdateTime(self):
        r"""<p>最后修改时间</p>
        :rtype: str
        """
        return self._LastUpdateTime

    @LastUpdateTime.setter
    def LastUpdateTime(self, LastUpdateTime):
        self._LastUpdateTime = LastUpdateTime

    @property
    def TokenLimitStatus(self):
        r"""<p>是否开启token控制</p>
        :rtype: bool
        """
        return self._TokenLimitStatus

    @TokenLimitStatus.setter
    def TokenLimitStatus(self, TokenLimitStatus):
        self._TokenLimitStatus = TokenLimitStatus

    @property
    def TokenLimitConfig(self):
        r"""<p>token控制</p>
        :rtype: :class:`tencentcloud.apis.v20240801.models.TokenLimitConfigDTO`
        """
        return self._TokenLimitConfig

    @TokenLimitConfig.setter
    def TokenLimitConfig(self, TokenLimitConfig):
        self._TokenLimitConfig = TokenLimitConfig

    @property
    def TmsStatus(self):
        r"""<p>是否开启tms配置</p>
        :rtype: bool
        """
        return self._TmsStatus

    @TmsStatus.setter
    def TmsStatus(self, TmsStatus):
        self._TmsStatus = TmsStatus

    @property
    def TmsConfig(self):
        r"""<p>tms配置</p>
        :rtype: :class:`tencentcloud.apis.v20240801.models.TmsConfigDTO`
        """
        return self._TmsConfig

    @TmsConfig.setter
    def TmsConfig(self, TmsConfig):
        self._TmsConfig = TmsConfig

    @property
    def IpWhiteStatus(self):
        r"""<p>是否开启IP白名单</p>
        :rtype: bool
        """
        return self._IpWhiteStatus

    @IpWhiteStatus.setter
    def IpWhiteStatus(self, IpWhiteStatus):
        self._IpWhiteStatus = IpWhiteStatus

    @property
    def IpWhiteList(self):
        r"""<p>IP白名单列表</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of str
        """
        return self._IpWhiteList

    @IpWhiteList.setter
    def IpWhiteList(self, IpWhiteList):
        self._IpWhiteList = IpWhiteList

    @property
    def IpBlackStatus(self):
        r"""<p>是否开启IP黑名单</p>
        :rtype: bool
        """
        return self._IpBlackStatus

    @IpBlackStatus.setter
    def IpBlackStatus(self, IpBlackStatus):
        self._IpBlackStatus = IpBlackStatus

    @property
    def IpBlackList(self):
        r"""<p>IP黑名单列表</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of str
        """
        return self._IpBlackList

    @IpBlackList.setter
    def IpBlackList(self, IpBlackList):
        self._IpBlackList = IpBlackList

    @property
    def PluginConfigs(self):
        r"""<p>插件配置</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of PluginConfigDTO
        """
        return self._PluginConfigs

    @PluginConfigs.setter
    def PluginConfigs(self, PluginConfigs):
        self._PluginConfigs = PluginConfigs

    @property
    def Timeout(self):
        r"""<p>超时配置，单位秒</p>
        :rtype: int
        """
        return self._Timeout

    @Timeout.setter
    def Timeout(self, Timeout):
        self._Timeout = Timeout

    @property
    def Status(self):
        r"""<p>状态：normal，disabled</p>
        :rtype: str
        """
        return self._Status

    @Status.setter
    def Status(self, Status):
        self._Status = Status

    @property
    def RelateAgentAppNum(self):
        r"""<p>关联应用数</p>
        :rtype: int
        """
        return self._RelateAgentAppNum

    @RelateAgentAppNum.setter
    def RelateAgentAppNum(self, RelateAgentAppNum):
        self._RelateAgentAppNum = RelateAgentAppNum

    @property
    def Url(self):
        r"""<p>请求路径</p>
        :rtype: str
        """
        return self._Url

    @Url.setter
    def Url(self, Url):
        self._Url = Url

    @property
    def PromptModerateStatus(self):
        r"""<p>是否开启提示词安全检测</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: bool
        """
        return self._PromptModerateStatus

    @PromptModerateStatus.setter
    def PromptModerateStatus(self, PromptModerateStatus):
        self._PromptModerateStatus = PromptModerateStatus

    @property
    def PromptModerateConfig(self):
        r"""<p>提示词安全检测配置</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: :class:`tencentcloud.apis.v20240801.models.PromptModerateConfigDTO`
        """
        return self._PromptModerateConfig

    @PromptModerateConfig.setter
    def PromptModerateConfig(self, PromptModerateConfig):
        self._PromptModerateConfig = PromptModerateConfig

    @property
    def SensitiveDataCheckStatus(self):
        r"""<p>是否开启敏感数据检测</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: bool
        """
        return self._SensitiveDataCheckStatus

    @SensitiveDataCheckStatus.setter
    def SensitiveDataCheckStatus(self, SensitiveDataCheckStatus):
        self._SensitiveDataCheckStatus = SensitiveDataCheckStatus

    @property
    def SensitiveDataCheckConfig(self):
        r"""<p>敏感数据检测配置</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: :class:`tencentcloud.apis.v20240801.models.SensitiveDataCheckConfigDTO`
        """
        return self._SensitiveDataCheckConfig

    @SensitiveDataCheckConfig.setter
    def SensitiveDataCheckConfig(self, SensitiveDataCheckConfig):
        self._SensitiveDataCheckConfig = SensitiveDataCheckConfig

    @property
    def TargetSelect(self):
        r"""<p>负载方式</p><p>枚举值：</p><ul><li>random： 随机</li><li>consistentHash： 会话保持</li></ul>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._TargetSelect

    @TargetSelect.setter
    def TargetSelect(self, TargetSelect):
        self._TargetSelect = TargetSelect

    @property
    def FindHostKeyMethod(self):
        r"""<p>会话判断方式</p><p>枚举值：</p><ul><li>fromClientIP： 从客户端IP判断</li><li>fromHeader： 从请求header判断</li><li>autoDetect： 自动探测</li></ul>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._FindHostKeyMethod

    @FindHostKeyMethod.setter
    def FindHostKeyMethod(self, FindHostKeyMethod):
        self._FindHostKeyMethod = FindHostKeyMethod

    @property
    def HostKeyHeaderName(self):
        r"""<p>会话判断header名称</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._HostKeyHeaderName

    @HostKeyHeaderName.setter
    def HostKeyHeaderName(self, HostKeyHeaderName):
        self._HostKeyHeaderName = HostKeyHeaderName

    @property
    def FallbackStatus(self):
        r"""<p>是否开启备份模型</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: bool
        """
        return self._FallbackStatus

    @FallbackStatus.setter
    def FallbackStatus(self, FallbackStatus):
        self._FallbackStatus = FallbackStatus

    @property
    def FallbackModels(self):
        r"""<p>备份模型</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of TargetModelDTO
        """
        return self._FallbackModels

    @FallbackModels.setter
    def FallbackModels(self, FallbackModels):
        self._FallbackModels = FallbackModels

    @property
    def ModelProtocol(self):
        r"""<p>模型类型</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._ModelProtocol

    @ModelProtocol.setter
    def ModelProtocol(self, ModelProtocol):
        self._ModelProtocol = ModelProtocol

    @property
    def RawCustomModelProtocolConfig(self):
        r"""<p>自定义模型协议配置</p>
        :rtype: str
        """
        return self._RawCustomModelProtocolConfig

    @RawCustomModelProtocolConfig.setter
    def RawCustomModelProtocolConfig(self, RawCustomModelProtocolConfig):
        self._RawCustomModelProtocolConfig = RawCustomModelProtocolConfig

    @property
    def RouteStrategy(self):
        r"""<p>路由策略</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._RouteStrategy

    @RouteStrategy.setter
    def RouteStrategy(self, RouteStrategy):
        self._RouteStrategy = RouteStrategy

    @property
    def TokenLengthRoute(self):
        r"""<p>token长度路由配置</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of TokenLengthRouteDTO
        """
        return self._TokenLengthRoute

    @TokenLengthRoute.setter
    def TokenLengthRoute(self, TokenLengthRoute):
        self._TokenLengthRoute = TokenLengthRoute

    @property
    def TaskComplexityRoute(self):
        r"""<p>任务复杂度路由配置</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: :class:`tencentcloud.apis.v20240801.models.TaskComplexityRouteDTO`
        """
        return self._TaskComplexityRoute

    @TaskComplexityRoute.setter
    def TaskComplexityRoute(self, TaskComplexityRoute):
        self._TaskComplexityRoute = TaskComplexityRoute

    @property
    def Domain(self):
        r"""<p>访问域名</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._Domain

    @Domain.setter
    def Domain(self, Domain):
        self._Domain = Domain

    @property
    def RequestProtocolType(self):
        r"""<p>访问协议</p><p>枚举值：</p><ul><li>http： http</li><li>https： https</li></ul>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._RequestProtocolType

    @RequestProtocolType.setter
    def RequestProtocolType(self, RequestProtocolType):
        self._RequestProtocolType = RequestProtocolType


    def _deserialize(self, params):
        self._AppID = params.get("AppID")
        self._Uin = params.get("Uin")
        self._InstanceID = params.get("InstanceID")
        self._ID = params.get("ID")
        self._Name = params.get("Name")
        self._Description = params.get("Description")
        self._PubPath = params.get("PubPath")
        self._PathMatchType = params.get("PathMatchType")
        if params.get("TargetModels") is not None:
            self._TargetModels = []
            for item in params.get("TargetModels"):
                obj = TargetModelDTO()
                obj._deserialize(item)
                self._TargetModels.append(obj)
        self._ModelNames = params.get("ModelNames")
        self._InvokeLimitConfigStatus = params.get("InvokeLimitConfigStatus")
        if params.get("InvokeLimitConfig") is not None:
            self._InvokeLimitConfig = InvokeLimitConfigDTO()
            self._InvokeLimitConfig._deserialize(params.get("InvokeLimitConfig"))
        self._CreateTime = params.get("CreateTime")
        self._LastUpdateTime = params.get("LastUpdateTime")
        self._TokenLimitStatus = params.get("TokenLimitStatus")
        if params.get("TokenLimitConfig") is not None:
            self._TokenLimitConfig = TokenLimitConfigDTO()
            self._TokenLimitConfig._deserialize(params.get("TokenLimitConfig"))
        self._TmsStatus = params.get("TmsStatus")
        if params.get("TmsConfig") is not None:
            self._TmsConfig = TmsConfigDTO()
            self._TmsConfig._deserialize(params.get("TmsConfig"))
        self._IpWhiteStatus = params.get("IpWhiteStatus")
        self._IpWhiteList = params.get("IpWhiteList")
        self._IpBlackStatus = params.get("IpBlackStatus")
        self._IpBlackList = params.get("IpBlackList")
        if params.get("PluginConfigs") is not None:
            self._PluginConfigs = []
            for item in params.get("PluginConfigs"):
                obj = PluginConfigDTO()
                obj._deserialize(item)
                self._PluginConfigs.append(obj)
        self._Timeout = params.get("Timeout")
        self._Status = params.get("Status")
        self._RelateAgentAppNum = params.get("RelateAgentAppNum")
        self._Url = params.get("Url")
        self._PromptModerateStatus = params.get("PromptModerateStatus")
        if params.get("PromptModerateConfig") is not None:
            self._PromptModerateConfig = PromptModerateConfigDTO()
            self._PromptModerateConfig._deserialize(params.get("PromptModerateConfig"))
        self._SensitiveDataCheckStatus = params.get("SensitiveDataCheckStatus")
        if params.get("SensitiveDataCheckConfig") is not None:
            self._SensitiveDataCheckConfig = SensitiveDataCheckConfigDTO()
            self._SensitiveDataCheckConfig._deserialize(params.get("SensitiveDataCheckConfig"))
        self._TargetSelect = params.get("TargetSelect")
        self._FindHostKeyMethod = params.get("FindHostKeyMethod")
        self._HostKeyHeaderName = params.get("HostKeyHeaderName")
        self._FallbackStatus = params.get("FallbackStatus")
        if params.get("FallbackModels") is not None:
            self._FallbackModels = []
            for item in params.get("FallbackModels"):
                obj = TargetModelDTO()
                obj._deserialize(item)
                self._FallbackModels.append(obj)
        self._ModelProtocol = params.get("ModelProtocol")
        self._RawCustomModelProtocolConfig = params.get("RawCustomModelProtocolConfig")
        self._RouteStrategy = params.get("RouteStrategy")
        if params.get("TokenLengthRoute") is not None:
            self._TokenLengthRoute = []
            for item in params.get("TokenLengthRoute"):
                obj = TokenLengthRouteDTO()
                obj._deserialize(item)
                self._TokenLengthRoute.append(obj)
        if params.get("TaskComplexityRoute") is not None:
            self._TaskComplexityRoute = TaskComplexityRouteDTO()
            self._TaskComplexityRoute._deserialize(params.get("TaskComplexityRoute"))
        self._Domain = params.get("Domain")
        self._RequestProtocolType = params.get("RequestProtocolType")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeModelServicesRequest(AbstractModel):
    r"""DescribeModelServices请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceID: <p>实例</p>
        :type InstanceID: str
        :param _Offset: <p>分页参数</p>
        :type Offset: int
        :param _Limit: <p>分页限制</p>
        :type Limit: int
        :param _IDs: <p>ID列表</p>
        :type IDs: list of str
        :param _NotIDs: <p>排除的ID列表</p>
        :type NotIDs: list of str
        :param _Status: <p>状态：normal，disabled</p>
        :type Status: str
        :param _Keyword: <p>关键词</p>
        :type Keyword: str
        :param _ModelID: <p>模型ID</p>
        :type ModelID: str
        :param _Sort: <p>排序</p>
        :type Sort: :class:`tencentcloud.apis.v20240801.models.DescribeModelServicesSort`
        :param _ModelProtocol: <p>模型类型，OpenAI或Anthropic</p>
        :type ModelProtocol: str
        """
        self._InstanceID = None
        self._Offset = None
        self._Limit = None
        self._IDs = None
        self._NotIDs = None
        self._Status = None
        self._Keyword = None
        self._ModelID = None
        self._Sort = None
        self._ModelProtocol = None

    @property
    def InstanceID(self):
        r"""<p>实例</p>
        :rtype: str
        """
        return self._InstanceID

    @InstanceID.setter
    def InstanceID(self, InstanceID):
        self._InstanceID = InstanceID

    @property
    def Offset(self):
        r"""<p>分页参数</p>
        :rtype: int
        """
        return self._Offset

    @Offset.setter
    def Offset(self, Offset):
        self._Offset = Offset

    @property
    def Limit(self):
        r"""<p>分页限制</p>
        :rtype: int
        """
        return self._Limit

    @Limit.setter
    def Limit(self, Limit):
        self._Limit = Limit

    @property
    def IDs(self):
        r"""<p>ID列表</p>
        :rtype: list of str
        """
        return self._IDs

    @IDs.setter
    def IDs(self, IDs):
        self._IDs = IDs

    @property
    def NotIDs(self):
        r"""<p>排除的ID列表</p>
        :rtype: list of str
        """
        return self._NotIDs

    @NotIDs.setter
    def NotIDs(self, NotIDs):
        self._NotIDs = NotIDs

    @property
    def Status(self):
        r"""<p>状态：normal，disabled</p>
        :rtype: str
        """
        return self._Status

    @Status.setter
    def Status(self, Status):
        self._Status = Status

    @property
    def Keyword(self):
        r"""<p>关键词</p>
        :rtype: str
        """
        return self._Keyword

    @Keyword.setter
    def Keyword(self, Keyword):
        self._Keyword = Keyword

    @property
    def ModelID(self):
        r"""<p>模型ID</p>
        :rtype: str
        """
        return self._ModelID

    @ModelID.setter
    def ModelID(self, ModelID):
        self._ModelID = ModelID

    @property
    def Sort(self):
        r"""<p>排序</p>
        :rtype: :class:`tencentcloud.apis.v20240801.models.DescribeModelServicesSort`
        """
        return self._Sort

    @Sort.setter
    def Sort(self, Sort):
        self._Sort = Sort

    @property
    def ModelProtocol(self):
        r"""<p>模型类型，OpenAI或Anthropic</p>
        :rtype: str
        """
        return self._ModelProtocol

    @ModelProtocol.setter
    def ModelProtocol(self, ModelProtocol):
        self._ModelProtocol = ModelProtocol


    def _deserialize(self, params):
        self._InstanceID = params.get("InstanceID")
        self._Offset = params.get("Offset")
        self._Limit = params.get("Limit")
        self._IDs = params.get("IDs")
        self._NotIDs = params.get("NotIDs")
        self._Status = params.get("Status")
        self._Keyword = params.get("Keyword")
        self._ModelID = params.get("ModelID")
        if params.get("Sort") is not None:
            self._Sort = DescribeModelServicesSort()
            self._Sort._deserialize(params.get("Sort"))
        self._ModelProtocol = params.get("ModelProtocol")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeModelServicesResponse(AbstractModel):
    r"""DescribeModelServices返回参数结构体

    """

    def __init__(self):
        r"""
        :param _Data: <p>结果集</p>
        :type Data: :class:`tencentcloud.apis.v20240801.models.DescribeModelServicesResponseVO`
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._Data = None
        self._RequestId = None

    @property
    def Data(self):
        r"""<p>结果集</p>
        :rtype: :class:`tencentcloud.apis.v20240801.models.DescribeModelServicesResponseVO`
        """
        return self._Data

    @Data.setter
    def Data(self, Data):
        self._Data = Data

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("Data") is not None:
            self._Data = DescribeModelServicesResponseVO()
            self._Data._deserialize(params.get("Data"))
        self._RequestId = params.get("RequestId")


class DescribeModelServicesResponseVO(AbstractModel):
    r"""查询模型列表的响应

    """

    def __init__(self):
        r"""
        :param _Total: 条目
        :type Total: int
        :param _Items: 列表
        :type Items: list of DescribeModelServiceResponseVO
        """
        self._Total = None
        self._Items = None

    @property
    def Total(self):
        r"""条目
        :rtype: int
        """
        return self._Total

    @Total.setter
    def Total(self, Total):
        self._Total = Total

    @property
    def Items(self):
        r"""列表
        :rtype: list of DescribeModelServiceResponseVO
        """
        return self._Items

    @Items.setter
    def Items(self, Items):
        self._Items = Items


    def _deserialize(self, params):
        self._Total = params.get("Total")
        if params.get("Items") is not None:
            self._Items = []
            for item in params.get("Items"):
                obj = DescribeModelServiceResponseVO()
                obj._deserialize(item)
                self._Items.append(obj)
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeModelServicesSort(AbstractModel):
    r"""查询模型服务列表的排序

    """

    def __init__(self):
        r"""
        :param _CreateTime: 创建时间
        :type CreateTime: int
        :param _LastUpdateTime: 最后修改时间
        :type LastUpdateTime: int
        :param _Name: 模型名称
        :type Name: int
        :param _Status: 状态
        :type Status: int
        """
        self._CreateTime = None
        self._LastUpdateTime = None
        self._Name = None
        self._Status = None

    @property
    def CreateTime(self):
        r"""创建时间
        :rtype: int
        """
        return self._CreateTime

    @CreateTime.setter
    def CreateTime(self, CreateTime):
        self._CreateTime = CreateTime

    @property
    def LastUpdateTime(self):
        r"""最后修改时间
        :rtype: int
        """
        return self._LastUpdateTime

    @LastUpdateTime.setter
    def LastUpdateTime(self, LastUpdateTime):
        self._LastUpdateTime = LastUpdateTime

    @property
    def Name(self):
        r"""模型名称
        :rtype: int
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def Status(self):
        r"""状态
        :rtype: int
        """
        return self._Status

    @Status.setter
    def Status(self, Status):
        self._Status = Status


    def _deserialize(self, params):
        self._CreateTime = params.get("CreateTime")
        self._LastUpdateTime = params.get("LastUpdateTime")
        self._Name = params.get("Name")
        self._Status = params.get("Status")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeModelsRequest(AbstractModel):
    r"""DescribeModels请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceID: 实例
        :type InstanceID: str
        :param _Offset: 分页参数
        :type Offset: int
        :param _Limit: 分页限制
        :type Limit: int
        :param _IDs: ID列表
        :type IDs: list of str
        :param _NotIDs: 排除的ID列表
        :type NotIDs: list of str
        :param _CredentialID: 凭据ID
        :type CredentialID: str
        :param _Keyword: 关键词
        :type Keyword: str
        :param _Sort: 排序
        :type Sort: :class:`tencentcloud.apis.v20240801.models.DescribeModelsSort`
        """
        self._InstanceID = None
        self._Offset = None
        self._Limit = None
        self._IDs = None
        self._NotIDs = None
        self._CredentialID = None
        self._Keyword = None
        self._Sort = None

    @property
    def InstanceID(self):
        r"""实例
        :rtype: str
        """
        return self._InstanceID

    @InstanceID.setter
    def InstanceID(self, InstanceID):
        self._InstanceID = InstanceID

    @property
    def Offset(self):
        r"""分页参数
        :rtype: int
        """
        return self._Offset

    @Offset.setter
    def Offset(self, Offset):
        self._Offset = Offset

    @property
    def Limit(self):
        r"""分页限制
        :rtype: int
        """
        return self._Limit

    @Limit.setter
    def Limit(self, Limit):
        self._Limit = Limit

    @property
    def IDs(self):
        r"""ID列表
        :rtype: list of str
        """
        return self._IDs

    @IDs.setter
    def IDs(self, IDs):
        self._IDs = IDs

    @property
    def NotIDs(self):
        r"""排除的ID列表
        :rtype: list of str
        """
        return self._NotIDs

    @NotIDs.setter
    def NotIDs(self, NotIDs):
        self._NotIDs = NotIDs

    @property
    def CredentialID(self):
        r"""凭据ID
        :rtype: str
        """
        return self._CredentialID

    @CredentialID.setter
    def CredentialID(self, CredentialID):
        self._CredentialID = CredentialID

    @property
    def Keyword(self):
        r"""关键词
        :rtype: str
        """
        return self._Keyword

    @Keyword.setter
    def Keyword(self, Keyword):
        self._Keyword = Keyword

    @property
    def Sort(self):
        r"""排序
        :rtype: :class:`tencentcloud.apis.v20240801.models.DescribeModelsSort`
        """
        return self._Sort

    @Sort.setter
    def Sort(self, Sort):
        self._Sort = Sort


    def _deserialize(self, params):
        self._InstanceID = params.get("InstanceID")
        self._Offset = params.get("Offset")
        self._Limit = params.get("Limit")
        self._IDs = params.get("IDs")
        self._NotIDs = params.get("NotIDs")
        self._CredentialID = params.get("CredentialID")
        self._Keyword = params.get("Keyword")
        if params.get("Sort") is not None:
            self._Sort = DescribeModelsSort()
            self._Sort._deserialize(params.get("Sort"))
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeModelsResponse(AbstractModel):
    r"""DescribeModels返回参数结构体

    """

    def __init__(self):
        r"""
        :param _Data: 结果集
        :type Data: :class:`tencentcloud.apis.v20240801.models.DescribeModelsResponseVO`
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._Data = None
        self._RequestId = None

    @property
    def Data(self):
        r"""结果集
        :rtype: :class:`tencentcloud.apis.v20240801.models.DescribeModelsResponseVO`
        """
        return self._Data

    @Data.setter
    def Data(self, Data):
        self._Data = Data

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("Data") is not None:
            self._Data = DescribeModelsResponseVO()
            self._Data._deserialize(params.get("Data"))
        self._RequestId = params.get("RequestId")


class DescribeModelsResponseVO(AbstractModel):
    r"""查询模型列表的响应

    """

    def __init__(self):
        r"""
        :param _Total: 条目
        :type Total: int
        :param _Items: 列表
        :type Items: list of DescribeModelResponseVO
        """
        self._Total = None
        self._Items = None

    @property
    def Total(self):
        r"""条目
        :rtype: int
        """
        return self._Total

    @Total.setter
    def Total(self, Total):
        self._Total = Total

    @property
    def Items(self):
        r"""列表
        :rtype: list of DescribeModelResponseVO
        """
        return self._Items

    @Items.setter
    def Items(self, Items):
        self._Items = Items


    def _deserialize(self, params):
        self._Total = params.get("Total")
        if params.get("Items") is not None:
            self._Items = []
            for item in params.get("Items"):
                obj = DescribeModelResponseVO()
                obj._deserialize(item)
                self._Items.append(obj)
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeModelsSort(AbstractModel):
    r"""DescribeModelsSort

    """

    def __init__(self):
        r"""
        :param _CreateTime: 创建时间
        :type CreateTime: int
        :param _LastUpdateTime: 最后修改时间
        :type LastUpdateTime: int
        :param _Name: 模型名称
        :type Name: int
        """
        self._CreateTime = None
        self._LastUpdateTime = None
        self._Name = None

    @property
    def CreateTime(self):
        r"""创建时间
        :rtype: int
        """
        return self._CreateTime

    @CreateTime.setter
    def CreateTime(self, CreateTime):
        self._CreateTime = CreateTime

    @property
    def LastUpdateTime(self):
        r"""最后修改时间
        :rtype: int
        """
        return self._LastUpdateTime

    @LastUpdateTime.setter
    def LastUpdateTime(self, LastUpdateTime):
        self._LastUpdateTime = LastUpdateTime

    @property
    def Name(self):
        r"""模型名称
        :rtype: int
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name


    def _deserialize(self, params):
        self._CreateTime = params.get("CreateTime")
        self._LastUpdateTime = params.get("LastUpdateTime")
        self._Name = params.get("Name")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeServiceRequest(AbstractModel):
    r"""DescribeService请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceID: <p>实例ID</p>
        :type InstanceID: str
        :param _ID: <p>业务ID</p>
        :type ID: str
        """
        self._InstanceID = None
        self._ID = None

    @property
    def InstanceID(self):
        r"""<p>实例ID</p>
        :rtype: str
        """
        return self._InstanceID

    @InstanceID.setter
    def InstanceID(self, InstanceID):
        self._InstanceID = InstanceID

    @property
    def ID(self):
        r"""<p>业务ID</p>
        :rtype: str
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID


    def _deserialize(self, params):
        self._InstanceID = params.get("InstanceID")
        self._ID = params.get("ID")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeServiceResponse(AbstractModel):
    r"""DescribeService返回参数结构体

    """

    def __init__(self):
        r"""
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._RequestId = None

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._RequestId = params.get("RequestId")


class DescribeServicesRequest(AbstractModel):
    r"""DescribeServices请求参数结构体

    """


class DescribeServicesResponse(AbstractModel):
    r"""DescribeServices返回参数结构体

    """

    def __init__(self):
        r"""
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._RequestId = None

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._RequestId = params.get("RequestId")


class FaultToleranceDTO(AbstractModel):
    r"""API Key容错策略配置

    """

    def __init__(self):
        r"""
        :param _Enabled: <p>是否启用API Key容错配置</p>
        :type Enabled: bool
        :param _ErrorCodes: <p>异常判定状态码，固定3位数字或字母</p>
        :type ErrorCodes: list of str
        :param _ErrorCount: <p>连续异常次数</p><p>单位：次</p>
        :type ErrorCount: int
        :param _IsolationTime: <p>隔离时长</p><p>单位：秒</p>
        :type IsolationTime: int
        :param _MaxSwitchCount: <p>最多切换次数</p><p>置0为不开启自动切换</p>
        :type MaxSwitchCount: int
        :param _SwitchTimeout: <p>切换总时间预算</p><p>单位：秒</p>
        :type SwitchTimeout: int
        """
        self._Enabled = None
        self._ErrorCodes = None
        self._ErrorCount = None
        self._IsolationTime = None
        self._MaxSwitchCount = None
        self._SwitchTimeout = None

    @property
    def Enabled(self):
        r"""<p>是否启用API Key容错配置</p>
        :rtype: bool
        """
        return self._Enabled

    @Enabled.setter
    def Enabled(self, Enabled):
        self._Enabled = Enabled

    @property
    def ErrorCodes(self):
        r"""<p>异常判定状态码，固定3位数字或字母</p>
        :rtype: list of str
        """
        return self._ErrorCodes

    @ErrorCodes.setter
    def ErrorCodes(self, ErrorCodes):
        self._ErrorCodes = ErrorCodes

    @property
    def ErrorCount(self):
        r"""<p>连续异常次数</p><p>单位：次</p>
        :rtype: int
        """
        return self._ErrorCount

    @ErrorCount.setter
    def ErrorCount(self, ErrorCount):
        self._ErrorCount = ErrorCount

    @property
    def IsolationTime(self):
        r"""<p>隔离时长</p><p>单位：秒</p>
        :rtype: int
        """
        return self._IsolationTime

    @IsolationTime.setter
    def IsolationTime(self, IsolationTime):
        self._IsolationTime = IsolationTime

    @property
    def MaxSwitchCount(self):
        r"""<p>最多切换次数</p><p>置0为不开启自动切换</p>
        :rtype: int
        """
        return self._MaxSwitchCount

    @MaxSwitchCount.setter
    def MaxSwitchCount(self, MaxSwitchCount):
        self._MaxSwitchCount = MaxSwitchCount

    @property
    def SwitchTimeout(self):
        r"""<p>切换总时间预算</p><p>单位：秒</p>
        :rtype: int
        """
        return self._SwitchTimeout

    @SwitchTimeout.setter
    def SwitchTimeout(self, SwitchTimeout):
        self._SwitchTimeout = SwitchTimeout


    def _deserialize(self, params):
        self._Enabled = params.get("Enabled")
        self._ErrorCodes = params.get("ErrorCodes")
        self._ErrorCount = params.get("ErrorCount")
        self._IsolationTime = params.get("IsolationTime")
        self._MaxSwitchCount = params.get("MaxSwitchCount")
        self._SwitchTimeout = params.get("SwitchTimeout")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class FieldValueDTO(AbstractModel):
    r"""FieldValue结构体

    """

    def __init__(self):
        r"""
        :param _Field: <p>属性</p>
        :type Field: str
        :param _Value: <p>值</p>
        :type Value: str
        """
        self._Field = None
        self._Value = None

    @property
    def Field(self):
        r"""<p>属性</p>
        :rtype: str
        """
        return self._Field

    @Field.setter
    def Field(self, Field):
        self._Field = Field

    @property
    def Value(self):
        r"""<p>值</p>
        :rtype: str
        """
        return self._Value

    @Value.setter
    def Value(self, Value):
        self._Value = Value


    def _deserialize(self, params):
        self._Field = params.get("Field")
        self._Value = params.get("Value")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class HealthCheckConfigDTO(AbstractModel):
    r"""HealthCheckConfigDTO

    """

    def __init__(self):
        r"""
        :param _HealthCheckPath: 健康检查路径
注意：此字段可能返回 null，表示取不到有效值。
        :type HealthCheckPath: str
        :param _ValidHealthCheckStatusCode: 状态码
注意：此字段可能返回 null，表示取不到有效值。
        :type ValidHealthCheckStatusCode: list of int
        :param _HealthCheckTimeout: 请求的超时时间
注意：此字段可能返回 null，表示取不到有效值。
        :type HealthCheckTimeout: int
        """
        self._HealthCheckPath = None
        self._ValidHealthCheckStatusCode = None
        self._HealthCheckTimeout = None

    @property
    def HealthCheckPath(self):
        r"""健康检查路径
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._HealthCheckPath

    @HealthCheckPath.setter
    def HealthCheckPath(self, HealthCheckPath):
        self._HealthCheckPath = HealthCheckPath

    @property
    def ValidHealthCheckStatusCode(self):
        r"""状态码
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of int
        """
        return self._ValidHealthCheckStatusCode

    @ValidHealthCheckStatusCode.setter
    def ValidHealthCheckStatusCode(self, ValidHealthCheckStatusCode):
        self._ValidHealthCheckStatusCode = ValidHealthCheckStatusCode

    @property
    def HealthCheckTimeout(self):
        r"""请求的超时时间
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: int
        """
        return self._HealthCheckTimeout

    @HealthCheckTimeout.setter
    def HealthCheckTimeout(self, HealthCheckTimeout):
        self._HealthCheckTimeout = HealthCheckTimeout


    def _deserialize(self, params):
        self._HealthCheckPath = params.get("HealthCheckPath")
        self._ValidHealthCheckStatusCode = params.get("ValidHealthCheckStatusCode")
        self._HealthCheckTimeout = params.get("HealthCheckTimeout")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class IDNameVO(AbstractModel):
    r"""IDNameVO

    """

    def __init__(self):
        r"""
        :param _ID: 业务ID
注意：此字段可能返回 null，表示取不到有效值。
        :type ID: str
        :param _Name: 名称
注意：此字段可能返回 null，表示取不到有效值。
        :type Name: str
        """
        self._ID = None
        self._Name = None

    @property
    def ID(self):
        r"""业务ID
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID

    @property
    def Name(self):
        r"""名称
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name


    def _deserialize(self, params):
        self._ID = params.get("ID")
        self._Name = params.get("Name")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class InvokeLimitConfigDTO(AbstractModel):
    r"""InvokeLimitConfigDTO

    """

    def __init__(self):
        r"""
        :param _Type: Type类型
注意：此字段可能返回 null，表示取不到有效值。
        :type Type: str
        :param _TokenBucketMaxNum: 令牌桶最大容量

注意：此字段可能返回 null，表示取不到有效值。
        :type TokenBucketMaxNum: int
        :param _TokenBucketRate: 令牌生成速率
注意：此字段可能返回 null，表示取不到有效值。
        :type TokenBucketRate: int
        :param _FunnelMaxNum: 漏斗容量
注意：此字段可能返回 null，表示取不到有效值。
        :type FunnelMaxNum: int
        :param _FunnelRate: 漏嘴流速
注意：此字段可能返回 null，表示取不到有效值。
        :type FunnelRate: int
        :param _SlidingWindowMaxNum: 滑动窗口最大请求数
注意：此字段可能返回 null，表示取不到有效值。
        :type SlidingWindowMaxNum: int
        :param _SlidingWindowSize: 滑动窗口长度
注意：此字段可能返回 null，表示取不到有效值。
        :type SlidingWindowSize: int
        :param _TimeWindow: 时间窗口最大请求数
注意：此字段可能返回 null，表示取不到有效值。
        :type TimeWindow: int
        :param _TimeWindowInterval: 时间窗口长度
注意：此字段可能返回 null，表示取不到有效值。
        :type TimeWindowInterval: int
        :param _Timeout: 请求的超时时间
注意：此字段可能返回 null，表示取不到有效值。
        :type Timeout: int
        """
        self._Type = None
        self._TokenBucketMaxNum = None
        self._TokenBucketRate = None
        self._FunnelMaxNum = None
        self._FunnelRate = None
        self._SlidingWindowMaxNum = None
        self._SlidingWindowSize = None
        self._TimeWindow = None
        self._TimeWindowInterval = None
        self._Timeout = None

    @property
    def Type(self):
        r"""Type类型
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._Type

    @Type.setter
    def Type(self, Type):
        self._Type = Type

    @property
    def TokenBucketMaxNum(self):
        r"""令牌桶最大容量

注意：此字段可能返回 null，表示取不到有效值。
        :rtype: int
        """
        return self._TokenBucketMaxNum

    @TokenBucketMaxNum.setter
    def TokenBucketMaxNum(self, TokenBucketMaxNum):
        self._TokenBucketMaxNum = TokenBucketMaxNum

    @property
    def TokenBucketRate(self):
        r"""令牌生成速率
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: int
        """
        return self._TokenBucketRate

    @TokenBucketRate.setter
    def TokenBucketRate(self, TokenBucketRate):
        self._TokenBucketRate = TokenBucketRate

    @property
    def FunnelMaxNum(self):
        r"""漏斗容量
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: int
        """
        return self._FunnelMaxNum

    @FunnelMaxNum.setter
    def FunnelMaxNum(self, FunnelMaxNum):
        self._FunnelMaxNum = FunnelMaxNum

    @property
    def FunnelRate(self):
        r"""漏嘴流速
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: int
        """
        return self._FunnelRate

    @FunnelRate.setter
    def FunnelRate(self, FunnelRate):
        self._FunnelRate = FunnelRate

    @property
    def SlidingWindowMaxNum(self):
        r"""滑动窗口最大请求数
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: int
        """
        return self._SlidingWindowMaxNum

    @SlidingWindowMaxNum.setter
    def SlidingWindowMaxNum(self, SlidingWindowMaxNum):
        self._SlidingWindowMaxNum = SlidingWindowMaxNum

    @property
    def SlidingWindowSize(self):
        r"""滑动窗口长度
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: int
        """
        return self._SlidingWindowSize

    @SlidingWindowSize.setter
    def SlidingWindowSize(self, SlidingWindowSize):
        self._SlidingWindowSize = SlidingWindowSize

    @property
    def TimeWindow(self):
        r"""时间窗口最大请求数
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: int
        """
        return self._TimeWindow

    @TimeWindow.setter
    def TimeWindow(self, TimeWindow):
        self._TimeWindow = TimeWindow

    @property
    def TimeWindowInterval(self):
        r"""时间窗口长度
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: int
        """
        return self._TimeWindowInterval

    @TimeWindowInterval.setter
    def TimeWindowInterval(self, TimeWindowInterval):
        self._TimeWindowInterval = TimeWindowInterval

    @property
    def Timeout(self):
        r"""请求的超时时间
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: int
        """
        return self._Timeout

    @Timeout.setter
    def Timeout(self, Timeout):
        self._Timeout = Timeout


    def _deserialize(self, params):
        self._Type = params.get("Type")
        self._TokenBucketMaxNum = params.get("TokenBucketMaxNum")
        self._TokenBucketRate = params.get("TokenBucketRate")
        self._FunnelMaxNum = params.get("FunnelMaxNum")
        self._FunnelRate = params.get("FunnelRate")
        self._SlidingWindowMaxNum = params.get("SlidingWindowMaxNum")
        self._SlidingWindowSize = params.get("SlidingWindowSize")
        self._TimeWindow = params.get("TimeWindow")
        self._TimeWindowInterval = params.get("TimeWindowInterval")
        self._Timeout = params.get("Timeout")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class IpConfig(AbstractModel):
    r"""ip黑白名单配置

    """

    def __init__(self):
        r"""
        :param _Ips: ip数组
注意：此字段可能返回 null，表示取不到有效值。
        :type Ips: list of str
        :param _EffectType: 生效类型
注意：此字段可能返回 null，表示取不到有效值。
        :type EffectType: str
        :param _EffectTimes: 生效时间
注意：此字段可能返回 null，表示取不到有效值。
        :type EffectTimes: list of StartEndTime
        :param _Comment: 备注
注意：此字段可能返回 null，表示取不到有效值。
        :type Comment: str
        """
        self._Ips = None
        self._EffectType = None
        self._EffectTimes = None
        self._Comment = None

    @property
    def Ips(self):
        r"""ip数组
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of str
        """
        return self._Ips

    @Ips.setter
    def Ips(self, Ips):
        self._Ips = Ips

    @property
    def EffectType(self):
        r"""生效类型
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._EffectType

    @EffectType.setter
    def EffectType(self, EffectType):
        self._EffectType = EffectType

    @property
    def EffectTimes(self):
        r"""生效时间
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of StartEndTime
        """
        return self._EffectTimes

    @EffectTimes.setter
    def EffectTimes(self, EffectTimes):
        self._EffectTimes = EffectTimes

    @property
    def Comment(self):
        r"""备注
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._Comment

    @Comment.setter
    def Comment(self, Comment):
        self._Comment = Comment


    def _deserialize(self, params):
        self._Ips = params.get("Ips")
        self._EffectType = params.get("EffectType")
        if params.get("EffectTimes") is not None:
            self._EffectTimes = []
            for item in params.get("EffectTimes"):
                obj = StartEndTime()
                obj._deserialize(item)
                self._EffectTimes.append(obj)
        self._Comment = params.get("Comment")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class LimitWindowsDTO(AbstractModel):
    r"""限流窗口配置

    """

    def __init__(self):
        r"""
        :param _Interval: <p>时间窗口，分钟</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type Interval: int
        :param _Limit: <p>累计上限，k</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type Limit: int
        :param _Type: <p>限流类型</p><p>枚举值：</p><ul><li>minute： 时间窗口</li><li>day： 自然日</li><li>month： 自然月</li><li>timeRange： 时间范围</li></ul>
注意：此字段可能返回 null，表示取不到有效值。
        :type Type: str
        :param _TimeRange: <p>时间区间配置</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type TimeRange: :class:`tencentcloud.apis.v20240801.models.TimeRange`
        """
        self._Interval = None
        self._Limit = None
        self._Type = None
        self._TimeRange = None

    @property
    def Interval(self):
        r"""<p>时间窗口，分钟</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: int
        """
        return self._Interval

    @Interval.setter
    def Interval(self, Interval):
        self._Interval = Interval

    @property
    def Limit(self):
        r"""<p>累计上限，k</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: int
        """
        return self._Limit

    @Limit.setter
    def Limit(self, Limit):
        self._Limit = Limit

    @property
    def Type(self):
        r"""<p>限流类型</p><p>枚举值：</p><ul><li>minute： 时间窗口</li><li>day： 自然日</li><li>month： 自然月</li><li>timeRange： 时间范围</li></ul>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._Type

    @Type.setter
    def Type(self, Type):
        self._Type = Type

    @property
    def TimeRange(self):
        r"""<p>时间区间配置</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: :class:`tencentcloud.apis.v20240801.models.TimeRange`
        """
        return self._TimeRange

    @TimeRange.setter
    def TimeRange(self, TimeRange):
        self._TimeRange = TimeRange


    def _deserialize(self, params):
        self._Interval = params.get("Interval")
        self._Limit = params.get("Limit")
        self._Type = params.get("Type")
        if params.get("TimeRange") is not None:
            self._TimeRange = TimeRange()
            self._TimeRange._deserialize(params.get("TimeRange"))
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class McpInputOutSchema(AbstractModel):
    r"""出入参说明

    """

    def __init__(self):
        r"""
        :param _Type: 类型
注意：此字段可能返回 null，表示取不到有效值。
        :type Type: str
        :param _Properties: 属性
注意：此字段可能返回 null，表示取不到有效值。
        :type Properties: str
        :param _Required: 必填字段
注意：此字段可能返回 null，表示取不到有效值。
        :type Required: list of str
        :param _Description: 描述
注意：此字段可能返回 null，表示取不到有效值。
        :type Description: str
        """
        self._Type = None
        self._Properties = None
        self._Required = None
        self._Description = None

    @property
    def Type(self):
        r"""类型
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._Type

    @Type.setter
    def Type(self, Type):
        self._Type = Type

    @property
    def Properties(self):
        r"""属性
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._Properties

    @Properties.setter
    def Properties(self, Properties):
        self._Properties = Properties

    @property
    def Required(self):
        r"""必填字段
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of str
        """
        return self._Required

    @Required.setter
    def Required(self, Required):
        self._Required = Required

    @property
    def Description(self):
        r"""描述
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._Description

    @Description.setter
    def Description(self, Description):
        self._Description = Description


    def _deserialize(self, params):
        self._Type = params.get("Type")
        self._Properties = params.get("Properties")
        self._Required = params.get("Required")
        self._Description = params.get("Description")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class McpSecurityRule(AbstractModel):
    r"""mcp安全规则

    """

    def __init__(self):
        r"""
        :param _ID: 规则ID
        :type ID: str
        :param _Status: 状态
        :type Status: str
        :param _Act: 处置动作
        :type Act: str
        """
        self._ID = None
        self._Status = None
        self._Act = None

    @property
    def ID(self):
        r"""规则ID
        :rtype: str
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID

    @property
    def Status(self):
        r"""状态
        :rtype: str
        """
        return self._Status

    @Status.setter
    def Status(self, Status):
        self._Status = Status

    @property
    def Act(self):
        r"""处置动作
        :rtype: str
        """
        return self._Act

    @Act.setter
    def Act(self, Act):
        self._Act = Act


    def _deserialize(self, params):
        self._ID = params.get("ID")
        self._Status = params.get("Status")
        self._Act = params.get("Act")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class McpSecurityRulesVO(AbstractModel):
    r"""绑定的安全规则列表

    """

    def __init__(self):
        r"""
        :param _ID: 规则ID
        :type ID: str
        :param _Type: 规则类型
        :type Type: str
        :param _Name: 规则名称
        :type Name: str
        :param _Description: 规则描述
        :type Description: str
        :param _RiskLevel: 风险等级
        :type RiskLevel: str
        :param _VersionNumber: 版本号
        :type VersionNumber: str
        :param _Status: 状态开关
        :type Status: str
        :param _Act: 当前选择的处置动作
        :type Act: str
        :param _SupportActs: 支持的处置动作
        :type SupportActs: list of str
        :param _BodyType: 内容类型
        :type BodyType: str
        :param _IconType: icon类型
        :type IconType: str
        """
        self._ID = None
        self._Type = None
        self._Name = None
        self._Description = None
        self._RiskLevel = None
        self._VersionNumber = None
        self._Status = None
        self._Act = None
        self._SupportActs = None
        self._BodyType = None
        self._IconType = None

    @property
    def ID(self):
        r"""规则ID
        :rtype: str
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID

    @property
    def Type(self):
        r"""规则类型
        :rtype: str
        """
        return self._Type

    @Type.setter
    def Type(self, Type):
        self._Type = Type

    @property
    def Name(self):
        r"""规则名称
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def Description(self):
        r"""规则描述
        :rtype: str
        """
        return self._Description

    @Description.setter
    def Description(self, Description):
        self._Description = Description

    @property
    def RiskLevel(self):
        r"""风险等级
        :rtype: str
        """
        return self._RiskLevel

    @RiskLevel.setter
    def RiskLevel(self, RiskLevel):
        self._RiskLevel = RiskLevel

    @property
    def VersionNumber(self):
        r"""版本号
        :rtype: str
        """
        return self._VersionNumber

    @VersionNumber.setter
    def VersionNumber(self, VersionNumber):
        self._VersionNumber = VersionNumber

    @property
    def Status(self):
        r"""状态开关
        :rtype: str
        """
        return self._Status

    @Status.setter
    def Status(self, Status):
        self._Status = Status

    @property
    def Act(self):
        r"""当前选择的处置动作
        :rtype: str
        """
        return self._Act

    @Act.setter
    def Act(self, Act):
        self._Act = Act

    @property
    def SupportActs(self):
        r"""支持的处置动作
        :rtype: list of str
        """
        return self._SupportActs

    @SupportActs.setter
    def SupportActs(self, SupportActs):
        self._SupportActs = SupportActs

    @property
    def BodyType(self):
        r"""内容类型
        :rtype: str
        """
        return self._BodyType

    @BodyType.setter
    def BodyType(self, BodyType):
        self._BodyType = BodyType

    @property
    def IconType(self):
        r"""icon类型
        :rtype: str
        """
        return self._IconType

    @IconType.setter
    def IconType(self, IconType):
        self._IconType = IconType


    def _deserialize(self, params):
        self._ID = params.get("ID")
        self._Type = params.get("Type")
        self._Name = params.get("Name")
        self._Description = params.get("Description")
        self._RiskLevel = params.get("RiskLevel")
        self._VersionNumber = params.get("VersionNumber")
        self._Status = params.get("Status")
        self._Act = params.get("Act")
        self._SupportActs = params.get("SupportActs")
        self._BodyType = params.get("BodyType")
        self._IconType = params.get("IconType")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class McpTool(AbstractModel):
    r"""mcp工具

    """

    def __init__(self):
        r"""
        :param _Name: 名称
注意：此字段可能返回 null，表示取不到有效值。
        :type Name: str
        :param _Description: 描述
注意：此字段可能返回 null，表示取不到有效值。
        :type Description: str
        :param _InputSchema: 入参参数
注意：此字段可能返回 null，表示取不到有效值。
        :type InputSchema: :class:`tencentcloud.apis.v20240801.models.McpInputOutSchema`
        :param _Annotations: 注释
注意：此字段可能返回 null，表示取不到有效值。
        :type Annotations: :class:`tencentcloud.apis.v20240801.models.McpToolAnnotation`
        :param _OutputSchema: 出参参数
注意：此字段可能返回 null，表示取不到有效值。
        :type OutputSchema: :class:`tencentcloud.apis.v20240801.models.McpInputOutSchema`
        """
        self._Name = None
        self._Description = None
        self._InputSchema = None
        self._Annotations = None
        self._OutputSchema = None

    @property
    def Name(self):
        r"""名称
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def Description(self):
        r"""描述
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._Description

    @Description.setter
    def Description(self, Description):
        self._Description = Description

    @property
    def InputSchema(self):
        r"""入参参数
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: :class:`tencentcloud.apis.v20240801.models.McpInputOutSchema`
        """
        return self._InputSchema

    @InputSchema.setter
    def InputSchema(self, InputSchema):
        self._InputSchema = InputSchema

    @property
    def Annotations(self):
        r"""注释
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: :class:`tencentcloud.apis.v20240801.models.McpToolAnnotation`
        """
        return self._Annotations

    @Annotations.setter
    def Annotations(self, Annotations):
        self._Annotations = Annotations

    @property
    def OutputSchema(self):
        r"""出参参数
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: :class:`tencentcloud.apis.v20240801.models.McpInputOutSchema`
        """
        return self._OutputSchema

    @OutputSchema.setter
    def OutputSchema(self, OutputSchema):
        self._OutputSchema = OutputSchema


    def _deserialize(self, params):
        self._Name = params.get("Name")
        self._Description = params.get("Description")
        if params.get("InputSchema") is not None:
            self._InputSchema = McpInputOutSchema()
            self._InputSchema._deserialize(params.get("InputSchema"))
        if params.get("Annotations") is not None:
            self._Annotations = McpToolAnnotation()
            self._Annotations._deserialize(params.get("Annotations"))
        if params.get("OutputSchema") is not None:
            self._OutputSchema = McpInputOutSchema()
            self._OutputSchema._deserialize(params.get("OutputSchema"))
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class McpToolAnnotation(AbstractModel):
    r"""mcp工具注解

    """

    def __init__(self):
        r"""
        :param _Title: title for the tool
注意：此字段可能返回 null，表示取不到有效值。
        :type Title: str
        :param _ReadOnlyHint: If true, the tool does not modify its environment
注意：此字段可能返回 null，表示取不到有效值。
        :type ReadOnlyHint: bool
        :param _DestructiveHint: If true, the tool may perform destructive updates
注意：此字段可能返回 null，表示取不到有效值。
        :type DestructiveHint: bool
        :param _IdempotentHint: If true, repeated calls with same args have no additional effect
注意：此字段可能返回 null，表示取不到有效值。
        :type IdempotentHint: bool
        :param _OpenWorldHint: If true, tool interacts with external entities
注意：此字段可能返回 null，表示取不到有效值。
        :type OpenWorldHint: bool
        """
        self._Title = None
        self._ReadOnlyHint = None
        self._DestructiveHint = None
        self._IdempotentHint = None
        self._OpenWorldHint = None

    @property
    def Title(self):
        r"""title for the tool
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._Title

    @Title.setter
    def Title(self, Title):
        self._Title = Title

    @property
    def ReadOnlyHint(self):
        r"""If true, the tool does not modify its environment
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: bool
        """
        return self._ReadOnlyHint

    @ReadOnlyHint.setter
    def ReadOnlyHint(self, ReadOnlyHint):
        self._ReadOnlyHint = ReadOnlyHint

    @property
    def DestructiveHint(self):
        r"""If true, the tool may perform destructive updates
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: bool
        """
        return self._DestructiveHint

    @DestructiveHint.setter
    def DestructiveHint(self, DestructiveHint):
        self._DestructiveHint = DestructiveHint

    @property
    def IdempotentHint(self):
        r"""If true, repeated calls with same args have no additional effect
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: bool
        """
        return self._IdempotentHint

    @IdempotentHint.setter
    def IdempotentHint(self, IdempotentHint):
        self._IdempotentHint = IdempotentHint

    @property
    def OpenWorldHint(self):
        r"""If true, tool interacts with external entities
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: bool
        """
        return self._OpenWorldHint

    @OpenWorldHint.setter
    def OpenWorldHint(self, OpenWorldHint):
        self._OpenWorldHint = OpenWorldHint


    def _deserialize(self, params):
        self._Title = params.get("Title")
        self._ReadOnlyHint = params.get("ReadOnlyHint")
        self._DestructiveHint = params.get("DestructiveHint")
        self._IdempotentHint = params.get("IdempotentHint")
        self._OpenWorldHint = params.get("OpenWorldHint")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class McpUrlObj(AbstractModel):
    r"""Mcp的访问URL

    """

    def __init__(self):
        r"""
        :param _SSEUrl: sse访问URL
        :type SSEUrl: str
        :param _StreamAbleUrl: streamable访问URL
        :type StreamAbleUrl: str
        """
        self._SSEUrl = None
        self._StreamAbleUrl = None

    @property
    def SSEUrl(self):
        r"""sse访问URL
        :rtype: str
        """
        return self._SSEUrl

    @SSEUrl.setter
    def SSEUrl(self, SSEUrl):
        self._SSEUrl = SSEUrl

    @property
    def StreamAbleUrl(self):
        r"""streamable访问URL
        :rtype: str
        """
        return self._StreamAbleUrl

    @StreamAbleUrl.setter
    def StreamAbleUrl(self, StreamAbleUrl):
        self._StreamAbleUrl = StreamAbleUrl


    def _deserialize(self, params):
        self._SSEUrl = params.get("SSEUrl")
        self._StreamAbleUrl = params.get("StreamAbleUrl")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ModifyAgentAppModelServicesRequest(AbstractModel):
    r"""ModifyAgentAppModelServices请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceID: 实例ID
        :type InstanceID: str
        :param _ID: 应用ID
        :type ID: str
        :param _ModelServices: 关联的model service
        :type ModelServices: list of AgentAppModelServiceDTO
        """
        self._InstanceID = None
        self._ID = None
        self._ModelServices = None

    @property
    def InstanceID(self):
        r"""实例ID
        :rtype: str
        """
        return self._InstanceID

    @InstanceID.setter
    def InstanceID(self, InstanceID):
        self._InstanceID = InstanceID

    @property
    def ID(self):
        r"""应用ID
        :rtype: str
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID

    @property
    def ModelServices(self):
        r"""关联的model service
        :rtype: list of AgentAppModelServiceDTO
        """
        return self._ModelServices

    @ModelServices.setter
    def ModelServices(self, ModelServices):
        self._ModelServices = ModelServices


    def _deserialize(self, params):
        self._InstanceID = params.get("InstanceID")
        self._ID = params.get("ID")
        if params.get("ModelServices") is not None:
            self._ModelServices = []
            for item in params.get("ModelServices"):
                obj = AgentAppModelServiceDTO()
                obj._deserialize(item)
                self._ModelServices.append(obj)
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ModifyAgentAppModelServicesResponse(AbstractModel):
    r"""ModifyAgentAppModelServices返回参数结构体

    """

    def __init__(self):
        r"""
        :param _Data: app id
        :type Data: :class:`tencentcloud.apis.v20240801.models.ResultIDVO`
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._Data = None
        self._RequestId = None

    @property
    def Data(self):
        r"""app id
        :rtype: :class:`tencentcloud.apis.v20240801.models.ResultIDVO`
        """
        return self._Data

    @Data.setter
    def Data(self, Data):
        self._Data = Data

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("Data") is not None:
            self._Data = ResultIDVO()
            self._Data._deserialize(params.get("Data"))
        self._RequestId = params.get("RequestId")


class ModifyAgentAppRequest(AbstractModel):
    r"""ModifyAgentApp请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceID: <p>实例ID</p>
        :type InstanceID: str
        :param _ID: <p>应用ID</p>
        :type ID: str
        :param _Name: <p>名称</p>
        :type Name: str
        :param _OAuth2ResourceServerID: <p>OAuth2资源服务器ID</p>
        :type OAuth2ResourceServerID: str
        :param _Description: <p>描述</p>
        :type Description: str
        :param _ConnectorIDs: <p>凭据ID</p>
        :type ConnectorIDs: list of str
        """
        self._InstanceID = None
        self._ID = None
        self._Name = None
        self._OAuth2ResourceServerID = None
        self._Description = None
        self._ConnectorIDs = None

    @property
    def InstanceID(self):
        r"""<p>实例ID</p>
        :rtype: str
        """
        return self._InstanceID

    @InstanceID.setter
    def InstanceID(self, InstanceID):
        self._InstanceID = InstanceID

    @property
    def ID(self):
        r"""<p>应用ID</p>
        :rtype: str
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID

    @property
    def Name(self):
        r"""<p>名称</p>
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def OAuth2ResourceServerID(self):
        r"""<p>OAuth2资源服务器ID</p>
        :rtype: str
        """
        return self._OAuth2ResourceServerID

    @OAuth2ResourceServerID.setter
    def OAuth2ResourceServerID(self, OAuth2ResourceServerID):
        self._OAuth2ResourceServerID = OAuth2ResourceServerID

    @property
    def Description(self):
        r"""<p>描述</p>
        :rtype: str
        """
        return self._Description

    @Description.setter
    def Description(self, Description):
        self._Description = Description

    @property
    def ConnectorIDs(self):
        r"""<p>凭据ID</p>
        :rtype: list of str
        """
        return self._ConnectorIDs

    @ConnectorIDs.setter
    def ConnectorIDs(self, ConnectorIDs):
        self._ConnectorIDs = ConnectorIDs


    def _deserialize(self, params):
        self._InstanceID = params.get("InstanceID")
        self._ID = params.get("ID")
        self._Name = params.get("Name")
        self._OAuth2ResourceServerID = params.get("OAuth2ResourceServerID")
        self._Description = params.get("Description")
        self._ConnectorIDs = params.get("ConnectorIDs")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ModifyAgentAppResponse(AbstractModel):
    r"""ModifyAgentApp返回参数结构体

    """

    def __init__(self):
        r"""
        :param _Data: <p>app id</p>
        :type Data: :class:`tencentcloud.apis.v20240801.models.ResultIDVO`
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._Data = None
        self._RequestId = None

    @property
    def Data(self):
        r"""<p>app id</p>
        :rtype: :class:`tencentcloud.apis.v20240801.models.ResultIDVO`
        """
        return self._Data

    @Data.setter
    def Data(self, Data):
        self._Data = Data

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("Data") is not None:
            self._Data = ResultIDVO()
            self._Data._deserialize(params.get("Data"))
        self._RequestId = params.get("RequestId")


class ModifyAgentCredentialRequest(AbstractModel):
    r"""ModifyAgentCredential请求参数结构体

    """


class ModifyAgentCredentialResponse(AbstractModel):
    r"""ModifyAgentCredential返回参数结构体

    """

    def __init__(self):
        r"""
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._RequestId = None

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._RequestId = params.get("RequestId")


class ModifyMcpServerRequest(AbstractModel):
    r"""ModifyMcpServer请求参数结构体

    """

    def __init__(self):
        r"""
        :param _ID: <p>mcp server ID</p>
        :type ID: str
        :param _Mode: <p>模式：proxy代理模式； wrap封装模式；</p>
        :type Mode: str
        :param _McpVersion: <p>版本号：2024-11-05 2025-03-26</p>
        :type McpVersion: str
        :param _InstanceID: <p>实例ID</p>
        :type InstanceID: str
        :param _Name: <p>名称</p>
        :type Name: str
        :param _Description: <p>描述</p>
        :type Description: str
        :param _WrapServices: <p>封装服务列表</p>
        :type WrapServices: list of str
        :param _TargetSelect: <p>负载方式，robin random consistentHash</p>
        :type TargetSelect: str
        :param _TargetHosts: <p>目标服务器</p>
        :type TargetHosts: list of TargetHostDTO
        :param _HttpProtocolType: <p>后端协议：http https</p>
        :type HttpProtocolType: str
        :param _CheckTargetCertsError: <p>证书检查</p>
        :type CheckTargetCertsError: bool
        :param _TargetPath: <p>目标路径</p>
        :type TargetPath: str
        :param _InvokeLimitConfigStatus: <p>流量控制开启状态</p>
        :type InvokeLimitConfigStatus: bool
        :param _InvokeLimitConfig: <p>流量控制配置</p>
        :type InvokeLimitConfig: :class:`tencentcloud.apis.v20240801.models.InvokeLimitConfigDTO`
        :param _IpWhiteStatus: <p>IP白名单开启状态</p>
        :type IpWhiteStatus: bool
        :param _IpWhiteConfig: <p>IP白名单配置</p>
        :type IpWhiteConfig: :class:`tencentcloud.apis.v20240801.models.IpConfig`
        :param _IpBlackStatus: <p>IP黑名单开启状态</p>
        :type IpBlackStatus: bool
        :param _IpBlackConfig: <p>IP黑名单配置</p>
        :type IpBlackConfig: :class:`tencentcloud.apis.v20240801.models.IpConfig`
        :param _TargetHostType: <p>目标Host类型 0 默认 1 vpc</p>
        :type TargetHostType: int
        :param _CustomHttpHost: <p>自定义host</p>
        :type CustomHttpHost: str
        :param _HttpHostType: <p>Http 请求host类型：useRequestHost 保持源请求；host targetHost 修正为源站host； customHost 自定义host</p>
        :type HttpHostType: str
        :param _Timeout: <p>请求的超时时间</p>
        :type Timeout: int
        :param _McpSecurityRules: <p>安全规则集</p>
        :type McpSecurityRules: list of McpSecurityRule
        :param _ToolConfigs: <p>工具集配置（openapi可能会用到）</p>
        :type ToolConfigs: list of ToolConfigDTO
        :param _WrapPaasID: <p>封装的API分组ID</p>
        :type WrapPaasID: str
        :param _PluginConfigs: <p>插件配置</p>
        :type PluginConfigs: list of PluginConfigDTO
        :param _IgnoreHealthCheck: <p>是否忽略健康检查</p>
        :type IgnoreHealthCheck: bool
        :param _CredentialID: <p>凭据ID</p>
        :type CredentialID: str
        :param _Domain: <p>访问域名</p>
        :type Domain: str
        :param _RequestProtocolType: <p>访问协议</p><p>枚举值：</p><ul><li>http： http</li><li>https： https</li></ul>
        :type RequestProtocolType: str
        """
        self._ID = None
        self._Mode = None
        self._McpVersion = None
        self._InstanceID = None
        self._Name = None
        self._Description = None
        self._WrapServices = None
        self._TargetSelect = None
        self._TargetHosts = None
        self._HttpProtocolType = None
        self._CheckTargetCertsError = None
        self._TargetPath = None
        self._InvokeLimitConfigStatus = None
        self._InvokeLimitConfig = None
        self._IpWhiteStatus = None
        self._IpWhiteConfig = None
        self._IpBlackStatus = None
        self._IpBlackConfig = None
        self._TargetHostType = None
        self._CustomHttpHost = None
        self._HttpHostType = None
        self._Timeout = None
        self._McpSecurityRules = None
        self._ToolConfigs = None
        self._WrapPaasID = None
        self._PluginConfigs = None
        self._IgnoreHealthCheck = None
        self._CredentialID = None
        self._Domain = None
        self._RequestProtocolType = None

    @property
    def ID(self):
        r"""<p>mcp server ID</p>
        :rtype: str
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID

    @property
    def Mode(self):
        r"""<p>模式：proxy代理模式； wrap封装模式；</p>
        :rtype: str
        """
        return self._Mode

    @Mode.setter
    def Mode(self, Mode):
        self._Mode = Mode

    @property
    def McpVersion(self):
        r"""<p>版本号：2024-11-05 2025-03-26</p>
        :rtype: str
        """
        return self._McpVersion

    @McpVersion.setter
    def McpVersion(self, McpVersion):
        self._McpVersion = McpVersion

    @property
    def InstanceID(self):
        r"""<p>实例ID</p>
        :rtype: str
        """
        return self._InstanceID

    @InstanceID.setter
    def InstanceID(self, InstanceID):
        self._InstanceID = InstanceID

    @property
    def Name(self):
        r"""<p>名称</p>
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def Description(self):
        r"""<p>描述</p>
        :rtype: str
        """
        return self._Description

    @Description.setter
    def Description(self, Description):
        self._Description = Description

    @property
    def WrapServices(self):
        r"""<p>封装服务列表</p>
        :rtype: list of str
        """
        return self._WrapServices

    @WrapServices.setter
    def WrapServices(self, WrapServices):
        self._WrapServices = WrapServices

    @property
    def TargetSelect(self):
        r"""<p>负载方式，robin random consistentHash</p>
        :rtype: str
        """
        return self._TargetSelect

    @TargetSelect.setter
    def TargetSelect(self, TargetSelect):
        self._TargetSelect = TargetSelect

    @property
    def TargetHosts(self):
        r"""<p>目标服务器</p>
        :rtype: list of TargetHostDTO
        """
        return self._TargetHosts

    @TargetHosts.setter
    def TargetHosts(self, TargetHosts):
        self._TargetHosts = TargetHosts

    @property
    def HttpProtocolType(self):
        r"""<p>后端协议：http https</p>
        :rtype: str
        """
        return self._HttpProtocolType

    @HttpProtocolType.setter
    def HttpProtocolType(self, HttpProtocolType):
        self._HttpProtocolType = HttpProtocolType

    @property
    def CheckTargetCertsError(self):
        r"""<p>证书检查</p>
        :rtype: bool
        """
        return self._CheckTargetCertsError

    @CheckTargetCertsError.setter
    def CheckTargetCertsError(self, CheckTargetCertsError):
        self._CheckTargetCertsError = CheckTargetCertsError

    @property
    def TargetPath(self):
        r"""<p>目标路径</p>
        :rtype: str
        """
        return self._TargetPath

    @TargetPath.setter
    def TargetPath(self, TargetPath):
        self._TargetPath = TargetPath

    @property
    def InvokeLimitConfigStatus(self):
        r"""<p>流量控制开启状态</p>
        :rtype: bool
        """
        return self._InvokeLimitConfigStatus

    @InvokeLimitConfigStatus.setter
    def InvokeLimitConfigStatus(self, InvokeLimitConfigStatus):
        self._InvokeLimitConfigStatus = InvokeLimitConfigStatus

    @property
    def InvokeLimitConfig(self):
        r"""<p>流量控制配置</p>
        :rtype: :class:`tencentcloud.apis.v20240801.models.InvokeLimitConfigDTO`
        """
        return self._InvokeLimitConfig

    @InvokeLimitConfig.setter
    def InvokeLimitConfig(self, InvokeLimitConfig):
        self._InvokeLimitConfig = InvokeLimitConfig

    @property
    def IpWhiteStatus(self):
        r"""<p>IP白名单开启状态</p>
        :rtype: bool
        """
        return self._IpWhiteStatus

    @IpWhiteStatus.setter
    def IpWhiteStatus(self, IpWhiteStatus):
        self._IpWhiteStatus = IpWhiteStatus

    @property
    def IpWhiteConfig(self):
        r"""<p>IP白名单配置</p>
        :rtype: :class:`tencentcloud.apis.v20240801.models.IpConfig`
        """
        return self._IpWhiteConfig

    @IpWhiteConfig.setter
    def IpWhiteConfig(self, IpWhiteConfig):
        self._IpWhiteConfig = IpWhiteConfig

    @property
    def IpBlackStatus(self):
        r"""<p>IP黑名单开启状态</p>
        :rtype: bool
        """
        return self._IpBlackStatus

    @IpBlackStatus.setter
    def IpBlackStatus(self, IpBlackStatus):
        self._IpBlackStatus = IpBlackStatus

    @property
    def IpBlackConfig(self):
        r"""<p>IP黑名单配置</p>
        :rtype: :class:`tencentcloud.apis.v20240801.models.IpConfig`
        """
        return self._IpBlackConfig

    @IpBlackConfig.setter
    def IpBlackConfig(self, IpBlackConfig):
        self._IpBlackConfig = IpBlackConfig

    @property
    def TargetHostType(self):
        r"""<p>目标Host类型 0 默认 1 vpc</p>
        :rtype: int
        """
        return self._TargetHostType

    @TargetHostType.setter
    def TargetHostType(self, TargetHostType):
        self._TargetHostType = TargetHostType

    @property
    def CustomHttpHost(self):
        r"""<p>自定义host</p>
        :rtype: str
        """
        return self._CustomHttpHost

    @CustomHttpHost.setter
    def CustomHttpHost(self, CustomHttpHost):
        self._CustomHttpHost = CustomHttpHost

    @property
    def HttpHostType(self):
        r"""<p>Http 请求host类型：useRequestHost 保持源请求；host targetHost 修正为源站host； customHost 自定义host</p>
        :rtype: str
        """
        return self._HttpHostType

    @HttpHostType.setter
    def HttpHostType(self, HttpHostType):
        self._HttpHostType = HttpHostType

    @property
    def Timeout(self):
        r"""<p>请求的超时时间</p>
        :rtype: int
        """
        return self._Timeout

    @Timeout.setter
    def Timeout(self, Timeout):
        self._Timeout = Timeout

    @property
    def McpSecurityRules(self):
        r"""<p>安全规则集</p>
        :rtype: list of McpSecurityRule
        """
        return self._McpSecurityRules

    @McpSecurityRules.setter
    def McpSecurityRules(self, McpSecurityRules):
        self._McpSecurityRules = McpSecurityRules

    @property
    def ToolConfigs(self):
        r"""<p>工具集配置（openapi可能会用到）</p>
        :rtype: list of ToolConfigDTO
        """
        return self._ToolConfigs

    @ToolConfigs.setter
    def ToolConfigs(self, ToolConfigs):
        self._ToolConfigs = ToolConfigs

    @property
    def WrapPaasID(self):
        r"""<p>封装的API分组ID</p>
        :rtype: str
        """
        return self._WrapPaasID

    @WrapPaasID.setter
    def WrapPaasID(self, WrapPaasID):
        self._WrapPaasID = WrapPaasID

    @property
    def PluginConfigs(self):
        r"""<p>插件配置</p>
        :rtype: list of PluginConfigDTO
        """
        return self._PluginConfigs

    @PluginConfigs.setter
    def PluginConfigs(self, PluginConfigs):
        self._PluginConfigs = PluginConfigs

    @property
    def IgnoreHealthCheck(self):
        r"""<p>是否忽略健康检查</p>
        :rtype: bool
        """
        return self._IgnoreHealthCheck

    @IgnoreHealthCheck.setter
    def IgnoreHealthCheck(self, IgnoreHealthCheck):
        self._IgnoreHealthCheck = IgnoreHealthCheck

    @property
    def CredentialID(self):
        r"""<p>凭据ID</p>
        :rtype: str
        """
        return self._CredentialID

    @CredentialID.setter
    def CredentialID(self, CredentialID):
        self._CredentialID = CredentialID

    @property
    def Domain(self):
        r"""<p>访问域名</p>
        :rtype: str
        """
        return self._Domain

    @Domain.setter
    def Domain(self, Domain):
        self._Domain = Domain

    @property
    def RequestProtocolType(self):
        r"""<p>访问协议</p><p>枚举值：</p><ul><li>http： http</li><li>https： https</li></ul>
        :rtype: str
        """
        return self._RequestProtocolType

    @RequestProtocolType.setter
    def RequestProtocolType(self, RequestProtocolType):
        self._RequestProtocolType = RequestProtocolType


    def _deserialize(self, params):
        self._ID = params.get("ID")
        self._Mode = params.get("Mode")
        self._McpVersion = params.get("McpVersion")
        self._InstanceID = params.get("InstanceID")
        self._Name = params.get("Name")
        self._Description = params.get("Description")
        self._WrapServices = params.get("WrapServices")
        self._TargetSelect = params.get("TargetSelect")
        if params.get("TargetHosts") is not None:
            self._TargetHosts = []
            for item in params.get("TargetHosts"):
                obj = TargetHostDTO()
                obj._deserialize(item)
                self._TargetHosts.append(obj)
        self._HttpProtocolType = params.get("HttpProtocolType")
        self._CheckTargetCertsError = params.get("CheckTargetCertsError")
        self._TargetPath = params.get("TargetPath")
        self._InvokeLimitConfigStatus = params.get("InvokeLimitConfigStatus")
        if params.get("InvokeLimitConfig") is not None:
            self._InvokeLimitConfig = InvokeLimitConfigDTO()
            self._InvokeLimitConfig._deserialize(params.get("InvokeLimitConfig"))
        self._IpWhiteStatus = params.get("IpWhiteStatus")
        if params.get("IpWhiteConfig") is not None:
            self._IpWhiteConfig = IpConfig()
            self._IpWhiteConfig._deserialize(params.get("IpWhiteConfig"))
        self._IpBlackStatus = params.get("IpBlackStatus")
        if params.get("IpBlackConfig") is not None:
            self._IpBlackConfig = IpConfig()
            self._IpBlackConfig._deserialize(params.get("IpBlackConfig"))
        self._TargetHostType = params.get("TargetHostType")
        self._CustomHttpHost = params.get("CustomHttpHost")
        self._HttpHostType = params.get("HttpHostType")
        self._Timeout = params.get("Timeout")
        if params.get("McpSecurityRules") is not None:
            self._McpSecurityRules = []
            for item in params.get("McpSecurityRules"):
                obj = McpSecurityRule()
                obj._deserialize(item)
                self._McpSecurityRules.append(obj)
        if params.get("ToolConfigs") is not None:
            self._ToolConfigs = []
            for item in params.get("ToolConfigs"):
                obj = ToolConfigDTO()
                obj._deserialize(item)
                self._ToolConfigs.append(obj)
        self._WrapPaasID = params.get("WrapPaasID")
        if params.get("PluginConfigs") is not None:
            self._PluginConfigs = []
            for item in params.get("PluginConfigs"):
                obj = PluginConfigDTO()
                obj._deserialize(item)
                self._PluginConfigs.append(obj)
        self._IgnoreHealthCheck = params.get("IgnoreHealthCheck")
        self._CredentialID = params.get("CredentialID")
        self._Domain = params.get("Domain")
        self._RequestProtocolType = params.get("RequestProtocolType")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ModifyMcpServerResponse(AbstractModel):
    r"""ModifyMcpServer返回参数结构体

    """

    def __init__(self):
        r"""
        :param _Data: <p>mcp server ID</p>
        :type Data: :class:`tencentcloud.apis.v20240801.models.ResultIDVO`
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._Data = None
        self._RequestId = None

    @property
    def Data(self):
        r"""<p>mcp server ID</p>
        :rtype: :class:`tencentcloud.apis.v20240801.models.ResultIDVO`
        """
        return self._Data

    @Data.setter
    def Data(self, Data):
        self._Data = Data

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("Data") is not None:
            self._Data = ResultIDVO()
            self._Data._deserialize(params.get("Data"))
        self._RequestId = params.get("RequestId")


class ModifyModelRequest(AbstractModel):
    r"""ModifyModel请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceID: <p>实例</p>
        :type InstanceID: str
        :param _ID: <p>模型ID</p>
        :type ID: str
        :param _Name: <p>模型名称</p>
        :type Name: str
        :param _HttpProtocolType: <p>协议类型：http/https</p>
        :type HttpProtocolType: str
        :param _TargetPath: <p>目标路径</p>
        :type TargetPath: str
        :param _TargetHosts: <p>目标服务器</p>
        :type TargetHosts: list of TargetHostDTO
        :param _CredentialID: <p>凭据ID</p>
        :type CredentialID: str
        :param _CheckTargetCertsError: <p>https时，是否检查证书合法</p>
        :type CheckTargetCertsError: bool
        :param _HttpProtocolVersion: <p>http协议版本：1.1/2.0</p>
        :type HttpProtocolVersion: str
        :param _ModelID: <p>model ID</p>
        :type ModelID: str
        :param _Description: <p>描述</p>
        :type Description: str
        """
        self._InstanceID = None
        self._ID = None
        self._Name = None
        self._HttpProtocolType = None
        self._TargetPath = None
        self._TargetHosts = None
        self._CredentialID = None
        self._CheckTargetCertsError = None
        self._HttpProtocolVersion = None
        self._ModelID = None
        self._Description = None

    @property
    def InstanceID(self):
        r"""<p>实例</p>
        :rtype: str
        """
        return self._InstanceID

    @InstanceID.setter
    def InstanceID(self, InstanceID):
        self._InstanceID = InstanceID

    @property
    def ID(self):
        r"""<p>模型ID</p>
        :rtype: str
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID

    @property
    def Name(self):
        r"""<p>模型名称</p>
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def HttpProtocolType(self):
        r"""<p>协议类型：http/https</p>
        :rtype: str
        """
        return self._HttpProtocolType

    @HttpProtocolType.setter
    def HttpProtocolType(self, HttpProtocolType):
        self._HttpProtocolType = HttpProtocolType

    @property
    def TargetPath(self):
        r"""<p>目标路径</p>
        :rtype: str
        """
        return self._TargetPath

    @TargetPath.setter
    def TargetPath(self, TargetPath):
        self._TargetPath = TargetPath

    @property
    def TargetHosts(self):
        r"""<p>目标服务器</p>
        :rtype: list of TargetHostDTO
        """
        return self._TargetHosts

    @TargetHosts.setter
    def TargetHosts(self, TargetHosts):
        self._TargetHosts = TargetHosts

    @property
    def CredentialID(self):
        r"""<p>凭据ID</p>
        :rtype: str
        """
        return self._CredentialID

    @CredentialID.setter
    def CredentialID(self, CredentialID):
        self._CredentialID = CredentialID

    @property
    def CheckTargetCertsError(self):
        r"""<p>https时，是否检查证书合法</p>
        :rtype: bool
        """
        return self._CheckTargetCertsError

    @CheckTargetCertsError.setter
    def CheckTargetCertsError(self, CheckTargetCertsError):
        self._CheckTargetCertsError = CheckTargetCertsError

    @property
    def HttpProtocolVersion(self):
        r"""<p>http协议版本：1.1/2.0</p>
        :rtype: str
        """
        return self._HttpProtocolVersion

    @HttpProtocolVersion.setter
    def HttpProtocolVersion(self, HttpProtocolVersion):
        self._HttpProtocolVersion = HttpProtocolVersion

    @property
    def ModelID(self):
        r"""<p>model ID</p>
        :rtype: str
        """
        return self._ModelID

    @ModelID.setter
    def ModelID(self, ModelID):
        self._ModelID = ModelID

    @property
    def Description(self):
        r"""<p>描述</p>
        :rtype: str
        """
        return self._Description

    @Description.setter
    def Description(self, Description):
        self._Description = Description


    def _deserialize(self, params):
        self._InstanceID = params.get("InstanceID")
        self._ID = params.get("ID")
        self._Name = params.get("Name")
        self._HttpProtocolType = params.get("HttpProtocolType")
        self._TargetPath = params.get("TargetPath")
        if params.get("TargetHosts") is not None:
            self._TargetHosts = []
            for item in params.get("TargetHosts"):
                obj = TargetHostDTO()
                obj._deserialize(item)
                self._TargetHosts.append(obj)
        self._CredentialID = params.get("CredentialID")
        self._CheckTargetCertsError = params.get("CheckTargetCertsError")
        self._HttpProtocolVersion = params.get("HttpProtocolVersion")
        self._ModelID = params.get("ModelID")
        self._Description = params.get("Description")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ModifyModelResponse(AbstractModel):
    r"""ModifyModel返回参数结构体

    """

    def __init__(self):
        r"""
        :param _Data: <p>结果集</p>
        :type Data: :class:`tencentcloud.apis.v20240801.models.ResultIDVO`
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._Data = None
        self._RequestId = None

    @property
    def Data(self):
        r"""<p>结果集</p>
        :rtype: :class:`tencentcloud.apis.v20240801.models.ResultIDVO`
        """
        return self._Data

    @Data.setter
    def Data(self, Data):
        self._Data = Data

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("Data") is not None:
            self._Data = ResultIDVO()
            self._Data._deserialize(params.get("Data"))
        self._RequestId = params.get("RequestId")


class ModifyModelServiceRequest(AbstractModel):
    r"""ModifyModelService请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceID: <p>实例</p>
        :type InstanceID: str
        :param _ID: <p>模型服务ID</p>
        :type ID: str
        :param _Name: <p>模型服务名称</p>
        :type Name: str
        :param _Description: <p>描述</p>
        :type Description: str
        :param _TargetModels: <p>模板模型列表</p>
        :type TargetModels: list of TargetModelDTO
        :param _InvokeLimitConfigStatus: <p>是否开启限流</p>
        :type InvokeLimitConfigStatus: bool
        :param _InvokeLimitConfig: <p>限流配置</p>
        :type InvokeLimitConfig: :class:`tencentcloud.apis.v20240801.models.InvokeLimitConfigDTO`
        :param _TokenLimitStatus: <p>是否开启token控制</p>
        :type TokenLimitStatus: bool
        :param _TokenLimitConfig: <p>token控制</p>
        :type TokenLimitConfig: :class:`tencentcloud.apis.v20240801.models.TokenLimitConfigDTO`
        :param _TmsStatus: <p>是否开启内容安全</p>
        :type TmsStatus: bool
        :param _TmsConfig: <p>内容安全配置</p>
        :type TmsConfig: :class:`tencentcloud.apis.v20240801.models.TmsConfigDTO`
        :param _IpWhiteStatus: <p>是否开启IP白名单</p>
        :type IpWhiteStatus: bool
        :param _IpWhiteList: <p>IP白名单</p>
        :type IpWhiteList: list of str
        :param _IpBlackStatus: <p>是否开启IP黑名单</p>
        :type IpBlackStatus: bool
        :param _IpBlackList: <p>IP黑名单</p>
        :type IpBlackList: list of str
        :param _PluginConfigs: <p>插件配置</p>
        :type PluginConfigs: list of PluginConfigDTO
        :param _Timeout: <p>超时配置，秒</p>
        :type Timeout: int
        :param _PromptModerateStatus: <p>是否开启提示词安全检测配置</p>
        :type PromptModerateStatus: bool
        :param _PromptModerateConfig: <p>提示词安全检测配置</p>
        :type PromptModerateConfig: :class:`tencentcloud.apis.v20240801.models.PromptModerateConfigDTO`
        :param _SensitiveDataCheckStatus: <p>是否开启敏感数据检测</p>
        :type SensitiveDataCheckStatus: bool
        :param _SensitiveDataCheckConfig: <p>敏感数据检测配置</p>
        :type SensitiveDataCheckConfig: :class:`tencentcloud.apis.v20240801.models.SensitiveDataCheckConfigDTO`
        :param _TargetSelect: <p>负载方式</p><p>枚举值：</p><ul><li>random： 随机</li><li>consistentHash： 会话保持</li></ul>
        :type TargetSelect: str
        :param _FindHostKeyMethod: <p>会话判断方式</p><p>枚举值：</p><ul><li>fromClientIP： 从客户端IP判断</li><li>fromHeader： 从请求header判断</li><li>autoDetect： 自动探测</li></ul>
        :type FindHostKeyMethod: str
        :param _HostKeyHeaderName: <p>会话判断header名称</p>
        :type HostKeyHeaderName: str
        :param _FallbackStatus: <p>是否开启备份模型</p>
        :type FallbackStatus: bool
        :param _FallbackModels: <p>备份模型</p>
        :type FallbackModels: list of TargetModelDTO
        :param _ModelProtocol: <p>模型类型</p>
        :type ModelProtocol: str
        :param _RawCustomModelProtocolConfig: <p>自定义模型协议配置</p>
        :type RawCustomModelProtocolConfig: str
        :param _RouteStrategy: <p>路由策略</p><p>枚举值：</p><ul><li>weight： 权重</li><li>taskComplexity： 任务复杂度</li><li>tokenLength： token长度</li></ul>
        :type RouteStrategy: str
        :param _TokenLengthRoute: <p>token长度路由策略</p>
        :type TokenLengthRoute: list of TokenLengthRouteDTO
        :param _TaskComplexityRoute: <p>任务复杂度路由策略</p>
        :type TaskComplexityRoute: :class:`tencentcloud.apis.v20240801.models.TaskComplexityRouteDTO`
        :param _Domain: <p>访问域名</p>
        :type Domain: str
        :param _RequestProtocolType: <p>访问协议</p>
        :type RequestProtocolType: str
        """
        self._InstanceID = None
        self._ID = None
        self._Name = None
        self._Description = None
        self._TargetModels = None
        self._InvokeLimitConfigStatus = None
        self._InvokeLimitConfig = None
        self._TokenLimitStatus = None
        self._TokenLimitConfig = None
        self._TmsStatus = None
        self._TmsConfig = None
        self._IpWhiteStatus = None
        self._IpWhiteList = None
        self._IpBlackStatus = None
        self._IpBlackList = None
        self._PluginConfigs = None
        self._Timeout = None
        self._PromptModerateStatus = None
        self._PromptModerateConfig = None
        self._SensitiveDataCheckStatus = None
        self._SensitiveDataCheckConfig = None
        self._TargetSelect = None
        self._FindHostKeyMethod = None
        self._HostKeyHeaderName = None
        self._FallbackStatus = None
        self._FallbackModels = None
        self._ModelProtocol = None
        self._RawCustomModelProtocolConfig = None
        self._RouteStrategy = None
        self._TokenLengthRoute = None
        self._TaskComplexityRoute = None
        self._Domain = None
        self._RequestProtocolType = None

    @property
    def InstanceID(self):
        r"""<p>实例</p>
        :rtype: str
        """
        return self._InstanceID

    @InstanceID.setter
    def InstanceID(self, InstanceID):
        self._InstanceID = InstanceID

    @property
    def ID(self):
        r"""<p>模型服务ID</p>
        :rtype: str
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID

    @property
    def Name(self):
        r"""<p>模型服务名称</p>
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def Description(self):
        r"""<p>描述</p>
        :rtype: str
        """
        return self._Description

    @Description.setter
    def Description(self, Description):
        self._Description = Description

    @property
    def TargetModels(self):
        r"""<p>模板模型列表</p>
        :rtype: list of TargetModelDTO
        """
        return self._TargetModels

    @TargetModels.setter
    def TargetModels(self, TargetModels):
        self._TargetModels = TargetModels

    @property
    def InvokeLimitConfigStatus(self):
        r"""<p>是否开启限流</p>
        :rtype: bool
        """
        return self._InvokeLimitConfigStatus

    @InvokeLimitConfigStatus.setter
    def InvokeLimitConfigStatus(self, InvokeLimitConfigStatus):
        self._InvokeLimitConfigStatus = InvokeLimitConfigStatus

    @property
    def InvokeLimitConfig(self):
        r"""<p>限流配置</p>
        :rtype: :class:`tencentcloud.apis.v20240801.models.InvokeLimitConfigDTO`
        """
        return self._InvokeLimitConfig

    @InvokeLimitConfig.setter
    def InvokeLimitConfig(self, InvokeLimitConfig):
        self._InvokeLimitConfig = InvokeLimitConfig

    @property
    def TokenLimitStatus(self):
        r"""<p>是否开启token控制</p>
        :rtype: bool
        """
        return self._TokenLimitStatus

    @TokenLimitStatus.setter
    def TokenLimitStatus(self, TokenLimitStatus):
        self._TokenLimitStatus = TokenLimitStatus

    @property
    def TokenLimitConfig(self):
        r"""<p>token控制</p>
        :rtype: :class:`tencentcloud.apis.v20240801.models.TokenLimitConfigDTO`
        """
        return self._TokenLimitConfig

    @TokenLimitConfig.setter
    def TokenLimitConfig(self, TokenLimitConfig):
        self._TokenLimitConfig = TokenLimitConfig

    @property
    def TmsStatus(self):
        r"""<p>是否开启内容安全</p>
        :rtype: bool
        """
        return self._TmsStatus

    @TmsStatus.setter
    def TmsStatus(self, TmsStatus):
        self._TmsStatus = TmsStatus

    @property
    def TmsConfig(self):
        r"""<p>内容安全配置</p>
        :rtype: :class:`tencentcloud.apis.v20240801.models.TmsConfigDTO`
        """
        return self._TmsConfig

    @TmsConfig.setter
    def TmsConfig(self, TmsConfig):
        self._TmsConfig = TmsConfig

    @property
    def IpWhiteStatus(self):
        r"""<p>是否开启IP白名单</p>
        :rtype: bool
        """
        return self._IpWhiteStatus

    @IpWhiteStatus.setter
    def IpWhiteStatus(self, IpWhiteStatus):
        self._IpWhiteStatus = IpWhiteStatus

    @property
    def IpWhiteList(self):
        r"""<p>IP白名单</p>
        :rtype: list of str
        """
        return self._IpWhiteList

    @IpWhiteList.setter
    def IpWhiteList(self, IpWhiteList):
        self._IpWhiteList = IpWhiteList

    @property
    def IpBlackStatus(self):
        r"""<p>是否开启IP黑名单</p>
        :rtype: bool
        """
        return self._IpBlackStatus

    @IpBlackStatus.setter
    def IpBlackStatus(self, IpBlackStatus):
        self._IpBlackStatus = IpBlackStatus

    @property
    def IpBlackList(self):
        r"""<p>IP黑名单</p>
        :rtype: list of str
        """
        return self._IpBlackList

    @IpBlackList.setter
    def IpBlackList(self, IpBlackList):
        self._IpBlackList = IpBlackList

    @property
    def PluginConfigs(self):
        r"""<p>插件配置</p>
        :rtype: list of PluginConfigDTO
        """
        return self._PluginConfigs

    @PluginConfigs.setter
    def PluginConfigs(self, PluginConfigs):
        self._PluginConfigs = PluginConfigs

    @property
    def Timeout(self):
        r"""<p>超时配置，秒</p>
        :rtype: int
        """
        return self._Timeout

    @Timeout.setter
    def Timeout(self, Timeout):
        self._Timeout = Timeout

    @property
    def PromptModerateStatus(self):
        r"""<p>是否开启提示词安全检测配置</p>
        :rtype: bool
        """
        return self._PromptModerateStatus

    @PromptModerateStatus.setter
    def PromptModerateStatus(self, PromptModerateStatus):
        self._PromptModerateStatus = PromptModerateStatus

    @property
    def PromptModerateConfig(self):
        r"""<p>提示词安全检测配置</p>
        :rtype: :class:`tencentcloud.apis.v20240801.models.PromptModerateConfigDTO`
        """
        return self._PromptModerateConfig

    @PromptModerateConfig.setter
    def PromptModerateConfig(self, PromptModerateConfig):
        self._PromptModerateConfig = PromptModerateConfig

    @property
    def SensitiveDataCheckStatus(self):
        r"""<p>是否开启敏感数据检测</p>
        :rtype: bool
        """
        return self._SensitiveDataCheckStatus

    @SensitiveDataCheckStatus.setter
    def SensitiveDataCheckStatus(self, SensitiveDataCheckStatus):
        self._SensitiveDataCheckStatus = SensitiveDataCheckStatus

    @property
    def SensitiveDataCheckConfig(self):
        r"""<p>敏感数据检测配置</p>
        :rtype: :class:`tencentcloud.apis.v20240801.models.SensitiveDataCheckConfigDTO`
        """
        return self._SensitiveDataCheckConfig

    @SensitiveDataCheckConfig.setter
    def SensitiveDataCheckConfig(self, SensitiveDataCheckConfig):
        self._SensitiveDataCheckConfig = SensitiveDataCheckConfig

    @property
    def TargetSelect(self):
        r"""<p>负载方式</p><p>枚举值：</p><ul><li>random： 随机</li><li>consistentHash： 会话保持</li></ul>
        :rtype: str
        """
        return self._TargetSelect

    @TargetSelect.setter
    def TargetSelect(self, TargetSelect):
        self._TargetSelect = TargetSelect

    @property
    def FindHostKeyMethod(self):
        r"""<p>会话判断方式</p><p>枚举值：</p><ul><li>fromClientIP： 从客户端IP判断</li><li>fromHeader： 从请求header判断</li><li>autoDetect： 自动探测</li></ul>
        :rtype: str
        """
        return self._FindHostKeyMethod

    @FindHostKeyMethod.setter
    def FindHostKeyMethod(self, FindHostKeyMethod):
        self._FindHostKeyMethod = FindHostKeyMethod

    @property
    def HostKeyHeaderName(self):
        r"""<p>会话判断header名称</p>
        :rtype: str
        """
        return self._HostKeyHeaderName

    @HostKeyHeaderName.setter
    def HostKeyHeaderName(self, HostKeyHeaderName):
        self._HostKeyHeaderName = HostKeyHeaderName

    @property
    def FallbackStatus(self):
        r"""<p>是否开启备份模型</p>
        :rtype: bool
        """
        return self._FallbackStatus

    @FallbackStatus.setter
    def FallbackStatus(self, FallbackStatus):
        self._FallbackStatus = FallbackStatus

    @property
    def FallbackModels(self):
        r"""<p>备份模型</p>
        :rtype: list of TargetModelDTO
        """
        return self._FallbackModels

    @FallbackModels.setter
    def FallbackModels(self, FallbackModels):
        self._FallbackModels = FallbackModels

    @property
    def ModelProtocol(self):
        r"""<p>模型类型</p>
        :rtype: str
        """
        return self._ModelProtocol

    @ModelProtocol.setter
    def ModelProtocol(self, ModelProtocol):
        self._ModelProtocol = ModelProtocol

    @property
    def RawCustomModelProtocolConfig(self):
        r"""<p>自定义模型协议配置</p>
        :rtype: str
        """
        return self._RawCustomModelProtocolConfig

    @RawCustomModelProtocolConfig.setter
    def RawCustomModelProtocolConfig(self, RawCustomModelProtocolConfig):
        self._RawCustomModelProtocolConfig = RawCustomModelProtocolConfig

    @property
    def RouteStrategy(self):
        r"""<p>路由策略</p><p>枚举值：</p><ul><li>weight： 权重</li><li>taskComplexity： 任务复杂度</li><li>tokenLength： token长度</li></ul>
        :rtype: str
        """
        return self._RouteStrategy

    @RouteStrategy.setter
    def RouteStrategy(self, RouteStrategy):
        self._RouteStrategy = RouteStrategy

    @property
    def TokenLengthRoute(self):
        r"""<p>token长度路由策略</p>
        :rtype: list of TokenLengthRouteDTO
        """
        return self._TokenLengthRoute

    @TokenLengthRoute.setter
    def TokenLengthRoute(self, TokenLengthRoute):
        self._TokenLengthRoute = TokenLengthRoute

    @property
    def TaskComplexityRoute(self):
        r"""<p>任务复杂度路由策略</p>
        :rtype: :class:`tencentcloud.apis.v20240801.models.TaskComplexityRouteDTO`
        """
        return self._TaskComplexityRoute

    @TaskComplexityRoute.setter
    def TaskComplexityRoute(self, TaskComplexityRoute):
        self._TaskComplexityRoute = TaskComplexityRoute

    @property
    def Domain(self):
        r"""<p>访问域名</p>
        :rtype: str
        """
        return self._Domain

    @Domain.setter
    def Domain(self, Domain):
        self._Domain = Domain

    @property
    def RequestProtocolType(self):
        r"""<p>访问协议</p>
        :rtype: str
        """
        return self._RequestProtocolType

    @RequestProtocolType.setter
    def RequestProtocolType(self, RequestProtocolType):
        self._RequestProtocolType = RequestProtocolType


    def _deserialize(self, params):
        self._InstanceID = params.get("InstanceID")
        self._ID = params.get("ID")
        self._Name = params.get("Name")
        self._Description = params.get("Description")
        if params.get("TargetModels") is not None:
            self._TargetModels = []
            for item in params.get("TargetModels"):
                obj = TargetModelDTO()
                obj._deserialize(item)
                self._TargetModels.append(obj)
        self._InvokeLimitConfigStatus = params.get("InvokeLimitConfigStatus")
        if params.get("InvokeLimitConfig") is not None:
            self._InvokeLimitConfig = InvokeLimitConfigDTO()
            self._InvokeLimitConfig._deserialize(params.get("InvokeLimitConfig"))
        self._TokenLimitStatus = params.get("TokenLimitStatus")
        if params.get("TokenLimitConfig") is not None:
            self._TokenLimitConfig = TokenLimitConfigDTO()
            self._TokenLimitConfig._deserialize(params.get("TokenLimitConfig"))
        self._TmsStatus = params.get("TmsStatus")
        if params.get("TmsConfig") is not None:
            self._TmsConfig = TmsConfigDTO()
            self._TmsConfig._deserialize(params.get("TmsConfig"))
        self._IpWhiteStatus = params.get("IpWhiteStatus")
        self._IpWhiteList = params.get("IpWhiteList")
        self._IpBlackStatus = params.get("IpBlackStatus")
        self._IpBlackList = params.get("IpBlackList")
        if params.get("PluginConfigs") is not None:
            self._PluginConfigs = []
            for item in params.get("PluginConfigs"):
                obj = PluginConfigDTO()
                obj._deserialize(item)
                self._PluginConfigs.append(obj)
        self._Timeout = params.get("Timeout")
        self._PromptModerateStatus = params.get("PromptModerateStatus")
        if params.get("PromptModerateConfig") is not None:
            self._PromptModerateConfig = PromptModerateConfigDTO()
            self._PromptModerateConfig._deserialize(params.get("PromptModerateConfig"))
        self._SensitiveDataCheckStatus = params.get("SensitiveDataCheckStatus")
        if params.get("SensitiveDataCheckConfig") is not None:
            self._SensitiveDataCheckConfig = SensitiveDataCheckConfigDTO()
            self._SensitiveDataCheckConfig._deserialize(params.get("SensitiveDataCheckConfig"))
        self._TargetSelect = params.get("TargetSelect")
        self._FindHostKeyMethod = params.get("FindHostKeyMethod")
        self._HostKeyHeaderName = params.get("HostKeyHeaderName")
        self._FallbackStatus = params.get("FallbackStatus")
        if params.get("FallbackModels") is not None:
            self._FallbackModels = []
            for item in params.get("FallbackModels"):
                obj = TargetModelDTO()
                obj._deserialize(item)
                self._FallbackModels.append(obj)
        self._ModelProtocol = params.get("ModelProtocol")
        self._RawCustomModelProtocolConfig = params.get("RawCustomModelProtocolConfig")
        self._RouteStrategy = params.get("RouteStrategy")
        if params.get("TokenLengthRoute") is not None:
            self._TokenLengthRoute = []
            for item in params.get("TokenLengthRoute"):
                obj = TokenLengthRouteDTO()
                obj._deserialize(item)
                self._TokenLengthRoute.append(obj)
        if params.get("TaskComplexityRoute") is not None:
            self._TaskComplexityRoute = TaskComplexityRouteDTO()
            self._TaskComplexityRoute._deserialize(params.get("TaskComplexityRoute"))
        self._Domain = params.get("Domain")
        self._RequestProtocolType = params.get("RequestProtocolType")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ModifyModelServiceResponse(AbstractModel):
    r"""ModifyModelService返回参数结构体

    """

    def __init__(self):
        r"""
        :param _Data: <p>结果集</p>
        :type Data: :class:`tencentcloud.apis.v20240801.models.ResultIDVO`
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._Data = None
        self._RequestId = None

    @property
    def Data(self):
        r"""<p>结果集</p>
        :rtype: :class:`tencentcloud.apis.v20240801.models.ResultIDVO`
        """
        return self._Data

    @Data.setter
    def Data(self, Data):
        self._Data = Data

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("Data") is not None:
            self._Data = ResultIDVO()
            self._Data._deserialize(params.get("Data"))
        self._RequestId = params.get("RequestId")


class ModifyServiceRequest(AbstractModel):
    r"""ModifyService请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceID: <p>实例</p>
        :type InstanceID: str
        :param _Name: <p>名称</p>
        :type Name: str
        :param _PaasID: <p>里约应用ID</p>
        :type PaasID: str
        :param _Description: <p>描述</p>
        :type Description: str
        :param _LabelIDs: <p>标签</p>
        :type LabelIDs: list of str
        :param _CategoryIDs: <p>目录</p>
        :type CategoryIDs: list of str
        :param _AuthType: <p>鉴权方式</p>
        :type AuthType: str
        :param _SignType: <p>签名</p>
        :type SignType: str
        :param _LoginTypes: <p>登录方式</p>
        :type LoginTypes: list of str
        :param _TargetSelect: <p>负载方式</p>
        :type TargetSelect: str
        :param _PubPath: <p>公开路径</p>
        :type PubPath: str
        :param _RequestMethod: <p>请求方法</p>
        :type RequestMethod: str
        :param _HttpProtocolType: <p>是否https</p>
        :type HttpProtocolType: str
        :param _CheckTargetCertsError: <p>证书检查</p>
        :type CheckTargetCertsError: bool
        :param _HttpProtocolVersion: <p>http协议类型</p>
        :type HttpProtocolVersion: str
        :param _Versions: <p>版本号</p>
        :type Versions: list of VersionDTO
        :param _TargetPath: <p>目标路径</p>
        :type TargetPath: str
        :param _RequestParamsValidatorStatus: <p>入参</p>
        :type RequestParamsValidatorStatus: bool
        :param _RequestParamsValidatorJsonInfoT: <p>入参</p>
        :type RequestParamsValidatorJsonInfoT: str
        :param _ResponseParamsValidatorStatus: <p>出参</p>
        :type ResponseParamsValidatorStatus: bool
        :param _ResponseParamsValidatorJsonInfoT: <p>出参</p>
        :type ResponseParamsValidatorJsonInfoT: str
        :param _InvokeLimitConfigStatus: <p>流量控制</p>
        :type InvokeLimitConfigStatus: bool
        :param _InvokeLimitConfig: <p>流量控制</p>
        :type InvokeLimitConfig: :class:`tencentcloud.apis.v20240801.models.InvokeLimitConfigDTO`
        :param _HealthCheckStatus: <p>健康检查</p>
        :type HealthCheckStatus: bool
        :param _HealthCheckConfig: <p>健康检查</p>
        :type HealthCheckConfig: :class:`tencentcloud.apis.v20240801.models.HealthCheckConfigDTO`
        :param _SourceTypeStatus: <p>格式转换</p>
        :type SourceTypeStatus: bool
        :param _SourceTypeConfig: <p>格式转换</p>
        :type SourceTypeConfig: :class:`tencentcloud.apis.v20240801.models.SourceTypeConfigDTO`
        :param _IpWhiteStatus: <p>IP白名单</p>
        :type IpWhiteStatus: bool
        :param _IpWhiteList: <p>IP白名单</p>
        :type IpWhiteList: list of str
        :param _IpBlackStatus: <p>IP黑名单</p>
        :type IpBlackStatus: bool
        :param _IpBlackList: <p>IP黑名单</p>
        :type IpBlackList: list of str
        :param _PluginConfigs: <p>插件</p>
        :type PluginConfigs: list of PluginConfigDTO
        :param _ID: <p>服务ID</p>
        :type ID: str
        """
        self._InstanceID = None
        self._Name = None
        self._PaasID = None
        self._Description = None
        self._LabelIDs = None
        self._CategoryIDs = None
        self._AuthType = None
        self._SignType = None
        self._LoginTypes = None
        self._TargetSelect = None
        self._PubPath = None
        self._RequestMethod = None
        self._HttpProtocolType = None
        self._CheckTargetCertsError = None
        self._HttpProtocolVersion = None
        self._Versions = None
        self._TargetPath = None
        self._RequestParamsValidatorStatus = None
        self._RequestParamsValidatorJsonInfoT = None
        self._ResponseParamsValidatorStatus = None
        self._ResponseParamsValidatorJsonInfoT = None
        self._InvokeLimitConfigStatus = None
        self._InvokeLimitConfig = None
        self._HealthCheckStatus = None
        self._HealthCheckConfig = None
        self._SourceTypeStatus = None
        self._SourceTypeConfig = None
        self._IpWhiteStatus = None
        self._IpWhiteList = None
        self._IpBlackStatus = None
        self._IpBlackList = None
        self._PluginConfigs = None
        self._ID = None

    @property
    def InstanceID(self):
        r"""<p>实例</p>
        :rtype: str
        """
        return self._InstanceID

    @InstanceID.setter
    def InstanceID(self, InstanceID):
        self._InstanceID = InstanceID

    @property
    def Name(self):
        r"""<p>名称</p>
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def PaasID(self):
        warnings.warn("parameter `PaasID` is deprecated", DeprecationWarning) 

        r"""<p>里约应用ID</p>
        :rtype: str
        """
        return self._PaasID

    @PaasID.setter
    def PaasID(self, PaasID):
        warnings.warn("parameter `PaasID` is deprecated", DeprecationWarning) 

        self._PaasID = PaasID

    @property
    def Description(self):
        r"""<p>描述</p>
        :rtype: str
        """
        return self._Description

    @Description.setter
    def Description(self, Description):
        self._Description = Description

    @property
    def LabelIDs(self):
        r"""<p>标签</p>
        :rtype: list of str
        """
        return self._LabelIDs

    @LabelIDs.setter
    def LabelIDs(self, LabelIDs):
        self._LabelIDs = LabelIDs

    @property
    def CategoryIDs(self):
        r"""<p>目录</p>
        :rtype: list of str
        """
        return self._CategoryIDs

    @CategoryIDs.setter
    def CategoryIDs(self, CategoryIDs):
        self._CategoryIDs = CategoryIDs

    @property
    def AuthType(self):
        warnings.warn("parameter `AuthType` is deprecated", DeprecationWarning) 

        r"""<p>鉴权方式</p>
        :rtype: str
        """
        return self._AuthType

    @AuthType.setter
    def AuthType(self, AuthType):
        warnings.warn("parameter `AuthType` is deprecated", DeprecationWarning) 

        self._AuthType = AuthType

    @property
    def SignType(self):
        warnings.warn("parameter `SignType` is deprecated", DeprecationWarning) 

        r"""<p>签名</p>
        :rtype: str
        """
        return self._SignType

    @SignType.setter
    def SignType(self, SignType):
        warnings.warn("parameter `SignType` is deprecated", DeprecationWarning) 

        self._SignType = SignType

    @property
    def LoginTypes(self):
        warnings.warn("parameter `LoginTypes` is deprecated", DeprecationWarning) 

        r"""<p>登录方式</p>
        :rtype: list of str
        """
        return self._LoginTypes

    @LoginTypes.setter
    def LoginTypes(self, LoginTypes):
        warnings.warn("parameter `LoginTypes` is deprecated", DeprecationWarning) 

        self._LoginTypes = LoginTypes

    @property
    def TargetSelect(self):
        r"""<p>负载方式</p>
        :rtype: str
        """
        return self._TargetSelect

    @TargetSelect.setter
    def TargetSelect(self, TargetSelect):
        self._TargetSelect = TargetSelect

    @property
    def PubPath(self):
        r"""<p>公开路径</p>
        :rtype: str
        """
        return self._PubPath

    @PubPath.setter
    def PubPath(self, PubPath):
        self._PubPath = PubPath

    @property
    def RequestMethod(self):
        r"""<p>请求方法</p>
        :rtype: str
        """
        return self._RequestMethod

    @RequestMethod.setter
    def RequestMethod(self, RequestMethod):
        self._RequestMethod = RequestMethod

    @property
    def HttpProtocolType(self):
        r"""<p>是否https</p>
        :rtype: str
        """
        return self._HttpProtocolType

    @HttpProtocolType.setter
    def HttpProtocolType(self, HttpProtocolType):
        self._HttpProtocolType = HttpProtocolType

    @property
    def CheckTargetCertsError(self):
        r"""<p>证书检查</p>
        :rtype: bool
        """
        return self._CheckTargetCertsError

    @CheckTargetCertsError.setter
    def CheckTargetCertsError(self, CheckTargetCertsError):
        self._CheckTargetCertsError = CheckTargetCertsError

    @property
    def HttpProtocolVersion(self):
        r"""<p>http协议类型</p>
        :rtype: str
        """
        return self._HttpProtocolVersion

    @HttpProtocolVersion.setter
    def HttpProtocolVersion(self, HttpProtocolVersion):
        self._HttpProtocolVersion = HttpProtocolVersion

    @property
    def Versions(self):
        r"""<p>版本号</p>
        :rtype: list of VersionDTO
        """
        return self._Versions

    @Versions.setter
    def Versions(self, Versions):
        self._Versions = Versions

    @property
    def TargetPath(self):
        r"""<p>目标路径</p>
        :rtype: str
        """
        return self._TargetPath

    @TargetPath.setter
    def TargetPath(self, TargetPath):
        self._TargetPath = TargetPath

    @property
    def RequestParamsValidatorStatus(self):
        r"""<p>入参</p>
        :rtype: bool
        """
        return self._RequestParamsValidatorStatus

    @RequestParamsValidatorStatus.setter
    def RequestParamsValidatorStatus(self, RequestParamsValidatorStatus):
        self._RequestParamsValidatorStatus = RequestParamsValidatorStatus

    @property
    def RequestParamsValidatorJsonInfoT(self):
        r"""<p>入参</p>
        :rtype: str
        """
        return self._RequestParamsValidatorJsonInfoT

    @RequestParamsValidatorJsonInfoT.setter
    def RequestParamsValidatorJsonInfoT(self, RequestParamsValidatorJsonInfoT):
        self._RequestParamsValidatorJsonInfoT = RequestParamsValidatorJsonInfoT

    @property
    def ResponseParamsValidatorStatus(self):
        r"""<p>出参</p>
        :rtype: bool
        """
        return self._ResponseParamsValidatorStatus

    @ResponseParamsValidatorStatus.setter
    def ResponseParamsValidatorStatus(self, ResponseParamsValidatorStatus):
        self._ResponseParamsValidatorStatus = ResponseParamsValidatorStatus

    @property
    def ResponseParamsValidatorJsonInfoT(self):
        r"""<p>出参</p>
        :rtype: str
        """
        return self._ResponseParamsValidatorJsonInfoT

    @ResponseParamsValidatorJsonInfoT.setter
    def ResponseParamsValidatorJsonInfoT(self, ResponseParamsValidatorJsonInfoT):
        self._ResponseParamsValidatorJsonInfoT = ResponseParamsValidatorJsonInfoT

    @property
    def InvokeLimitConfigStatus(self):
        r"""<p>流量控制</p>
        :rtype: bool
        """
        return self._InvokeLimitConfigStatus

    @InvokeLimitConfigStatus.setter
    def InvokeLimitConfigStatus(self, InvokeLimitConfigStatus):
        self._InvokeLimitConfigStatus = InvokeLimitConfigStatus

    @property
    def InvokeLimitConfig(self):
        r"""<p>流量控制</p>
        :rtype: :class:`tencentcloud.apis.v20240801.models.InvokeLimitConfigDTO`
        """
        return self._InvokeLimitConfig

    @InvokeLimitConfig.setter
    def InvokeLimitConfig(self, InvokeLimitConfig):
        self._InvokeLimitConfig = InvokeLimitConfig

    @property
    def HealthCheckStatus(self):
        r"""<p>健康检查</p>
        :rtype: bool
        """
        return self._HealthCheckStatus

    @HealthCheckStatus.setter
    def HealthCheckStatus(self, HealthCheckStatus):
        self._HealthCheckStatus = HealthCheckStatus

    @property
    def HealthCheckConfig(self):
        r"""<p>健康检查</p>
        :rtype: :class:`tencentcloud.apis.v20240801.models.HealthCheckConfigDTO`
        """
        return self._HealthCheckConfig

    @HealthCheckConfig.setter
    def HealthCheckConfig(self, HealthCheckConfig):
        self._HealthCheckConfig = HealthCheckConfig

    @property
    def SourceTypeStatus(self):
        r"""<p>格式转换</p>
        :rtype: bool
        """
        return self._SourceTypeStatus

    @SourceTypeStatus.setter
    def SourceTypeStatus(self, SourceTypeStatus):
        self._SourceTypeStatus = SourceTypeStatus

    @property
    def SourceTypeConfig(self):
        r"""<p>格式转换</p>
        :rtype: :class:`tencentcloud.apis.v20240801.models.SourceTypeConfigDTO`
        """
        return self._SourceTypeConfig

    @SourceTypeConfig.setter
    def SourceTypeConfig(self, SourceTypeConfig):
        self._SourceTypeConfig = SourceTypeConfig

    @property
    def IpWhiteStatus(self):
        r"""<p>IP白名单</p>
        :rtype: bool
        """
        return self._IpWhiteStatus

    @IpWhiteStatus.setter
    def IpWhiteStatus(self, IpWhiteStatus):
        self._IpWhiteStatus = IpWhiteStatus

    @property
    def IpWhiteList(self):
        r"""<p>IP白名单</p>
        :rtype: list of str
        """
        return self._IpWhiteList

    @IpWhiteList.setter
    def IpWhiteList(self, IpWhiteList):
        self._IpWhiteList = IpWhiteList

    @property
    def IpBlackStatus(self):
        r"""<p>IP黑名单</p>
        :rtype: bool
        """
        return self._IpBlackStatus

    @IpBlackStatus.setter
    def IpBlackStatus(self, IpBlackStatus):
        self._IpBlackStatus = IpBlackStatus

    @property
    def IpBlackList(self):
        r"""<p>IP黑名单</p>
        :rtype: list of str
        """
        return self._IpBlackList

    @IpBlackList.setter
    def IpBlackList(self, IpBlackList):
        self._IpBlackList = IpBlackList

    @property
    def PluginConfigs(self):
        r"""<p>插件</p>
        :rtype: list of PluginConfigDTO
        """
        return self._PluginConfigs

    @PluginConfigs.setter
    def PluginConfigs(self, PluginConfigs):
        self._PluginConfigs = PluginConfigs

    @property
    def ID(self):
        r"""<p>服务ID</p>
        :rtype: str
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID


    def _deserialize(self, params):
        self._InstanceID = params.get("InstanceID")
        self._Name = params.get("Name")
        self._PaasID = params.get("PaasID")
        self._Description = params.get("Description")
        self._LabelIDs = params.get("LabelIDs")
        self._CategoryIDs = params.get("CategoryIDs")
        self._AuthType = params.get("AuthType")
        self._SignType = params.get("SignType")
        self._LoginTypes = params.get("LoginTypes")
        self._TargetSelect = params.get("TargetSelect")
        self._PubPath = params.get("PubPath")
        self._RequestMethod = params.get("RequestMethod")
        self._HttpProtocolType = params.get("HttpProtocolType")
        self._CheckTargetCertsError = params.get("CheckTargetCertsError")
        self._HttpProtocolVersion = params.get("HttpProtocolVersion")
        if params.get("Versions") is not None:
            self._Versions = []
            for item in params.get("Versions"):
                obj = VersionDTO()
                obj._deserialize(item)
                self._Versions.append(obj)
        self._TargetPath = params.get("TargetPath")
        self._RequestParamsValidatorStatus = params.get("RequestParamsValidatorStatus")
        self._RequestParamsValidatorJsonInfoT = params.get("RequestParamsValidatorJsonInfoT")
        self._ResponseParamsValidatorStatus = params.get("ResponseParamsValidatorStatus")
        self._ResponseParamsValidatorJsonInfoT = params.get("ResponseParamsValidatorJsonInfoT")
        self._InvokeLimitConfigStatus = params.get("InvokeLimitConfigStatus")
        if params.get("InvokeLimitConfig") is not None:
            self._InvokeLimitConfig = InvokeLimitConfigDTO()
            self._InvokeLimitConfig._deserialize(params.get("InvokeLimitConfig"))
        self._HealthCheckStatus = params.get("HealthCheckStatus")
        if params.get("HealthCheckConfig") is not None:
            self._HealthCheckConfig = HealthCheckConfigDTO()
            self._HealthCheckConfig._deserialize(params.get("HealthCheckConfig"))
        self._SourceTypeStatus = params.get("SourceTypeStatus")
        if params.get("SourceTypeConfig") is not None:
            self._SourceTypeConfig = SourceTypeConfigDTO()
            self._SourceTypeConfig._deserialize(params.get("SourceTypeConfig"))
        self._IpWhiteStatus = params.get("IpWhiteStatus")
        self._IpWhiteList = params.get("IpWhiteList")
        self._IpBlackStatus = params.get("IpBlackStatus")
        self._IpBlackList = params.get("IpBlackList")
        if params.get("PluginConfigs") is not None:
            self._PluginConfigs = []
            for item in params.get("PluginConfigs"):
                obj = PluginConfigDTO()
                obj._deserialize(item)
                self._PluginConfigs.append(obj)
        self._ID = params.get("ID")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ModifyServiceResponse(AbstractModel):
    r"""ModifyService返回参数结构体

    """

    def __init__(self):
        r"""
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._RequestId = None

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._RequestId = params.get("RequestId")


class PluginConfigDTO(AbstractModel):
    r"""PluginConfigDTO

    """

    def __init__(self):
        r"""
        :param _Status: 状态
注意：此字段可能返回 null，表示取不到有效值。
        :type Status: bool
        :param _PluginName: 名称
注意：此字段可能返回 null，表示取不到有效值。
        :type PluginName: str
        :param _Description: 描述
注意：此字段可能返回 null，表示取不到有效值。
        :type Description: str
        :param _PluginID: ID
注意：此字段可能返回 null，表示取不到有效值。
        :type PluginID: str
        :param _Level: 优先级
注意：此字段可能返回 null，表示取不到有效值。
        :type Level: int
        :param _PluginFormValues: 表单配置
注意：此字段可能返回 null，表示取不到有效值。
        :type PluginFormValues: list of PluginFormValueDTO
        """
        self._Status = None
        self._PluginName = None
        self._Description = None
        self._PluginID = None
        self._Level = None
        self._PluginFormValues = None

    @property
    def Status(self):
        r"""状态
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: bool
        """
        return self._Status

    @Status.setter
    def Status(self, Status):
        self._Status = Status

    @property
    def PluginName(self):
        r"""名称
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._PluginName

    @PluginName.setter
    def PluginName(self, PluginName):
        self._PluginName = PluginName

    @property
    def Description(self):
        r"""描述
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._Description

    @Description.setter
    def Description(self, Description):
        self._Description = Description

    @property
    def PluginID(self):
        r"""ID
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._PluginID

    @PluginID.setter
    def PluginID(self, PluginID):
        self._PluginID = PluginID

    @property
    def Level(self):
        r"""优先级
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: int
        """
        return self._Level

    @Level.setter
    def Level(self, Level):
        self._Level = Level

    @property
    def PluginFormValues(self):
        r"""表单配置
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of PluginFormValueDTO
        """
        return self._PluginFormValues

    @PluginFormValues.setter
    def PluginFormValues(self, PluginFormValues):
        self._PluginFormValues = PluginFormValues


    def _deserialize(self, params):
        self._Status = params.get("Status")
        self._PluginName = params.get("PluginName")
        self._Description = params.get("Description")
        self._PluginID = params.get("PluginID")
        self._Level = params.get("Level")
        if params.get("PluginFormValues") is not None:
            self._PluginFormValues = []
            for item in params.get("PluginFormValues"):
                obj = PluginFormValueDTO()
                obj._deserialize(item)
                self._PluginFormValues.append(obj)
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class PluginFormValueDTO(AbstractModel):
    r"""PluginFormValueDTO

    """

    def __init__(self):
        r"""
        :param _Field: 字段
注意：此字段可能返回 null，表示取不到有效值。
        :type Field: str
        :param _Value: 值
注意：此字段可能返回 null，表示取不到有效值。
        :type Value: str
        """
        self._Field = None
        self._Value = None

    @property
    def Field(self):
        r"""字段
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._Field

    @Field.setter
    def Field(self, Field):
        self._Field = Field

    @property
    def Value(self):
        r"""值
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._Value

    @Value.setter
    def Value(self, Value):
        self._Value = Value


    def _deserialize(self, params):
        self._Field = params.get("Field")
        self._Value = params.get("Value")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class PromptModerateConfigDTO(AbstractModel):
    r"""提示词安全配置

    """

    def __init__(self):
        r"""
        :param _Action: <p>执行动作</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type Action: str
        :param _InterceptMessage: <p>响应拦截内容</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type InterceptMessage: str
        :param _ContextScope: <p>检测上下文</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type ContextScope: str
        """
        self._Action = None
        self._InterceptMessage = None
        self._ContextScope = None

    @property
    def Action(self):
        r"""<p>执行动作</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._Action

    @Action.setter
    def Action(self, Action):
        self._Action = Action

    @property
    def InterceptMessage(self):
        r"""<p>响应拦截内容</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._InterceptMessage

    @InterceptMessage.setter
    def InterceptMessage(self, InterceptMessage):
        self._InterceptMessage = InterceptMessage

    @property
    def ContextScope(self):
        r"""<p>检测上下文</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._ContextScope

    @ContextScope.setter
    def ContextScope(self, ContextScope):
        self._ContextScope = ContextScope


    def _deserialize(self, params):
        self._Action = params.get("Action")
        self._InterceptMessage = params.get("InterceptMessage")
        self._ContextScope = params.get("ContextScope")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ResultIDVO(AbstractModel):
    r"""ResultIDVO

    """

    def __init__(self):
        r"""
        :param _ID: 对象ID
注意：此字段可能返回 null，表示取不到有效值。
        :type ID: str
        """
        self._ID = None

    @property
    def ID(self):
        r"""对象ID
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID


    def _deserialize(self, params):
        self._ID = params.get("ID")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ResultIDsVO(AbstractModel):
    r"""结果ID数组

    """

    def __init__(self):
        r"""
        :param _IDs: 结果ID数组
注意：此字段可能返回 null，表示取不到有效值。
        :type IDs: list of str
        """
        self._IDs = None

    @property
    def IDs(self):
        r"""结果ID数组
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of str
        """
        return self._IDs

    @IDs.setter
    def IDs(self, IDs):
        self._IDs = IDs


    def _deserialize(self, params):
        self._IDs = params.get("IDs")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class SensitiveDataCheckConfigDTO(AbstractModel):
    r"""敏感数据检测配置

    """

    def __init__(self):
        r"""
        :param _Action: <p>执行动作</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type Action: str
        :param _InterceptMessage: <p>响应拦截内容</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type InterceptMessage: str
        :param _CheckItems: <p>检测项</p><p>枚举值：</p><ul><li>birthday： 生日</li><li>email： 邮箱</li><li>identity_number： 身份证</li><li>phone_number： 电话号码</li><li>secret： 秘钥</li><li>password： 密码</li><li>private_key： 私钥</li></ul>
注意：此字段可能返回 null，表示取不到有效值。
        :type CheckItems: list of str
        :param _ContextScope: <p>检测上下文</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type ContextScope: str
        """
        self._Action = None
        self._InterceptMessage = None
        self._CheckItems = None
        self._ContextScope = None

    @property
    def Action(self):
        r"""<p>执行动作</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._Action

    @Action.setter
    def Action(self, Action):
        self._Action = Action

    @property
    def InterceptMessage(self):
        r"""<p>响应拦截内容</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._InterceptMessage

    @InterceptMessage.setter
    def InterceptMessage(self, InterceptMessage):
        self._InterceptMessage = InterceptMessage

    @property
    def CheckItems(self):
        r"""<p>检测项</p><p>枚举值：</p><ul><li>birthday： 生日</li><li>email： 邮箱</li><li>identity_number： 身份证</li><li>phone_number： 电话号码</li><li>secret： 秘钥</li><li>password： 密码</li><li>private_key： 私钥</li></ul>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of str
        """
        return self._CheckItems

    @CheckItems.setter
    def CheckItems(self, CheckItems):
        self._CheckItems = CheckItems

    @property
    def ContextScope(self):
        r"""<p>检测上下文</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._ContextScope

    @ContextScope.setter
    def ContextScope(self, ContextScope):
        self._ContextScope = ContextScope


    def _deserialize(self, params):
        self._Action = params.get("Action")
        self._InterceptMessage = params.get("InterceptMessage")
        self._CheckItems = params.get("CheckItems")
        self._ContextScope = params.get("ContextScope")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ServiceDatabaseOrderParam(AbstractModel):
    r"""ServiceDatabaseOrderParam

    """

    def __init__(self):
        r"""
        :param _FieldName: <p>字段名称</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type FieldName: str
        :param _Order: <p>排序 asc desc</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type Order: str
        """
        self._FieldName = None
        self._Order = None

    @property
    def FieldName(self):
        r"""<p>字段名称</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._FieldName

    @FieldName.setter
    def FieldName(self, FieldName):
        self._FieldName = FieldName

    @property
    def Order(self):
        r"""<p>排序 asc desc</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._Order

    @Order.setter
    def Order(self, Order):
        self._Order = Order


    def _deserialize(self, params):
        self._FieldName = params.get("FieldName")
        self._Order = params.get("Order")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ServiceDatabaseReqParam(AbstractModel):
    r"""向导模式请求参数

    """

    def __init__(self):
        r"""
        :param _FieldName: <p>表字段名</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type FieldName: str
        :param _Operator: <p>操作符</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type Operator: str
        :param _Val: <p>参数名/常量</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type Val: str
        :param _ValType: <p>参数类型</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type ValType: str
        :param _InternalField: <p>内部字段</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type InternalField: bool
        """
        self._FieldName = None
        self._Operator = None
        self._Val = None
        self._ValType = None
        self._InternalField = None

    @property
    def FieldName(self):
        r"""<p>表字段名</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._FieldName

    @FieldName.setter
    def FieldName(self, FieldName):
        self._FieldName = FieldName

    @property
    def Operator(self):
        r"""<p>操作符</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._Operator

    @Operator.setter
    def Operator(self, Operator):
        self._Operator = Operator

    @property
    def Val(self):
        r"""<p>参数名/常量</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._Val

    @Val.setter
    def Val(self, Val):
        self._Val = Val

    @property
    def ValType(self):
        r"""<p>参数类型</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._ValType

    @ValType.setter
    def ValType(self, ValType):
        self._ValType = ValType

    @property
    def InternalField(self):
        r"""<p>内部字段</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: bool
        """
        return self._InternalField

    @InternalField.setter
    def InternalField(self, InternalField):
        self._InternalField = InternalField


    def _deserialize(self, params):
        self._FieldName = params.get("FieldName")
        self._Operator = params.get("Operator")
        self._Val = params.get("Val")
        self._ValType = params.get("ValType")
        self._InternalField = params.get("InternalField")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ServiceDatabaseRespParam(AbstractModel):
    r"""响应参数

    """

    def __init__(self):
        r"""
        :param _FieldName: <p>源字段名称</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type FieldName: str
        :param _Name: <p>目标字段名称</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type Name: str
        """
        self._FieldName = None
        self._Name = None

    @property
    def FieldName(self):
        r"""<p>源字段名称</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._FieldName

    @FieldName.setter
    def FieldName(self, FieldName):
        self._FieldName = FieldName

    @property
    def Name(self):
        r"""<p>目标字段名称</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name


    def _deserialize(self, params):
        self._FieldName = params.get("FieldName")
        self._Name = params.get("Name")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ServiceVO(AbstractModel):
    r"""ServiceVO

    """

    def __init__(self):
        r"""
        :param _InstanceID: <p>实例</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type InstanceID: str
        :param _Name: <p>名称</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type Name: str
        :param _PaasID: <p>里约应用ID</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type PaasID: str
        :param _Description: <p>描述</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type Description: str
        :param _LabelIDs: <p>标签</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type LabelIDs: list of str
        :param _CategoryIDs: <p>目录</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type CategoryIDs: list of str
        :param _AuthType: <p>鉴权方式</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type AuthType: str
        :param _SignType: <p>签名</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type SignType: str
        :param _LoginTypes: <p>登录方式</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type LoginTypes: list of str
        :param _TargetSelect: <p>负载方式</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type TargetSelect: str
        :param _PubPath: <p>公开路径</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type PubPath: str
        :param _RequestMethod: <p>请求方法</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type RequestMethod: str
        :param _TargetHosts: <p>目标服务器</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type TargetHosts: list of TargetHostDTO
        :param _HttpProtocolType: <p>是否https</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type HttpProtocolType: str
        :param _CheckTargetCertsError: <p>证书检查</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type CheckTargetCertsError: bool
        :param _HttpProtocolVersion: <p>http协议类型</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type HttpProtocolVersion: str
        :param _Versions: <p>版本号</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type Versions: list of VersionDTO
        :param _TargetPath: <p>目标路径</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type TargetPath: str
        :param _RequestParamsValidatorStatus: <p>入参</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type RequestParamsValidatorStatus: bool
        :param _RequestParamsValidatorJsonInfoT: <p>入参</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type RequestParamsValidatorJsonInfoT: str
        :param _ResponseParamsValidatorStatus: <p>出参</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type ResponseParamsValidatorStatus: bool
        :param _ResponseParamsValidatorJsonInfoT: <p>出参</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type ResponseParamsValidatorJsonInfoT: str
        :param _InvokeLimitConfigStatus: <p>流量控制</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type InvokeLimitConfigStatus: bool
        :param _InvokeLimitConfig: <p>流量控制</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type InvokeLimitConfig: :class:`tencentcloud.apis.v20240801.models.InvokeLimitConfigDTO`
        :param _HealthCheckStatus: <p>健康检查</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type HealthCheckStatus: bool
        :param _HealthCheckConfig: <p>健康检查</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type HealthCheckConfig: :class:`tencentcloud.apis.v20240801.models.HealthCheckConfigDTO`
        :param _SourceTypeStatus: <p>格式转换</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type SourceTypeStatus: bool
        :param _SourceTypeConfig: <p>格式转换</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type SourceTypeConfig: :class:`tencentcloud.apis.v20240801.models.SourceTypeConfigDTO`
        :param _TokenLimitStatus: <p>是否开启Token限流</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type TokenLimitStatus: bool
        :param _TokenLimitConfig: <p>Token限流配置</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type TokenLimitConfig: :class:`tencentcloud.apis.v20240801.models.TokenLimitConfigDTO`
        :param _TmsStatus: <p>是否开启内容安全</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type TmsStatus: bool
        :param _TmsConfig: <p>内容安全配置</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type TmsConfig: :class:`tencentcloud.apis.v20240801.models.TmsConfigDTO`
        :param _IpWhiteStatus: <p>IP白名单</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type IpWhiteStatus: bool
        :param _IpWhiteList: <p>IP白名单</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type IpWhiteList: list of str
        :param _IpBlackStatus: <p>IP黑名单</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type IpBlackStatus: bool
        :param _IpBlackList: <p>IP黑名单</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type IpBlackList: list of str
        :param _PluginConfigs: <p>插件</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type PluginConfigs: list of PluginConfigDTO
        :param _ID: <p>服务ID</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type ID: str
        :param _Status: <p>状态</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type Status: str
        :param _Url: <p>预览地址</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type Url: str
        :param _App: <p>app</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type App: :class:`tencentcloud.apis.v20240801.models.IDNameVO`
        :param _Catalogs: <p>目录</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type Catalogs: list of IDNameVO
        :param _Labels: <p>标签</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type Labels: list of IDNameVO
        :param _Logins: <p>认证方式</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type Logins: list of IDNameVO
        :param _AuthAppNum: <p>授权数</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type AuthAppNum: int
        :param _CreateTime: <p>创建时间</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type CreateTime: str
        :param _LastUpdateTime: <p>最后修改时间</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type LastUpdateTime: str
        :param _AppID: <p>应用ID</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type AppID: int
        :param _Uin: <p>用户ID</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type Uin: str
        :param _Domain: <p>域名</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type Domain: str
        :param _OpenMessageLogStatus: <p>是否开启报文记录</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type OpenMessageLogStatus: bool
        :param _CurrPaasIDSubscriptionID: <p>订阅页面的当前用户是否订阅了该API</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type CurrPaasIDSubscriptionID: str
        :param _TargetServiceType: <p>目标服务类型 Restful Database Mock</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type TargetServiceType: str
        :param _SqlTemplate: <p>SQL模板</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type SqlTemplate: :class:`tencentcloud.apis.v20240801.models.SqlTemplate`
        :param _TargetHostType: <p>目标Host类型 0 默认 1 vpc</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type TargetHostType: int
        :param _TargetServiceHostType: <p>后端服务类型 0 自定义 原始数据:ip/域名或vpc 1 后端服务 服务组</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type TargetServiceHostType: int
        :param _TargetServerGroupID: <p>后端服务组ID</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type TargetServerGroupID: str
        :param _TargetServerGroup: <p>后端服务组</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type TargetServerGroup: :class:`tencentcloud.apis.v20240801.models.TargetServerGroupDTO`
        :param _CustomHttpHost: <p>自定义host</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type CustomHttpHost: str
        :param _HttpHostType: <p>Http 请求host类型 useRequestHost 保持源请求host targetHost 修正为源站host  customHost 自定义host</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type HttpHostType: str
        :param _MockStatusCode: <p>mock响应状态码</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type MockStatusCode: int
        :param _MockBody: <p>mock响应body</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type MockBody: str
        :param _MockHeaders: <p>mock响应头</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type MockHeaders: list of FieldValueDTO
        :param _PathMatchType: <p>路径匹配类型: prefix 前缀匹配(不送默认); absolute 绝对匹配; regex正则匹配;</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type PathMatchType: str
        :param _CustomMatch: <p>自定义匹配条件</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type CustomMatch: :class:`tencentcloud.apis.v20240801.models.CustomMatch`
        :param _Timeout: <p>请求的超时时间</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type Timeout: int
        :param _McpServerNum: <p>绑定的mcp server数量</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type McpServerNum: int
        :param _CredentialID: <p>凭据ID</p>
        :type CredentialID: str
        :param _CredentialName: <p>凭据名称</p>
        :type CredentialName: str
        :param _RequestProtocolType: <p>访问协议</p><p>枚举值：</p><ul><li>http： http</li><li>https： https</li></ul>
注意：此字段可能返回 null，表示取不到有效值。
        :type RequestProtocolType: str
        """
        self._InstanceID = None
        self._Name = None
        self._PaasID = None
        self._Description = None
        self._LabelIDs = None
        self._CategoryIDs = None
        self._AuthType = None
        self._SignType = None
        self._LoginTypes = None
        self._TargetSelect = None
        self._PubPath = None
        self._RequestMethod = None
        self._TargetHosts = None
        self._HttpProtocolType = None
        self._CheckTargetCertsError = None
        self._HttpProtocolVersion = None
        self._Versions = None
        self._TargetPath = None
        self._RequestParamsValidatorStatus = None
        self._RequestParamsValidatorJsonInfoT = None
        self._ResponseParamsValidatorStatus = None
        self._ResponseParamsValidatorJsonInfoT = None
        self._InvokeLimitConfigStatus = None
        self._InvokeLimitConfig = None
        self._HealthCheckStatus = None
        self._HealthCheckConfig = None
        self._SourceTypeStatus = None
        self._SourceTypeConfig = None
        self._TokenLimitStatus = None
        self._TokenLimitConfig = None
        self._TmsStatus = None
        self._TmsConfig = None
        self._IpWhiteStatus = None
        self._IpWhiteList = None
        self._IpBlackStatus = None
        self._IpBlackList = None
        self._PluginConfigs = None
        self._ID = None
        self._Status = None
        self._Url = None
        self._App = None
        self._Catalogs = None
        self._Labels = None
        self._Logins = None
        self._AuthAppNum = None
        self._CreateTime = None
        self._LastUpdateTime = None
        self._AppID = None
        self._Uin = None
        self._Domain = None
        self._OpenMessageLogStatus = None
        self._CurrPaasIDSubscriptionID = None
        self._TargetServiceType = None
        self._SqlTemplate = None
        self._TargetHostType = None
        self._TargetServiceHostType = None
        self._TargetServerGroupID = None
        self._TargetServerGroup = None
        self._CustomHttpHost = None
        self._HttpHostType = None
        self._MockStatusCode = None
        self._MockBody = None
        self._MockHeaders = None
        self._PathMatchType = None
        self._CustomMatch = None
        self._Timeout = None
        self._McpServerNum = None
        self._CredentialID = None
        self._CredentialName = None
        self._RequestProtocolType = None

    @property
    def InstanceID(self):
        r"""<p>实例</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._InstanceID

    @InstanceID.setter
    def InstanceID(self, InstanceID):
        self._InstanceID = InstanceID

    @property
    def Name(self):
        r"""<p>名称</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def PaasID(self):
        warnings.warn("parameter `PaasID` is deprecated", DeprecationWarning) 

        r"""<p>里约应用ID</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._PaasID

    @PaasID.setter
    def PaasID(self, PaasID):
        warnings.warn("parameter `PaasID` is deprecated", DeprecationWarning) 

        self._PaasID = PaasID

    @property
    def Description(self):
        r"""<p>描述</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._Description

    @Description.setter
    def Description(self, Description):
        self._Description = Description

    @property
    def LabelIDs(self):
        r"""<p>标签</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of str
        """
        return self._LabelIDs

    @LabelIDs.setter
    def LabelIDs(self, LabelIDs):
        self._LabelIDs = LabelIDs

    @property
    def CategoryIDs(self):
        r"""<p>目录</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of str
        """
        return self._CategoryIDs

    @CategoryIDs.setter
    def CategoryIDs(self, CategoryIDs):
        self._CategoryIDs = CategoryIDs

    @property
    def AuthType(self):
        warnings.warn("parameter `AuthType` is deprecated", DeprecationWarning) 

        r"""<p>鉴权方式</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._AuthType

    @AuthType.setter
    def AuthType(self, AuthType):
        warnings.warn("parameter `AuthType` is deprecated", DeprecationWarning) 

        self._AuthType = AuthType

    @property
    def SignType(self):
        warnings.warn("parameter `SignType` is deprecated", DeprecationWarning) 

        r"""<p>签名</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._SignType

    @SignType.setter
    def SignType(self, SignType):
        warnings.warn("parameter `SignType` is deprecated", DeprecationWarning) 

        self._SignType = SignType

    @property
    def LoginTypes(self):
        warnings.warn("parameter `LoginTypes` is deprecated", DeprecationWarning) 

        r"""<p>登录方式</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of str
        """
        return self._LoginTypes

    @LoginTypes.setter
    def LoginTypes(self, LoginTypes):
        warnings.warn("parameter `LoginTypes` is deprecated", DeprecationWarning) 

        self._LoginTypes = LoginTypes

    @property
    def TargetSelect(self):
        r"""<p>负载方式</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._TargetSelect

    @TargetSelect.setter
    def TargetSelect(self, TargetSelect):
        self._TargetSelect = TargetSelect

    @property
    def PubPath(self):
        r"""<p>公开路径</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._PubPath

    @PubPath.setter
    def PubPath(self, PubPath):
        self._PubPath = PubPath

    @property
    def RequestMethod(self):
        r"""<p>请求方法</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._RequestMethod

    @RequestMethod.setter
    def RequestMethod(self, RequestMethod):
        self._RequestMethod = RequestMethod

    @property
    def TargetHosts(self):
        r"""<p>目标服务器</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of TargetHostDTO
        """
        return self._TargetHosts

    @TargetHosts.setter
    def TargetHosts(self, TargetHosts):
        self._TargetHosts = TargetHosts

    @property
    def HttpProtocolType(self):
        r"""<p>是否https</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._HttpProtocolType

    @HttpProtocolType.setter
    def HttpProtocolType(self, HttpProtocolType):
        self._HttpProtocolType = HttpProtocolType

    @property
    def CheckTargetCertsError(self):
        r"""<p>证书检查</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: bool
        """
        return self._CheckTargetCertsError

    @CheckTargetCertsError.setter
    def CheckTargetCertsError(self, CheckTargetCertsError):
        self._CheckTargetCertsError = CheckTargetCertsError

    @property
    def HttpProtocolVersion(self):
        r"""<p>http协议类型</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._HttpProtocolVersion

    @HttpProtocolVersion.setter
    def HttpProtocolVersion(self, HttpProtocolVersion):
        self._HttpProtocolVersion = HttpProtocolVersion

    @property
    def Versions(self):
        r"""<p>版本号</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of VersionDTO
        """
        return self._Versions

    @Versions.setter
    def Versions(self, Versions):
        self._Versions = Versions

    @property
    def TargetPath(self):
        r"""<p>目标路径</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._TargetPath

    @TargetPath.setter
    def TargetPath(self, TargetPath):
        self._TargetPath = TargetPath

    @property
    def RequestParamsValidatorStatus(self):
        r"""<p>入参</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: bool
        """
        return self._RequestParamsValidatorStatus

    @RequestParamsValidatorStatus.setter
    def RequestParamsValidatorStatus(self, RequestParamsValidatorStatus):
        self._RequestParamsValidatorStatus = RequestParamsValidatorStatus

    @property
    def RequestParamsValidatorJsonInfoT(self):
        r"""<p>入参</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._RequestParamsValidatorJsonInfoT

    @RequestParamsValidatorJsonInfoT.setter
    def RequestParamsValidatorJsonInfoT(self, RequestParamsValidatorJsonInfoT):
        self._RequestParamsValidatorJsonInfoT = RequestParamsValidatorJsonInfoT

    @property
    def ResponseParamsValidatorStatus(self):
        r"""<p>出参</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: bool
        """
        return self._ResponseParamsValidatorStatus

    @ResponseParamsValidatorStatus.setter
    def ResponseParamsValidatorStatus(self, ResponseParamsValidatorStatus):
        self._ResponseParamsValidatorStatus = ResponseParamsValidatorStatus

    @property
    def ResponseParamsValidatorJsonInfoT(self):
        r"""<p>出参</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._ResponseParamsValidatorJsonInfoT

    @ResponseParamsValidatorJsonInfoT.setter
    def ResponseParamsValidatorJsonInfoT(self, ResponseParamsValidatorJsonInfoT):
        self._ResponseParamsValidatorJsonInfoT = ResponseParamsValidatorJsonInfoT

    @property
    def InvokeLimitConfigStatus(self):
        r"""<p>流量控制</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: bool
        """
        return self._InvokeLimitConfigStatus

    @InvokeLimitConfigStatus.setter
    def InvokeLimitConfigStatus(self, InvokeLimitConfigStatus):
        self._InvokeLimitConfigStatus = InvokeLimitConfigStatus

    @property
    def InvokeLimitConfig(self):
        r"""<p>流量控制</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: :class:`tencentcloud.apis.v20240801.models.InvokeLimitConfigDTO`
        """
        return self._InvokeLimitConfig

    @InvokeLimitConfig.setter
    def InvokeLimitConfig(self, InvokeLimitConfig):
        self._InvokeLimitConfig = InvokeLimitConfig

    @property
    def HealthCheckStatus(self):
        r"""<p>健康检查</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: bool
        """
        return self._HealthCheckStatus

    @HealthCheckStatus.setter
    def HealthCheckStatus(self, HealthCheckStatus):
        self._HealthCheckStatus = HealthCheckStatus

    @property
    def HealthCheckConfig(self):
        r"""<p>健康检查</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: :class:`tencentcloud.apis.v20240801.models.HealthCheckConfigDTO`
        """
        return self._HealthCheckConfig

    @HealthCheckConfig.setter
    def HealthCheckConfig(self, HealthCheckConfig):
        self._HealthCheckConfig = HealthCheckConfig

    @property
    def SourceTypeStatus(self):
        r"""<p>格式转换</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: bool
        """
        return self._SourceTypeStatus

    @SourceTypeStatus.setter
    def SourceTypeStatus(self, SourceTypeStatus):
        self._SourceTypeStatus = SourceTypeStatus

    @property
    def SourceTypeConfig(self):
        r"""<p>格式转换</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: :class:`tencentcloud.apis.v20240801.models.SourceTypeConfigDTO`
        """
        return self._SourceTypeConfig

    @SourceTypeConfig.setter
    def SourceTypeConfig(self, SourceTypeConfig):
        self._SourceTypeConfig = SourceTypeConfig

    @property
    def TokenLimitStatus(self):
        warnings.warn("parameter `TokenLimitStatus` is deprecated", DeprecationWarning) 

        r"""<p>是否开启Token限流</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: bool
        """
        return self._TokenLimitStatus

    @TokenLimitStatus.setter
    def TokenLimitStatus(self, TokenLimitStatus):
        warnings.warn("parameter `TokenLimitStatus` is deprecated", DeprecationWarning) 

        self._TokenLimitStatus = TokenLimitStatus

    @property
    def TokenLimitConfig(self):
        warnings.warn("parameter `TokenLimitConfig` is deprecated", DeprecationWarning) 

        r"""<p>Token限流配置</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: :class:`tencentcloud.apis.v20240801.models.TokenLimitConfigDTO`
        """
        return self._TokenLimitConfig

    @TokenLimitConfig.setter
    def TokenLimitConfig(self, TokenLimitConfig):
        warnings.warn("parameter `TokenLimitConfig` is deprecated", DeprecationWarning) 

        self._TokenLimitConfig = TokenLimitConfig

    @property
    def TmsStatus(self):
        warnings.warn("parameter `TmsStatus` is deprecated", DeprecationWarning) 

        r"""<p>是否开启内容安全</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: bool
        """
        return self._TmsStatus

    @TmsStatus.setter
    def TmsStatus(self, TmsStatus):
        warnings.warn("parameter `TmsStatus` is deprecated", DeprecationWarning) 

        self._TmsStatus = TmsStatus

    @property
    def TmsConfig(self):
        warnings.warn("parameter `TmsConfig` is deprecated", DeprecationWarning) 

        r"""<p>内容安全配置</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: :class:`tencentcloud.apis.v20240801.models.TmsConfigDTO`
        """
        return self._TmsConfig

    @TmsConfig.setter
    def TmsConfig(self, TmsConfig):
        warnings.warn("parameter `TmsConfig` is deprecated", DeprecationWarning) 

        self._TmsConfig = TmsConfig

    @property
    def IpWhiteStatus(self):
        r"""<p>IP白名单</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: bool
        """
        return self._IpWhiteStatus

    @IpWhiteStatus.setter
    def IpWhiteStatus(self, IpWhiteStatus):
        self._IpWhiteStatus = IpWhiteStatus

    @property
    def IpWhiteList(self):
        r"""<p>IP白名单</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of str
        """
        return self._IpWhiteList

    @IpWhiteList.setter
    def IpWhiteList(self, IpWhiteList):
        self._IpWhiteList = IpWhiteList

    @property
    def IpBlackStatus(self):
        r"""<p>IP黑名单</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: bool
        """
        return self._IpBlackStatus

    @IpBlackStatus.setter
    def IpBlackStatus(self, IpBlackStatus):
        self._IpBlackStatus = IpBlackStatus

    @property
    def IpBlackList(self):
        r"""<p>IP黑名单</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of str
        """
        return self._IpBlackList

    @IpBlackList.setter
    def IpBlackList(self, IpBlackList):
        self._IpBlackList = IpBlackList

    @property
    def PluginConfigs(self):
        r"""<p>插件</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of PluginConfigDTO
        """
        return self._PluginConfigs

    @PluginConfigs.setter
    def PluginConfigs(self, PluginConfigs):
        self._PluginConfigs = PluginConfigs

    @property
    def ID(self):
        r"""<p>服务ID</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID

    @property
    def Status(self):
        r"""<p>状态</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._Status

    @Status.setter
    def Status(self, Status):
        self._Status = Status

    @property
    def Url(self):
        r"""<p>预览地址</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._Url

    @Url.setter
    def Url(self, Url):
        self._Url = Url

    @property
    def App(self):
        r"""<p>app</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: :class:`tencentcloud.apis.v20240801.models.IDNameVO`
        """
        return self._App

    @App.setter
    def App(self, App):
        self._App = App

    @property
    def Catalogs(self):
        r"""<p>目录</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of IDNameVO
        """
        return self._Catalogs

    @Catalogs.setter
    def Catalogs(self, Catalogs):
        self._Catalogs = Catalogs

    @property
    def Labels(self):
        r"""<p>标签</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of IDNameVO
        """
        return self._Labels

    @Labels.setter
    def Labels(self, Labels):
        self._Labels = Labels

    @property
    def Logins(self):
        r"""<p>认证方式</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of IDNameVO
        """
        return self._Logins

    @Logins.setter
    def Logins(self, Logins):
        self._Logins = Logins

    @property
    def AuthAppNum(self):
        r"""<p>授权数</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: int
        """
        return self._AuthAppNum

    @AuthAppNum.setter
    def AuthAppNum(self, AuthAppNum):
        self._AuthAppNum = AuthAppNum

    @property
    def CreateTime(self):
        r"""<p>创建时间</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._CreateTime

    @CreateTime.setter
    def CreateTime(self, CreateTime):
        self._CreateTime = CreateTime

    @property
    def LastUpdateTime(self):
        r"""<p>最后修改时间</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._LastUpdateTime

    @LastUpdateTime.setter
    def LastUpdateTime(self, LastUpdateTime):
        self._LastUpdateTime = LastUpdateTime

    @property
    def AppID(self):
        r"""<p>应用ID</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: int
        """
        return self._AppID

    @AppID.setter
    def AppID(self, AppID):
        self._AppID = AppID

    @property
    def Uin(self):
        r"""<p>用户ID</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._Uin

    @Uin.setter
    def Uin(self, Uin):
        self._Uin = Uin

    @property
    def Domain(self):
        r"""<p>域名</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._Domain

    @Domain.setter
    def Domain(self, Domain):
        self._Domain = Domain

    @property
    def OpenMessageLogStatus(self):
        r"""<p>是否开启报文记录</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: bool
        """
        return self._OpenMessageLogStatus

    @OpenMessageLogStatus.setter
    def OpenMessageLogStatus(self, OpenMessageLogStatus):
        self._OpenMessageLogStatus = OpenMessageLogStatus

    @property
    def CurrPaasIDSubscriptionID(self):
        warnings.warn("parameter `CurrPaasIDSubscriptionID` is deprecated", DeprecationWarning) 

        r"""<p>订阅页面的当前用户是否订阅了该API</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._CurrPaasIDSubscriptionID

    @CurrPaasIDSubscriptionID.setter
    def CurrPaasIDSubscriptionID(self, CurrPaasIDSubscriptionID):
        warnings.warn("parameter `CurrPaasIDSubscriptionID` is deprecated", DeprecationWarning) 

        self._CurrPaasIDSubscriptionID = CurrPaasIDSubscriptionID

    @property
    def TargetServiceType(self):
        r"""<p>目标服务类型 Restful Database Mock</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._TargetServiceType

    @TargetServiceType.setter
    def TargetServiceType(self, TargetServiceType):
        self._TargetServiceType = TargetServiceType

    @property
    def SqlTemplate(self):
        r"""<p>SQL模板</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: :class:`tencentcloud.apis.v20240801.models.SqlTemplate`
        """
        return self._SqlTemplate

    @SqlTemplate.setter
    def SqlTemplate(self, SqlTemplate):
        self._SqlTemplate = SqlTemplate

    @property
    def TargetHostType(self):
        r"""<p>目标Host类型 0 默认 1 vpc</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: int
        """
        return self._TargetHostType

    @TargetHostType.setter
    def TargetHostType(self, TargetHostType):
        self._TargetHostType = TargetHostType

    @property
    def TargetServiceHostType(self):
        r"""<p>后端服务类型 0 自定义 原始数据:ip/域名或vpc 1 后端服务 服务组</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: int
        """
        return self._TargetServiceHostType

    @TargetServiceHostType.setter
    def TargetServiceHostType(self, TargetServiceHostType):
        self._TargetServiceHostType = TargetServiceHostType

    @property
    def TargetServerGroupID(self):
        r"""<p>后端服务组ID</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._TargetServerGroupID

    @TargetServerGroupID.setter
    def TargetServerGroupID(self, TargetServerGroupID):
        self._TargetServerGroupID = TargetServerGroupID

    @property
    def TargetServerGroup(self):
        r"""<p>后端服务组</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: :class:`tencentcloud.apis.v20240801.models.TargetServerGroupDTO`
        """
        return self._TargetServerGroup

    @TargetServerGroup.setter
    def TargetServerGroup(self, TargetServerGroup):
        self._TargetServerGroup = TargetServerGroup

    @property
    def CustomHttpHost(self):
        r"""<p>自定义host</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._CustomHttpHost

    @CustomHttpHost.setter
    def CustomHttpHost(self, CustomHttpHost):
        self._CustomHttpHost = CustomHttpHost

    @property
    def HttpHostType(self):
        r"""<p>Http 请求host类型 useRequestHost 保持源请求host targetHost 修正为源站host  customHost 自定义host</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._HttpHostType

    @HttpHostType.setter
    def HttpHostType(self, HttpHostType):
        self._HttpHostType = HttpHostType

    @property
    def MockStatusCode(self):
        r"""<p>mock响应状态码</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: int
        """
        return self._MockStatusCode

    @MockStatusCode.setter
    def MockStatusCode(self, MockStatusCode):
        self._MockStatusCode = MockStatusCode

    @property
    def MockBody(self):
        r"""<p>mock响应body</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._MockBody

    @MockBody.setter
    def MockBody(self, MockBody):
        self._MockBody = MockBody

    @property
    def MockHeaders(self):
        r"""<p>mock响应头</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of FieldValueDTO
        """
        return self._MockHeaders

    @MockHeaders.setter
    def MockHeaders(self, MockHeaders):
        self._MockHeaders = MockHeaders

    @property
    def PathMatchType(self):
        r"""<p>路径匹配类型: prefix 前缀匹配(不送默认); absolute 绝对匹配; regex正则匹配;</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._PathMatchType

    @PathMatchType.setter
    def PathMatchType(self, PathMatchType):
        self._PathMatchType = PathMatchType

    @property
    def CustomMatch(self):
        r"""<p>自定义匹配条件</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: :class:`tencentcloud.apis.v20240801.models.CustomMatch`
        """
        return self._CustomMatch

    @CustomMatch.setter
    def CustomMatch(self, CustomMatch):
        self._CustomMatch = CustomMatch

    @property
    def Timeout(self):
        r"""<p>请求的超时时间</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: int
        """
        return self._Timeout

    @Timeout.setter
    def Timeout(self, Timeout):
        self._Timeout = Timeout

    @property
    def McpServerNum(self):
        r"""<p>绑定的mcp server数量</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: int
        """
        return self._McpServerNum

    @McpServerNum.setter
    def McpServerNum(self, McpServerNum):
        self._McpServerNum = McpServerNum

    @property
    def CredentialID(self):
        r"""<p>凭据ID</p>
        :rtype: str
        """
        return self._CredentialID

    @CredentialID.setter
    def CredentialID(self, CredentialID):
        self._CredentialID = CredentialID

    @property
    def CredentialName(self):
        r"""<p>凭据名称</p>
        :rtype: str
        """
        return self._CredentialName

    @CredentialName.setter
    def CredentialName(self, CredentialName):
        self._CredentialName = CredentialName

    @property
    def RequestProtocolType(self):
        r"""<p>访问协议</p><p>枚举值：</p><ul><li>http： http</li><li>https： https</li></ul>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._RequestProtocolType

    @RequestProtocolType.setter
    def RequestProtocolType(self, RequestProtocolType):
        self._RequestProtocolType = RequestProtocolType


    def _deserialize(self, params):
        self._InstanceID = params.get("InstanceID")
        self._Name = params.get("Name")
        self._PaasID = params.get("PaasID")
        self._Description = params.get("Description")
        self._LabelIDs = params.get("LabelIDs")
        self._CategoryIDs = params.get("CategoryIDs")
        self._AuthType = params.get("AuthType")
        self._SignType = params.get("SignType")
        self._LoginTypes = params.get("LoginTypes")
        self._TargetSelect = params.get("TargetSelect")
        self._PubPath = params.get("PubPath")
        self._RequestMethod = params.get("RequestMethod")
        if params.get("TargetHosts") is not None:
            self._TargetHosts = []
            for item in params.get("TargetHosts"):
                obj = TargetHostDTO()
                obj._deserialize(item)
                self._TargetHosts.append(obj)
        self._HttpProtocolType = params.get("HttpProtocolType")
        self._CheckTargetCertsError = params.get("CheckTargetCertsError")
        self._HttpProtocolVersion = params.get("HttpProtocolVersion")
        if params.get("Versions") is not None:
            self._Versions = []
            for item in params.get("Versions"):
                obj = VersionDTO()
                obj._deserialize(item)
                self._Versions.append(obj)
        self._TargetPath = params.get("TargetPath")
        self._RequestParamsValidatorStatus = params.get("RequestParamsValidatorStatus")
        self._RequestParamsValidatorJsonInfoT = params.get("RequestParamsValidatorJsonInfoT")
        self._ResponseParamsValidatorStatus = params.get("ResponseParamsValidatorStatus")
        self._ResponseParamsValidatorJsonInfoT = params.get("ResponseParamsValidatorJsonInfoT")
        self._InvokeLimitConfigStatus = params.get("InvokeLimitConfigStatus")
        if params.get("InvokeLimitConfig") is not None:
            self._InvokeLimitConfig = InvokeLimitConfigDTO()
            self._InvokeLimitConfig._deserialize(params.get("InvokeLimitConfig"))
        self._HealthCheckStatus = params.get("HealthCheckStatus")
        if params.get("HealthCheckConfig") is not None:
            self._HealthCheckConfig = HealthCheckConfigDTO()
            self._HealthCheckConfig._deserialize(params.get("HealthCheckConfig"))
        self._SourceTypeStatus = params.get("SourceTypeStatus")
        if params.get("SourceTypeConfig") is not None:
            self._SourceTypeConfig = SourceTypeConfigDTO()
            self._SourceTypeConfig._deserialize(params.get("SourceTypeConfig"))
        self._TokenLimitStatus = params.get("TokenLimitStatus")
        if params.get("TokenLimitConfig") is not None:
            self._TokenLimitConfig = TokenLimitConfigDTO()
            self._TokenLimitConfig._deserialize(params.get("TokenLimitConfig"))
        self._TmsStatus = params.get("TmsStatus")
        if params.get("TmsConfig") is not None:
            self._TmsConfig = TmsConfigDTO()
            self._TmsConfig._deserialize(params.get("TmsConfig"))
        self._IpWhiteStatus = params.get("IpWhiteStatus")
        self._IpWhiteList = params.get("IpWhiteList")
        self._IpBlackStatus = params.get("IpBlackStatus")
        self._IpBlackList = params.get("IpBlackList")
        if params.get("PluginConfigs") is not None:
            self._PluginConfigs = []
            for item in params.get("PluginConfigs"):
                obj = PluginConfigDTO()
                obj._deserialize(item)
                self._PluginConfigs.append(obj)
        self._ID = params.get("ID")
        self._Status = params.get("Status")
        self._Url = params.get("Url")
        if params.get("App") is not None:
            self._App = IDNameVO()
            self._App._deserialize(params.get("App"))
        if params.get("Catalogs") is not None:
            self._Catalogs = []
            for item in params.get("Catalogs"):
                obj = IDNameVO()
                obj._deserialize(item)
                self._Catalogs.append(obj)
        if params.get("Labels") is not None:
            self._Labels = []
            for item in params.get("Labels"):
                obj = IDNameVO()
                obj._deserialize(item)
                self._Labels.append(obj)
        if params.get("Logins") is not None:
            self._Logins = []
            for item in params.get("Logins"):
                obj = IDNameVO()
                obj._deserialize(item)
                self._Logins.append(obj)
        self._AuthAppNum = params.get("AuthAppNum")
        self._CreateTime = params.get("CreateTime")
        self._LastUpdateTime = params.get("LastUpdateTime")
        self._AppID = params.get("AppID")
        self._Uin = params.get("Uin")
        self._Domain = params.get("Domain")
        self._OpenMessageLogStatus = params.get("OpenMessageLogStatus")
        self._CurrPaasIDSubscriptionID = params.get("CurrPaasIDSubscriptionID")
        self._TargetServiceType = params.get("TargetServiceType")
        if params.get("SqlTemplate") is not None:
            self._SqlTemplate = SqlTemplate()
            self._SqlTemplate._deserialize(params.get("SqlTemplate"))
        self._TargetHostType = params.get("TargetHostType")
        self._TargetServiceHostType = params.get("TargetServiceHostType")
        self._TargetServerGroupID = params.get("TargetServerGroupID")
        if params.get("TargetServerGroup") is not None:
            self._TargetServerGroup = TargetServerGroupDTO()
            self._TargetServerGroup._deserialize(params.get("TargetServerGroup"))
        self._CustomHttpHost = params.get("CustomHttpHost")
        self._HttpHostType = params.get("HttpHostType")
        self._MockStatusCode = params.get("MockStatusCode")
        self._MockBody = params.get("MockBody")
        if params.get("MockHeaders") is not None:
            self._MockHeaders = []
            for item in params.get("MockHeaders"):
                obj = FieldValueDTO()
                obj._deserialize(item)
                self._MockHeaders.append(obj)
        self._PathMatchType = params.get("PathMatchType")
        if params.get("CustomMatch") is not None:
            self._CustomMatch = CustomMatch()
            self._CustomMatch._deserialize(params.get("CustomMatch"))
        self._Timeout = params.get("Timeout")
        self._McpServerNum = params.get("McpServerNum")
        self._CredentialID = params.get("CredentialID")
        self._CredentialName = params.get("CredentialName")
        self._RequestProtocolType = params.get("RequestProtocolType")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class SimpleCondition(AbstractModel):
    r"""匹配条件请求参数

    """

    def __init__(self):
        r"""
        :param _Key: <p>字段名</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type Key: str
        :param _Condition: <p>匹配方式: eq 等于;ne 不等于;regex 正则;</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type Condition: str
        :param _Value: <p>字段值 或正则表达式</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type Value: str
        """
        self._Key = None
        self._Condition = None
        self._Value = None

    @property
    def Key(self):
        r"""<p>字段名</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._Key

    @Key.setter
    def Key(self, Key):
        self._Key = Key

    @property
    def Condition(self):
        r"""<p>匹配方式: eq 等于;ne 不等于;regex 正则;</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._Condition

    @Condition.setter
    def Condition(self, Condition):
        self._Condition = Condition

    @property
    def Value(self):
        r"""<p>字段值 或正则表达式</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._Value

    @Value.setter
    def Value(self, Value):
        self._Value = Value


    def _deserialize(self, params):
        self._Key = params.get("Key")
        self._Condition = params.get("Condition")
        self._Value = params.get("Value")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class SourceTypeConfigDTO(AbstractModel):
    r"""SourceTypeConfigDTO

    """

    def __init__(self):
        r"""
        :param _ReqSourceType: json xml urlencoded amf0 amf3 hessian1 hessian2

注意：此字段可能返回 null，表示取不到有效值。
        :type ReqSourceType: str
        :param _ReqTargetType: json xml urlencoded amf0 amf3 hessian1 hessian2

注意：此字段可能返回 null，表示取不到有效值。
        :type ReqTargetType: str
        :param _ResSourceType: json xml urlencoded amf0 amf3 hessian1 hessian2

注意：此字段可能返回 null，表示取不到有效值。
        :type ResSourceType: str
        :param _ResTargetType: json xml urlencoded amf0 amf3 hessian1 hessian2

注意：此字段可能返回 null，表示取不到有效值。
        :type ResTargetType: str
        """
        self._ReqSourceType = None
        self._ReqTargetType = None
        self._ResSourceType = None
        self._ResTargetType = None

    @property
    def ReqSourceType(self):
        r"""json xml urlencoded amf0 amf3 hessian1 hessian2

注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._ReqSourceType

    @ReqSourceType.setter
    def ReqSourceType(self, ReqSourceType):
        self._ReqSourceType = ReqSourceType

    @property
    def ReqTargetType(self):
        r"""json xml urlencoded amf0 amf3 hessian1 hessian2

注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._ReqTargetType

    @ReqTargetType.setter
    def ReqTargetType(self, ReqTargetType):
        self._ReqTargetType = ReqTargetType

    @property
    def ResSourceType(self):
        r"""json xml urlencoded amf0 amf3 hessian1 hessian2

注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._ResSourceType

    @ResSourceType.setter
    def ResSourceType(self, ResSourceType):
        self._ResSourceType = ResSourceType

    @property
    def ResTargetType(self):
        r"""json xml urlencoded amf0 amf3 hessian1 hessian2

注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._ResTargetType

    @ResTargetType.setter
    def ResTargetType(self, ResTargetType):
        self._ResTargetType = ResTargetType


    def _deserialize(self, params):
        self._ReqSourceType = params.get("ReqSourceType")
        self._ReqTargetType = params.get("ReqTargetType")
        self._ResSourceType = params.get("ResSourceType")
        self._ResTargetType = params.get("ResTargetType")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class SqlTemplate(AbstractModel):
    r"""SqlTemplate SQL模板

    """

    def __init__(self):
        r"""
        :param _DbConfigMode: <p>配置方式  script  脚本 wizard 向导</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type DbConfigMode: str
        :param _DataSourceID: <p>数据源ID</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type DataSourceID: str
        :param _Sql: <p>Sql代码</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type Sql: str
        :param _WizardConfig: <p>向导模式配置</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type WizardConfig: :class:`tencentcloud.apis.v20240801.models.WizardConfig`
        """
        self._DbConfigMode = None
        self._DataSourceID = None
        self._Sql = None
        self._WizardConfig = None

    @property
    def DbConfigMode(self):
        r"""<p>配置方式  script  脚本 wizard 向导</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._DbConfigMode

    @DbConfigMode.setter
    def DbConfigMode(self, DbConfigMode):
        self._DbConfigMode = DbConfigMode

    @property
    def DataSourceID(self):
        r"""<p>数据源ID</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._DataSourceID

    @DataSourceID.setter
    def DataSourceID(self, DataSourceID):
        self._DataSourceID = DataSourceID

    @property
    def Sql(self):
        r"""<p>Sql代码</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._Sql

    @Sql.setter
    def Sql(self, Sql):
        self._Sql = Sql

    @property
    def WizardConfig(self):
        r"""<p>向导模式配置</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: :class:`tencentcloud.apis.v20240801.models.WizardConfig`
        """
        return self._WizardConfig

    @WizardConfig.setter
    def WizardConfig(self, WizardConfig):
        self._WizardConfig = WizardConfig


    def _deserialize(self, params):
        self._DbConfigMode = params.get("DbConfigMode")
        self._DataSourceID = params.get("DataSourceID")
        self._Sql = params.get("Sql")
        if params.get("WizardConfig") is not None:
            self._WizardConfig = WizardConfig()
            self._WizardConfig._deserialize(params.get("WizardConfig"))
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class StartEndTime(AbstractModel):
    r"""开始结束时间结构体

    """

    def __init__(self):
        r"""
        :param _StartTime: 开始时间
注意：此字段可能返回 null，表示取不到有效值。
        :type StartTime: str
        :param _EndTime: 结束时间
注意：此字段可能返回 null，表示取不到有效值。
        :type EndTime: str
        """
        self._StartTime = None
        self._EndTime = None

    @property
    def StartTime(self):
        r"""开始时间
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._StartTime

    @StartTime.setter
    def StartTime(self, StartTime):
        self._StartTime = StartTime

    @property
    def EndTime(self):
        r"""结束时间
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._EndTime

    @EndTime.setter
    def EndTime(self, EndTime):
        self._EndTime = EndTime


    def _deserialize(self, params):
        self._StartTime = params.get("StartTime")
        self._EndTime = params.get("EndTime")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class TargetHostDTO(AbstractModel):
    r"""TargetHostDTO

    """

    def __init__(self):
        r"""
        :param _Host: 服务器
注意：此字段可能返回 null，表示取不到有效值。
        :type Host: str
        :param _Rank: 权重
注意：此字段可能返回 null，表示取不到有效值。
        :type Rank: int
        """
        self._Host = None
        self._Rank = None

    @property
    def Host(self):
        r"""服务器
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._Host

    @Host.setter
    def Host(self, Host):
        self._Host = Host

    @property
    def Rank(self):
        r"""权重
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: int
        """
        return self._Rank

    @Rank.setter
    def Rank(self, Rank):
        self._Rank = Rank


    def _deserialize(self, params):
        self._Host = params.get("Host")
        self._Rank = params.get("Rank")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class TargetModelDTO(AbstractModel):
    r"""模板模型

    """

    def __init__(self):
        r"""
        :param _ID: 模型ID
        :type ID: str
        :param _Name: 匹配名称
        :type Name: str
        :param _Rank: 权重
        :type Rank: int
        """
        self._ID = None
        self._Name = None
        self._Rank = None

    @property
    def ID(self):
        r"""模型ID
        :rtype: str
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID

    @property
    def Name(self):
        r"""匹配名称
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def Rank(self):
        r"""权重
        :rtype: int
        """
        return self._Rank

    @Rank.setter
    def Rank(self, Rank):
        self._Rank = Rank


    def _deserialize(self, params):
        self._ID = params.get("ID")
        self._Name = params.get("Name")
        self._Rank = params.get("Rank")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class TargetServerGroupDTO(AbstractModel):
    r"""后端服务组DTO

    """

    def __init__(self):
        r"""
        :param _ID: <p>后端服务组ID</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type ID: str
        :param _Name: <p>名称</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type Name: str
        :param _TargetHosts: <p>目标服务器列表</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type TargetHosts: list of TargetHostDTO
        :param _TargetHostType: <p>目标Host类型 0 默认 1 vpc</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type TargetHostType: int
        :param _ServiceCount: <p>关联的服务数量</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type ServiceCount: int
        :param _CreateTime: <p>创建时间</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type CreateTime: str
        """
        self._ID = None
        self._Name = None
        self._TargetHosts = None
        self._TargetHostType = None
        self._ServiceCount = None
        self._CreateTime = None

    @property
    def ID(self):
        r"""<p>后端服务组ID</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID

    @property
    def Name(self):
        r"""<p>名称</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def TargetHosts(self):
        r"""<p>目标服务器列表</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of TargetHostDTO
        """
        return self._TargetHosts

    @TargetHosts.setter
    def TargetHosts(self, TargetHosts):
        self._TargetHosts = TargetHosts

    @property
    def TargetHostType(self):
        r"""<p>目标Host类型 0 默认 1 vpc</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: int
        """
        return self._TargetHostType

    @TargetHostType.setter
    def TargetHostType(self, TargetHostType):
        self._TargetHostType = TargetHostType

    @property
    def ServiceCount(self):
        r"""<p>关联的服务数量</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: int
        """
        return self._ServiceCount

    @ServiceCount.setter
    def ServiceCount(self, ServiceCount):
        self._ServiceCount = ServiceCount

    @property
    def CreateTime(self):
        r"""<p>创建时间</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._CreateTime

    @CreateTime.setter
    def CreateTime(self, CreateTime):
        self._CreateTime = CreateTime


    def _deserialize(self, params):
        self._ID = params.get("ID")
        self._Name = params.get("Name")
        if params.get("TargetHosts") is not None:
            self._TargetHosts = []
            for item in params.get("TargetHosts"):
                obj = TargetHostDTO()
                obj._deserialize(item)
                self._TargetHosts.append(obj)
        self._TargetHostType = params.get("TargetHostType")
        self._ServiceCount = params.get("ServiceCount")
        self._CreateTime = params.get("CreateTime")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class TaskComplexityRouteDTO(AbstractModel):
    r"""任务复杂度路由参数

    """

    def __init__(self):
        r"""
        :param _ComplexityBias: <p>倾向度</p><p>取值范围：[0, 1]</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type ComplexityBias: float
        :param _SimpleTargetModels: <p>简单模型</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type SimpleTargetModels: list of TargetModelDTO
        :param _ComplexTargetModels: <p>复杂模型</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type ComplexTargetModels: list of TargetModelDTO
        """
        self._ComplexityBias = None
        self._SimpleTargetModels = None
        self._ComplexTargetModels = None

    @property
    def ComplexityBias(self):
        r"""<p>倾向度</p><p>取值范围：[0, 1]</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: float
        """
        return self._ComplexityBias

    @ComplexityBias.setter
    def ComplexityBias(self, ComplexityBias):
        self._ComplexityBias = ComplexityBias

    @property
    def SimpleTargetModels(self):
        r"""<p>简单模型</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of TargetModelDTO
        """
        return self._SimpleTargetModels

    @SimpleTargetModels.setter
    def SimpleTargetModels(self, SimpleTargetModels):
        self._SimpleTargetModels = SimpleTargetModels

    @property
    def ComplexTargetModels(self):
        r"""<p>复杂模型</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of TargetModelDTO
        """
        return self._ComplexTargetModels

    @ComplexTargetModels.setter
    def ComplexTargetModels(self, ComplexTargetModels):
        self._ComplexTargetModels = ComplexTargetModels


    def _deserialize(self, params):
        self._ComplexityBias = params.get("ComplexityBias")
        if params.get("SimpleTargetModels") is not None:
            self._SimpleTargetModels = []
            for item in params.get("SimpleTargetModels"):
                obj = TargetModelDTO()
                obj._deserialize(item)
                self._SimpleTargetModels.append(obj)
        if params.get("ComplexTargetModels") is not None:
            self._ComplexTargetModels = []
            for item in params.get("ComplexTargetModels"):
                obj = TargetModelDTO()
                obj._deserialize(item)
                self._ComplexTargetModels.append(obj)
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class TimeRange(AbstractModel):
    r"""时间区间配置

    """

    def __init__(self):
        r"""
        :param _Start: <p>起始时间</p><p>参数格式：格式：09:00:00</p>
        :type Start: str
        :param _End: <p>结束时间</p><p>参数格式：格式：12:00:00</p>
        :type End: str
        """
        self._Start = None
        self._End = None

    @property
    def Start(self):
        r"""<p>起始时间</p><p>参数格式：格式：09:00:00</p>
        :rtype: str
        """
        return self._Start

    @Start.setter
    def Start(self, Start):
        self._Start = Start

    @property
    def End(self):
        r"""<p>结束时间</p><p>参数格式：格式：12:00:00</p>
        :rtype: str
        """
        return self._End

    @End.setter
    def End(self, End):
        self._End = End


    def _deserialize(self, params):
        self._Start = params.get("Start")
        self._End = params.get("End")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class TmsConfigDTO(AbstractModel):
    r"""内容安全配置

    """

    def __init__(self):
        r"""
        :param _Scope: <p>检测范围,请求/响应</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type Scope: list of str
        :param _Mode: <p>检测形式</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type Mode: str
        :param _Action: <p>执行动作</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type Action: str
        :param _MergeCount: <p>合并请求检测event数，联动Mode字段sync</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type MergeCount: int
        :param _BizType: <p>风控策略</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type BizType: str
        :param _InterceptMessage: <p>响应拦截内容</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type InterceptMessage: str
        :param _ContextScope: <p>检测上下文</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type ContextScope: str
        """
        self._Scope = None
        self._Mode = None
        self._Action = None
        self._MergeCount = None
        self._BizType = None
        self._InterceptMessage = None
        self._ContextScope = None

    @property
    def Scope(self):
        r"""<p>检测范围,请求/响应</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of str
        """
        return self._Scope

    @Scope.setter
    def Scope(self, Scope):
        self._Scope = Scope

    @property
    def Mode(self):
        r"""<p>检测形式</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._Mode

    @Mode.setter
    def Mode(self, Mode):
        self._Mode = Mode

    @property
    def Action(self):
        r"""<p>执行动作</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._Action

    @Action.setter
    def Action(self, Action):
        self._Action = Action

    @property
    def MergeCount(self):
        r"""<p>合并请求检测event数，联动Mode字段sync</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: int
        """
        return self._MergeCount

    @MergeCount.setter
    def MergeCount(self, MergeCount):
        self._MergeCount = MergeCount

    @property
    def BizType(self):
        r"""<p>风控策略</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._BizType

    @BizType.setter
    def BizType(self, BizType):
        self._BizType = BizType

    @property
    def InterceptMessage(self):
        r"""<p>响应拦截内容</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._InterceptMessage

    @InterceptMessage.setter
    def InterceptMessage(self, InterceptMessage):
        self._InterceptMessage = InterceptMessage

    @property
    def ContextScope(self):
        r"""<p>检测上下文</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._ContextScope

    @ContextScope.setter
    def ContextScope(self, ContextScope):
        self._ContextScope = ContextScope


    def _deserialize(self, params):
        self._Scope = params.get("Scope")
        self._Mode = params.get("Mode")
        self._Action = params.get("Action")
        self._MergeCount = params.get("MergeCount")
        self._BizType = params.get("BizType")
        self._InterceptMessage = params.get("InterceptMessage")
        self._ContextScope = params.get("ContextScope")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class TokenLengthRouteDTO(AbstractModel):
    r"""token长度路由参数

    """

    def __init__(self):
        r"""
        :param _MinTokens: <p>Token 区间下限</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type MinTokens: int
        :param _MaxTokens: <p>Token 区间上限</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type MaxTokens: int
        :param _TargetModels: <p>模型</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type TargetModels: list of TargetModelDTO
        """
        self._MinTokens = None
        self._MaxTokens = None
        self._TargetModels = None

    @property
    def MinTokens(self):
        r"""<p>Token 区间下限</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: int
        """
        return self._MinTokens

    @MinTokens.setter
    def MinTokens(self, MinTokens):
        self._MinTokens = MinTokens

    @property
    def MaxTokens(self):
        r"""<p>Token 区间上限</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: int
        """
        return self._MaxTokens

    @MaxTokens.setter
    def MaxTokens(self, MaxTokens):
        self._MaxTokens = MaxTokens

    @property
    def TargetModels(self):
        r"""<p>模型</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of TargetModelDTO
        """
        return self._TargetModels

    @TargetModels.setter
    def TargetModels(self, TargetModels):
        self._TargetModels = TargetModels


    def _deserialize(self, params):
        self._MinTokens = params.get("MinTokens")
        self._MaxTokens = params.get("MaxTokens")
        if params.get("TargetModels") is not None:
            self._TargetModels = []
            for item in params.get("TargetModels"):
                obj = TargetModelDTO()
                obj._deserialize(item)
                self._TargetModels.append(obj)
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class TokenLimitConfigDTO(AbstractModel):
    r"""Token限流配置

    """

    def __init__(self):
        r"""
        :param _Type: <p>限流类型</p><p>枚举值：</p><ul><li>minute： 时间窗口</li><li>day： 自然日</li><li>month： 自然月</li></ul>
注意：此字段可能返回 null，表示取不到有效值。
        :type Type: str
        :param _LimitRequestBody: <p>单次请求上限，k</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type LimitRequestBody: int
        :param _LimitWindows: <p>累次token总量消耗上限</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type LimitWindows: list of LimitWindowsDTO
        """
        self._Type = None
        self._LimitRequestBody = None
        self._LimitWindows = None

    @property
    def Type(self):
        warnings.warn("parameter `Type` is deprecated", DeprecationWarning) 

        r"""<p>限流类型</p><p>枚举值：</p><ul><li>minute： 时间窗口</li><li>day： 自然日</li><li>month： 自然月</li></ul>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._Type

    @Type.setter
    def Type(self, Type):
        warnings.warn("parameter `Type` is deprecated", DeprecationWarning) 

        self._Type = Type

    @property
    def LimitRequestBody(self):
        r"""<p>单次请求上限，k</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: int
        """
        return self._LimitRequestBody

    @LimitRequestBody.setter
    def LimitRequestBody(self, LimitRequestBody):
        self._LimitRequestBody = LimitRequestBody

    @property
    def LimitWindows(self):
        r"""<p>累次token总量消耗上限</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of LimitWindowsDTO
        """
        return self._LimitWindows

    @LimitWindows.setter
    def LimitWindows(self, LimitWindows):
        self._LimitWindows = LimitWindows


    def _deserialize(self, params):
        self._Type = params.get("Type")
        self._LimitRequestBody = params.get("LimitRequestBody")
        if params.get("LimitWindows") is not None:
            self._LimitWindows = []
            for item in params.get("LimitWindows"):
                obj = LimitWindowsDTO()
                obj._deserialize(item)
                self._LimitWindows.append(obj)
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ToolConfigDTO(AbstractModel):
    r"""工具级别配置

    """

    def __init__(self):
        r"""
        :param _ToolName: 工具名称
注意：此字段可能返回 null，表示取不到有效值。
        :type ToolName: str
        :param _InvokeLimitConfigStatus: 是否开启限流配置
        :type InvokeLimitConfigStatus: bool
        :param _InvokeLimitConfig: 限流配置
        :type InvokeLimitConfig: :class:`tencentcloud.apis.v20240801.models.InvokeLimitConfigDTO`
        :param _McpSecurityRules: 绑定安全规则
        :type McpSecurityRules: list of BindMcpSecurityRuleDTO
        """
        self._ToolName = None
        self._InvokeLimitConfigStatus = None
        self._InvokeLimitConfig = None
        self._McpSecurityRules = None

    @property
    def ToolName(self):
        r"""工具名称
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._ToolName

    @ToolName.setter
    def ToolName(self, ToolName):
        self._ToolName = ToolName

    @property
    def InvokeLimitConfigStatus(self):
        r"""是否开启限流配置
        :rtype: bool
        """
        return self._InvokeLimitConfigStatus

    @InvokeLimitConfigStatus.setter
    def InvokeLimitConfigStatus(self, InvokeLimitConfigStatus):
        self._InvokeLimitConfigStatus = InvokeLimitConfigStatus

    @property
    def InvokeLimitConfig(self):
        r"""限流配置
        :rtype: :class:`tencentcloud.apis.v20240801.models.InvokeLimitConfigDTO`
        """
        return self._InvokeLimitConfig

    @InvokeLimitConfig.setter
    def InvokeLimitConfig(self, InvokeLimitConfig):
        self._InvokeLimitConfig = InvokeLimitConfig

    @property
    def McpSecurityRules(self):
        r"""绑定安全规则
        :rtype: list of BindMcpSecurityRuleDTO
        """
        return self._McpSecurityRules

    @McpSecurityRules.setter
    def McpSecurityRules(self, McpSecurityRules):
        self._McpSecurityRules = McpSecurityRules


    def _deserialize(self, params):
        self._ToolName = params.get("ToolName")
        self._InvokeLimitConfigStatus = params.get("InvokeLimitConfigStatus")
        if params.get("InvokeLimitConfig") is not None:
            self._InvokeLimitConfig = InvokeLimitConfigDTO()
            self._InvokeLimitConfig._deserialize(params.get("InvokeLimitConfig"))
        if params.get("McpSecurityRules") is not None:
            self._McpSecurityRules = []
            for item in params.get("McpSecurityRules"):
                obj = BindMcpSecurityRuleDTO()
                obj._deserialize(item)
                self._McpSecurityRules.append(obj)
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ToolConfigVO(AbstractModel):
    r"""工具配置响应

    """

    def __init__(self):
        r"""
        :param _ToolName: 工具名称
        :type ToolName: str
        :param _InvokeLimitConfigStatus: 是否开启限流配置
        :type InvokeLimitConfigStatus: bool
        :param _InvokeLimitConfig: 限流配置
        :type InvokeLimitConfig: :class:`tencentcloud.apis.v20240801.models.InvokeLimitConfigDTO`
        :param _McpSecurityRules: 绑定安全规则（响应）
        :type McpSecurityRules: list of BindMcpSecurityRuleVO
        """
        self._ToolName = None
        self._InvokeLimitConfigStatus = None
        self._InvokeLimitConfig = None
        self._McpSecurityRules = None

    @property
    def ToolName(self):
        r"""工具名称
        :rtype: str
        """
        return self._ToolName

    @ToolName.setter
    def ToolName(self, ToolName):
        self._ToolName = ToolName

    @property
    def InvokeLimitConfigStatus(self):
        r"""是否开启限流配置
        :rtype: bool
        """
        return self._InvokeLimitConfigStatus

    @InvokeLimitConfigStatus.setter
    def InvokeLimitConfigStatus(self, InvokeLimitConfigStatus):
        self._InvokeLimitConfigStatus = InvokeLimitConfigStatus

    @property
    def InvokeLimitConfig(self):
        r"""限流配置
        :rtype: :class:`tencentcloud.apis.v20240801.models.InvokeLimitConfigDTO`
        """
        return self._InvokeLimitConfig

    @InvokeLimitConfig.setter
    def InvokeLimitConfig(self, InvokeLimitConfig):
        self._InvokeLimitConfig = InvokeLimitConfig

    @property
    def McpSecurityRules(self):
        r"""绑定安全规则（响应）
        :rtype: list of BindMcpSecurityRuleVO
        """
        return self._McpSecurityRules

    @McpSecurityRules.setter
    def McpSecurityRules(self, McpSecurityRules):
        self._McpSecurityRules = McpSecurityRules


    def _deserialize(self, params):
        self._ToolName = params.get("ToolName")
        self._InvokeLimitConfigStatus = params.get("InvokeLimitConfigStatus")
        if params.get("InvokeLimitConfig") is not None:
            self._InvokeLimitConfig = InvokeLimitConfigDTO()
            self._InvokeLimitConfig._deserialize(params.get("InvokeLimitConfig"))
        if params.get("McpSecurityRules") is not None:
            self._McpSecurityRules = []
            for item in params.get("McpSecurityRules"):
                obj = BindMcpSecurityRuleVO()
                obj._deserialize(item)
                self._McpSecurityRules.append(obj)
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class VersionDTO(AbstractModel):
    r"""VersionDTO

    """

    def __init__(self):
        r"""
        :param _Version: Version版本
注意：此字段可能返回 null，表示取不到有效值。
        :type Version: str
        :param _TargetPath: 目标路径
注意：此字段可能返回 null，表示取不到有效值。
        :type TargetPath: str
        """
        self._Version = None
        self._TargetPath = None

    @property
    def Version(self):
        r"""Version版本
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._Version

    @Version.setter
    def Version(self, Version):
        self._Version = Version

    @property
    def TargetPath(self):
        r"""目标路径
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._TargetPath

    @TargetPath.setter
    def TargetPath(self, TargetPath):
        self._TargetPath = TargetPath


    def _deserialize(self, params):
        self._Version = params.get("Version")
        self._TargetPath = params.get("TargetPath")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class WizardConfig(AbstractModel):
    r"""WizardConfig 向导模式配置

    """

    def __init__(self):
        r"""
        :param _DbTable: <p>表名</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type DbTable: str
        :param _DbEnablePaging: <p>是否分页</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type DbEnablePaging: bool
        :param _DbReqParams: <p>请求参数</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type DbReqParams: list of ServiceDatabaseReqParam
        :param _DbRespParams: <p>响应参数</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type DbRespParams: list of ServiceDatabaseRespParam
        :param _DbOrdParams: <p>排序参数</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type DbOrdParams: list of ServiceDatabaseOrderParam
        :param _DbEnableMappingResp: <p>是否开启出参映射</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type DbEnableMappingResp: bool
        """
        self._DbTable = None
        self._DbEnablePaging = None
        self._DbReqParams = None
        self._DbRespParams = None
        self._DbOrdParams = None
        self._DbEnableMappingResp = None

    @property
    def DbTable(self):
        r"""<p>表名</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._DbTable

    @DbTable.setter
    def DbTable(self, DbTable):
        self._DbTable = DbTable

    @property
    def DbEnablePaging(self):
        r"""<p>是否分页</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: bool
        """
        return self._DbEnablePaging

    @DbEnablePaging.setter
    def DbEnablePaging(self, DbEnablePaging):
        self._DbEnablePaging = DbEnablePaging

    @property
    def DbReqParams(self):
        r"""<p>请求参数</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of ServiceDatabaseReqParam
        """
        return self._DbReqParams

    @DbReqParams.setter
    def DbReqParams(self, DbReqParams):
        self._DbReqParams = DbReqParams

    @property
    def DbRespParams(self):
        r"""<p>响应参数</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of ServiceDatabaseRespParam
        """
        return self._DbRespParams

    @DbRespParams.setter
    def DbRespParams(self, DbRespParams):
        self._DbRespParams = DbRespParams

    @property
    def DbOrdParams(self):
        r"""<p>排序参数</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of ServiceDatabaseOrderParam
        """
        return self._DbOrdParams

    @DbOrdParams.setter
    def DbOrdParams(self, DbOrdParams):
        self._DbOrdParams = DbOrdParams

    @property
    def DbEnableMappingResp(self):
        r"""<p>是否开启出参映射</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: bool
        """
        return self._DbEnableMappingResp

    @DbEnableMappingResp.setter
    def DbEnableMappingResp(self, DbEnableMappingResp):
        self._DbEnableMappingResp = DbEnableMappingResp


    def _deserialize(self, params):
        self._DbTable = params.get("DbTable")
        self._DbEnablePaging = params.get("DbEnablePaging")
        if params.get("DbReqParams") is not None:
            self._DbReqParams = []
            for item in params.get("DbReqParams"):
                obj = ServiceDatabaseReqParam()
                obj._deserialize(item)
                self._DbReqParams.append(obj)
        if params.get("DbRespParams") is not None:
            self._DbRespParams = []
            for item in params.get("DbRespParams"):
                obj = ServiceDatabaseRespParam()
                obj._deserialize(item)
                self._DbRespParams.append(obj)
        if params.get("DbOrdParams") is not None:
            self._DbOrdParams = []
            for item in params.get("DbOrdParams"):
                obj = ServiceDatabaseOrderParam()
                obj._deserialize(item)
                self._DbOrdParams.append(obj)
        self._DbEnableMappingResp = params.get("DbEnableMappingResp")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        