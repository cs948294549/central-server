# -*- coding: utf8 -*-
# Copyright (c) 2017-2025 Tencent. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import warnings

from tencentcloud.common.abstract_model import AbstractModel


class ActionAlterCkUserRequest(AbstractModel):
    r"""ActionAlterCkUser请求参数结构体

    """

    def __init__(self):
        r"""
        :param _UserInfo: 用户信息
        :type UserInfo: :class:`tencentcloud.cdwch.v20200915.models.CkUserAlterInfo`
        :param _ApiType: api接口类型，
AddSystemUser新增用户，UpdateSystemUser，修改用户
        :type ApiType: str
        """
        self._UserInfo = None
        self._ApiType = None

    @property
    def UserInfo(self):
        r"""用户信息
        :rtype: :class:`tencentcloud.cdwch.v20200915.models.CkUserAlterInfo`
        """
        return self._UserInfo

    @UserInfo.setter
    def UserInfo(self, UserInfo):
        self._UserInfo = UserInfo

    @property
    def ApiType(self):
        r"""api接口类型，
AddSystemUser新增用户，UpdateSystemUser，修改用户
        :rtype: str
        """
        return self._ApiType

    @ApiType.setter
    def ApiType(self, ApiType):
        self._ApiType = ApiType


    def _deserialize(self, params):
        if params.get("UserInfo") is not None:
            self._UserInfo = CkUserAlterInfo()
            self._UserInfo._deserialize(params.get("UserInfo"))
        self._ApiType = params.get("ApiType")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ActionAlterCkUserResponse(AbstractModel):
    r"""ActionAlterCkUser返回参数结构体

    """

    def __init__(self):
        r"""
        :param _ErrMsg: 错误信息
        :type ErrMsg: str
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._ErrMsg = None
        self._RequestId = None

    @property
    def ErrMsg(self):
        r"""错误信息
        :rtype: str
        """
        return self._ErrMsg

    @ErrMsg.setter
    def ErrMsg(self, ErrMsg):
        self._ErrMsg = ErrMsg

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._ErrMsg = params.get("ErrMsg")
        self._RequestId = params.get("RequestId")


class AttachCBSSpec(AbstractModel):
    r"""集群内节点的规格磁盘规格描述

    """

    def __init__(self):
        r"""
        :param _DiskType: 节点磁盘类型，例如“CLOUD_SSD”\"CLOUD_PREMIUM"
        :type DiskType: str
        :param _DiskSize: 磁盘容量，单位G
        :type DiskSize: int
        :param _DiskCount: 磁盘总数
        :type DiskCount: int
        :param _DiskDesc: 描述
        :type DiskDesc: str
        """
        self._DiskType = None
        self._DiskSize = None
        self._DiskCount = None
        self._DiskDesc = None

    @property
    def DiskType(self):
        r"""节点磁盘类型，例如“CLOUD_SSD”\"CLOUD_PREMIUM"
        :rtype: str
        """
        return self._DiskType

    @DiskType.setter
    def DiskType(self, DiskType):
        self._DiskType = DiskType

    @property
    def DiskSize(self):
        r"""磁盘容量，单位G
        :rtype: int
        """
        return self._DiskSize

    @DiskSize.setter
    def DiskSize(self, DiskSize):
        self._DiskSize = DiskSize

    @property
    def DiskCount(self):
        r"""磁盘总数
        :rtype: int
        """
        return self._DiskCount

    @DiskCount.setter
    def DiskCount(self, DiskCount):
        self._DiskCount = DiskCount

    @property
    def DiskDesc(self):
        r"""描述
        :rtype: str
        """
        return self._DiskDesc

    @DiskDesc.setter
    def DiskDesc(self, DiskDesc):
        self._DiskDesc = DiskDesc


    def _deserialize(self, params):
        self._DiskType = params.get("DiskType")
        self._DiskSize = params.get("DiskSize")
        self._DiskCount = params.get("DiskCount")
        self._DiskDesc = params.get("DiskDesc")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class BackUpJobDisplay(AbstractModel):
    r"""备份任务详情

    """

    def __init__(self):
        r"""
        :param _JobId: 备份任务id
        :type JobId: int
        :param _Snapshot: 备份任务名
        :type Snapshot: str
        :param _BackUpType: 任务类型(元数据),(数据)
        :type BackUpType: str
        :param _BackUpSize: 备份数据量
        :type BackUpSize: int
        :param _BackUpTime: 任务创建时间
        :type BackUpTime: str
        :param _ExpireTime: 任务过期时间
        :type ExpireTime: str
        :param _JobStatus: 任务状态
        :type JobStatus: str
        :param _ProcessSize: 处理数据量
        :type ProcessSize: int
        :param _ErrorReason: 错误原因
        :type ErrorReason: str
        """
        self._JobId = None
        self._Snapshot = None
        self._BackUpType = None
        self._BackUpSize = None
        self._BackUpTime = None
        self._ExpireTime = None
        self._JobStatus = None
        self._ProcessSize = None
        self._ErrorReason = None

    @property
    def JobId(self):
        r"""备份任务id
        :rtype: int
        """
        return self._JobId

    @JobId.setter
    def JobId(self, JobId):
        self._JobId = JobId

    @property
    def Snapshot(self):
        r"""备份任务名
        :rtype: str
        """
        return self._Snapshot

    @Snapshot.setter
    def Snapshot(self, Snapshot):
        self._Snapshot = Snapshot

    @property
    def BackUpType(self):
        r"""任务类型(元数据),(数据)
        :rtype: str
        """
        return self._BackUpType

    @BackUpType.setter
    def BackUpType(self, BackUpType):
        self._BackUpType = BackUpType

    @property
    def BackUpSize(self):
        r"""备份数据量
        :rtype: int
        """
        return self._BackUpSize

    @BackUpSize.setter
    def BackUpSize(self, BackUpSize):
        self._BackUpSize = BackUpSize

    @property
    def BackUpTime(self):
        r"""任务创建时间
        :rtype: str
        """
        return self._BackUpTime

    @BackUpTime.setter
    def BackUpTime(self, BackUpTime):
        self._BackUpTime = BackUpTime

    @property
    def ExpireTime(self):
        r"""任务过期时间
        :rtype: str
        """
        return self._ExpireTime

    @ExpireTime.setter
    def ExpireTime(self, ExpireTime):
        self._ExpireTime = ExpireTime

    @property
    def JobStatus(self):
        r"""任务状态
        :rtype: str
        """
        return self._JobStatus

    @JobStatus.setter
    def JobStatus(self, JobStatus):
        self._JobStatus = JobStatus

    @property
    def ProcessSize(self):
        r"""处理数据量
        :rtype: int
        """
        return self._ProcessSize

    @ProcessSize.setter
    def ProcessSize(self, ProcessSize):
        self._ProcessSize = ProcessSize

    @property
    def ErrorReason(self):
        r"""错误原因
        :rtype: str
        """
        return self._ErrorReason

    @ErrorReason.setter
    def ErrorReason(self, ErrorReason):
        self._ErrorReason = ErrorReason


    def _deserialize(self, params):
        self._JobId = params.get("JobId")
        self._Snapshot = params.get("Snapshot")
        self._BackUpType = params.get("BackUpType")
        self._BackUpSize = params.get("BackUpSize")
        self._BackUpTime = params.get("BackUpTime")
        self._ExpireTime = params.get("ExpireTime")
        self._JobStatus = params.get("JobStatus")
        self._ProcessSize = params.get("ProcessSize")
        self._ErrorReason = params.get("ErrorReason")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class BackupTableContent(AbstractModel):
    r"""备份表信息

    """

    def __init__(self):
        r"""
        :param _Database: 数据库
        :type Database: str
        :param _Table: 表
        :type Table: str
        :param _TotalBytes: 表总字节数
        :type TotalBytes: int
        :param _VCluster: 虚拟cluster
        :type VCluster: str
        :param _Ips: 表ip
        :type Ips: str
        :param _ZooPath: zk路径
        :type ZooPath: str
        :param _Rip: cvm的ip地址
        :type Rip: str
        """
        self._Database = None
        self._Table = None
        self._TotalBytes = None
        self._VCluster = None
        self._Ips = None
        self._ZooPath = None
        self._Rip = None

    @property
    def Database(self):
        r"""数据库
        :rtype: str
        """
        return self._Database

    @Database.setter
    def Database(self, Database):
        self._Database = Database

    @property
    def Table(self):
        r"""表
        :rtype: str
        """
        return self._Table

    @Table.setter
    def Table(self, Table):
        self._Table = Table

    @property
    def TotalBytes(self):
        r"""表总字节数
        :rtype: int
        """
        return self._TotalBytes

    @TotalBytes.setter
    def TotalBytes(self, TotalBytes):
        self._TotalBytes = TotalBytes

    @property
    def VCluster(self):
        r"""虚拟cluster
        :rtype: str
        """
        return self._VCluster

    @VCluster.setter
    def VCluster(self, VCluster):
        self._VCluster = VCluster

    @property
    def Ips(self):
        r"""表ip
        :rtype: str
        """
        return self._Ips

    @Ips.setter
    def Ips(self, Ips):
        self._Ips = Ips

    @property
    def ZooPath(self):
        r"""zk路径
        :rtype: str
        """
        return self._ZooPath

    @ZooPath.setter
    def ZooPath(self, ZooPath):
        self._ZooPath = ZooPath

    @property
    def Rip(self):
        r"""cvm的ip地址
        :rtype: str
        """
        return self._Rip

    @Rip.setter
    def Rip(self, Rip):
        self._Rip = Rip


    def _deserialize(self, params):
        self._Database = params.get("Database")
        self._Table = params.get("Table")
        self._TotalBytes = params.get("TotalBytes")
        self._VCluster = params.get("VCluster")
        self._Ips = params.get("Ips")
        self._ZooPath = params.get("ZooPath")
        self._Rip = params.get("Rip")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class CNResource(AbstractModel):
    r"""资源信息

    """

    def __init__(self):
        r"""
        :param _ID: 资源id
        :type ID: int
        :param _InstanceID: 集群的id
        :type InstanceID: str
        :param _AppID: 用户appid
        :type AppID: int
        :param _Uin: 用户uin
        :type Uin: str
        :param _Component: 组件
        :type Component: str
        :param _DeployMode: 部署模式
        :type DeployMode: int
        :param _SpecName: 规格名称
        :type SpecName: str
        :param _ResourceID: 资源id
        :type ResourceID: str
        :param _Status: 资源的状态
        :type Status: int
        :param _IP: 私有网络ip
        :type IP: str
        :param _CPU: 核数
        :type CPU: int
        :param _Memory: 内存
        :type Memory: int
        :param _Storage: 存储大小
        :type Storage: int
        :param _UUID: 服务器ID
        :type UUID: str
        :param _Region: 地域
        :type Region: str
        :param _Zone: 地区
        :type Zone: str
        :param _Details: 详细信息
        :type Details: str
        :param _CreateTime: 创建时间
        :type CreateTime: str
        :param _ModifyTime: 修改时间
        :type ModifyTime: str
        :param _ExpireTime: 过期时间
        :type ExpireTime: str
        """
        self._ID = None
        self._InstanceID = None
        self._AppID = None
        self._Uin = None
        self._Component = None
        self._DeployMode = None
        self._SpecName = None
        self._ResourceID = None
        self._Status = None
        self._IP = None
        self._CPU = None
        self._Memory = None
        self._Storage = None
        self._UUID = None
        self._Region = None
        self._Zone = None
        self._Details = None
        self._CreateTime = None
        self._ModifyTime = None
        self._ExpireTime = None

    @property
    def ID(self):
        r"""资源id
        :rtype: int
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID

    @property
    def InstanceID(self):
        r"""集群的id
        :rtype: str
        """
        return self._InstanceID

    @InstanceID.setter
    def InstanceID(self, InstanceID):
        self._InstanceID = InstanceID

    @property
    def AppID(self):
        r"""用户appid
        :rtype: int
        """
        return self._AppID

    @AppID.setter
    def AppID(self, AppID):
        self._AppID = AppID

    @property
    def Uin(self):
        r"""用户uin
        :rtype: str
        """
        return self._Uin

    @Uin.setter
    def Uin(self, Uin):
        self._Uin = Uin

    @property
    def Component(self):
        r"""组件
        :rtype: str
        """
        return self._Component

    @Component.setter
    def Component(self, Component):
        self._Component = Component

    @property
    def DeployMode(self):
        r"""部署模式
        :rtype: int
        """
        return self._DeployMode

    @DeployMode.setter
    def DeployMode(self, DeployMode):
        self._DeployMode = DeployMode

    @property
    def SpecName(self):
        r"""规格名称
        :rtype: str
        """
        return self._SpecName

    @SpecName.setter
    def SpecName(self, SpecName):
        self._SpecName = SpecName

    @property
    def ResourceID(self):
        r"""资源id
        :rtype: str
        """
        return self._ResourceID

    @ResourceID.setter
    def ResourceID(self, ResourceID):
        self._ResourceID = ResourceID

    @property
    def Status(self):
        r"""资源的状态
        :rtype: int
        """
        return self._Status

    @Status.setter
    def Status(self, Status):
        self._Status = Status

    @property
    def IP(self):
        r"""私有网络ip
        :rtype: str
        """
        return self._IP

    @IP.setter
    def IP(self, IP):
        self._IP = IP

    @property
    def CPU(self):
        r"""核数
        :rtype: int
        """
        return self._CPU

    @CPU.setter
    def CPU(self, CPU):
        self._CPU = CPU

    @property
    def Memory(self):
        r"""内存
        :rtype: int
        """
        return self._Memory

    @Memory.setter
    def Memory(self, Memory):
        self._Memory = Memory

    @property
    def Storage(self):
        r"""存储大小
        :rtype: int
        """
        return self._Storage

    @Storage.setter
    def Storage(self, Storage):
        self._Storage = Storage

    @property
    def UUID(self):
        r"""服务器ID
        :rtype: str
        """
        return self._UUID

    @UUID.setter
    def UUID(self, UUID):
        self._UUID = UUID

    @property
    def Region(self):
        r"""地域
        :rtype: str
        """
        return self._Region

    @Region.setter
    def Region(self, Region):
        self._Region = Region

    @property
    def Zone(self):
        r"""地区
        :rtype: str
        """
        return self._Zone

    @Zone.setter
    def Zone(self, Zone):
        self._Zone = Zone

    @property
    def Details(self):
        r"""详细信息
        :rtype: str
        """
        return self._Details

    @Details.setter
    def Details(self, Details):
        self._Details = Details

    @property
    def CreateTime(self):
        r"""创建时间
        :rtype: str
        """
        return self._CreateTime

    @CreateTime.setter
    def CreateTime(self, CreateTime):
        self._CreateTime = CreateTime

    @property
    def ModifyTime(self):
        r"""修改时间
        :rtype: str
        """
        return self._ModifyTime

    @ModifyTime.setter
    def ModifyTime(self, ModifyTime):
        self._ModifyTime = ModifyTime

    @property
    def ExpireTime(self):
        r"""过期时间
        :rtype: str
        """
        return self._ExpireTime

    @ExpireTime.setter
    def ExpireTime(self, ExpireTime):
        self._ExpireTime = ExpireTime


    def _deserialize(self, params):
        self._ID = params.get("ID")
        self._InstanceID = params.get("InstanceID")
        self._AppID = params.get("AppID")
        self._Uin = params.get("Uin")
        self._Component = params.get("Component")
        self._DeployMode = params.get("DeployMode")
        self._SpecName = params.get("SpecName")
        self._ResourceID = params.get("ResourceID")
        self._Status = params.get("Status")
        self._IP = params.get("IP")
        self._CPU = params.get("CPU")
        self._Memory = params.get("Memory")
        self._Storage = params.get("Storage")
        self._UUID = params.get("UUID")
        self._Region = params.get("Region")
        self._Zone = params.get("Zone")
        self._Details = params.get("Details")
        self._CreateTime = params.get("CreateTime")
        self._ModifyTime = params.get("ModifyTime")
        self._ExpireTime = params.get("ExpireTime")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class Charge(AbstractModel):
    r"""集群计费相关信息

    """

    def __init__(self):
        r"""
        :param _ChargeType: 计费类型，“PREPAID” 预付费，“POSTPAID_BY_HOUR” 后付费
        :type ChargeType: str
        :param _RenewFlag: ChargeType为PREPAID时，必传，表示是否自动续费，1表示自动续费开启
        :type RenewFlag: int
        :param _TimeSpan: ChargeType为PREPAID时，必传，表示计费时间长度，多少个月
        :type TimeSpan: int
        """
        self._ChargeType = None
        self._RenewFlag = None
        self._TimeSpan = None

    @property
    def ChargeType(self):
        r"""计费类型，“PREPAID” 预付费，“POSTPAID_BY_HOUR” 后付费
        :rtype: str
        """
        return self._ChargeType

    @ChargeType.setter
    def ChargeType(self, ChargeType):
        self._ChargeType = ChargeType

    @property
    def RenewFlag(self):
        r"""ChargeType为PREPAID时，必传，表示是否自动续费，1表示自动续费开启
        :rtype: int
        """
        return self._RenewFlag

    @RenewFlag.setter
    def RenewFlag(self, RenewFlag):
        self._RenewFlag = RenewFlag

    @property
    def TimeSpan(self):
        r"""ChargeType为PREPAID时，必传，表示计费时间长度，多少个月
        :rtype: int
        """
        return self._TimeSpan

    @TimeSpan.setter
    def TimeSpan(self, TimeSpan):
        self._TimeSpan = TimeSpan


    def _deserialize(self, params):
        self._ChargeType = params.get("ChargeType")
        self._RenewFlag = params.get("RenewFlag")
        self._TimeSpan = params.get("TimeSpan")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class CkUserAlterInfo(AbstractModel):
    r"""新增或是修改ck用户

    """

    def __init__(self):
        r"""
        :param _InstanceId: 集群实例id
        :type InstanceId: str
        :param _UserName: 用户名
        :type UserName: str
        :param _PassWord: base64加密后的密码
        :type PassWord: str
        :param _Describe: 描述
        :type Describe: str
        :param _OriginalPassword: 账户的当前密码
        :type OriginalPassword: str
        """
        self._InstanceId = None
        self._UserName = None
        self._PassWord = None
        self._Describe = None
        self._OriginalPassword = None

    @property
    def InstanceId(self):
        r"""集群实例id
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId

    @property
    def UserName(self):
        r"""用户名
        :rtype: str
        """
        return self._UserName

    @UserName.setter
    def UserName(self, UserName):
        self._UserName = UserName

    @property
    def PassWord(self):
        r"""base64加密后的密码
        :rtype: str
        """
        return self._PassWord

    @PassWord.setter
    def PassWord(self, PassWord):
        self._PassWord = PassWord

    @property
    def Describe(self):
        r"""描述
        :rtype: str
        """
        return self._Describe

    @Describe.setter
    def Describe(self, Describe):
        self._Describe = Describe

    @property
    def OriginalPassword(self):
        r"""账户的当前密码
        :rtype: str
        """
        return self._OriginalPassword

    @OriginalPassword.setter
    def OriginalPassword(self, OriginalPassword):
        self._OriginalPassword = OriginalPassword


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        self._UserName = params.get("UserName")
        self._PassWord = params.get("PassWord")
        self._Describe = params.get("Describe")
        self._OriginalPassword = params.get("OriginalPassword")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ClusterConfigsInfoFromEMR(AbstractModel):
    r"""用于返回XML格式的配置文件和内容以及其他配置文件有关的信息

    """

    def __init__(self):
        r"""
        :param _FileName: 配置文件名称
        :type FileName: str
        :param _FileConf: 配置文件对应的相关属性信息
        :type FileConf: str
        :param _KeyConf: 配置文件对应的其他属性信息
        :type KeyConf: str
        :param _OriParam: 配置文件的内容，base64编码
        :type OriParam: str
        :param _NeedRestart: 用于表示当前配置文件是不是有过修改后没有重启，提醒用户需要重启
        :type NeedRestart: int
        :param _FilePath: 保存配置文件的路径
        :type FilePath: str
        :param _Ip: 节点级配置的ip，当ConfigLevel取值为node时，此参数必选；
        :type Ip: str
        :param _ConfigLevel: 可选参数，参数取值：node,cluster; node: 节点级参数配置，cluster: 实例级参数配置；
        :type ConfigLevel: str
        """
        self._FileName = None
        self._FileConf = None
        self._KeyConf = None
        self._OriParam = None
        self._NeedRestart = None
        self._FilePath = None
        self._Ip = None
        self._ConfigLevel = None

    @property
    def FileName(self):
        r"""配置文件名称
        :rtype: str
        """
        return self._FileName

    @FileName.setter
    def FileName(self, FileName):
        self._FileName = FileName

    @property
    def FileConf(self):
        r"""配置文件对应的相关属性信息
        :rtype: str
        """
        return self._FileConf

    @FileConf.setter
    def FileConf(self, FileConf):
        self._FileConf = FileConf

    @property
    def KeyConf(self):
        r"""配置文件对应的其他属性信息
        :rtype: str
        """
        return self._KeyConf

    @KeyConf.setter
    def KeyConf(self, KeyConf):
        self._KeyConf = KeyConf

    @property
    def OriParam(self):
        r"""配置文件的内容，base64编码
        :rtype: str
        """
        return self._OriParam

    @OriParam.setter
    def OriParam(self, OriParam):
        self._OriParam = OriParam

    @property
    def NeedRestart(self):
        r"""用于表示当前配置文件是不是有过修改后没有重启，提醒用户需要重启
        :rtype: int
        """
        return self._NeedRestart

    @NeedRestart.setter
    def NeedRestart(self, NeedRestart):
        self._NeedRestart = NeedRestart

    @property
    def FilePath(self):
        r"""保存配置文件的路径
        :rtype: str
        """
        return self._FilePath

    @FilePath.setter
    def FilePath(self, FilePath):
        self._FilePath = FilePath

    @property
    def Ip(self):
        r"""节点级配置的ip，当ConfigLevel取值为node时，此参数必选；
        :rtype: str
        """
        return self._Ip

    @Ip.setter
    def Ip(self, Ip):
        self._Ip = Ip

    @property
    def ConfigLevel(self):
        r"""可选参数，参数取值：node,cluster; node: 节点级参数配置，cluster: 实例级参数配置；
        :rtype: str
        """
        return self._ConfigLevel

    @ConfigLevel.setter
    def ConfigLevel(self, ConfigLevel):
        self._ConfigLevel = ConfigLevel


    def _deserialize(self, params):
        self._FileName = params.get("FileName")
        self._FileConf = params.get("FileConf")
        self._KeyConf = params.get("KeyConf")
        self._OriParam = params.get("OriParam")
        self._NeedRestart = params.get("NeedRestart")
        self._FilePath = params.get("FilePath")
        self._Ip = params.get("Ip")
        self._ConfigLevel = params.get("ConfigLevel")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ClusterInfo(AbstractModel):
    r"""clickhouse vcluster信息

    """

    def __init__(self):
        r"""
        :param _ClusterName: vcluster名字
        :type ClusterName: str
        :param _NodeIps: 当前cluster的IP列表
        :type NodeIps: list of str
        """
        self._ClusterName = None
        self._NodeIps = None

    @property
    def ClusterName(self):
        r"""vcluster名字
        :rtype: str
        """
        return self._ClusterName

    @ClusterName.setter
    def ClusterName(self, ClusterName):
        self._ClusterName = ClusterName

    @property
    def NodeIps(self):
        r"""当前cluster的IP列表
        :rtype: list of str
        """
        return self._NodeIps

    @NodeIps.setter
    def NodeIps(self, NodeIps):
        self._NodeIps = NodeIps


    def _deserialize(self, params):
        self._ClusterName = params.get("ClusterName")
        self._NodeIps = params.get("NodeIps")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class CnInstanceInfo(AbstractModel):
    r"""云原生实例详情

    """

    def __init__(self):
        r"""
        :param _ID: ID值
        :type ID: int
        :param _InstanceType: cdwch-cn或者其他
        :type InstanceType: str
        :param _InstanceName: cdwch-cn或者其他
        :type InstanceName: str
        :param _Status: Running
        :type Status: str
        :param _StatusDesc: 运行中
        :type StatusDesc: str
        :param _InstanceStateInfo: 无
        :type InstanceStateInfo: :class:`tencentcloud.cdwch.v20200915.models.InstanceStateInfo`
        :param _InstanceID: -
        :type InstanceID: str
        :param _Resources: 无
        :type Resources: list of CNResource
        :param _IsSecondaryZone: desc
        :type IsSecondaryZone: str
        :param _SecondaryZoneInfo: desc
        :type SecondaryZoneInfo: str
        """
        self._ID = None
        self._InstanceType = None
        self._InstanceName = None
        self._Status = None
        self._StatusDesc = None
        self._InstanceStateInfo = None
        self._InstanceID = None
        self._Resources = None
        self._IsSecondaryZone = None
        self._SecondaryZoneInfo = None

    @property
    def ID(self):
        r"""ID值
        :rtype: int
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID

    @property
    def InstanceType(self):
        r"""cdwch-cn或者其他
        :rtype: str
        """
        return self._InstanceType

    @InstanceType.setter
    def InstanceType(self, InstanceType):
        self._InstanceType = InstanceType

    @property
    def InstanceName(self):
        r"""cdwch-cn或者其他
        :rtype: str
        """
        return self._InstanceName

    @InstanceName.setter
    def InstanceName(self, InstanceName):
        self._InstanceName = InstanceName

    @property
    def Status(self):
        r"""Running
        :rtype: str
        """
        return self._Status

    @Status.setter
    def Status(self, Status):
        self._Status = Status

    @property
    def StatusDesc(self):
        r"""运行中
        :rtype: str
        """
        return self._StatusDesc

    @StatusDesc.setter
    def StatusDesc(self, StatusDesc):
        self._StatusDesc = StatusDesc

    @property
    def InstanceStateInfo(self):
        r"""无
        :rtype: :class:`tencentcloud.cdwch.v20200915.models.InstanceStateInfo`
        """
        return self._InstanceStateInfo

    @InstanceStateInfo.setter
    def InstanceStateInfo(self, InstanceStateInfo):
        self._InstanceStateInfo = InstanceStateInfo

    @property
    def InstanceID(self):
        r"""-
        :rtype: str
        """
        return self._InstanceID

    @InstanceID.setter
    def InstanceID(self, InstanceID):
        self._InstanceID = InstanceID

    @property
    def Resources(self):
        r"""无
        :rtype: list of CNResource
        """
        return self._Resources

    @Resources.setter
    def Resources(self, Resources):
        self._Resources = Resources

    @property
    def IsSecondaryZone(self):
        r"""desc
        :rtype: str
        """
        return self._IsSecondaryZone

    @IsSecondaryZone.setter
    def IsSecondaryZone(self, IsSecondaryZone):
        self._IsSecondaryZone = IsSecondaryZone

    @property
    def SecondaryZoneInfo(self):
        r"""desc
        :rtype: str
        """
        return self._SecondaryZoneInfo

    @SecondaryZoneInfo.setter
    def SecondaryZoneInfo(self, SecondaryZoneInfo):
        self._SecondaryZoneInfo = SecondaryZoneInfo


    def _deserialize(self, params):
        self._ID = params.get("ID")
        self._InstanceType = params.get("InstanceType")
        self._InstanceName = params.get("InstanceName")
        self._Status = params.get("Status")
        self._StatusDesc = params.get("StatusDesc")
        if params.get("InstanceStateInfo") is not None:
            self._InstanceStateInfo = InstanceStateInfo()
            self._InstanceStateInfo._deserialize(params.get("InstanceStateInfo"))
        self._InstanceID = params.get("InstanceID")
        if params.get("Resources") is not None:
            self._Resources = []
            for item in params.get("Resources"):
                obj = CNResource()
                obj._deserialize(item)
                self._Resources.append(obj)
        self._IsSecondaryZone = params.get("IsSecondaryZone")
        self._SecondaryZoneInfo = params.get("SecondaryZoneInfo")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ConfigSubmitContext(AbstractModel):
    r"""配置文件修改信息

    """

    def __init__(self):
        r"""
        :param _FileName: 配置文件名称
        :type FileName: str
        :param _OldConfValue: 配置文件旧内容，base64编码
        :type OldConfValue: str
        :param _NewConfValue: 配置文件新内容，base64编码
        :type NewConfValue: str
        :param _FilePath: 保存配置文件的路径
        :type FilePath: str
        :param _Ip: 节点ip信息，可选参数，当修改集群节点级配置（例如keeper_config.xml）时此参数必填；
        :type Ip: str
        """
        self._FileName = None
        self._OldConfValue = None
        self._NewConfValue = None
        self._FilePath = None
        self._Ip = None

    @property
    def FileName(self):
        r"""配置文件名称
        :rtype: str
        """
        return self._FileName

    @FileName.setter
    def FileName(self, FileName):
        self._FileName = FileName

    @property
    def OldConfValue(self):
        r"""配置文件旧内容，base64编码
        :rtype: str
        """
        return self._OldConfValue

    @OldConfValue.setter
    def OldConfValue(self, OldConfValue):
        self._OldConfValue = OldConfValue

    @property
    def NewConfValue(self):
        r"""配置文件新内容，base64编码
        :rtype: str
        """
        return self._NewConfValue

    @NewConfValue.setter
    def NewConfValue(self, NewConfValue):
        self._NewConfValue = NewConfValue

    @property
    def FilePath(self):
        r"""保存配置文件的路径
        :rtype: str
        """
        return self._FilePath

    @FilePath.setter
    def FilePath(self, FilePath):
        self._FilePath = FilePath

    @property
    def Ip(self):
        r"""节点ip信息，可选参数，当修改集群节点级配置（例如keeper_config.xml）时此参数必填；
        :rtype: str
        """
        return self._Ip

    @Ip.setter
    def Ip(self, Ip):
        self._Ip = Ip


    def _deserialize(self, params):
        self._FileName = params.get("FileName")
        self._OldConfValue = params.get("OldConfValue")
        self._NewConfValue = params.get("NewConfValue")
        self._FilePath = params.get("FilePath")
        self._Ip = params.get("Ip")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class CreateBackUpScheduleRequest(AbstractModel):
    r"""CreateBackUpSchedule请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceId: 集群id
        :type InstanceId: str
        :param _ScheduleType: 策略类型 meta(元数据)  data (表数据)
        :type ScheduleType: str
        :param _OperationType: 操作类型 create(创建) update(编辑修改)
        :type OperationType: str
        :param _RetainDays: 保留天数 例如7
        :type RetainDays: int
        :param _ScheduleId: 编辑时需要传
        :type ScheduleId: int
        :param _WeekDays: 选择的星期 逗号分隔，例如 2 代表周二
        :type WeekDays: str
        :param _ExecuteHour: 执行小时
        :type ExecuteHour: int
        :param _BackUpTables: 备份表列表
        :type BackUpTables: list of BackupTableContent
        """
        self._InstanceId = None
        self._ScheduleType = None
        self._OperationType = None
        self._RetainDays = None
        self._ScheduleId = None
        self._WeekDays = None
        self._ExecuteHour = None
        self._BackUpTables = None

    @property
    def InstanceId(self):
        r"""集群id
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId

    @property
    def ScheduleType(self):
        r"""策略类型 meta(元数据)  data (表数据)
        :rtype: str
        """
        return self._ScheduleType

    @ScheduleType.setter
    def ScheduleType(self, ScheduleType):
        self._ScheduleType = ScheduleType

    @property
    def OperationType(self):
        r"""操作类型 create(创建) update(编辑修改)
        :rtype: str
        """
        return self._OperationType

    @OperationType.setter
    def OperationType(self, OperationType):
        self._OperationType = OperationType

    @property
    def RetainDays(self):
        r"""保留天数 例如7
        :rtype: int
        """
        return self._RetainDays

    @RetainDays.setter
    def RetainDays(self, RetainDays):
        self._RetainDays = RetainDays

    @property
    def ScheduleId(self):
        r"""编辑时需要传
        :rtype: int
        """
        return self._ScheduleId

    @ScheduleId.setter
    def ScheduleId(self, ScheduleId):
        self._ScheduleId = ScheduleId

    @property
    def WeekDays(self):
        r"""选择的星期 逗号分隔，例如 2 代表周二
        :rtype: str
        """
        return self._WeekDays

    @WeekDays.setter
    def WeekDays(self, WeekDays):
        self._WeekDays = WeekDays

    @property
    def ExecuteHour(self):
        r"""执行小时
        :rtype: int
        """
        return self._ExecuteHour

    @ExecuteHour.setter
    def ExecuteHour(self, ExecuteHour):
        self._ExecuteHour = ExecuteHour

    @property
    def BackUpTables(self):
        r"""备份表列表
        :rtype: list of BackupTableContent
        """
        return self._BackUpTables

    @BackUpTables.setter
    def BackUpTables(self, BackUpTables):
        self._BackUpTables = BackUpTables


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        self._ScheduleType = params.get("ScheduleType")
        self._OperationType = params.get("OperationType")
        self._RetainDays = params.get("RetainDays")
        self._ScheduleId = params.get("ScheduleId")
        self._WeekDays = params.get("WeekDays")
        self._ExecuteHour = params.get("ExecuteHour")
        if params.get("BackUpTables") is not None:
            self._BackUpTables = []
            for item in params.get("BackUpTables"):
                obj = BackupTableContent()
                obj._deserialize(item)
                self._BackUpTables.append(obj)
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class CreateBackUpScheduleResponse(AbstractModel):
    r"""CreateBackUpSchedule返回参数结构体

    """

    def __init__(self):
        r"""
        :param _ErrorMsg: 错误描述
        :type ErrorMsg: str
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._ErrorMsg = None
        self._RequestId = None

    @property
    def ErrorMsg(self):
        r"""错误描述
        :rtype: str
        """
        return self._ErrorMsg

    @ErrorMsg.setter
    def ErrorMsg(self, ErrorMsg):
        self._ErrorMsg = ErrorMsg

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._ErrorMsg = params.get("ErrorMsg")
        self._RequestId = params.get("RequestId")


class CreateInstanceNewRequest(AbstractModel):
    r"""CreateInstanceNew请求参数结构体

    """

    def __init__(self):
        r"""
        :param _Zone: <p>可用区</p>
        :type Zone: str
        :param _HaFlag: <p>是否高可用</p>
        :type HaFlag: bool
        :param _UserVPCId: <p>私有网络</p>
        :type UserVPCId: str
        :param _UserSubnetId: <p>子网</p>
        :type UserSubnetId: str
        :param _ProductVersion: <p>系统版本</p>
        :type ProductVersion: str
        :param _ChargeProperties: <p>计费方式</p>
        :type ChargeProperties: :class:`tencentcloud.cdwch.v20200915.models.Charge`
        :param _InstanceName: <p>实例名称</p>
        :type InstanceName: str
        :param _DataSpec: <p>数据节点<br>SpecName从DescribeSpec接口中返回的DataSpec.Name获取</p>
        :type DataSpec: :class:`tencentcloud.cdwch.v20200915.models.NodeSpec`
        :param _Tags: <p>标签列表（废弃）</p>
        :type Tags: :class:`tencentcloud.cdwch.v20200915.models.Tag`
        :param _ClsLogSetId: <p>日志主题ID</p>
        :type ClsLogSetId: str
        :param _CosBucketName: <p>COS桶名称</p>
        :type CosBucketName: str
        :param _MountDiskType: <p>是否是裸盘挂载，默认值 0 为 未挂载，1 为挂载。</p>
        :type MountDiskType: int
        :param _HAZk: <p>是否是ZK高可用</p>
        :type HAZk: bool
        :param _CommonSpec: <p>ZK节点SpecName从DescribeSpec接口中返回的CommonSpec结构体的Name（ZK节点）获取</p>
        :type CommonSpec: :class:`tencentcloud.cdwch.v20200915.models.NodeSpec`
        :param _TagItems: <p>标签列表</p>
        :type TagItems: list of Tag
        :param _SecondaryZoneInfo: <p>副可用区信息</p>
        :type SecondaryZoneInfo: list of SecondaryZoneInfo
        :param _CkDefaultUserPwd: <p>default账号登录实例的密码。8-16个字符，至少包含大写字母、小写字母、数字和特殊字符!@#%^*中的三种，第一个字符不能为特殊字符</p>
        :type CkDefaultUserPwd: str
        :param _ClusterType: <p>集群类型</p>
        :type ClusterType: str
        """
        self._Zone = None
        self._HaFlag = None
        self._UserVPCId = None
        self._UserSubnetId = None
        self._ProductVersion = None
        self._ChargeProperties = None
        self._InstanceName = None
        self._DataSpec = None
        self._Tags = None
        self._ClsLogSetId = None
        self._CosBucketName = None
        self._MountDiskType = None
        self._HAZk = None
        self._CommonSpec = None
        self._TagItems = None
        self._SecondaryZoneInfo = None
        self._CkDefaultUserPwd = None
        self._ClusterType = None

    @property
    def Zone(self):
        r"""<p>可用区</p>
        :rtype: str
        """
        return self._Zone

    @Zone.setter
    def Zone(self, Zone):
        self._Zone = Zone

    @property
    def HaFlag(self):
        r"""<p>是否高可用</p>
        :rtype: bool
        """
        return self._HaFlag

    @HaFlag.setter
    def HaFlag(self, HaFlag):
        self._HaFlag = HaFlag

    @property
    def UserVPCId(self):
        r"""<p>私有网络</p>
        :rtype: str
        """
        return self._UserVPCId

    @UserVPCId.setter
    def UserVPCId(self, UserVPCId):
        self._UserVPCId = UserVPCId

    @property
    def UserSubnetId(self):
        r"""<p>子网</p>
        :rtype: str
        """
        return self._UserSubnetId

    @UserSubnetId.setter
    def UserSubnetId(self, UserSubnetId):
        self._UserSubnetId = UserSubnetId

    @property
    def ProductVersion(self):
        r"""<p>系统版本</p>
        :rtype: str
        """
        return self._ProductVersion

    @ProductVersion.setter
    def ProductVersion(self, ProductVersion):
        self._ProductVersion = ProductVersion

    @property
    def ChargeProperties(self):
        r"""<p>计费方式</p>
        :rtype: :class:`tencentcloud.cdwch.v20200915.models.Charge`
        """
        return self._ChargeProperties

    @ChargeProperties.setter
    def ChargeProperties(self, ChargeProperties):
        self._ChargeProperties = ChargeProperties

    @property
    def InstanceName(self):
        r"""<p>实例名称</p>
        :rtype: str
        """
        return self._InstanceName

    @InstanceName.setter
    def InstanceName(self, InstanceName):
        self._InstanceName = InstanceName

    @property
    def DataSpec(self):
        r"""<p>数据节点<br>SpecName从DescribeSpec接口中返回的DataSpec.Name获取</p>
        :rtype: :class:`tencentcloud.cdwch.v20200915.models.NodeSpec`
        """
        return self._DataSpec

    @DataSpec.setter
    def DataSpec(self, DataSpec):
        self._DataSpec = DataSpec

    @property
    def Tags(self):
        warnings.warn("parameter `Tags` is deprecated", DeprecationWarning) 

        r"""<p>标签列表（废弃）</p>
        :rtype: :class:`tencentcloud.cdwch.v20200915.models.Tag`
        """
        return self._Tags

    @Tags.setter
    def Tags(self, Tags):
        warnings.warn("parameter `Tags` is deprecated", DeprecationWarning) 

        self._Tags = Tags

    @property
    def ClsLogSetId(self):
        r"""<p>日志主题ID</p>
        :rtype: str
        """
        return self._ClsLogSetId

    @ClsLogSetId.setter
    def ClsLogSetId(self, ClsLogSetId):
        self._ClsLogSetId = ClsLogSetId

    @property
    def CosBucketName(self):
        r"""<p>COS桶名称</p>
        :rtype: str
        """
        return self._CosBucketName

    @CosBucketName.setter
    def CosBucketName(self, CosBucketName):
        self._CosBucketName = CosBucketName

    @property
    def MountDiskType(self):
        r"""<p>是否是裸盘挂载，默认值 0 为 未挂载，1 为挂载。</p>
        :rtype: int
        """
        return self._MountDiskType

    @MountDiskType.setter
    def MountDiskType(self, MountDiskType):
        self._MountDiskType = MountDiskType

    @property
    def HAZk(self):
        r"""<p>是否是ZK高可用</p>
        :rtype: bool
        """
        return self._HAZk

    @HAZk.setter
    def HAZk(self, HAZk):
        self._HAZk = HAZk

    @property
    def CommonSpec(self):
        r"""<p>ZK节点SpecName从DescribeSpec接口中返回的CommonSpec结构体的Name（ZK节点）获取</p>
        :rtype: :class:`tencentcloud.cdwch.v20200915.models.NodeSpec`
        """
        return self._CommonSpec

    @CommonSpec.setter
    def CommonSpec(self, CommonSpec):
        self._CommonSpec = CommonSpec

    @property
    def TagItems(self):
        r"""<p>标签列表</p>
        :rtype: list of Tag
        """
        return self._TagItems

    @TagItems.setter
    def TagItems(self, TagItems):
        self._TagItems = TagItems

    @property
    def SecondaryZoneInfo(self):
        r"""<p>副可用区信息</p>
        :rtype: list of SecondaryZoneInfo
        """
        return self._SecondaryZoneInfo

    @SecondaryZoneInfo.setter
    def SecondaryZoneInfo(self, SecondaryZoneInfo):
        self._SecondaryZoneInfo = SecondaryZoneInfo

    @property
    def CkDefaultUserPwd(self):
        r"""<p>default账号登录实例的密码。8-16个字符，至少包含大写字母、小写字母、数字和特殊字符!@#%^*中的三种，第一个字符不能为特殊字符</p>
        :rtype: str
        """
        return self._CkDefaultUserPwd

    @CkDefaultUserPwd.setter
    def CkDefaultUserPwd(self, CkDefaultUserPwd):
        self._CkDefaultUserPwd = CkDefaultUserPwd

    @property
    def ClusterType(self):
        r"""<p>集群类型</p>
        :rtype: str
        """
        return self._ClusterType

    @ClusterType.setter
    def ClusterType(self, ClusterType):
        self._ClusterType = ClusterType


    def _deserialize(self, params):
        self._Zone = params.get("Zone")
        self._HaFlag = params.get("HaFlag")
        self._UserVPCId = params.get("UserVPCId")
        self._UserSubnetId = params.get("UserSubnetId")
        self._ProductVersion = params.get("ProductVersion")
        if params.get("ChargeProperties") is not None:
            self._ChargeProperties = Charge()
            self._ChargeProperties._deserialize(params.get("ChargeProperties"))
        self._InstanceName = params.get("InstanceName")
        if params.get("DataSpec") is not None:
            self._DataSpec = NodeSpec()
            self._DataSpec._deserialize(params.get("DataSpec"))
        if params.get("Tags") is not None:
            self._Tags = Tag()
            self._Tags._deserialize(params.get("Tags"))
        self._ClsLogSetId = params.get("ClsLogSetId")
        self._CosBucketName = params.get("CosBucketName")
        self._MountDiskType = params.get("MountDiskType")
        self._HAZk = params.get("HAZk")
        if params.get("CommonSpec") is not None:
            self._CommonSpec = NodeSpec()
            self._CommonSpec._deserialize(params.get("CommonSpec"))
        if params.get("TagItems") is not None:
            self._TagItems = []
            for item in params.get("TagItems"):
                obj = Tag()
                obj._deserialize(item)
                self._TagItems.append(obj)
        if params.get("SecondaryZoneInfo") is not None:
            self._SecondaryZoneInfo = []
            for item in params.get("SecondaryZoneInfo"):
                obj = SecondaryZoneInfo()
                obj._deserialize(item)
                self._SecondaryZoneInfo.append(obj)
        self._CkDefaultUserPwd = params.get("CkDefaultUserPwd")
        self._ClusterType = params.get("ClusterType")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class CreateInstanceNewResponse(AbstractModel):
    r"""CreateInstanceNew返回参数结构体

    """

    def __init__(self):
        r"""
        :param _FlowId: <p>流程ID</p>
        :type FlowId: str
        :param _InstanceId: <p>实例ID</p>
        :type InstanceId: str
        :param _ErrorMsg: <p>错误信息</p>
        :type ErrorMsg: str
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._FlowId = None
        self._InstanceId = None
        self._ErrorMsg = None
        self._RequestId = None

    @property
    def FlowId(self):
        r"""<p>流程ID</p>
        :rtype: str
        """
        return self._FlowId

    @FlowId.setter
    def FlowId(self, FlowId):
        self._FlowId = FlowId

    @property
    def InstanceId(self):
        r"""<p>实例ID</p>
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId

    @property
    def ErrorMsg(self):
        r"""<p>错误信息</p>
        :rtype: str
        """
        return self._ErrorMsg

    @ErrorMsg.setter
    def ErrorMsg(self, ErrorMsg):
        self._ErrorMsg = ErrorMsg

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._FlowId = params.get("FlowId")
        self._InstanceId = params.get("InstanceId")
        self._ErrorMsg = params.get("ErrorMsg")
        self._RequestId = params.get("RequestId")


class DatabasePrivilegeInfo(AbstractModel):
    r"""数据库权限信息

    """

    def __init__(self):
        r"""
        :param _DatabaseName: 数据库名称
        :type DatabaseName: str
        :param _DatabasePrivileges: 库表权限，SELECT、INSERT_ALL、ALTER、TRUNCATE、DROP_TABLE、CREATE_TABLE、DROP_DATABASE
        :type DatabasePrivileges: list of str
        :param _TablePrivilegeList: 库下面的表权限
        :type TablePrivilegeList: list of TablePrivilegeInfo
        """
        self._DatabaseName = None
        self._DatabasePrivileges = None
        self._TablePrivilegeList = None

    @property
    def DatabaseName(self):
        r"""数据库名称
        :rtype: str
        """
        return self._DatabaseName

    @DatabaseName.setter
    def DatabaseName(self, DatabaseName):
        self._DatabaseName = DatabaseName

    @property
    def DatabasePrivileges(self):
        r"""库表权限，SELECT、INSERT_ALL、ALTER、TRUNCATE、DROP_TABLE、CREATE_TABLE、DROP_DATABASE
        :rtype: list of str
        """
        return self._DatabasePrivileges

    @DatabasePrivileges.setter
    def DatabasePrivileges(self, DatabasePrivileges):
        self._DatabasePrivileges = DatabasePrivileges

    @property
    def TablePrivilegeList(self):
        r"""库下面的表权限
        :rtype: list of TablePrivilegeInfo
        """
        return self._TablePrivilegeList

    @TablePrivilegeList.setter
    def TablePrivilegeList(self, TablePrivilegeList):
        self._TablePrivilegeList = TablePrivilegeList


    def _deserialize(self, params):
        self._DatabaseName = params.get("DatabaseName")
        self._DatabasePrivileges = params.get("DatabasePrivileges")
        if params.get("TablePrivilegeList") is not None:
            self._TablePrivilegeList = []
            for item in params.get("TablePrivilegeList"):
                obj = TablePrivilegeInfo()
                obj._deserialize(item)
                self._TablePrivilegeList.append(obj)
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DeleteBackUpDataRequest(AbstractModel):
    r"""DeleteBackUpData请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceId: 集群id
        :type InstanceId: str
        :param _BackUpJobId: 任务id
        :type BackUpJobId: int
        :param _IsDeleteAll: 是否删除所有数据
        :type IsDeleteAll: bool
        """
        self._InstanceId = None
        self._BackUpJobId = None
        self._IsDeleteAll = None

    @property
    def InstanceId(self):
        r"""集群id
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId

    @property
    def BackUpJobId(self):
        r"""任务id
        :rtype: int
        """
        return self._BackUpJobId

    @BackUpJobId.setter
    def BackUpJobId(self, BackUpJobId):
        self._BackUpJobId = BackUpJobId

    @property
    def IsDeleteAll(self):
        r"""是否删除所有数据
        :rtype: bool
        """
        return self._IsDeleteAll

    @IsDeleteAll.setter
    def IsDeleteAll(self, IsDeleteAll):
        self._IsDeleteAll = IsDeleteAll


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        self._BackUpJobId = params.get("BackUpJobId")
        self._IsDeleteAll = params.get("IsDeleteAll")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DeleteBackUpDataResponse(AbstractModel):
    r"""DeleteBackUpData返回参数结构体

    """

    def __init__(self):
        r"""
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._RequestId = None

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._RequestId = params.get("RequestId")


class DescribeBackUpJobDetailRequest(AbstractModel):
    r"""DescribeBackUpJobDetail请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceId: 集群id
        :type InstanceId: str
        :param _BackUpJobId: 任务id
        :type BackUpJobId: int
        """
        self._InstanceId = None
        self._BackUpJobId = None

    @property
    def InstanceId(self):
        r"""集群id
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId

    @property
    def BackUpJobId(self):
        r"""任务id
        :rtype: int
        """
        return self._BackUpJobId

    @BackUpJobId.setter
    def BackUpJobId(self, BackUpJobId):
        self._BackUpJobId = BackUpJobId


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        self._BackUpJobId = params.get("BackUpJobId")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeBackUpJobDetailResponse(AbstractModel):
    r"""DescribeBackUpJobDetail返回参数结构体

    """

    def __init__(self):
        r"""
        :param _TableContents: 备份表详情
        :type TableContents: list of BackupTableContent
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._TableContents = None
        self._RequestId = None

    @property
    def TableContents(self):
        r"""备份表详情
        :rtype: list of BackupTableContent
        """
        return self._TableContents

    @TableContents.setter
    def TableContents(self, TableContents):
        self._TableContents = TableContents

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("TableContents") is not None:
            self._TableContents = []
            for item in params.get("TableContents"):
                obj = BackupTableContent()
                obj._deserialize(item)
                self._TableContents.append(obj)
        self._RequestId = params.get("RequestId")


class DescribeBackUpJobRequest(AbstractModel):
    r"""DescribeBackUpJob请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceId: 集群id
        :type InstanceId: str
        :param _PageSize: 分页大小
        :type PageSize: int
        :param _PageNum: 页号
        :type PageNum: int
        :param _BeginTime: 开始时间
        :type BeginTime: str
        :param _EndTime: 结束时间
        :type EndTime: str
        """
        self._InstanceId = None
        self._PageSize = None
        self._PageNum = None
        self._BeginTime = None
        self._EndTime = None

    @property
    def InstanceId(self):
        r"""集群id
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId

    @property
    def PageSize(self):
        r"""分页大小
        :rtype: int
        """
        return self._PageSize

    @PageSize.setter
    def PageSize(self, PageSize):
        self._PageSize = PageSize

    @property
    def PageNum(self):
        r"""页号
        :rtype: int
        """
        return self._PageNum

    @PageNum.setter
    def PageNum(self, PageNum):
        self._PageNum = PageNum

    @property
    def BeginTime(self):
        r"""开始时间
        :rtype: str
        """
        return self._BeginTime

    @BeginTime.setter
    def BeginTime(self, BeginTime):
        self._BeginTime = BeginTime

    @property
    def EndTime(self):
        r"""结束时间
        :rtype: str
        """
        return self._EndTime

    @EndTime.setter
    def EndTime(self, EndTime):
        self._EndTime = EndTime


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        self._PageSize = params.get("PageSize")
        self._PageNum = params.get("PageNum")
        self._BeginTime = params.get("BeginTime")
        self._EndTime = params.get("EndTime")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeBackUpJobResponse(AbstractModel):
    r"""DescribeBackUpJob返回参数结构体

    """

    def __init__(self):
        r"""
        :param _BackUpJobs: 任务列表
        :type BackUpJobs: list of BackUpJobDisplay
        :param _ErrorMsg: 错误描述
        :type ErrorMsg: str
        :param _TotalCount: 数量
        :type TotalCount: int
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._BackUpJobs = None
        self._ErrorMsg = None
        self._TotalCount = None
        self._RequestId = None

    @property
    def BackUpJobs(self):
        r"""任务列表
        :rtype: list of BackUpJobDisplay
        """
        return self._BackUpJobs

    @BackUpJobs.setter
    def BackUpJobs(self, BackUpJobs):
        self._BackUpJobs = BackUpJobs

    @property
    def ErrorMsg(self):
        r"""错误描述
        :rtype: str
        """
        return self._ErrorMsg

    @ErrorMsg.setter
    def ErrorMsg(self, ErrorMsg):
        self._ErrorMsg = ErrorMsg

    @property
    def TotalCount(self):
        r"""数量
        :rtype: int
        """
        return self._TotalCount

    @TotalCount.setter
    def TotalCount(self, TotalCount):
        self._TotalCount = TotalCount

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("BackUpJobs") is not None:
            self._BackUpJobs = []
            for item in params.get("BackUpJobs"):
                obj = BackUpJobDisplay()
                obj._deserialize(item)
                self._BackUpJobs.append(obj)
        self._ErrorMsg = params.get("ErrorMsg")
        self._TotalCount = params.get("TotalCount")
        self._RequestId = params.get("RequestId")


class DescribeBackUpScheduleRequest(AbstractModel):
    r"""DescribeBackUpSchedule请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceId: 集群id
        :type InstanceId: str
        """
        self._InstanceId = None

    @property
    def InstanceId(self):
        r"""集群id
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeBackUpScheduleResponse(AbstractModel):
    r"""DescribeBackUpSchedule返回参数结构体

    """

    def __init__(self):
        r"""
        :param _BackUpOpened: 备份是否开启
        :type BackUpOpened: bool
        :param _MetaStrategy: 元数据备份策略
        :type MetaStrategy: :class:`tencentcloud.cdwch.v20200915.models.ScheduleStrategy`
        :param _DataStrategy: 表数据备份策略
        :type DataStrategy: :class:`tencentcloud.cdwch.v20200915.models.ScheduleStrategy`
        :param _BackUpContents: 备份表列表
        :type BackUpContents: list of BackupTableContent
        :param _BackUpStatus: 备份的状态
        :type BackUpStatus: int
        :param _ErrorMsg: 错误信息
        :type ErrorMsg: str
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._BackUpOpened = None
        self._MetaStrategy = None
        self._DataStrategy = None
        self._BackUpContents = None
        self._BackUpStatus = None
        self._ErrorMsg = None
        self._RequestId = None

    @property
    def BackUpOpened(self):
        r"""备份是否开启
        :rtype: bool
        """
        return self._BackUpOpened

    @BackUpOpened.setter
    def BackUpOpened(self, BackUpOpened):
        self._BackUpOpened = BackUpOpened

    @property
    def MetaStrategy(self):
        r"""元数据备份策略
        :rtype: :class:`tencentcloud.cdwch.v20200915.models.ScheduleStrategy`
        """
        return self._MetaStrategy

    @MetaStrategy.setter
    def MetaStrategy(self, MetaStrategy):
        self._MetaStrategy = MetaStrategy

    @property
    def DataStrategy(self):
        r"""表数据备份策略
        :rtype: :class:`tencentcloud.cdwch.v20200915.models.ScheduleStrategy`
        """
        return self._DataStrategy

    @DataStrategy.setter
    def DataStrategy(self, DataStrategy):
        self._DataStrategy = DataStrategy

    @property
    def BackUpContents(self):
        r"""备份表列表
        :rtype: list of BackupTableContent
        """
        return self._BackUpContents

    @BackUpContents.setter
    def BackUpContents(self, BackUpContents):
        self._BackUpContents = BackUpContents

    @property
    def BackUpStatus(self):
        r"""备份的状态
        :rtype: int
        """
        return self._BackUpStatus

    @BackUpStatus.setter
    def BackUpStatus(self, BackUpStatus):
        self._BackUpStatus = BackUpStatus

    @property
    def ErrorMsg(self):
        r"""错误信息
        :rtype: str
        """
        return self._ErrorMsg

    @ErrorMsg.setter
    def ErrorMsg(self, ErrorMsg):
        self._ErrorMsg = ErrorMsg

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._BackUpOpened = params.get("BackUpOpened")
        if params.get("MetaStrategy") is not None:
            self._MetaStrategy = ScheduleStrategy()
            self._MetaStrategy._deserialize(params.get("MetaStrategy"))
        if params.get("DataStrategy") is not None:
            self._DataStrategy = ScheduleStrategy()
            self._DataStrategy._deserialize(params.get("DataStrategy"))
        if params.get("BackUpContents") is not None:
            self._BackUpContents = []
            for item in params.get("BackUpContents"):
                obj = BackupTableContent()
                obj._deserialize(item)
                self._BackUpContents.append(obj)
        self._BackUpStatus = params.get("BackUpStatus")
        self._ErrorMsg = params.get("ErrorMsg")
        self._RequestId = params.get("RequestId")


class DescribeBackUpTablesRequest(AbstractModel):
    r"""DescribeBackUpTables请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceId: 集群id
        :type InstanceId: str
        """
        self._InstanceId = None

    @property
    def InstanceId(self):
        r"""集群id
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeBackUpTablesResponse(AbstractModel):
    r"""DescribeBackUpTables返回参数结构体

    """

    def __init__(self):
        r"""
        :param _AvailableTables: 可备份表列表
        :type AvailableTables: list of BackupTableContent
        :param _ErrorMsg: 错误描述
        :type ErrorMsg: str
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._AvailableTables = None
        self._ErrorMsg = None
        self._RequestId = None

    @property
    def AvailableTables(self):
        r"""可备份表列表
        :rtype: list of BackupTableContent
        """
        return self._AvailableTables

    @AvailableTables.setter
    def AvailableTables(self, AvailableTables):
        self._AvailableTables = AvailableTables

    @property
    def ErrorMsg(self):
        r"""错误描述
        :rtype: str
        """
        return self._ErrorMsg

    @ErrorMsg.setter
    def ErrorMsg(self, ErrorMsg):
        self._ErrorMsg = ErrorMsg

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("AvailableTables") is not None:
            self._AvailableTables = []
            for item in params.get("AvailableTables"):
                obj = BackupTableContent()
                obj._deserialize(item)
                self._AvailableTables.append(obj)
        self._ErrorMsg = params.get("ErrorMsg")
        self._RequestId = params.get("RequestId")


class DescribeCNInstancesRequest(AbstractModel):
    r"""DescribeCNInstances请求参数结构体

    """

    def __init__(self):
        r"""
        :param _SearchInstanceID: 搜索的集群id名称
        :type SearchInstanceID: str
        :param _SearchInstanceName: 搜索的集群name
        :type SearchInstanceName: str
        :param _Offset: 分页参数，第一页为0，第二页为10
        :type Offset: int
        :param _Limit: 分页参数，分页步长，默认为10
        :type Limit: int
        :param _SearchTags: 搜索标签列表
        :type SearchTags: list of SearchTags
        :param _InstanceType: 集群类型，弹性版或自研数仓版
        :type InstanceType: str
        :param _Components: 组件名称列表
        :type Components: list of str
        """
        self._SearchInstanceID = None
        self._SearchInstanceName = None
        self._Offset = None
        self._Limit = None
        self._SearchTags = None
        self._InstanceType = None
        self._Components = None

    @property
    def SearchInstanceID(self):
        r"""搜索的集群id名称
        :rtype: str
        """
        return self._SearchInstanceID

    @SearchInstanceID.setter
    def SearchInstanceID(self, SearchInstanceID):
        self._SearchInstanceID = SearchInstanceID

    @property
    def SearchInstanceName(self):
        r"""搜索的集群name
        :rtype: str
        """
        return self._SearchInstanceName

    @SearchInstanceName.setter
    def SearchInstanceName(self, SearchInstanceName):
        self._SearchInstanceName = SearchInstanceName

    @property
    def Offset(self):
        r"""分页参数，第一页为0，第二页为10
        :rtype: int
        """
        return self._Offset

    @Offset.setter
    def Offset(self, Offset):
        self._Offset = Offset

    @property
    def Limit(self):
        r"""分页参数，分页步长，默认为10
        :rtype: int
        """
        return self._Limit

    @Limit.setter
    def Limit(self, Limit):
        self._Limit = Limit

    @property
    def SearchTags(self):
        r"""搜索标签列表
        :rtype: list of SearchTags
        """
        return self._SearchTags

    @SearchTags.setter
    def SearchTags(self, SearchTags):
        self._SearchTags = SearchTags

    @property
    def InstanceType(self):
        r"""集群类型，弹性版或自研数仓版
        :rtype: str
        """
        return self._InstanceType

    @InstanceType.setter
    def InstanceType(self, InstanceType):
        self._InstanceType = InstanceType

    @property
    def Components(self):
        r"""组件名称列表
        :rtype: list of str
        """
        return self._Components

    @Components.setter
    def Components(self, Components):
        self._Components = Components


    def _deserialize(self, params):
        self._SearchInstanceID = params.get("SearchInstanceID")
        self._SearchInstanceName = params.get("SearchInstanceName")
        self._Offset = params.get("Offset")
        self._Limit = params.get("Limit")
        if params.get("SearchTags") is not None:
            self._SearchTags = []
            for item in params.get("SearchTags"):
                obj = SearchTags()
                obj._deserialize(item)
                self._SearchTags.append(obj)
        self._InstanceType = params.get("InstanceType")
        self._Components = params.get("Components")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeCNInstancesResponse(AbstractModel):
    r"""DescribeCNInstances返回参数结构体

    """

    def __init__(self):
        r"""
        :param _TotalCount: 实例总数
        :type TotalCount: int
        :param _InstancesList: 实例数组
        :type InstancesList: list of CnInstanceInfo
        :param _ErrorMsg: 错误信息
        :type ErrorMsg: str
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._TotalCount = None
        self._InstancesList = None
        self._ErrorMsg = None
        self._RequestId = None

    @property
    def TotalCount(self):
        r"""实例总数
        :rtype: int
        """
        return self._TotalCount

    @TotalCount.setter
    def TotalCount(self, TotalCount):
        self._TotalCount = TotalCount

    @property
    def InstancesList(self):
        r"""实例数组
        :rtype: list of CnInstanceInfo
        """
        return self._InstancesList

    @InstancesList.setter
    def InstancesList(self, InstancesList):
        self._InstancesList = InstancesList

    @property
    def ErrorMsg(self):
        r"""错误信息
        :rtype: str
        """
        return self._ErrorMsg

    @ErrorMsg.setter
    def ErrorMsg(self, ErrorMsg):
        self._ErrorMsg = ErrorMsg

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._TotalCount = params.get("TotalCount")
        if params.get("InstancesList") is not None:
            self._InstancesList = []
            for item in params.get("InstancesList"):
                obj = CnInstanceInfo()
                obj._deserialize(item)
                self._InstancesList.append(obj)
        self._ErrorMsg = params.get("ErrorMsg")
        self._RequestId = params.get("RequestId")


class DescribeCkSqlApisRequest(AbstractModel):
    r"""DescribeCkSqlApis请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceId: <p>实例id</p>
        :type InstanceId: str
        :param _ApiType: <p>api接口名称,GetClusters:获取集群cluster列表<br>GetSystemUsers:获取系统用户列表<br>CheckNodeCluster: 检查节点是否隶属一个cluster<br>GetClusterDatabases: 获取一个cluster下的数据库列表<br>GetClusterTables: 获取一个cluster下的数据库表列表<br>GetPrivilegeUsers: 获取授权的用户列表<br>GET_USER_CLUSTER_PRIVILEGES:获取用户cluster下的权限<br>GetUserClusterNewPrivileges:获取用户cluster下的权限 (新版）<br>RevokeClusterUser:解绑cluster用户<br>DeleteSystemUser:删除系统用户 —— 必须所有cluster先解绑<br>GetUserOptionMessages:获取用户配置备注信息<br>GET_USER_CONFIGS:获取用户配置列表  QUOTA、PROFILE、POLICY</p>
        :type ApiType: str
        :param _Cluster: <p>clickhouse逻辑集群名称，可通过连接集群执行 <code>SHOW CLUSTERS</code> 查询获得。当 ApiType 取值为 GET_SYSTEM_USERS、GET_PRIVILEGE_USERS、GET_CLUSTER_DATABASES或GET_CLUSTER_TABLES 时，本参数必填。</p>
        :type Cluster: str
        :param _UserName: <p>用户名称，api与user相关的必填</p>
        :type UserName: str
        :param _UserType: <p>账户的类型</p>
        :type UserType: str
        :param _InstanceType: <p>实例类型</p><p>枚举值：</p><ul><li>SSC： 弹性版实例</li><li>Standard： 标准版实例</li></ul>
        :type InstanceType: str
        """
        self._InstanceId = None
        self._ApiType = None
        self._Cluster = None
        self._UserName = None
        self._UserType = None
        self._InstanceType = None

    @property
    def InstanceId(self):
        r"""<p>实例id</p>
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId

    @property
    def ApiType(self):
        r"""<p>api接口名称,GetClusters:获取集群cluster列表<br>GetSystemUsers:获取系统用户列表<br>CheckNodeCluster: 检查节点是否隶属一个cluster<br>GetClusterDatabases: 获取一个cluster下的数据库列表<br>GetClusterTables: 获取一个cluster下的数据库表列表<br>GetPrivilegeUsers: 获取授权的用户列表<br>GET_USER_CLUSTER_PRIVILEGES:获取用户cluster下的权限<br>GetUserClusterNewPrivileges:获取用户cluster下的权限 (新版）<br>RevokeClusterUser:解绑cluster用户<br>DeleteSystemUser:删除系统用户 —— 必须所有cluster先解绑<br>GetUserOptionMessages:获取用户配置备注信息<br>GET_USER_CONFIGS:获取用户配置列表  QUOTA、PROFILE、POLICY</p>
        :rtype: str
        """
        return self._ApiType

    @ApiType.setter
    def ApiType(self, ApiType):
        self._ApiType = ApiType

    @property
    def Cluster(self):
        r"""<p>clickhouse逻辑集群名称，可通过连接集群执行 <code>SHOW CLUSTERS</code> 查询获得。当 ApiType 取值为 GET_SYSTEM_USERS、GET_PRIVILEGE_USERS、GET_CLUSTER_DATABASES或GET_CLUSTER_TABLES 时，本参数必填。</p>
        :rtype: str
        """
        return self._Cluster

    @Cluster.setter
    def Cluster(self, Cluster):
        self._Cluster = Cluster

    @property
    def UserName(self):
        r"""<p>用户名称，api与user相关的必填</p>
        :rtype: str
        """
        return self._UserName

    @UserName.setter
    def UserName(self, UserName):
        self._UserName = UserName

    @property
    def UserType(self):
        r"""<p>账户的类型</p>
        :rtype: str
        """
        return self._UserType

    @UserType.setter
    def UserType(self, UserType):
        self._UserType = UserType

    @property
    def InstanceType(self):
        r"""<p>实例类型</p><p>枚举值：</p><ul><li>SSC： 弹性版实例</li><li>Standard： 标准版实例</li></ul>
        :rtype: str
        """
        return self._InstanceType

    @InstanceType.setter
    def InstanceType(self, InstanceType):
        self._InstanceType = InstanceType


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        self._ApiType = params.get("ApiType")
        self._Cluster = params.get("Cluster")
        self._UserName = params.get("UserName")
        self._UserType = params.get("UserType")
        self._InstanceType = params.get("InstanceType")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeCkSqlApisResponse(AbstractModel):
    r"""DescribeCkSqlApis返回参数结构体

    """

    def __init__(self):
        r"""
        :param _ReturnData: <p>返回的查询数据，大部分情况是list，也可能是bool</p>
        :type ReturnData: str
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._ReturnData = None
        self._RequestId = None

    @property
    def ReturnData(self):
        r"""<p>返回的查询数据，大部分情况是list，也可能是bool</p>
        :rtype: str
        """
        return self._ReturnData

    @ReturnData.setter
    def ReturnData(self, ReturnData):
        self._ReturnData = ReturnData

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._ReturnData = params.get("ReturnData")
        self._RequestId = params.get("RequestId")


class DescribeClusterConfigsRequest(AbstractModel):
    r"""DescribeClusterConfigs请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceId: 集群实例ID
        :type InstanceId: str
        """
        self._InstanceId = None

    @property
    def InstanceId(self):
        r"""集群实例ID
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeClusterConfigsResponse(AbstractModel):
    r"""DescribeClusterConfigs返回参数结构体

    """

    def __init__(self):
        r"""
        :param _ClusterConfList: 返回实例的配置文件相关的信息
        :type ClusterConfList: list of ClusterConfigsInfoFromEMR
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._ClusterConfList = None
        self._RequestId = None

    @property
    def ClusterConfList(self):
        r"""返回实例的配置文件相关的信息
        :rtype: list of ClusterConfigsInfoFromEMR
        """
        return self._ClusterConfList

    @ClusterConfList.setter
    def ClusterConfList(self, ClusterConfList):
        self._ClusterConfList = ClusterConfList

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("ClusterConfList") is not None:
            self._ClusterConfList = []
            for item in params.get("ClusterConfList"):
                obj = ClusterConfigsInfoFromEMR()
                obj._deserialize(item)
                self._ClusterConfList.append(obj)
        self._RequestId = params.get("RequestId")


class DescribeEventTasksRequest(AbstractModel):
    r"""DescribeEventTasks请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceId: 集群id
        :type InstanceId: str
        :param _EventTaskId: 过滤的事件任务id
        :type EventTaskId: int
        :param _PageNumber: 页码，默认为1
        :type PageNumber: int
        :param _PageSize: 每页数量（支持10、20、30、50、100、200），默认为100
        :type PageSize: int
        :param _EventCode: 事件名称过滤
        :type EventCode: str
        :param _Status: (1-待处理;2-已预约;3-处理中;4-已结束;5-处理中;-1-已忽略;-2-已删除)
        :type Status: list of int
        :param _StartTime: 创建时间范围开始 (格式: YYYY-MM-DD HH:MM:SS)，最大支持查询180天信息
        :type StartTime: str
        :param _EndTime: 创建时间范围结束 (格式: YYYY-MM-DD HH:MM:SS)
        :type EndTime: str
        :param _SortField: 排序字段（事件类型：event_code；触发时间：create_time；完成时间：end_time）
        :type SortField: str
        :param _SortOrder: 排序顺序 (asc/desc)
        :type SortOrder: str
        """
        self._InstanceId = None
        self._EventTaskId = None
        self._PageNumber = None
        self._PageSize = None
        self._EventCode = None
        self._Status = None
        self._StartTime = None
        self._EndTime = None
        self._SortField = None
        self._SortOrder = None

    @property
    def InstanceId(self):
        r"""集群id
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId

    @property
    def EventTaskId(self):
        r"""过滤的事件任务id
        :rtype: int
        """
        return self._EventTaskId

    @EventTaskId.setter
    def EventTaskId(self, EventTaskId):
        self._EventTaskId = EventTaskId

    @property
    def PageNumber(self):
        r"""页码，默认为1
        :rtype: int
        """
        return self._PageNumber

    @PageNumber.setter
    def PageNumber(self, PageNumber):
        self._PageNumber = PageNumber

    @property
    def PageSize(self):
        r"""每页数量（支持10、20、30、50、100、200），默认为100
        :rtype: int
        """
        return self._PageSize

    @PageSize.setter
    def PageSize(self, PageSize):
        self._PageSize = PageSize

    @property
    def EventCode(self):
        r"""事件名称过滤
        :rtype: str
        """
        return self._EventCode

    @EventCode.setter
    def EventCode(self, EventCode):
        self._EventCode = EventCode

    @property
    def Status(self):
        r"""(1-待处理;2-已预约;3-处理中;4-已结束;5-处理中;-1-已忽略;-2-已删除)
        :rtype: list of int
        """
        return self._Status

    @Status.setter
    def Status(self, Status):
        self._Status = Status

    @property
    def StartTime(self):
        r"""创建时间范围开始 (格式: YYYY-MM-DD HH:MM:SS)，最大支持查询180天信息
        :rtype: str
        """
        return self._StartTime

    @StartTime.setter
    def StartTime(self, StartTime):
        self._StartTime = StartTime

    @property
    def EndTime(self):
        r"""创建时间范围结束 (格式: YYYY-MM-DD HH:MM:SS)
        :rtype: str
        """
        return self._EndTime

    @EndTime.setter
    def EndTime(self, EndTime):
        self._EndTime = EndTime

    @property
    def SortField(self):
        r"""排序字段（事件类型：event_code；触发时间：create_time；完成时间：end_time）
        :rtype: str
        """
        return self._SortField

    @SortField.setter
    def SortField(self, SortField):
        self._SortField = SortField

    @property
    def SortOrder(self):
        r"""排序顺序 (asc/desc)
        :rtype: str
        """
        return self._SortOrder

    @SortOrder.setter
    def SortOrder(self, SortOrder):
        self._SortOrder = SortOrder


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        self._EventTaskId = params.get("EventTaskId")
        self._PageNumber = params.get("PageNumber")
        self._PageSize = params.get("PageSize")
        self._EventCode = params.get("EventCode")
        self._Status = params.get("Status")
        self._StartTime = params.get("StartTime")
        self._EndTime = params.get("EndTime")
        self._SortField = params.get("SortField")
        self._SortOrder = params.get("SortOrder")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeEventTasksResponse(AbstractModel):
    r"""DescribeEventTasks返回参数结构体

    """

    def __init__(self):
        r"""
        :param _EventTasks: 产生的事件任务
        :type EventTasks: list of EventTask
        :param _TotalCount: 事件任务总数
        :type TotalCount: int
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._EventTasks = None
        self._TotalCount = None
        self._RequestId = None

    @property
    def EventTasks(self):
        r"""产生的事件任务
        :rtype: list of EventTask
        """
        return self._EventTasks

    @EventTasks.setter
    def EventTasks(self, EventTasks):
        self._EventTasks = EventTasks

    @property
    def TotalCount(self):
        r"""事件任务总数
        :rtype: int
        """
        return self._TotalCount

    @TotalCount.setter
    def TotalCount(self, TotalCount):
        self._TotalCount = TotalCount

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("EventTasks") is not None:
            self._EventTasks = []
            for item in params.get("EventTasks"):
                obj = EventTask()
                obj._deserialize(item)
                self._EventTasks.append(obj)
        self._TotalCount = params.get("TotalCount")
        self._RequestId = params.get("RequestId")


class DescribeInstanceClustersRequest(AbstractModel):
    r"""DescribeInstanceClusters请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceId: 实例ID
        :type InstanceId: str
        """
        self._InstanceId = None

    @property
    def InstanceId(self):
        r"""实例ID
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeInstanceClustersResponse(AbstractModel):
    r"""DescribeInstanceClusters返回参数结构体

    """

    def __init__(self):
        r"""
        :param _Clusters: cluster列表
        :type Clusters: list of ClusterInfo
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._Clusters = None
        self._RequestId = None

    @property
    def Clusters(self):
        r"""cluster列表
        :rtype: list of ClusterInfo
        """
        return self._Clusters

    @Clusters.setter
    def Clusters(self, Clusters):
        self._Clusters = Clusters

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("Clusters") is not None:
            self._Clusters = []
            for item in params.get("Clusters"):
                obj = ClusterInfo()
                obj._deserialize(item)
                self._Clusters.append(obj)
        self._RequestId = params.get("RequestId")


class DescribeInstanceKeyValConfigsRequest(AbstractModel):
    r"""DescribeInstanceKeyValConfigs请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceId: 集群实例ID
        :type InstanceId: str
        :param _SearchConfigName: 搜索的配置项名称
        :type SearchConfigName: str
        """
        self._InstanceId = None
        self._SearchConfigName = None

    @property
    def InstanceId(self):
        r"""集群实例ID
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId

    @property
    def SearchConfigName(self):
        r"""搜索的配置项名称
        :rtype: str
        """
        return self._SearchConfigName

    @SearchConfigName.setter
    def SearchConfigName(self, SearchConfigName):
        self._SearchConfigName = SearchConfigName


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        self._SearchConfigName = params.get("SearchConfigName")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeInstanceKeyValConfigsResponse(AbstractModel):
    r"""DescribeInstanceKeyValConfigs返回参数结构体

    """

    def __init__(self):
        r"""
        :param _ConfigItems: 参数列表
        :type ConfigItems: list of InstanceConfigInfo
        :param _UnConfigItems: 未配置的参数列表
注意：此字段可能返回 null，表示取不到有效值。
        :type UnConfigItems: list of InstanceConfigInfo
        :param _MapConfigItems: 配置的多层级参数列表
注意：此字段可能返回 null，表示取不到有效值。
        :type MapConfigItems: list of MapConfigItem
        :param _ErrorMsg: 错误信息
        :type ErrorMsg: str
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._ConfigItems = None
        self._UnConfigItems = None
        self._MapConfigItems = None
        self._ErrorMsg = None
        self._RequestId = None

    @property
    def ConfigItems(self):
        r"""参数列表
        :rtype: list of InstanceConfigInfo
        """
        return self._ConfigItems

    @ConfigItems.setter
    def ConfigItems(self, ConfigItems):
        self._ConfigItems = ConfigItems

    @property
    def UnConfigItems(self):
        r"""未配置的参数列表
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of InstanceConfigInfo
        """
        return self._UnConfigItems

    @UnConfigItems.setter
    def UnConfigItems(self, UnConfigItems):
        self._UnConfigItems = UnConfigItems

    @property
    def MapConfigItems(self):
        r"""配置的多层级参数列表
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of MapConfigItem
        """
        return self._MapConfigItems

    @MapConfigItems.setter
    def MapConfigItems(self, MapConfigItems):
        self._MapConfigItems = MapConfigItems

    @property
    def ErrorMsg(self):
        r"""错误信息
        :rtype: str
        """
        return self._ErrorMsg

    @ErrorMsg.setter
    def ErrorMsg(self, ErrorMsg):
        self._ErrorMsg = ErrorMsg

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("ConfigItems") is not None:
            self._ConfigItems = []
            for item in params.get("ConfigItems"):
                obj = InstanceConfigInfo()
                obj._deserialize(item)
                self._ConfigItems.append(obj)
        if params.get("UnConfigItems") is not None:
            self._UnConfigItems = []
            for item in params.get("UnConfigItems"):
                obj = InstanceConfigInfo()
                obj._deserialize(item)
                self._UnConfigItems.append(obj)
        if params.get("MapConfigItems") is not None:
            self._MapConfigItems = []
            for item in params.get("MapConfigItems"):
                obj = MapConfigItem()
                obj._deserialize(item)
                self._MapConfigItems.append(obj)
        self._ErrorMsg = params.get("ErrorMsg")
        self._RequestId = params.get("RequestId")


class DescribeInstanceNodesRequest(AbstractModel):
    r"""DescribeInstanceNodes请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceId: 集群实例ID
        :type InstanceId: str
        :param _NodeRole: 集群角色类型，“DATA” 为数据节点、“COMMON” 为 ZooKeeper 节点，默认为 "DATA" 数据节点。
        :type NodeRole: str
        :param _Offset: 分页参数，第一页为0，第二页为10
        :type Offset: int
        :param _Limit: 分页参数，分页步长，默认为10
        :type Limit: int
        :param _DisplayPolicy: 展现策略，All时显示所有
        :type DisplayPolicy: str
        :param _ForceAll: 当true的时候返回所有节点，即Limit无限大
        :type ForceAll: bool
        """
        self._InstanceId = None
        self._NodeRole = None
        self._Offset = None
        self._Limit = None
        self._DisplayPolicy = None
        self._ForceAll = None

    @property
    def InstanceId(self):
        r"""集群实例ID
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId

    @property
    def NodeRole(self):
        r"""集群角色类型，“DATA” 为数据节点、“COMMON” 为 ZooKeeper 节点，默认为 "DATA" 数据节点。
        :rtype: str
        """
        return self._NodeRole

    @NodeRole.setter
    def NodeRole(self, NodeRole):
        self._NodeRole = NodeRole

    @property
    def Offset(self):
        r"""分页参数，第一页为0，第二页为10
        :rtype: int
        """
        return self._Offset

    @Offset.setter
    def Offset(self, Offset):
        self._Offset = Offset

    @property
    def Limit(self):
        r"""分页参数，分页步长，默认为10
        :rtype: int
        """
        return self._Limit

    @Limit.setter
    def Limit(self, Limit):
        self._Limit = Limit

    @property
    def DisplayPolicy(self):
        r"""展现策略，All时显示所有
        :rtype: str
        """
        return self._DisplayPolicy

    @DisplayPolicy.setter
    def DisplayPolicy(self, DisplayPolicy):
        self._DisplayPolicy = DisplayPolicy

    @property
    def ForceAll(self):
        r"""当true的时候返回所有节点，即Limit无限大
        :rtype: bool
        """
        return self._ForceAll

    @ForceAll.setter
    def ForceAll(self, ForceAll):
        self._ForceAll = ForceAll


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        self._NodeRole = params.get("NodeRole")
        self._Offset = params.get("Offset")
        self._Limit = params.get("Limit")
        self._DisplayPolicy = params.get("DisplayPolicy")
        self._ForceAll = params.get("ForceAll")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeInstanceNodesResponse(AbstractModel):
    r"""DescribeInstanceNodes返回参数结构体

    """

    def __init__(self):
        r"""
        :param _TotalCount: 总数
        :type TotalCount: int
        :param _InstanceNodesList: 实例节点总数
注意：此字段可能返回 null，表示取不到有效值。
        :type InstanceNodesList: list of InstanceNode
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._TotalCount = None
        self._InstanceNodesList = None
        self._RequestId = None

    @property
    def TotalCount(self):
        r"""总数
        :rtype: int
        """
        return self._TotalCount

    @TotalCount.setter
    def TotalCount(self, TotalCount):
        self._TotalCount = TotalCount

    @property
    def InstanceNodesList(self):
        r"""实例节点总数
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of InstanceNode
        """
        return self._InstanceNodesList

    @InstanceNodesList.setter
    def InstanceNodesList(self, InstanceNodesList):
        self._InstanceNodesList = InstanceNodesList

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._TotalCount = params.get("TotalCount")
        if params.get("InstanceNodesList") is not None:
            self._InstanceNodesList = []
            for item in params.get("InstanceNodesList"):
                obj = InstanceNode()
                obj._deserialize(item)
                self._InstanceNodesList.append(obj)
        self._RequestId = params.get("RequestId")


class DescribeInstanceRequest(AbstractModel):
    r"""DescribeInstance请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceId: <p>集群实例ID</p>
        :type InstanceId: str
        :param _IsOpenApi: <p>是否是open api查询</p>
        :type IsOpenApi: bool
        """
        self._InstanceId = None
        self._IsOpenApi = None

    @property
    def InstanceId(self):
        r"""<p>集群实例ID</p>
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId

    @property
    def IsOpenApi(self):
        r"""<p>是否是open api查询</p>
        :rtype: bool
        """
        return self._IsOpenApi

    @IsOpenApi.setter
    def IsOpenApi(self, IsOpenApi):
        self._IsOpenApi = IsOpenApi


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        self._IsOpenApi = params.get("IsOpenApi")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeInstanceResponse(AbstractModel):
    r"""DescribeInstance返回参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceInfo: <p>实例描述信息</p>
        :type InstanceInfo: :class:`tencentcloud.cdwch.v20200915.models.InstanceInfo`
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._InstanceInfo = None
        self._RequestId = None

    @property
    def InstanceInfo(self):
        r"""<p>实例描述信息</p>
        :rtype: :class:`tencentcloud.cdwch.v20200915.models.InstanceInfo`
        """
        return self._InstanceInfo

    @InstanceInfo.setter
    def InstanceInfo(self, InstanceInfo):
        self._InstanceInfo = InstanceInfo

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("InstanceInfo") is not None:
            self._InstanceInfo = InstanceInfo()
            self._InstanceInfo._deserialize(params.get("InstanceInfo"))
        self._RequestId = params.get("RequestId")


class DescribeInstanceShardsRequest(AbstractModel):
    r"""DescribeInstanceShards请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceId: 集群实例ID
        :type InstanceId: str
        """
        self._InstanceId = None

    @property
    def InstanceId(self):
        r"""集群实例ID
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeInstanceShardsResponse(AbstractModel):
    r"""DescribeInstanceShards返回参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceShardsList: 实例shard信息
        :type InstanceShardsList: str
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._InstanceShardsList = None
        self._RequestId = None

    @property
    def InstanceShardsList(self):
        r"""实例shard信息
        :rtype: str
        """
        return self._InstanceShardsList

    @InstanceShardsList.setter
    def InstanceShardsList(self, InstanceShardsList):
        self._InstanceShardsList = InstanceShardsList

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._InstanceShardsList = params.get("InstanceShardsList")
        self._RequestId = params.get("RequestId")


class DescribeInstanceStateRequest(AbstractModel):
    r"""DescribeInstanceState请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceId: 集群实例名称
        :type InstanceId: str
        """
        self._InstanceId = None

    @property
    def InstanceId(self):
        r"""集群实例名称
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeInstanceStateResponse(AbstractModel):
    r"""DescribeInstanceState返回参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceState: 集群状态，例如：Serving
        :type InstanceState: str
        :param _FlowCreateTime: 集群操作创建时间
        :type FlowCreateTime: str
        :param _FlowName: 集群操作名称
        :type FlowName: str
        :param _FlowProgress: 集群操作进度
        :type FlowProgress: float
        :param _InstanceStateDesc: 集群状态描述，例如：运行中
        :type InstanceStateDesc: str
        :param _FlowMsg: 集群流程错误信息，例如：“创建失败，资源不足”
        :type FlowMsg: str
        :param _ProcessName: 当前步骤的名称，例如：”购买资源中“
        :type ProcessName: str
        :param _ProcessSubName: 当前步骤的名称，例如：”购买资源中“
        :type ProcessSubName: str
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._InstanceState = None
        self._FlowCreateTime = None
        self._FlowName = None
        self._FlowProgress = None
        self._InstanceStateDesc = None
        self._FlowMsg = None
        self._ProcessName = None
        self._ProcessSubName = None
        self._RequestId = None

    @property
    def InstanceState(self):
        r"""集群状态，例如：Serving
        :rtype: str
        """
        return self._InstanceState

    @InstanceState.setter
    def InstanceState(self, InstanceState):
        self._InstanceState = InstanceState

    @property
    def FlowCreateTime(self):
        r"""集群操作创建时间
        :rtype: str
        """
        return self._FlowCreateTime

    @FlowCreateTime.setter
    def FlowCreateTime(self, FlowCreateTime):
        self._FlowCreateTime = FlowCreateTime

    @property
    def FlowName(self):
        r"""集群操作名称
        :rtype: str
        """
        return self._FlowName

    @FlowName.setter
    def FlowName(self, FlowName):
        self._FlowName = FlowName

    @property
    def FlowProgress(self):
        r"""集群操作进度
        :rtype: float
        """
        return self._FlowProgress

    @FlowProgress.setter
    def FlowProgress(self, FlowProgress):
        self._FlowProgress = FlowProgress

    @property
    def InstanceStateDesc(self):
        r"""集群状态描述，例如：运行中
        :rtype: str
        """
        return self._InstanceStateDesc

    @InstanceStateDesc.setter
    def InstanceStateDesc(self, InstanceStateDesc):
        self._InstanceStateDesc = InstanceStateDesc

    @property
    def FlowMsg(self):
        r"""集群流程错误信息，例如：“创建失败，资源不足”
        :rtype: str
        """
        return self._FlowMsg

    @FlowMsg.setter
    def FlowMsg(self, FlowMsg):
        self._FlowMsg = FlowMsg

    @property
    def ProcessName(self):
        r"""当前步骤的名称，例如：”购买资源中“
        :rtype: str
        """
        return self._ProcessName

    @ProcessName.setter
    def ProcessName(self, ProcessName):
        self._ProcessName = ProcessName

    @property
    def ProcessSubName(self):
        r"""当前步骤的名称，例如：”购买资源中“
        :rtype: str
        """
        return self._ProcessSubName

    @ProcessSubName.setter
    def ProcessSubName(self, ProcessSubName):
        self._ProcessSubName = ProcessSubName

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._InstanceState = params.get("InstanceState")
        self._FlowCreateTime = params.get("FlowCreateTime")
        self._FlowName = params.get("FlowName")
        self._FlowProgress = params.get("FlowProgress")
        self._InstanceStateDesc = params.get("InstanceStateDesc")
        self._FlowMsg = params.get("FlowMsg")
        self._ProcessName = params.get("ProcessName")
        self._ProcessSubName = params.get("ProcessSubName")
        self._RequestId = params.get("RequestId")


class DescribeInstancesNewRequest(AbstractModel):
    r"""DescribeInstancesNew请求参数结构体

    """

    def __init__(self):
        r"""
        :param _SearchInstanceId: 搜索的集群id名称
        :type SearchInstanceId: str
        :param _SearchInstanceName: 搜索的集群name
        :type SearchInstanceName: str
        :param _Offset: 分页参数，第一页为0，第二页为10
        :type Offset: int
        :param _Limit: 分页参数，分页步长，默认为10
        :type Limit: int
        :param _SearchTags: 搜索标签列表
        :type SearchTags: list of SearchTags
        :param _IsSimple: 信息详细与否
        :type IsSimple: bool
        :param _Vips: vip列表
        :type Vips: list of str
        """
        self._SearchInstanceId = None
        self._SearchInstanceName = None
        self._Offset = None
        self._Limit = None
        self._SearchTags = None
        self._IsSimple = None
        self._Vips = None

    @property
    def SearchInstanceId(self):
        r"""搜索的集群id名称
        :rtype: str
        """
        return self._SearchInstanceId

    @SearchInstanceId.setter
    def SearchInstanceId(self, SearchInstanceId):
        self._SearchInstanceId = SearchInstanceId

    @property
    def SearchInstanceName(self):
        r"""搜索的集群name
        :rtype: str
        """
        return self._SearchInstanceName

    @SearchInstanceName.setter
    def SearchInstanceName(self, SearchInstanceName):
        self._SearchInstanceName = SearchInstanceName

    @property
    def Offset(self):
        r"""分页参数，第一页为0，第二页为10
        :rtype: int
        """
        return self._Offset

    @Offset.setter
    def Offset(self, Offset):
        self._Offset = Offset

    @property
    def Limit(self):
        r"""分页参数，分页步长，默认为10
        :rtype: int
        """
        return self._Limit

    @Limit.setter
    def Limit(self, Limit):
        self._Limit = Limit

    @property
    def SearchTags(self):
        r"""搜索标签列表
        :rtype: list of SearchTags
        """
        return self._SearchTags

    @SearchTags.setter
    def SearchTags(self, SearchTags):
        self._SearchTags = SearchTags

    @property
    def IsSimple(self):
        r"""信息详细与否
        :rtype: bool
        """
        return self._IsSimple

    @IsSimple.setter
    def IsSimple(self, IsSimple):
        self._IsSimple = IsSimple

    @property
    def Vips(self):
        r"""vip列表
        :rtype: list of str
        """
        return self._Vips

    @Vips.setter
    def Vips(self, Vips):
        self._Vips = Vips


    def _deserialize(self, params):
        self._SearchInstanceId = params.get("SearchInstanceId")
        self._SearchInstanceName = params.get("SearchInstanceName")
        self._Offset = params.get("Offset")
        self._Limit = params.get("Limit")
        if params.get("SearchTags") is not None:
            self._SearchTags = []
            for item in params.get("SearchTags"):
                obj = SearchTags()
                obj._deserialize(item)
                self._SearchTags.append(obj)
        self._IsSimple = params.get("IsSimple")
        self._Vips = params.get("Vips")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeInstancesNewResponse(AbstractModel):
    r"""DescribeInstancesNew返回参数结构体

    """

    def __init__(self):
        r"""
        :param _TotalCount: 实例总数
        :type TotalCount: int
        :param _InstancesList: 实例数组
        :type InstancesList: list of InstanceInfo
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._TotalCount = None
        self._InstancesList = None
        self._RequestId = None

    @property
    def TotalCount(self):
        r"""实例总数
        :rtype: int
        """
        return self._TotalCount

    @TotalCount.setter
    def TotalCount(self, TotalCount):
        self._TotalCount = TotalCount

    @property
    def InstancesList(self):
        r"""实例数组
        :rtype: list of InstanceInfo
        """
        return self._InstancesList

    @InstancesList.setter
    def InstancesList(self, InstancesList):
        self._InstancesList = InstancesList

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._TotalCount = params.get("TotalCount")
        if params.get("InstancesList") is not None:
            self._InstancesList = []
            for item in params.get("InstancesList"):
                obj = InstanceInfo()
                obj._deserialize(item)
                self._InstancesList.append(obj)
        self._RequestId = params.get("RequestId")


class DescribeSpecRequest(AbstractModel):
    r"""DescribeSpec请求参数结构体

    """

    def __init__(self):
        r"""
        :param _Zone: 地域信息，例如"ap-guangzhou-1"
        :type Zone: str
        :param _PayMode: 计费类型，PREPAID 包年包月，POSTPAID_BY_HOUR 按量计费
        :type PayMode: str
        :param _IsElastic: 是否弹性ck
        :type IsElastic: bool
        :param _CaseType: 是否是购买页面需要的spec
        :type CaseType: int
        """
        self._Zone = None
        self._PayMode = None
        self._IsElastic = None
        self._CaseType = None

    @property
    def Zone(self):
        r"""地域信息，例如"ap-guangzhou-1"
        :rtype: str
        """
        return self._Zone

    @Zone.setter
    def Zone(self, Zone):
        self._Zone = Zone

    @property
    def PayMode(self):
        r"""计费类型，PREPAID 包年包月，POSTPAID_BY_HOUR 按量计费
        :rtype: str
        """
        return self._PayMode

    @PayMode.setter
    def PayMode(self, PayMode):
        self._PayMode = PayMode

    @property
    def IsElastic(self):
        r"""是否弹性ck
        :rtype: bool
        """
        return self._IsElastic

    @IsElastic.setter
    def IsElastic(self, IsElastic):
        self._IsElastic = IsElastic

    @property
    def CaseType(self):
        r"""是否是购买页面需要的spec
        :rtype: int
        """
        return self._CaseType

    @CaseType.setter
    def CaseType(self, CaseType):
        self._CaseType = CaseType


    def _deserialize(self, params):
        self._Zone = params.get("Zone")
        self._PayMode = params.get("PayMode")
        self._IsElastic = params.get("IsElastic")
        self._CaseType = params.get("CaseType")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeSpecResponse(AbstractModel):
    r"""DescribeSpec返回参数结构体

    """

    def __init__(self):
        r"""
        :param _CommonSpec: zookeeper节点规格描述
        :type CommonSpec: list of ResourceSpec
        :param _DataSpec: 数据节点规格描述
        :type DataSpec: list of ResourceSpec
        :param _AttachCBSSpec: 云盘列表
        :type AttachCBSSpec: list of DiskSpec
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._CommonSpec = None
        self._DataSpec = None
        self._AttachCBSSpec = None
        self._RequestId = None

    @property
    def CommonSpec(self):
        r"""zookeeper节点规格描述
        :rtype: list of ResourceSpec
        """
        return self._CommonSpec

    @CommonSpec.setter
    def CommonSpec(self, CommonSpec):
        self._CommonSpec = CommonSpec

    @property
    def DataSpec(self):
        r"""数据节点规格描述
        :rtype: list of ResourceSpec
        """
        return self._DataSpec

    @DataSpec.setter
    def DataSpec(self, DataSpec):
        self._DataSpec = DataSpec

    @property
    def AttachCBSSpec(self):
        r"""云盘列表
        :rtype: list of DiskSpec
        """
        return self._AttachCBSSpec

    @AttachCBSSpec.setter
    def AttachCBSSpec(self, AttachCBSSpec):
        self._AttachCBSSpec = AttachCBSSpec

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("CommonSpec") is not None:
            self._CommonSpec = []
            for item in params.get("CommonSpec"):
                obj = ResourceSpec()
                obj._deserialize(item)
                self._CommonSpec.append(obj)
        if params.get("DataSpec") is not None:
            self._DataSpec = []
            for item in params.get("DataSpec"):
                obj = ResourceSpec()
                obj._deserialize(item)
                self._DataSpec.append(obj)
        if params.get("AttachCBSSpec") is not None:
            self._AttachCBSSpec = []
            for item in params.get("AttachCBSSpec"):
                obj = DiskSpec()
                obj._deserialize(item)
                self._AttachCBSSpec.append(obj)
        self._RequestId = params.get("RequestId")


class DestroyInstanceRequest(AbstractModel):
    r"""DestroyInstance请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceId: 集群id
        :type InstanceId: str
        """
        self._InstanceId = None

    @property
    def InstanceId(self):
        r"""集群id
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DestroyInstanceResponse(AbstractModel):
    r"""DestroyInstance返回参数结构体

    """

    def __init__(self):
        r"""
        :param _FlowID: 作业id
        :type FlowID: str
        :param _InstanceID: 集群id
        :type InstanceID: str
        :param _ErrorMsg: 错误信息
        :type ErrorMsg: str
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._FlowID = None
        self._InstanceID = None
        self._ErrorMsg = None
        self._RequestId = None

    @property
    def FlowID(self):
        r"""作业id
        :rtype: str
        """
        return self._FlowID

    @FlowID.setter
    def FlowID(self, FlowID):
        self._FlowID = FlowID

    @property
    def InstanceID(self):
        r"""集群id
        :rtype: str
        """
        return self._InstanceID

    @InstanceID.setter
    def InstanceID(self, InstanceID):
        self._InstanceID = InstanceID

    @property
    def ErrorMsg(self):
        r"""错误信息
        :rtype: str
        """
        return self._ErrorMsg

    @ErrorMsg.setter
    def ErrorMsg(self, ErrorMsg):
        self._ErrorMsg = ErrorMsg

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._FlowID = params.get("FlowID")
        self._InstanceID = params.get("InstanceID")
        self._ErrorMsg = params.get("ErrorMsg")
        self._RequestId = params.get("RequestId")


class DiskEncryptInfo(AbstractModel):
    r"""群磁盘加密信息。用于 DescribeInstances / DescribeInstance 返回实例的当前加密配置，供控制台、SDK、运维侧识别该集群是否启用磁盘加密、使用的是哪一把 KMS 根密钥

    """

    def __init__(self):
        r"""
        :param _EncryptType: <p>加密类型</p><p>枚举值：</p><ul><li>CUSTOMER_KMS： 客户自定义的KMS密钥信息</li><li>TENCENT_KEY： 使用腾讯云自动创建的KMS密钥信息</li></ul>
        :type EncryptType: str
        :param _KmsKeyId: <p>KMS 根密钥ID</p>
        :type KmsKeyId: str
        :param _KmsRegion: <p>KMS密钥地域</p>
        :type KmsRegion: str
        :param _KmsKeyName: <p>KMS 根密钥 key 名</p>
        :type KmsKeyName: str
        """
        self._EncryptType = None
        self._KmsKeyId = None
        self._KmsRegion = None
        self._KmsKeyName = None

    @property
    def EncryptType(self):
        r"""<p>加密类型</p><p>枚举值：</p><ul><li>CUSTOMER_KMS： 客户自定义的KMS密钥信息</li><li>TENCENT_KEY： 使用腾讯云自动创建的KMS密钥信息</li></ul>
        :rtype: str
        """
        return self._EncryptType

    @EncryptType.setter
    def EncryptType(self, EncryptType):
        self._EncryptType = EncryptType

    @property
    def KmsKeyId(self):
        r"""<p>KMS 根密钥ID</p>
        :rtype: str
        """
        return self._KmsKeyId

    @KmsKeyId.setter
    def KmsKeyId(self, KmsKeyId):
        self._KmsKeyId = KmsKeyId

    @property
    def KmsRegion(self):
        r"""<p>KMS密钥地域</p>
        :rtype: str
        """
        return self._KmsRegion

    @KmsRegion.setter
    def KmsRegion(self, KmsRegion):
        self._KmsRegion = KmsRegion

    @property
    def KmsKeyName(self):
        r"""<p>KMS 根密钥 key 名</p>
        :rtype: str
        """
        return self._KmsKeyName

    @KmsKeyName.setter
    def KmsKeyName(self, KmsKeyName):
        self._KmsKeyName = KmsKeyName


    def _deserialize(self, params):
        self._EncryptType = params.get("EncryptType")
        self._KmsKeyId = params.get("KmsKeyId")
        self._KmsRegion = params.get("KmsRegion")
        self._KmsKeyName = params.get("KmsKeyName")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DiskSpec(AbstractModel):
    r"""磁盘规格描述

    """

    def __init__(self):
        r"""
        :param _DiskType: 磁盘类型，例如“CLOUD_SSD", "LOCAL_SSD"等
        :type DiskType: str
        :param _DiskDesc: 磁盘类型说明，例如"云SSD", "本地SSD"等
        :type DiskDesc: str
        :param _MinDiskSize: 磁盘最小规格大小，单位G
        :type MinDiskSize: int
        :param _MaxDiskSize: 磁盘最大规格大小，单位G
        :type MaxDiskSize: int
        :param _DiskCount: 磁盘数目
        :type DiskCount: int
        """
        self._DiskType = None
        self._DiskDesc = None
        self._MinDiskSize = None
        self._MaxDiskSize = None
        self._DiskCount = None

    @property
    def DiskType(self):
        r"""磁盘类型，例如“CLOUD_SSD", "LOCAL_SSD"等
        :rtype: str
        """
        return self._DiskType

    @DiskType.setter
    def DiskType(self, DiskType):
        self._DiskType = DiskType

    @property
    def DiskDesc(self):
        r"""磁盘类型说明，例如"云SSD", "本地SSD"等
        :rtype: str
        """
        return self._DiskDesc

    @DiskDesc.setter
    def DiskDesc(self, DiskDesc):
        self._DiskDesc = DiskDesc

    @property
    def MinDiskSize(self):
        r"""磁盘最小规格大小，单位G
        :rtype: int
        """
        return self._MinDiskSize

    @MinDiskSize.setter
    def MinDiskSize(self, MinDiskSize):
        self._MinDiskSize = MinDiskSize

    @property
    def MaxDiskSize(self):
        r"""磁盘最大规格大小，单位G
        :rtype: int
        """
        return self._MaxDiskSize

    @MaxDiskSize.setter
    def MaxDiskSize(self, MaxDiskSize):
        self._MaxDiskSize = MaxDiskSize

    @property
    def DiskCount(self):
        r"""磁盘数目
        :rtype: int
        """
        return self._DiskCount

    @DiskCount.setter
    def DiskCount(self, DiskCount):
        self._DiskCount = DiskCount


    def _deserialize(self, params):
        self._DiskType = params.get("DiskType")
        self._DiskDesc = params.get("DiskDesc")
        self._MinDiskSize = params.get("MinDiskSize")
        self._MaxDiskSize = params.get("MaxDiskSize")
        self._DiskCount = params.get("DiskCount")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class EventTask(AbstractModel):
    r"""事件任务

    """

    def __init__(self):
        r"""
        :param _InstanceId: 集群id
        :type InstanceId: str
        :param _EventTaskId: 事件任务的id	
        :type EventTaskId: int
        :param _HandleUser: 处理人uin
        :type HandleUser: str
        :param _EventCode: 事件名称	
        :type EventCode: str
        :param _RepairId: CVM相关事件的维修id
        :type RepairId: str
        :param _EventNameDescribe: 事件名称描述	
        :type EventNameDescribe: str
        :param _EventPriority: 事件等级（0-低；1-中；2-高；3-严重）	
        :type EventPriority: int
        :param _EventDetail: 事件详情	
        :type EventDetail: str
        :param _IP: 影响集群节点	
        :type IP: str
        :param _CreateTime: 事件触发时间	
        :type CreateTime: str
        :param _Status: 事件状态(1-待处理;2-已预约;3-处理中;4-已完成;5-处理中;6-自动处理中;-1-已忽略;-2-已删除)	
        :type Status: int
        :param _NeedAuthorization: 是否需要授权维修：1-不需要，2-需要
        :type NeedAuthorization: int
        :param _OperationType: 该事件涉及到的操作类型（OnlineMigrationForInstance-实例在线迁移,OnlineMaintenanceForInstance-实例在线维修,等）	
        :type OperationType: list of str
        :param _FinishTime: 完成时间
        :type FinishTime: str
        :param _OperationGuide: 操作指引
        :type OperationGuide: str
        :param _ResourceId: 资源id
        :type ResourceId: str
        """
        self._InstanceId = None
        self._EventTaskId = None
        self._HandleUser = None
        self._EventCode = None
        self._RepairId = None
        self._EventNameDescribe = None
        self._EventPriority = None
        self._EventDetail = None
        self._IP = None
        self._CreateTime = None
        self._Status = None
        self._NeedAuthorization = None
        self._OperationType = None
        self._FinishTime = None
        self._OperationGuide = None
        self._ResourceId = None

    @property
    def InstanceId(self):
        r"""集群id
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId

    @property
    def EventTaskId(self):
        r"""事件任务的id	
        :rtype: int
        """
        return self._EventTaskId

    @EventTaskId.setter
    def EventTaskId(self, EventTaskId):
        self._EventTaskId = EventTaskId

    @property
    def HandleUser(self):
        r"""处理人uin
        :rtype: str
        """
        return self._HandleUser

    @HandleUser.setter
    def HandleUser(self, HandleUser):
        self._HandleUser = HandleUser

    @property
    def EventCode(self):
        r"""事件名称	
        :rtype: str
        """
        return self._EventCode

    @EventCode.setter
    def EventCode(self, EventCode):
        self._EventCode = EventCode

    @property
    def RepairId(self):
        r"""CVM相关事件的维修id
        :rtype: str
        """
        return self._RepairId

    @RepairId.setter
    def RepairId(self, RepairId):
        self._RepairId = RepairId

    @property
    def EventNameDescribe(self):
        r"""事件名称描述	
        :rtype: str
        """
        return self._EventNameDescribe

    @EventNameDescribe.setter
    def EventNameDescribe(self, EventNameDescribe):
        self._EventNameDescribe = EventNameDescribe

    @property
    def EventPriority(self):
        r"""事件等级（0-低；1-中；2-高；3-严重）	
        :rtype: int
        """
        return self._EventPriority

    @EventPriority.setter
    def EventPriority(self, EventPriority):
        self._EventPriority = EventPriority

    @property
    def EventDetail(self):
        r"""事件详情	
        :rtype: str
        """
        return self._EventDetail

    @EventDetail.setter
    def EventDetail(self, EventDetail):
        self._EventDetail = EventDetail

    @property
    def IP(self):
        r"""影响集群节点	
        :rtype: str
        """
        return self._IP

    @IP.setter
    def IP(self, IP):
        self._IP = IP

    @property
    def CreateTime(self):
        r"""事件触发时间	
        :rtype: str
        """
        return self._CreateTime

    @CreateTime.setter
    def CreateTime(self, CreateTime):
        self._CreateTime = CreateTime

    @property
    def Status(self):
        r"""事件状态(1-待处理;2-已预约;3-处理中;4-已完成;5-处理中;6-自动处理中;-1-已忽略;-2-已删除)	
        :rtype: int
        """
        return self._Status

    @Status.setter
    def Status(self, Status):
        self._Status = Status

    @property
    def NeedAuthorization(self):
        r"""是否需要授权维修：1-不需要，2-需要
        :rtype: int
        """
        return self._NeedAuthorization

    @NeedAuthorization.setter
    def NeedAuthorization(self, NeedAuthorization):
        self._NeedAuthorization = NeedAuthorization

    @property
    def OperationType(self):
        r"""该事件涉及到的操作类型（OnlineMigrationForInstance-实例在线迁移,OnlineMaintenanceForInstance-实例在线维修,等）	
        :rtype: list of str
        """
        return self._OperationType

    @OperationType.setter
    def OperationType(self, OperationType):
        self._OperationType = OperationType

    @property
    def FinishTime(self):
        r"""完成时间
        :rtype: str
        """
        return self._FinishTime

    @FinishTime.setter
    def FinishTime(self, FinishTime):
        self._FinishTime = FinishTime

    @property
    def OperationGuide(self):
        r"""操作指引
        :rtype: str
        """
        return self._OperationGuide

    @OperationGuide.setter
    def OperationGuide(self, OperationGuide):
        self._OperationGuide = OperationGuide

    @property
    def ResourceId(self):
        r"""资源id
        :rtype: str
        """
        return self._ResourceId

    @ResourceId.setter
    def ResourceId(self, ResourceId):
        self._ResourceId = ResourceId


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        self._EventTaskId = params.get("EventTaskId")
        self._HandleUser = params.get("HandleUser")
        self._EventCode = params.get("EventCode")
        self._RepairId = params.get("RepairId")
        self._EventNameDescribe = params.get("EventNameDescribe")
        self._EventPriority = params.get("EventPriority")
        self._EventDetail = params.get("EventDetail")
        self._IP = params.get("IP")
        self._CreateTime = params.get("CreateTime")
        self._Status = params.get("Status")
        self._NeedAuthorization = params.get("NeedAuthorization")
        self._OperationType = params.get("OperationType")
        self._FinishTime = params.get("FinishTime")
        self._OperationGuide = params.get("OperationGuide")
        self._ResourceId = params.get("ResourceId")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class GroupInfo(AbstractModel):
    r"""集群分组信息描述

    """

    def __init__(self):
        r"""
        :param _GroupName: 分组名称
        :type GroupName: str
        :param _ShardName: 分片变量名称
        :type ShardName: str
        :param _ReplicaName: 副本变量名称
        :type ReplicaName: str
        """
        self._GroupName = None
        self._ShardName = None
        self._ReplicaName = None

    @property
    def GroupName(self):
        r"""分组名称
        :rtype: str
        """
        return self._GroupName

    @GroupName.setter
    def GroupName(self, GroupName):
        self._GroupName = GroupName

    @property
    def ShardName(self):
        r"""分片变量名称
        :rtype: str
        """
        return self._ShardName

    @ShardName.setter
    def ShardName(self, ShardName):
        self._ShardName = ShardName

    @property
    def ReplicaName(self):
        r"""副本变量名称
        :rtype: str
        """
        return self._ReplicaName

    @ReplicaName.setter
    def ReplicaName(self, ReplicaName):
        self._ReplicaName = ReplicaName


    def _deserialize(self, params):
        self._GroupName = params.get("GroupName")
        self._ShardName = params.get("ShardName")
        self._ReplicaName = params.get("ReplicaName")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class InstanceConfigInfo(AbstractModel):
    r"""集群配置信息

    """

    def __init__(self):
        r"""
        :param _ConfKey: <p>配置项名称</p>
        :type ConfKey: str
        :param _ConfValue: <p>配置项内容</p>
        :type ConfValue: str
        :param _DefaultValue: <p>默认值</p>
        :type DefaultValue: str
        :param _NeedRestart: <p>是否需要重启</p>
        :type NeedRestart: bool
        :param _Editable: <p>是否可编辑</p>
        :type Editable: bool
        :param _ConfDesc: <p>配置项解释</p>
        :type ConfDesc: str
        :param _FileName: <p>文件名称</p>
        :type FileName: str
        :param _ModifyRuleType: <p>规则名称类型</p>
        :type ModifyRuleType: str
        :param _ModifyRuleValue: <p>规则名称内容</p>
        :type ModifyRuleValue: str
        :param _Uin: <p>修改人的uin</p>
        :type Uin: str
        :param _ModifyTime: <p>修改时间</p>
        :type ModifyTime: str
        :param _ValueRange: <p>取值范围</p>
        :type ValueRange: str
        :param _AbnormalParam: <p>标记异常</p>
        :type AbnormalParam: str
        :param _ConfigEffective: <p>是否生效</p>
        :type ConfigEffective: str
        """
        self._ConfKey = None
        self._ConfValue = None
        self._DefaultValue = None
        self._NeedRestart = None
        self._Editable = None
        self._ConfDesc = None
        self._FileName = None
        self._ModifyRuleType = None
        self._ModifyRuleValue = None
        self._Uin = None
        self._ModifyTime = None
        self._ValueRange = None
        self._AbnormalParam = None
        self._ConfigEffective = None

    @property
    def ConfKey(self):
        r"""<p>配置项名称</p>
        :rtype: str
        """
        return self._ConfKey

    @ConfKey.setter
    def ConfKey(self, ConfKey):
        self._ConfKey = ConfKey

    @property
    def ConfValue(self):
        r"""<p>配置项内容</p>
        :rtype: str
        """
        return self._ConfValue

    @ConfValue.setter
    def ConfValue(self, ConfValue):
        self._ConfValue = ConfValue

    @property
    def DefaultValue(self):
        r"""<p>默认值</p>
        :rtype: str
        """
        return self._DefaultValue

    @DefaultValue.setter
    def DefaultValue(self, DefaultValue):
        self._DefaultValue = DefaultValue

    @property
    def NeedRestart(self):
        r"""<p>是否需要重启</p>
        :rtype: bool
        """
        return self._NeedRestart

    @NeedRestart.setter
    def NeedRestart(self, NeedRestart):
        self._NeedRestart = NeedRestart

    @property
    def Editable(self):
        r"""<p>是否可编辑</p>
        :rtype: bool
        """
        return self._Editable

    @Editable.setter
    def Editable(self, Editable):
        self._Editable = Editable

    @property
    def ConfDesc(self):
        r"""<p>配置项解释</p>
        :rtype: str
        """
        return self._ConfDesc

    @ConfDesc.setter
    def ConfDesc(self, ConfDesc):
        self._ConfDesc = ConfDesc

    @property
    def FileName(self):
        r"""<p>文件名称</p>
        :rtype: str
        """
        return self._FileName

    @FileName.setter
    def FileName(self, FileName):
        self._FileName = FileName

    @property
    def ModifyRuleType(self):
        r"""<p>规则名称类型</p>
        :rtype: str
        """
        return self._ModifyRuleType

    @ModifyRuleType.setter
    def ModifyRuleType(self, ModifyRuleType):
        self._ModifyRuleType = ModifyRuleType

    @property
    def ModifyRuleValue(self):
        r"""<p>规则名称内容</p>
        :rtype: str
        """
        return self._ModifyRuleValue

    @ModifyRuleValue.setter
    def ModifyRuleValue(self, ModifyRuleValue):
        self._ModifyRuleValue = ModifyRuleValue

    @property
    def Uin(self):
        r"""<p>修改人的uin</p>
        :rtype: str
        """
        return self._Uin

    @Uin.setter
    def Uin(self, Uin):
        self._Uin = Uin

    @property
    def ModifyTime(self):
        r"""<p>修改时间</p>
        :rtype: str
        """
        return self._ModifyTime

    @ModifyTime.setter
    def ModifyTime(self, ModifyTime):
        self._ModifyTime = ModifyTime

    @property
    def ValueRange(self):
        r"""<p>取值范围</p>
        :rtype: str
        """
        return self._ValueRange

    @ValueRange.setter
    def ValueRange(self, ValueRange):
        self._ValueRange = ValueRange

    @property
    def AbnormalParam(self):
        r"""<p>标记异常</p>
        :rtype: str
        """
        return self._AbnormalParam

    @AbnormalParam.setter
    def AbnormalParam(self, AbnormalParam):
        self._AbnormalParam = AbnormalParam

    @property
    def ConfigEffective(self):
        r"""<p>是否生效</p>
        :rtype: str
        """
        return self._ConfigEffective

    @ConfigEffective.setter
    def ConfigEffective(self, ConfigEffective):
        self._ConfigEffective = ConfigEffective


    def _deserialize(self, params):
        self._ConfKey = params.get("ConfKey")
        self._ConfValue = params.get("ConfValue")
        self._DefaultValue = params.get("DefaultValue")
        self._NeedRestart = params.get("NeedRestart")
        self._Editable = params.get("Editable")
        self._ConfDesc = params.get("ConfDesc")
        self._FileName = params.get("FileName")
        self._ModifyRuleType = params.get("ModifyRuleType")
        self._ModifyRuleValue = params.get("ModifyRuleValue")
        self._Uin = params.get("Uin")
        self._ModifyTime = params.get("ModifyTime")
        self._ValueRange = params.get("ValueRange")
        self._AbnormalParam = params.get("AbnormalParam")
        self._ConfigEffective = params.get("ConfigEffective")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class InstanceConfigItem(AbstractModel):
    r"""KV配置

    """

    def __init__(self):
        r"""
        :param _ConfKey: <p>key</p>
        :type ConfKey: str
        :param _ConfValue: <p>value</p>
        :type ConfValue: str
        :param _ModifyType: <p>add/delete/update</p>
        :type ModifyType: str
        :param _NeedRestart: <p>是否需要重启</p>
        :type NeedRestart: bool
        :param _OriginalConfValue: <p>修改前的值</p>
        :type OriginalConfValue: str
        """
        self._ConfKey = None
        self._ConfValue = None
        self._ModifyType = None
        self._NeedRestart = None
        self._OriginalConfValue = None

    @property
    def ConfKey(self):
        r"""<p>key</p>
        :rtype: str
        """
        return self._ConfKey

    @ConfKey.setter
    def ConfKey(self, ConfKey):
        self._ConfKey = ConfKey

    @property
    def ConfValue(self):
        r"""<p>value</p>
        :rtype: str
        """
        return self._ConfValue

    @ConfValue.setter
    def ConfValue(self, ConfValue):
        self._ConfValue = ConfValue

    @property
    def ModifyType(self):
        r"""<p>add/delete/update</p>
        :rtype: str
        """
        return self._ModifyType

    @ModifyType.setter
    def ModifyType(self, ModifyType):
        self._ModifyType = ModifyType

    @property
    def NeedRestart(self):
        r"""<p>是否需要重启</p>
        :rtype: bool
        """
        return self._NeedRestart

    @NeedRestart.setter
    def NeedRestart(self, NeedRestart):
        self._NeedRestart = NeedRestart

    @property
    def OriginalConfValue(self):
        r"""<p>修改前的值</p>
        :rtype: str
        """
        return self._OriginalConfValue

    @OriginalConfValue.setter
    def OriginalConfValue(self, OriginalConfValue):
        self._OriginalConfValue = OriginalConfValue


    def _deserialize(self, params):
        self._ConfKey = params.get("ConfKey")
        self._ConfValue = params.get("ConfValue")
        self._ModifyType = params.get("ModifyType")
        self._NeedRestart = params.get("NeedRestart")
        self._OriginalConfValue = params.get("OriginalConfValue")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class InstanceDetail(AbstractModel):
    r"""Instance表detail字段

    """

    def __init__(self):
        r"""
        :param _EnableAlarmStrategy: 告警策略是否可用
        :type EnableAlarmStrategy: bool
        """
        self._EnableAlarmStrategy = None

    @property
    def EnableAlarmStrategy(self):
        r"""告警策略是否可用
        :rtype: bool
        """
        return self._EnableAlarmStrategy

    @EnableAlarmStrategy.setter
    def EnableAlarmStrategy(self, EnableAlarmStrategy):
        self._EnableAlarmStrategy = EnableAlarmStrategy


    def _deserialize(self, params):
        self._EnableAlarmStrategy = params.get("EnableAlarmStrategy")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class InstanceInfo(AbstractModel):
    r"""实例的描述信息

    """

    def __init__(self):
        r"""
        :param _InstanceId: <p>集群实例ID, &quot;cdw-xxxx&quot; 字符串类型</p>
        :type InstanceId: str
        :param _InstanceName: <p>集群实例名称</p>
        :type InstanceName: str
        :param _Status: <p>状态,<br>Init 创建中; Serving 运行中；<br>Deleted已销毁；Deleting 销毁中；<br>Modify 集群变更中；</p>
        :type Status: str
        :param _Version: <p>版本</p>
        :type Version: str
        :param _Region: <p>地域, ap-guangzhou</p>
        :type Region: str
        :param _Zone: <p>可用区， ap-guangzhou-3</p>
        :type Zone: str
        :param _VpcId: <p>私有网络名称</p>
        :type VpcId: str
        :param _SubnetId: <p>子网名称</p>
        :type SubnetId: str
        :param _PayMode: <p>付费类型，&quot;hour&quot;, &quot;prepay&quot;</p>
        :type PayMode: str
        :param _CreateTime: <p>创建时间</p>
        :type CreateTime: str
        :param _ExpireTime: <p>过期时间</p>
        :type ExpireTime: str
        :param _MasterSummary: <p>数据节点描述信息</p>
        :type MasterSummary: :class:`tencentcloud.cdwch.v20200915.models.NodesSummary`
        :param _CommonSummary: <p>zookeeper节点描述信息</p>
        :type CommonSummary: :class:`tencentcloud.cdwch.v20200915.models.NodesSummary`
        :param _HA: <p>高可用,&quot;true&quot; &quot;false&quot;</p>
        :type HA: str
        :param _AccessInfo: <p>访问地址，例如 &quot;10.0.0.1:9000&quot;</p>
        :type AccessInfo: str
        :param _Id: <p>记录ID，数值型</p>
        :type Id: int
        :param _RegionId: <p>regionId, 表示地域</p>
        :type RegionId: int
        :param _ZoneDesc: <p>可用区说明，例如 &quot;广州二区&quot;</p>
        :type ZoneDesc: str
        :param _FlowMsg: <p>错误流程说明信息</p>
        :type FlowMsg: str
        :param _StatusDesc: <p>状态描述，例如“运行中”等</p>
        :type StatusDesc: str
        :param _RenewFlag: <p>自动续费标记</p>
        :type RenewFlag: bool
        :param _Tags: <p>标签列表</p>
        :type Tags: list of Tag
        :param _Monitor: <p>监控信息</p>
        :type Monitor: str
        :param _HasClsTopic: <p>是否开通日志</p>
        :type HasClsTopic: bool
        :param _ClsTopicId: <p>日志主题ID</p>
        :type ClsTopicId: str
        :param _ClsLogSetId: <p>日志集ID</p>
        :type ClsLogSetId: str
        :param _EnableXMLConfig: <p>是否支持xml配置管理</p>
        :type EnableXMLConfig: int
        :param _RegionDesc: <p>区域</p>
        :type RegionDesc: str
        :param _Eip: <p>弹性网卡地址</p>
        :type Eip: str
        :param _CosMoveFactor: <p>冷热分层系数</p>
        :type CosMoveFactor: int
        :param _Kind: <p>external/local/yunti</p>
        :type Kind: str
        :param _IsElastic: <p>是否弹性ck</p>
        :type IsElastic: bool
        :param _InstanceStateInfo: <p>集群详细状态</p>
        :type InstanceStateInfo: :class:`tencentcloud.cdwch.v20200915.models.InstanceStateInfo`
        :param _HAZk: <p>ZK高可用</p>
        :type HAZk: bool
        :param _MountDiskType: <p>挂载盘,默认0:没有类型；1:裸盘;2:lvm</p>
        :type MountDiskType: int
        :param _CHProxyVip: <p>chproxy连接ip</p>
        :type CHProxyVip: str
        :param _CosBucketName: <p>cos buket的名字</p>
        :type CosBucketName: str
        :param _CanAttachCbs: <p>是否可以挂载云盘</p>
        :type CanAttachCbs: bool
        :param _CanAttachCbsLvm: <p>是否可以挂载云盘阵列</p>
        :type CanAttachCbsLvm: bool
        :param _CanAttachCos: <p>是否可以挂载cos</p>
        :type CanAttachCos: bool
        :param _Components: <p>服务信息</p>
        :type Components: list of ServiceInfo
        :param _UpgradeVersions: <p>可升级的内核版本</p>
        :type UpgradeVersions: str
        :param _EsIndexId: <p>ex-index</p>
        :type EsIndexId: str
        :param _EsIndexUsername: <p>username</p>
        :type EsIndexUsername: str
        :param _EsIndexPassword: <p>password</p>
        :type EsIndexPassword: str
        :param _HasEsIndex: <p>true</p>
        :type HasEsIndex: bool
        :param _IsSecondaryZone: <p>true</p>
        :type IsSecondaryZone: bool
        :param _SecondaryZoneInfo: <p>desc</p>
        :type SecondaryZoneInfo: str
        :param _ClickHouseKeeper: <p>是否clickhouse-keeper</p>
        :type ClickHouseKeeper: bool
        :param _Details: <p>实例扩展信息</p>
        :type Details: :class:`tencentcloud.cdwch.v20200915.models.InstanceDetail`
        :param _IsWhiteSGs: <p>安全组白名单</p>
        :type IsWhiteSGs: bool
        :param _BindSGs: <p>绑定的安全组</p>
        :type BindSGs: list of str
        :param _HasPublicCloudClb: <p>是否开启公网clb</p>
        :type HasPublicCloudClb: bool
        :param _UpgradeZkVersions: <p>可升级的zk版本</p>
        :type UpgradeZkVersions: str
        :param _ShowRip: <p>是否显示rip</p>
        :type ShowRip: str
        :param _InstanceType: <p>实例类型：标准型 standard，无keeper节点类型noKeeper；</p>
        :type InstanceType: str
        :param _EnableConfigKeyValue: <p>keyvalue视图</p>
        :type EnableConfigKeyValue: str
        :param _HttpsEnabled: <p>实例是否开启HTTPS</p><p>枚举值：</p><ul><li>true： 已开启HTTPS</li><li>false： 未开启HTTPS</li></ul>
        :type HttpsEnabled: bool
        :param _DiskEncryptInfo: <p>集群磁盘加密配置</p>
        :type DiskEncryptInfo: :class:`tencentcloud.cdwch.v20200915.models.DiskEncryptInfo`
        """
        self._InstanceId = None
        self._InstanceName = None
        self._Status = None
        self._Version = None
        self._Region = None
        self._Zone = None
        self._VpcId = None
        self._SubnetId = None
        self._PayMode = None
        self._CreateTime = None
        self._ExpireTime = None
        self._MasterSummary = None
        self._CommonSummary = None
        self._HA = None
        self._AccessInfo = None
        self._Id = None
        self._RegionId = None
        self._ZoneDesc = None
        self._FlowMsg = None
        self._StatusDesc = None
        self._RenewFlag = None
        self._Tags = None
        self._Monitor = None
        self._HasClsTopic = None
        self._ClsTopicId = None
        self._ClsLogSetId = None
        self._EnableXMLConfig = None
        self._RegionDesc = None
        self._Eip = None
        self._CosMoveFactor = None
        self._Kind = None
        self._IsElastic = None
        self._InstanceStateInfo = None
        self._HAZk = None
        self._MountDiskType = None
        self._CHProxyVip = None
        self._CosBucketName = None
        self._CanAttachCbs = None
        self._CanAttachCbsLvm = None
        self._CanAttachCos = None
        self._Components = None
        self._UpgradeVersions = None
        self._EsIndexId = None
        self._EsIndexUsername = None
        self._EsIndexPassword = None
        self._HasEsIndex = None
        self._IsSecondaryZone = None
        self._SecondaryZoneInfo = None
        self._ClickHouseKeeper = None
        self._Details = None
        self._IsWhiteSGs = None
        self._BindSGs = None
        self._HasPublicCloudClb = None
        self._UpgradeZkVersions = None
        self._ShowRip = None
        self._InstanceType = None
        self._EnableConfigKeyValue = None
        self._HttpsEnabled = None
        self._DiskEncryptInfo = None

    @property
    def InstanceId(self):
        r"""<p>集群实例ID, &quot;cdw-xxxx&quot; 字符串类型</p>
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId

    @property
    def InstanceName(self):
        r"""<p>集群实例名称</p>
        :rtype: str
        """
        return self._InstanceName

    @InstanceName.setter
    def InstanceName(self, InstanceName):
        self._InstanceName = InstanceName

    @property
    def Status(self):
        r"""<p>状态,<br>Init 创建中; Serving 运行中；<br>Deleted已销毁；Deleting 销毁中；<br>Modify 集群变更中；</p>
        :rtype: str
        """
        return self._Status

    @Status.setter
    def Status(self, Status):
        self._Status = Status

    @property
    def Version(self):
        r"""<p>版本</p>
        :rtype: str
        """
        return self._Version

    @Version.setter
    def Version(self, Version):
        self._Version = Version

    @property
    def Region(self):
        r"""<p>地域, ap-guangzhou</p>
        :rtype: str
        """
        return self._Region

    @Region.setter
    def Region(self, Region):
        self._Region = Region

    @property
    def Zone(self):
        r"""<p>可用区， ap-guangzhou-3</p>
        :rtype: str
        """
        return self._Zone

    @Zone.setter
    def Zone(self, Zone):
        self._Zone = Zone

    @property
    def VpcId(self):
        r"""<p>私有网络名称</p>
        :rtype: str
        """
        return self._VpcId

    @VpcId.setter
    def VpcId(self, VpcId):
        self._VpcId = VpcId

    @property
    def SubnetId(self):
        r"""<p>子网名称</p>
        :rtype: str
        """
        return self._SubnetId

    @SubnetId.setter
    def SubnetId(self, SubnetId):
        self._SubnetId = SubnetId

    @property
    def PayMode(self):
        r"""<p>付费类型，&quot;hour&quot;, &quot;prepay&quot;</p>
        :rtype: str
        """
        return self._PayMode

    @PayMode.setter
    def PayMode(self, PayMode):
        self._PayMode = PayMode

    @property
    def CreateTime(self):
        r"""<p>创建时间</p>
        :rtype: str
        """
        return self._CreateTime

    @CreateTime.setter
    def CreateTime(self, CreateTime):
        self._CreateTime = CreateTime

    @property
    def ExpireTime(self):
        r"""<p>过期时间</p>
        :rtype: str
        """
        return self._ExpireTime

    @ExpireTime.setter
    def ExpireTime(self, ExpireTime):
        self._ExpireTime = ExpireTime

    @property
    def MasterSummary(self):
        r"""<p>数据节点描述信息</p>
        :rtype: :class:`tencentcloud.cdwch.v20200915.models.NodesSummary`
        """
        return self._MasterSummary

    @MasterSummary.setter
    def MasterSummary(self, MasterSummary):
        self._MasterSummary = MasterSummary

    @property
    def CommonSummary(self):
        r"""<p>zookeeper节点描述信息</p>
        :rtype: :class:`tencentcloud.cdwch.v20200915.models.NodesSummary`
        """
        return self._CommonSummary

    @CommonSummary.setter
    def CommonSummary(self, CommonSummary):
        self._CommonSummary = CommonSummary

    @property
    def HA(self):
        r"""<p>高可用,&quot;true&quot; &quot;false&quot;</p>
        :rtype: str
        """
        return self._HA

    @HA.setter
    def HA(self, HA):
        self._HA = HA

    @property
    def AccessInfo(self):
        r"""<p>访问地址，例如 &quot;10.0.0.1:9000&quot;</p>
        :rtype: str
        """
        return self._AccessInfo

    @AccessInfo.setter
    def AccessInfo(self, AccessInfo):
        self._AccessInfo = AccessInfo

    @property
    def Id(self):
        r"""<p>记录ID，数值型</p>
        :rtype: int
        """
        return self._Id

    @Id.setter
    def Id(self, Id):
        self._Id = Id

    @property
    def RegionId(self):
        r"""<p>regionId, 表示地域</p>
        :rtype: int
        """
        return self._RegionId

    @RegionId.setter
    def RegionId(self, RegionId):
        self._RegionId = RegionId

    @property
    def ZoneDesc(self):
        r"""<p>可用区说明，例如 &quot;广州二区&quot;</p>
        :rtype: str
        """
        return self._ZoneDesc

    @ZoneDesc.setter
    def ZoneDesc(self, ZoneDesc):
        self._ZoneDesc = ZoneDesc

    @property
    def FlowMsg(self):
        r"""<p>错误流程说明信息</p>
        :rtype: str
        """
        return self._FlowMsg

    @FlowMsg.setter
    def FlowMsg(self, FlowMsg):
        self._FlowMsg = FlowMsg

    @property
    def StatusDesc(self):
        r"""<p>状态描述，例如“运行中”等</p>
        :rtype: str
        """
        return self._StatusDesc

    @StatusDesc.setter
    def StatusDesc(self, StatusDesc):
        self._StatusDesc = StatusDesc

    @property
    def RenewFlag(self):
        r"""<p>自动续费标记</p>
        :rtype: bool
        """
        return self._RenewFlag

    @RenewFlag.setter
    def RenewFlag(self, RenewFlag):
        self._RenewFlag = RenewFlag

    @property
    def Tags(self):
        r"""<p>标签列表</p>
        :rtype: list of Tag
        """
        return self._Tags

    @Tags.setter
    def Tags(self, Tags):
        self._Tags = Tags

    @property
    def Monitor(self):
        r"""<p>监控信息</p>
        :rtype: str
        """
        return self._Monitor

    @Monitor.setter
    def Monitor(self, Monitor):
        self._Monitor = Monitor

    @property
    def HasClsTopic(self):
        r"""<p>是否开通日志</p>
        :rtype: bool
        """
        return self._HasClsTopic

    @HasClsTopic.setter
    def HasClsTopic(self, HasClsTopic):
        self._HasClsTopic = HasClsTopic

    @property
    def ClsTopicId(self):
        r"""<p>日志主题ID</p>
        :rtype: str
        """
        return self._ClsTopicId

    @ClsTopicId.setter
    def ClsTopicId(self, ClsTopicId):
        self._ClsTopicId = ClsTopicId

    @property
    def ClsLogSetId(self):
        r"""<p>日志集ID</p>
        :rtype: str
        """
        return self._ClsLogSetId

    @ClsLogSetId.setter
    def ClsLogSetId(self, ClsLogSetId):
        self._ClsLogSetId = ClsLogSetId

    @property
    def EnableXMLConfig(self):
        r"""<p>是否支持xml配置管理</p>
        :rtype: int
        """
        return self._EnableXMLConfig

    @EnableXMLConfig.setter
    def EnableXMLConfig(self, EnableXMLConfig):
        self._EnableXMLConfig = EnableXMLConfig

    @property
    def RegionDesc(self):
        r"""<p>区域</p>
        :rtype: str
        """
        return self._RegionDesc

    @RegionDesc.setter
    def RegionDesc(self, RegionDesc):
        self._RegionDesc = RegionDesc

    @property
    def Eip(self):
        r"""<p>弹性网卡地址</p>
        :rtype: str
        """
        return self._Eip

    @Eip.setter
    def Eip(self, Eip):
        self._Eip = Eip

    @property
    def CosMoveFactor(self):
        r"""<p>冷热分层系数</p>
        :rtype: int
        """
        return self._CosMoveFactor

    @CosMoveFactor.setter
    def CosMoveFactor(self, CosMoveFactor):
        self._CosMoveFactor = CosMoveFactor

    @property
    def Kind(self):
        r"""<p>external/local/yunti</p>
        :rtype: str
        """
        return self._Kind

    @Kind.setter
    def Kind(self, Kind):
        self._Kind = Kind

    @property
    def IsElastic(self):
        r"""<p>是否弹性ck</p>
        :rtype: bool
        """
        return self._IsElastic

    @IsElastic.setter
    def IsElastic(self, IsElastic):
        self._IsElastic = IsElastic

    @property
    def InstanceStateInfo(self):
        r"""<p>集群详细状态</p>
        :rtype: :class:`tencentcloud.cdwch.v20200915.models.InstanceStateInfo`
        """
        return self._InstanceStateInfo

    @InstanceStateInfo.setter
    def InstanceStateInfo(self, InstanceStateInfo):
        self._InstanceStateInfo = InstanceStateInfo

    @property
    def HAZk(self):
        r"""<p>ZK高可用</p>
        :rtype: bool
        """
        return self._HAZk

    @HAZk.setter
    def HAZk(self, HAZk):
        self._HAZk = HAZk

    @property
    def MountDiskType(self):
        r"""<p>挂载盘,默认0:没有类型；1:裸盘;2:lvm</p>
        :rtype: int
        """
        return self._MountDiskType

    @MountDiskType.setter
    def MountDiskType(self, MountDiskType):
        self._MountDiskType = MountDiskType

    @property
    def CHProxyVip(self):
        r"""<p>chproxy连接ip</p>
        :rtype: str
        """
        return self._CHProxyVip

    @CHProxyVip.setter
    def CHProxyVip(self, CHProxyVip):
        self._CHProxyVip = CHProxyVip

    @property
    def CosBucketName(self):
        r"""<p>cos buket的名字</p>
        :rtype: str
        """
        return self._CosBucketName

    @CosBucketName.setter
    def CosBucketName(self, CosBucketName):
        self._CosBucketName = CosBucketName

    @property
    def CanAttachCbs(self):
        r"""<p>是否可以挂载云盘</p>
        :rtype: bool
        """
        return self._CanAttachCbs

    @CanAttachCbs.setter
    def CanAttachCbs(self, CanAttachCbs):
        self._CanAttachCbs = CanAttachCbs

    @property
    def CanAttachCbsLvm(self):
        r"""<p>是否可以挂载云盘阵列</p>
        :rtype: bool
        """
        return self._CanAttachCbsLvm

    @CanAttachCbsLvm.setter
    def CanAttachCbsLvm(self, CanAttachCbsLvm):
        self._CanAttachCbsLvm = CanAttachCbsLvm

    @property
    def CanAttachCos(self):
        r"""<p>是否可以挂载cos</p>
        :rtype: bool
        """
        return self._CanAttachCos

    @CanAttachCos.setter
    def CanAttachCos(self, CanAttachCos):
        self._CanAttachCos = CanAttachCos

    @property
    def Components(self):
        r"""<p>服务信息</p>
        :rtype: list of ServiceInfo
        """
        return self._Components

    @Components.setter
    def Components(self, Components):
        self._Components = Components

    @property
    def UpgradeVersions(self):
        r"""<p>可升级的内核版本</p>
        :rtype: str
        """
        return self._UpgradeVersions

    @UpgradeVersions.setter
    def UpgradeVersions(self, UpgradeVersions):
        self._UpgradeVersions = UpgradeVersions

    @property
    def EsIndexId(self):
        r"""<p>ex-index</p>
        :rtype: str
        """
        return self._EsIndexId

    @EsIndexId.setter
    def EsIndexId(self, EsIndexId):
        self._EsIndexId = EsIndexId

    @property
    def EsIndexUsername(self):
        r"""<p>username</p>
        :rtype: str
        """
        return self._EsIndexUsername

    @EsIndexUsername.setter
    def EsIndexUsername(self, EsIndexUsername):
        self._EsIndexUsername = EsIndexUsername

    @property
    def EsIndexPassword(self):
        r"""<p>password</p>
        :rtype: str
        """
        return self._EsIndexPassword

    @EsIndexPassword.setter
    def EsIndexPassword(self, EsIndexPassword):
        self._EsIndexPassword = EsIndexPassword

    @property
    def HasEsIndex(self):
        r"""<p>true</p>
        :rtype: bool
        """
        return self._HasEsIndex

    @HasEsIndex.setter
    def HasEsIndex(self, HasEsIndex):
        self._HasEsIndex = HasEsIndex

    @property
    def IsSecondaryZone(self):
        r"""<p>true</p>
        :rtype: bool
        """
        return self._IsSecondaryZone

    @IsSecondaryZone.setter
    def IsSecondaryZone(self, IsSecondaryZone):
        self._IsSecondaryZone = IsSecondaryZone

    @property
    def SecondaryZoneInfo(self):
        r"""<p>desc</p>
        :rtype: str
        """
        return self._SecondaryZoneInfo

    @SecondaryZoneInfo.setter
    def SecondaryZoneInfo(self, SecondaryZoneInfo):
        self._SecondaryZoneInfo = SecondaryZoneInfo

    @property
    def ClickHouseKeeper(self):
        r"""<p>是否clickhouse-keeper</p>
        :rtype: bool
        """
        return self._ClickHouseKeeper

    @ClickHouseKeeper.setter
    def ClickHouseKeeper(self, ClickHouseKeeper):
        self._ClickHouseKeeper = ClickHouseKeeper

    @property
    def Details(self):
        r"""<p>实例扩展信息</p>
        :rtype: :class:`tencentcloud.cdwch.v20200915.models.InstanceDetail`
        """
        return self._Details

    @Details.setter
    def Details(self, Details):
        self._Details = Details

    @property
    def IsWhiteSGs(self):
        r"""<p>安全组白名单</p>
        :rtype: bool
        """
        return self._IsWhiteSGs

    @IsWhiteSGs.setter
    def IsWhiteSGs(self, IsWhiteSGs):
        self._IsWhiteSGs = IsWhiteSGs

    @property
    def BindSGs(self):
        r"""<p>绑定的安全组</p>
        :rtype: list of str
        """
        return self._BindSGs

    @BindSGs.setter
    def BindSGs(self, BindSGs):
        self._BindSGs = BindSGs

    @property
    def HasPublicCloudClb(self):
        r"""<p>是否开启公网clb</p>
        :rtype: bool
        """
        return self._HasPublicCloudClb

    @HasPublicCloudClb.setter
    def HasPublicCloudClb(self, HasPublicCloudClb):
        self._HasPublicCloudClb = HasPublicCloudClb

    @property
    def UpgradeZkVersions(self):
        r"""<p>可升级的zk版本</p>
        :rtype: str
        """
        return self._UpgradeZkVersions

    @UpgradeZkVersions.setter
    def UpgradeZkVersions(self, UpgradeZkVersions):
        self._UpgradeZkVersions = UpgradeZkVersions

    @property
    def ShowRip(self):
        r"""<p>是否显示rip</p>
        :rtype: str
        """
        return self._ShowRip

    @ShowRip.setter
    def ShowRip(self, ShowRip):
        self._ShowRip = ShowRip

    @property
    def InstanceType(self):
        r"""<p>实例类型：标准型 standard，无keeper节点类型noKeeper；</p>
        :rtype: str
        """
        return self._InstanceType

    @InstanceType.setter
    def InstanceType(self, InstanceType):
        self._InstanceType = InstanceType

    @property
    def EnableConfigKeyValue(self):
        r"""<p>keyvalue视图</p>
        :rtype: str
        """
        return self._EnableConfigKeyValue

    @EnableConfigKeyValue.setter
    def EnableConfigKeyValue(self, EnableConfigKeyValue):
        self._EnableConfigKeyValue = EnableConfigKeyValue

    @property
    def HttpsEnabled(self):
        r"""<p>实例是否开启HTTPS</p><p>枚举值：</p><ul><li>true： 已开启HTTPS</li><li>false： 未开启HTTPS</li></ul>
        :rtype: bool
        """
        return self._HttpsEnabled

    @HttpsEnabled.setter
    def HttpsEnabled(self, HttpsEnabled):
        self._HttpsEnabled = HttpsEnabled

    @property
    def DiskEncryptInfo(self):
        r"""<p>集群磁盘加密配置</p>
        :rtype: :class:`tencentcloud.cdwch.v20200915.models.DiskEncryptInfo`
        """
        return self._DiskEncryptInfo

    @DiskEncryptInfo.setter
    def DiskEncryptInfo(self, DiskEncryptInfo):
        self._DiskEncryptInfo = DiskEncryptInfo


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        self._InstanceName = params.get("InstanceName")
        self._Status = params.get("Status")
        self._Version = params.get("Version")
        self._Region = params.get("Region")
        self._Zone = params.get("Zone")
        self._VpcId = params.get("VpcId")
        self._SubnetId = params.get("SubnetId")
        self._PayMode = params.get("PayMode")
        self._CreateTime = params.get("CreateTime")
        self._ExpireTime = params.get("ExpireTime")
        if params.get("MasterSummary") is not None:
            self._MasterSummary = NodesSummary()
            self._MasterSummary._deserialize(params.get("MasterSummary"))
        if params.get("CommonSummary") is not None:
            self._CommonSummary = NodesSummary()
            self._CommonSummary._deserialize(params.get("CommonSummary"))
        self._HA = params.get("HA")
        self._AccessInfo = params.get("AccessInfo")
        self._Id = params.get("Id")
        self._RegionId = params.get("RegionId")
        self._ZoneDesc = params.get("ZoneDesc")
        self._FlowMsg = params.get("FlowMsg")
        self._StatusDesc = params.get("StatusDesc")
        self._RenewFlag = params.get("RenewFlag")
        if params.get("Tags") is not None:
            self._Tags = []
            for item in params.get("Tags"):
                obj = Tag()
                obj._deserialize(item)
                self._Tags.append(obj)
        self._Monitor = params.get("Monitor")
        self._HasClsTopic = params.get("HasClsTopic")
        self._ClsTopicId = params.get("ClsTopicId")
        self._ClsLogSetId = params.get("ClsLogSetId")
        self._EnableXMLConfig = params.get("EnableXMLConfig")
        self._RegionDesc = params.get("RegionDesc")
        self._Eip = params.get("Eip")
        self._CosMoveFactor = params.get("CosMoveFactor")
        self._Kind = params.get("Kind")
        self._IsElastic = params.get("IsElastic")
        if params.get("InstanceStateInfo") is not None:
            self._InstanceStateInfo = InstanceStateInfo()
            self._InstanceStateInfo._deserialize(params.get("InstanceStateInfo"))
        self._HAZk = params.get("HAZk")
        self._MountDiskType = params.get("MountDiskType")
        self._CHProxyVip = params.get("CHProxyVip")
        self._CosBucketName = params.get("CosBucketName")
        self._CanAttachCbs = params.get("CanAttachCbs")
        self._CanAttachCbsLvm = params.get("CanAttachCbsLvm")
        self._CanAttachCos = params.get("CanAttachCos")
        if params.get("Components") is not None:
            self._Components = []
            for item in params.get("Components"):
                obj = ServiceInfo()
                obj._deserialize(item)
                self._Components.append(obj)
        self._UpgradeVersions = params.get("UpgradeVersions")
        self._EsIndexId = params.get("EsIndexId")
        self._EsIndexUsername = params.get("EsIndexUsername")
        self._EsIndexPassword = params.get("EsIndexPassword")
        self._HasEsIndex = params.get("HasEsIndex")
        self._IsSecondaryZone = params.get("IsSecondaryZone")
        self._SecondaryZoneInfo = params.get("SecondaryZoneInfo")
        self._ClickHouseKeeper = params.get("ClickHouseKeeper")
        if params.get("Details") is not None:
            self._Details = InstanceDetail()
            self._Details._deserialize(params.get("Details"))
        self._IsWhiteSGs = params.get("IsWhiteSGs")
        self._BindSGs = params.get("BindSGs")
        self._HasPublicCloudClb = params.get("HasPublicCloudClb")
        self._UpgradeZkVersions = params.get("UpgradeZkVersions")
        self._ShowRip = params.get("ShowRip")
        self._InstanceType = params.get("InstanceType")
        self._EnableConfigKeyValue = params.get("EnableConfigKeyValue")
        self._HttpsEnabled = params.get("HttpsEnabled")
        if params.get("DiskEncryptInfo") is not None:
            self._DiskEncryptInfo = DiskEncryptInfo()
            self._DiskEncryptInfo._deserialize(params.get("DiskEncryptInfo"))
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class InstanceNode(AbstractModel):
    r"""实例节点描述信息

    """

    def __init__(self):
        r"""
        :param _Ip: IP地址
        :type Ip: str
        :param _Spec: 机型，如 S1
        :type Spec: str
        :param _Core: cpu核数
        :type Core: int
        :param _Memory: 内存大小
        :type Memory: int
        :param _DiskType: 磁盘类型
        :type DiskType: str
        :param _DiskSize: 磁盘大小
        :type DiskSize: int
        :param _Cluster: 所属clickhouse cluster名称
        :type Cluster: str
        :param _NodeGroups: 节点所属的分组信息
        :type NodeGroups: list of GroupInfo
        :param _Rip: VPC IP
        :type Rip: str
        :param _IsCHProxy: ture的时候表示该节点上部署了chPROXY进程
        :type IsCHProxy: bool
        :param _Status: 节点状态
        :type Status: str
        :param _UUID: 节点uuid
        :type UUID: str
        :param _Zone: 区
        :type Zone: str
        :param _ZoneDesc: 去描述
        :type ZoneDesc: str
        :param _RealResourceId: 真实资源id
        :type RealResourceId: str
        :param _SubnetId: 子网信息
        :type SubnetId: str
        """
        self._Ip = None
        self._Spec = None
        self._Core = None
        self._Memory = None
        self._DiskType = None
        self._DiskSize = None
        self._Cluster = None
        self._NodeGroups = None
        self._Rip = None
        self._IsCHProxy = None
        self._Status = None
        self._UUID = None
        self._Zone = None
        self._ZoneDesc = None
        self._RealResourceId = None
        self._SubnetId = None

    @property
    def Ip(self):
        r"""IP地址
        :rtype: str
        """
        return self._Ip

    @Ip.setter
    def Ip(self, Ip):
        self._Ip = Ip

    @property
    def Spec(self):
        r"""机型，如 S1
        :rtype: str
        """
        return self._Spec

    @Spec.setter
    def Spec(self, Spec):
        self._Spec = Spec

    @property
    def Core(self):
        r"""cpu核数
        :rtype: int
        """
        return self._Core

    @Core.setter
    def Core(self, Core):
        self._Core = Core

    @property
    def Memory(self):
        r"""内存大小
        :rtype: int
        """
        return self._Memory

    @Memory.setter
    def Memory(self, Memory):
        self._Memory = Memory

    @property
    def DiskType(self):
        r"""磁盘类型
        :rtype: str
        """
        return self._DiskType

    @DiskType.setter
    def DiskType(self, DiskType):
        self._DiskType = DiskType

    @property
    def DiskSize(self):
        r"""磁盘大小
        :rtype: int
        """
        return self._DiskSize

    @DiskSize.setter
    def DiskSize(self, DiskSize):
        self._DiskSize = DiskSize

    @property
    def Cluster(self):
        r"""所属clickhouse cluster名称
        :rtype: str
        """
        return self._Cluster

    @Cluster.setter
    def Cluster(self, Cluster):
        self._Cluster = Cluster

    @property
    def NodeGroups(self):
        r"""节点所属的分组信息
        :rtype: list of GroupInfo
        """
        return self._NodeGroups

    @NodeGroups.setter
    def NodeGroups(self, NodeGroups):
        self._NodeGroups = NodeGroups

    @property
    def Rip(self):
        r"""VPC IP
        :rtype: str
        """
        return self._Rip

    @Rip.setter
    def Rip(self, Rip):
        self._Rip = Rip

    @property
    def IsCHProxy(self):
        r"""ture的时候表示该节点上部署了chPROXY进程
        :rtype: bool
        """
        return self._IsCHProxy

    @IsCHProxy.setter
    def IsCHProxy(self, IsCHProxy):
        self._IsCHProxy = IsCHProxy

    @property
    def Status(self):
        r"""节点状态
        :rtype: str
        """
        return self._Status

    @Status.setter
    def Status(self, Status):
        self._Status = Status

    @property
    def UUID(self):
        r"""节点uuid
        :rtype: str
        """
        return self._UUID

    @UUID.setter
    def UUID(self, UUID):
        self._UUID = UUID

    @property
    def Zone(self):
        r"""区
        :rtype: str
        """
        return self._Zone

    @Zone.setter
    def Zone(self, Zone):
        self._Zone = Zone

    @property
    def ZoneDesc(self):
        r"""去描述
        :rtype: str
        """
        return self._ZoneDesc

    @ZoneDesc.setter
    def ZoneDesc(self, ZoneDesc):
        self._ZoneDesc = ZoneDesc

    @property
    def RealResourceId(self):
        r"""真实资源id
        :rtype: str
        """
        return self._RealResourceId

    @RealResourceId.setter
    def RealResourceId(self, RealResourceId):
        self._RealResourceId = RealResourceId

    @property
    def SubnetId(self):
        r"""子网信息
        :rtype: str
        """
        return self._SubnetId

    @SubnetId.setter
    def SubnetId(self, SubnetId):
        self._SubnetId = SubnetId


    def _deserialize(self, params):
        self._Ip = params.get("Ip")
        self._Spec = params.get("Spec")
        self._Core = params.get("Core")
        self._Memory = params.get("Memory")
        self._DiskType = params.get("DiskType")
        self._DiskSize = params.get("DiskSize")
        self._Cluster = params.get("Cluster")
        if params.get("NodeGroups") is not None:
            self._NodeGroups = []
            for item in params.get("NodeGroups"):
                obj = GroupInfo()
                obj._deserialize(item)
                self._NodeGroups.append(obj)
        self._Rip = params.get("Rip")
        self._IsCHProxy = params.get("IsCHProxy")
        self._Status = params.get("Status")
        self._UUID = params.get("UUID")
        self._Zone = params.get("Zone")
        self._ZoneDesc = params.get("ZoneDesc")
        self._RealResourceId = params.get("RealResourceId")
        self._SubnetId = params.get("SubnetId")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class InstanceStateInfo(AbstractModel):
    r"""集群状态抽象后的结构体

    """

    def __init__(self):
        r"""
        :param _InstanceState: <p>集群状态，例如：Serving</p>
        :type InstanceState: str
        :param _FlowCreateTime: <p>集群操作创建时间</p>
        :type FlowCreateTime: str
        :param _FlowName: <p>集群操作名称</p>
        :type FlowName: str
        :param _FlowProgress: <p>集群操作进度</p>
        :type FlowProgress: int
        :param _InstanceStateDesc: <p>集群状态描述，例如：运行中</p>
        :type InstanceStateDesc: str
        :param _FlowMsg: <p>集群流程错误信息，例如：“创建失败，资源不足”</p>
        :type FlowMsg: str
        :param _ProcessName: <p>当前步骤的名称，例如：”购买资源中“</p>
        :type ProcessName: str
        :param _RequestId: <p>请求id</p>
        :type RequestId: str
        :param _ProcessSubName: <p>流程的二级名称</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type ProcessSubName: str
        :param _RequestID: <p>请求ID</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type RequestID: str
        """
        self._InstanceState = None
        self._FlowCreateTime = None
        self._FlowName = None
        self._FlowProgress = None
        self._InstanceStateDesc = None
        self._FlowMsg = None
        self._ProcessName = None
        self._RequestId = None
        self._ProcessSubName = None
        self._RequestID = None

    @property
    def InstanceState(self):
        r"""<p>集群状态，例如：Serving</p>
        :rtype: str
        """
        return self._InstanceState

    @InstanceState.setter
    def InstanceState(self, InstanceState):
        self._InstanceState = InstanceState

    @property
    def FlowCreateTime(self):
        r"""<p>集群操作创建时间</p>
        :rtype: str
        """
        return self._FlowCreateTime

    @FlowCreateTime.setter
    def FlowCreateTime(self, FlowCreateTime):
        self._FlowCreateTime = FlowCreateTime

    @property
    def FlowName(self):
        r"""<p>集群操作名称</p>
        :rtype: str
        """
        return self._FlowName

    @FlowName.setter
    def FlowName(self, FlowName):
        self._FlowName = FlowName

    @property
    def FlowProgress(self):
        r"""<p>集群操作进度</p>
        :rtype: int
        """
        return self._FlowProgress

    @FlowProgress.setter
    def FlowProgress(self, FlowProgress):
        self._FlowProgress = FlowProgress

    @property
    def InstanceStateDesc(self):
        r"""<p>集群状态描述，例如：运行中</p>
        :rtype: str
        """
        return self._InstanceStateDesc

    @InstanceStateDesc.setter
    def InstanceStateDesc(self, InstanceStateDesc):
        self._InstanceStateDesc = InstanceStateDesc

    @property
    def FlowMsg(self):
        r"""<p>集群流程错误信息，例如：“创建失败，资源不足”</p>
        :rtype: str
        """
        return self._FlowMsg

    @FlowMsg.setter
    def FlowMsg(self, FlowMsg):
        self._FlowMsg = FlowMsg

    @property
    def ProcessName(self):
        r"""<p>当前步骤的名称，例如：”购买资源中“</p>
        :rtype: str
        """
        return self._ProcessName

    @ProcessName.setter
    def ProcessName(self, ProcessName):
        self._ProcessName = ProcessName

    @property
    def RequestId(self):
        r"""<p>请求id</p>
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId

    @property
    def ProcessSubName(self):
        r"""<p>流程的二级名称</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._ProcessSubName

    @ProcessSubName.setter
    def ProcessSubName(self, ProcessSubName):
        self._ProcessSubName = ProcessSubName

    @property
    def RequestID(self):
        r"""<p>请求ID</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._RequestID

    @RequestID.setter
    def RequestID(self, RequestID):
        self._RequestID = RequestID


    def _deserialize(self, params):
        self._InstanceState = params.get("InstanceState")
        self._FlowCreateTime = params.get("FlowCreateTime")
        self._FlowName = params.get("FlowName")
        self._FlowProgress = params.get("FlowProgress")
        self._InstanceStateDesc = params.get("InstanceStateDesc")
        self._FlowMsg = params.get("FlowMsg")
        self._ProcessName = params.get("ProcessName")
        self._RequestId = params.get("RequestId")
        self._ProcessSubName = params.get("ProcessSubName")
        self._RequestID = params.get("RequestID")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class MapConfigItem(AbstractModel):
    r"""kv配置，多层级item

    """

    def __init__(self):
        r"""
        :param _ConfKey: key
        :type ConfKey: str
        :param _Items: 列表
        :type Items: list of InstanceConfigInfo
        """
        self._ConfKey = None
        self._Items = None

    @property
    def ConfKey(self):
        r"""key
        :rtype: str
        """
        return self._ConfKey

    @ConfKey.setter
    def ConfKey(self, ConfKey):
        self._ConfKey = ConfKey

    @property
    def Items(self):
        r"""列表
        :rtype: list of InstanceConfigInfo
        """
        return self._Items

    @Items.setter
    def Items(self, Items):
        self._Items = Items


    def _deserialize(self, params):
        self._ConfKey = params.get("ConfKey")
        if params.get("Items") is not None:
            self._Items = []
            for item in params.get("Items"):
                obj = InstanceConfigInfo()
                obj._deserialize(item)
                self._Items.append(obj)
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ModifyClusterConfigsRequest(AbstractModel):
    r"""ModifyClusterConfigs请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceId: 集群ID，例如cdwch-xxxx
        :type InstanceId: str
        :param _ModifyConfContext: 配置文件修改信息
        :type ModifyConfContext: list of ConfigSubmitContext
        :param _Remark: 修改原因
        :type Remark: str
        """
        self._InstanceId = None
        self._ModifyConfContext = None
        self._Remark = None

    @property
    def InstanceId(self):
        r"""集群ID，例如cdwch-xxxx
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId

    @property
    def ModifyConfContext(self):
        r"""配置文件修改信息
        :rtype: list of ConfigSubmitContext
        """
        return self._ModifyConfContext

    @ModifyConfContext.setter
    def ModifyConfContext(self, ModifyConfContext):
        self._ModifyConfContext = ModifyConfContext

    @property
    def Remark(self):
        r"""修改原因
        :rtype: str
        """
        return self._Remark

    @Remark.setter
    def Remark(self, Remark):
        self._Remark = Remark


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        if params.get("ModifyConfContext") is not None:
            self._ModifyConfContext = []
            for item in params.get("ModifyConfContext"):
                obj = ConfigSubmitContext()
                obj._deserialize(item)
                self._ModifyConfContext.append(obj)
        self._Remark = params.get("Remark")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ModifyClusterConfigsResponse(AbstractModel):
    r"""ModifyClusterConfigs返回参数结构体

    """

    def __init__(self):
        r"""
        :param _FlowId: 流程相关信息
        :type FlowId: int
        :param _ErrorMsg: 错误信息
        :type ErrorMsg: str
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._FlowId = None
        self._ErrorMsg = None
        self._RequestId = None

    @property
    def FlowId(self):
        r"""流程相关信息
        :rtype: int
        """
        return self._FlowId

    @FlowId.setter
    def FlowId(self, FlowId):
        self._FlowId = FlowId

    @property
    def ErrorMsg(self):
        r"""错误信息
        :rtype: str
        """
        return self._ErrorMsg

    @ErrorMsg.setter
    def ErrorMsg(self, ErrorMsg):
        self._ErrorMsg = ErrorMsg

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._FlowId = params.get("FlowId")
        self._ErrorMsg = params.get("ErrorMsg")
        self._RequestId = params.get("RequestId")


class ModifyInstanceKeyValConfigsRequest(AbstractModel):
    r"""ModifyInstanceKeyValConfigs请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceId: 实例ID
        :type InstanceId: str
        :param _AddItems: 新增配置列表
        :type AddItems: list of InstanceConfigItem
        :param _UpdateItems: 更新配置列表
        :type UpdateItems: list of InstanceConfigItem
        :param _DeleteItems: 删除配置列表
        :type DeleteItems: :class:`tencentcloud.cdwch.v20200915.models.InstanceConfigItem`
        :param _DelItems: 删除配置列表
        :type DelItems: list of InstanceConfigItem
        :param _Remark: 备注
        :type Remark: str
        """
        self._InstanceId = None
        self._AddItems = None
        self._UpdateItems = None
        self._DeleteItems = None
        self._DelItems = None
        self._Remark = None

    @property
    def InstanceId(self):
        r"""实例ID
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId

    @property
    def AddItems(self):
        r"""新增配置列表
        :rtype: list of InstanceConfigItem
        """
        return self._AddItems

    @AddItems.setter
    def AddItems(self, AddItems):
        self._AddItems = AddItems

    @property
    def UpdateItems(self):
        r"""更新配置列表
        :rtype: list of InstanceConfigItem
        """
        return self._UpdateItems

    @UpdateItems.setter
    def UpdateItems(self, UpdateItems):
        self._UpdateItems = UpdateItems

    @property
    def DeleteItems(self):
        r"""删除配置列表
        :rtype: :class:`tencentcloud.cdwch.v20200915.models.InstanceConfigItem`
        """
        return self._DeleteItems

    @DeleteItems.setter
    def DeleteItems(self, DeleteItems):
        self._DeleteItems = DeleteItems

    @property
    def DelItems(self):
        r"""删除配置列表
        :rtype: list of InstanceConfigItem
        """
        return self._DelItems

    @DelItems.setter
    def DelItems(self, DelItems):
        self._DelItems = DelItems

    @property
    def Remark(self):
        r"""备注
        :rtype: str
        """
        return self._Remark

    @Remark.setter
    def Remark(self, Remark):
        self._Remark = Remark


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        if params.get("AddItems") is not None:
            self._AddItems = []
            for item in params.get("AddItems"):
                obj = InstanceConfigItem()
                obj._deserialize(item)
                self._AddItems.append(obj)
        if params.get("UpdateItems") is not None:
            self._UpdateItems = []
            for item in params.get("UpdateItems"):
                obj = InstanceConfigItem()
                obj._deserialize(item)
                self._UpdateItems.append(obj)
        if params.get("DeleteItems") is not None:
            self._DeleteItems = InstanceConfigItem()
            self._DeleteItems._deserialize(params.get("DeleteItems"))
        if params.get("DelItems") is not None:
            self._DelItems = []
            for item in params.get("DelItems"):
                obj = InstanceConfigItem()
                obj._deserialize(item)
                self._DelItems.append(obj)
        self._Remark = params.get("Remark")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ModifyInstanceKeyValConfigsResponse(AbstractModel):
    r"""ModifyInstanceKeyValConfigs返回参数结构体

    """

    def __init__(self):
        r"""
        :param _ErrorMsg: 错误信息
        :type ErrorMsg: str
        :param _FlowId: ID
        :type FlowId: int
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._ErrorMsg = None
        self._FlowId = None
        self._RequestId = None

    @property
    def ErrorMsg(self):
        r"""错误信息
        :rtype: str
        """
        return self._ErrorMsg

    @ErrorMsg.setter
    def ErrorMsg(self, ErrorMsg):
        self._ErrorMsg = ErrorMsg

    @property
    def FlowId(self):
        r"""ID
        :rtype: int
        """
        return self._FlowId

    @FlowId.setter
    def FlowId(self, FlowId):
        self._FlowId = FlowId

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._ErrorMsg = params.get("ErrorMsg")
        self._FlowId = params.get("FlowId")
        self._RequestId = params.get("RequestId")


class ModifyUserNewPrivilegeRequest(AbstractModel):
    r"""ModifyUserNewPrivilege请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceId: <p>实例id</p>
        :type InstanceId: str
        :param _Cluster: <p>clickhouse逻辑集群名称，可通过连接集群执行 <code>SHOW CLUSTERS</code> 查询获得</p>
        :type Cluster: str
        :param _UserName: <p>用户名</p>
        :type UserName: str
        :param _AllDatabase: <p>是否所有数据库表</p>
        :type AllDatabase: bool
        :param _GlobalPrivileges: <p>全局权限</p>
        :type GlobalPrivileges: list of str
        :param _DatabasePrivilegeList: <p>数据库表权限</p>
        :type DatabasePrivilegeList: list of DatabasePrivilegeInfo
        :param _InstanceType: <p>实例类型</p><p>枚举值：</p><ul><li>SSC： 弹性版实例</li><li>Standard： 标准版实例</li></ul>
        :type InstanceType: str
        """
        self._InstanceId = None
        self._Cluster = None
        self._UserName = None
        self._AllDatabase = None
        self._GlobalPrivileges = None
        self._DatabasePrivilegeList = None
        self._InstanceType = None

    @property
    def InstanceId(self):
        r"""<p>实例id</p>
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId

    @property
    def Cluster(self):
        r"""<p>clickhouse逻辑集群名称，可通过连接集群执行 <code>SHOW CLUSTERS</code> 查询获得</p>
        :rtype: str
        """
        return self._Cluster

    @Cluster.setter
    def Cluster(self, Cluster):
        self._Cluster = Cluster

    @property
    def UserName(self):
        r"""<p>用户名</p>
        :rtype: str
        """
        return self._UserName

    @UserName.setter
    def UserName(self, UserName):
        self._UserName = UserName

    @property
    def AllDatabase(self):
        r"""<p>是否所有数据库表</p>
        :rtype: bool
        """
        return self._AllDatabase

    @AllDatabase.setter
    def AllDatabase(self, AllDatabase):
        self._AllDatabase = AllDatabase

    @property
    def GlobalPrivileges(self):
        r"""<p>全局权限</p>
        :rtype: list of str
        """
        return self._GlobalPrivileges

    @GlobalPrivileges.setter
    def GlobalPrivileges(self, GlobalPrivileges):
        self._GlobalPrivileges = GlobalPrivileges

    @property
    def DatabasePrivilegeList(self):
        r"""<p>数据库表权限</p>
        :rtype: list of DatabasePrivilegeInfo
        """
        return self._DatabasePrivilegeList

    @DatabasePrivilegeList.setter
    def DatabasePrivilegeList(self, DatabasePrivilegeList):
        self._DatabasePrivilegeList = DatabasePrivilegeList

    @property
    def InstanceType(self):
        r"""<p>实例类型</p><p>枚举值：</p><ul><li>SSC： 弹性版实例</li><li>Standard： 标准版实例</li></ul>
        :rtype: str
        """
        return self._InstanceType

    @InstanceType.setter
    def InstanceType(self, InstanceType):
        self._InstanceType = InstanceType


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        self._Cluster = params.get("Cluster")
        self._UserName = params.get("UserName")
        self._AllDatabase = params.get("AllDatabase")
        self._GlobalPrivileges = params.get("GlobalPrivileges")
        if params.get("DatabasePrivilegeList") is not None:
            self._DatabasePrivilegeList = []
            for item in params.get("DatabasePrivilegeList"):
                obj = DatabasePrivilegeInfo()
                obj._deserialize(item)
                self._DatabasePrivilegeList.append(obj)
        self._InstanceType = params.get("InstanceType")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ModifyUserNewPrivilegeResponse(AbstractModel):
    r"""ModifyUserNewPrivilege返回参数结构体

    """

    def __init__(self):
        r"""
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._RequestId = None

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._RequestId = params.get("RequestId")


class NodeSpec(AbstractModel):
    r"""创建集群时的规格

    """

    def __init__(self):
        r"""
        :param _SpecName: 规格名称
        :type SpecName: str
        :param _Count: 数量
        :type Count: int
        :param _DiskSize: 云盘大小
        :type DiskSize: int
        """
        self._SpecName = None
        self._Count = None
        self._DiskSize = None

    @property
    def SpecName(self):
        r"""规格名称
        :rtype: str
        """
        return self._SpecName

    @SpecName.setter
    def SpecName(self, SpecName):
        self._SpecName = SpecName

    @property
    def Count(self):
        r"""数量
        :rtype: int
        """
        return self._Count

    @Count.setter
    def Count(self, Count):
        self._Count = Count

    @property
    def DiskSize(self):
        r"""云盘大小
        :rtype: int
        """
        return self._DiskSize

    @DiskSize.setter
    def DiskSize(self, DiskSize):
        self._DiskSize = DiskSize


    def _deserialize(self, params):
        self._SpecName = params.get("SpecName")
        self._Count = params.get("Count")
        self._DiskSize = params.get("DiskSize")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class NodesSummary(AbstractModel):
    r"""节点角色描述信息

    """

    def __init__(self):
        r"""
        :param _Spec: 机型，如 S1
        :type Spec: str
        :param _NodeSize: 节点数目
        :type NodeSize: int
        :param _Core: cpu核数，单位个
        :type Core: int
        :param _Memory: 内存大小，单位G
        :type Memory: int
        :param _Disk: 磁盘大小，单位G
        :type Disk: int
        :param _DiskType: 磁盘类型
        :type DiskType: str
        :param _DiskDesc: 磁盘描述
        :type DiskDesc: str
        :param _AttachCBSSpec: 挂载云盘信息
        :type AttachCBSSpec: :class:`tencentcloud.cdwch.v20200915.models.AttachCBSSpec`
        :param _SubProductType: 子产品类型
        :type SubProductType: str
        :param _SpecCore: 规格对应的核数
        :type SpecCore: int
        :param _SpecMemory: 规格对应的内存大小
        :type SpecMemory: int
        :param _DiskCount: 磁盘的数量
        :type DiskCount: int
        :param _MaxDiskSize: 磁盘的最大大小
        :type MaxDiskSize: int
        :param _Encrypt: 是否为加密云盘
        :type Encrypt: int
        """
        self._Spec = None
        self._NodeSize = None
        self._Core = None
        self._Memory = None
        self._Disk = None
        self._DiskType = None
        self._DiskDesc = None
        self._AttachCBSSpec = None
        self._SubProductType = None
        self._SpecCore = None
        self._SpecMemory = None
        self._DiskCount = None
        self._MaxDiskSize = None
        self._Encrypt = None

    @property
    def Spec(self):
        r"""机型，如 S1
        :rtype: str
        """
        return self._Spec

    @Spec.setter
    def Spec(self, Spec):
        self._Spec = Spec

    @property
    def NodeSize(self):
        r"""节点数目
        :rtype: int
        """
        return self._NodeSize

    @NodeSize.setter
    def NodeSize(self, NodeSize):
        self._NodeSize = NodeSize

    @property
    def Core(self):
        r"""cpu核数，单位个
        :rtype: int
        """
        return self._Core

    @Core.setter
    def Core(self, Core):
        self._Core = Core

    @property
    def Memory(self):
        r"""内存大小，单位G
        :rtype: int
        """
        return self._Memory

    @Memory.setter
    def Memory(self, Memory):
        self._Memory = Memory

    @property
    def Disk(self):
        r"""磁盘大小，单位G
        :rtype: int
        """
        return self._Disk

    @Disk.setter
    def Disk(self, Disk):
        self._Disk = Disk

    @property
    def DiskType(self):
        r"""磁盘类型
        :rtype: str
        """
        return self._DiskType

    @DiskType.setter
    def DiskType(self, DiskType):
        self._DiskType = DiskType

    @property
    def DiskDesc(self):
        r"""磁盘描述
        :rtype: str
        """
        return self._DiskDesc

    @DiskDesc.setter
    def DiskDesc(self, DiskDesc):
        self._DiskDesc = DiskDesc

    @property
    def AttachCBSSpec(self):
        r"""挂载云盘信息
        :rtype: :class:`tencentcloud.cdwch.v20200915.models.AttachCBSSpec`
        """
        return self._AttachCBSSpec

    @AttachCBSSpec.setter
    def AttachCBSSpec(self, AttachCBSSpec):
        self._AttachCBSSpec = AttachCBSSpec

    @property
    def SubProductType(self):
        r"""子产品类型
        :rtype: str
        """
        return self._SubProductType

    @SubProductType.setter
    def SubProductType(self, SubProductType):
        self._SubProductType = SubProductType

    @property
    def SpecCore(self):
        r"""规格对应的核数
        :rtype: int
        """
        return self._SpecCore

    @SpecCore.setter
    def SpecCore(self, SpecCore):
        self._SpecCore = SpecCore

    @property
    def SpecMemory(self):
        r"""规格对应的内存大小
        :rtype: int
        """
        return self._SpecMemory

    @SpecMemory.setter
    def SpecMemory(self, SpecMemory):
        self._SpecMemory = SpecMemory

    @property
    def DiskCount(self):
        r"""磁盘的数量
        :rtype: int
        """
        return self._DiskCount

    @DiskCount.setter
    def DiskCount(self, DiskCount):
        self._DiskCount = DiskCount

    @property
    def MaxDiskSize(self):
        r"""磁盘的最大大小
        :rtype: int
        """
        return self._MaxDiskSize

    @MaxDiskSize.setter
    def MaxDiskSize(self, MaxDiskSize):
        self._MaxDiskSize = MaxDiskSize

    @property
    def Encrypt(self):
        r"""是否为加密云盘
        :rtype: int
        """
        return self._Encrypt

    @Encrypt.setter
    def Encrypt(self, Encrypt):
        self._Encrypt = Encrypt


    def _deserialize(self, params):
        self._Spec = params.get("Spec")
        self._NodeSize = params.get("NodeSize")
        self._Core = params.get("Core")
        self._Memory = params.get("Memory")
        self._Disk = params.get("Disk")
        self._DiskType = params.get("DiskType")
        self._DiskDesc = params.get("DiskDesc")
        if params.get("AttachCBSSpec") is not None:
            self._AttachCBSSpec = AttachCBSSpec()
            self._AttachCBSSpec._deserialize(params.get("AttachCBSSpec"))
        self._SubProductType = params.get("SubProductType")
        self._SpecCore = params.get("SpecCore")
        self._SpecMemory = params.get("SpecMemory")
        self._DiskCount = params.get("DiskCount")
        self._MaxDiskSize = params.get("MaxDiskSize")
        self._Encrypt = params.get("Encrypt")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class OpenBackUpRequest(AbstractModel):
    r"""OpenBackUp请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceId: 集群id
        :type InstanceId: str
        :param _OperationType: OPEN 或者CLOSE
        :type OperationType: str
        :param _CosBucketName: 桶名字
        :type CosBucketName: str
        """
        self._InstanceId = None
        self._OperationType = None
        self._CosBucketName = None

    @property
    def InstanceId(self):
        r"""集群id
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId

    @property
    def OperationType(self):
        r"""OPEN 或者CLOSE
        :rtype: str
        """
        return self._OperationType

    @OperationType.setter
    def OperationType(self, OperationType):
        self._OperationType = OperationType

    @property
    def CosBucketName(self):
        r"""桶名字
        :rtype: str
        """
        return self._CosBucketName

    @CosBucketName.setter
    def CosBucketName(self, CosBucketName):
        self._CosBucketName = CosBucketName


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        self._OperationType = params.get("OperationType")
        self._CosBucketName = params.get("CosBucketName")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class OpenBackUpResponse(AbstractModel):
    r"""OpenBackUp返回参数结构体

    """

    def __init__(self):
        r"""
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._RequestId = None

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._RequestId = params.get("RequestId")


class RecoverBackUpJobRequest(AbstractModel):
    r"""RecoverBackUpJob请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceId: 集群id
        :type InstanceId: str
        :param _BackUpJobId: 任务id
        :type BackUpJobId: int
        """
        self._InstanceId = None
        self._BackUpJobId = None

    @property
    def InstanceId(self):
        r"""集群id
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId

    @property
    def BackUpJobId(self):
        r"""任务id
        :rtype: int
        """
        return self._BackUpJobId

    @BackUpJobId.setter
    def BackUpJobId(self, BackUpJobId):
        self._BackUpJobId = BackUpJobId


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        self._BackUpJobId = params.get("BackUpJobId")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class RecoverBackUpJobResponse(AbstractModel):
    r"""RecoverBackUpJob返回参数结构体

    """

    def __init__(self):
        r"""
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._RequestId = None

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._RequestId = params.get("RequestId")


class ResizeDiskRequest(AbstractModel):
    r"""ResizeDisk请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceId: 实例唯一ID
        :type InstanceId: str
        :param _Type: 节点类型，DATA：clickhouse节点，COMMON：为zookeeper节点
        :type Type: str
        :param _DiskSize: 磁盘扩容后容量，不能小于原有用量。clickhouse最小200，且为100的整数倍。 zk最小100，且为10的整数倍；
        :type DiskSize: int
        """
        self._InstanceId = None
        self._Type = None
        self._DiskSize = None

    @property
    def InstanceId(self):
        r"""实例唯一ID
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId

    @property
    def Type(self):
        r"""节点类型，DATA：clickhouse节点，COMMON：为zookeeper节点
        :rtype: str
        """
        return self._Type

    @Type.setter
    def Type(self, Type):
        self._Type = Type

    @property
    def DiskSize(self):
        r"""磁盘扩容后容量，不能小于原有用量。clickhouse最小200，且为100的整数倍。 zk最小100，且为10的整数倍；
        :rtype: int
        """
        return self._DiskSize

    @DiskSize.setter
    def DiskSize(self, DiskSize):
        self._DiskSize = DiskSize


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        self._Type = params.get("Type")
        self._DiskSize = params.get("DiskSize")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ResizeDiskResponse(AbstractModel):
    r"""ResizeDisk返回参数结构体

    """

    def __init__(self):
        r"""
        :param _FlowId: 流程ID
        :type FlowId: str
        :param _InstanceId: 实例ID
        :type InstanceId: str
        :param _ErrorMsg: 错误信息
        :type ErrorMsg: str
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._FlowId = None
        self._InstanceId = None
        self._ErrorMsg = None
        self._RequestId = None

    @property
    def FlowId(self):
        r"""流程ID
        :rtype: str
        """
        return self._FlowId

    @FlowId.setter
    def FlowId(self, FlowId):
        self._FlowId = FlowId

    @property
    def InstanceId(self):
        r"""实例ID
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId

    @property
    def ErrorMsg(self):
        r"""错误信息
        :rtype: str
        """
        return self._ErrorMsg

    @ErrorMsg.setter
    def ErrorMsg(self, ErrorMsg):
        self._ErrorMsg = ErrorMsg

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._FlowId = params.get("FlowId")
        self._InstanceId = params.get("InstanceId")
        self._ErrorMsg = params.get("ErrorMsg")
        self._RequestId = params.get("RequestId")


class ResourceSpec(AbstractModel):
    r"""资源规格描述信息

    """

    def __init__(self):
        r"""
        :param _Name: 规格名称，例如“SCH1"
        :type Name: str
        :param _Cpu: cpu核数
        :type Cpu: int
        :param _Mem: 内存大小，单位G
        :type Mem: int
        :param _Type: 分类标记，STANDARD/BIGDATA/HIGHIO分别表示标准型/大数据型/高IO
        :type Type: str
        :param _SystemDisk: 系统盘描述信息
        :type SystemDisk: :class:`tencentcloud.cdwch.v20200915.models.DiskSpec`
        :param _DataDisk: 数据盘描述信息
        :type DataDisk: :class:`tencentcloud.cdwch.v20200915.models.DiskSpec`
        :param _MaxNodeSize: 最大节点数目限制
        :type MaxNodeSize: int
        :param _Available: 是否可用，false代表售罄
        :type Available: bool
        :param _ComputeSpecDesc: 规格描述信息
        :type ComputeSpecDesc: str
        :param _DisplayName: 规格名
        :type DisplayName: str
        :param _InstanceQuota: 库存数
        :type InstanceQuota: int
        """
        self._Name = None
        self._Cpu = None
        self._Mem = None
        self._Type = None
        self._SystemDisk = None
        self._DataDisk = None
        self._MaxNodeSize = None
        self._Available = None
        self._ComputeSpecDesc = None
        self._DisplayName = None
        self._InstanceQuota = None

    @property
    def Name(self):
        r"""规格名称，例如“SCH1"
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def Cpu(self):
        r"""cpu核数
        :rtype: int
        """
        return self._Cpu

    @Cpu.setter
    def Cpu(self, Cpu):
        self._Cpu = Cpu

    @property
    def Mem(self):
        r"""内存大小，单位G
        :rtype: int
        """
        return self._Mem

    @Mem.setter
    def Mem(self, Mem):
        self._Mem = Mem

    @property
    def Type(self):
        r"""分类标记，STANDARD/BIGDATA/HIGHIO分别表示标准型/大数据型/高IO
        :rtype: str
        """
        return self._Type

    @Type.setter
    def Type(self, Type):
        self._Type = Type

    @property
    def SystemDisk(self):
        r"""系统盘描述信息
        :rtype: :class:`tencentcloud.cdwch.v20200915.models.DiskSpec`
        """
        return self._SystemDisk

    @SystemDisk.setter
    def SystemDisk(self, SystemDisk):
        self._SystemDisk = SystemDisk

    @property
    def DataDisk(self):
        r"""数据盘描述信息
        :rtype: :class:`tencentcloud.cdwch.v20200915.models.DiskSpec`
        """
        return self._DataDisk

    @DataDisk.setter
    def DataDisk(self, DataDisk):
        self._DataDisk = DataDisk

    @property
    def MaxNodeSize(self):
        r"""最大节点数目限制
        :rtype: int
        """
        return self._MaxNodeSize

    @MaxNodeSize.setter
    def MaxNodeSize(self, MaxNodeSize):
        self._MaxNodeSize = MaxNodeSize

    @property
    def Available(self):
        r"""是否可用，false代表售罄
        :rtype: bool
        """
        return self._Available

    @Available.setter
    def Available(self, Available):
        self._Available = Available

    @property
    def ComputeSpecDesc(self):
        r"""规格描述信息
        :rtype: str
        """
        return self._ComputeSpecDesc

    @ComputeSpecDesc.setter
    def ComputeSpecDesc(self, ComputeSpecDesc):
        self._ComputeSpecDesc = ComputeSpecDesc

    @property
    def DisplayName(self):
        r"""规格名
        :rtype: str
        """
        return self._DisplayName

    @DisplayName.setter
    def DisplayName(self, DisplayName):
        self._DisplayName = DisplayName

    @property
    def InstanceQuota(self):
        r"""库存数
        :rtype: int
        """
        return self._InstanceQuota

    @InstanceQuota.setter
    def InstanceQuota(self, InstanceQuota):
        self._InstanceQuota = InstanceQuota


    def _deserialize(self, params):
        self._Name = params.get("Name")
        self._Cpu = params.get("Cpu")
        self._Mem = params.get("Mem")
        self._Type = params.get("Type")
        if params.get("SystemDisk") is not None:
            self._SystemDisk = DiskSpec()
            self._SystemDisk._deserialize(params.get("SystemDisk"))
        if params.get("DataDisk") is not None:
            self._DataDisk = DiskSpec()
            self._DataDisk._deserialize(params.get("DataDisk"))
        self._MaxNodeSize = params.get("MaxNodeSize")
        self._Available = params.get("Available")
        self._ComputeSpecDesc = params.get("ComputeSpecDesc")
        self._DisplayName = params.get("DisplayName")
        self._InstanceQuota = params.get("InstanceQuota")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class RestartInstanceRequest(AbstractModel):
    r"""RestartInstance请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceId: 实例id
        :type InstanceId: str
        :param _NodeType: 节点类型，可选值：CK / ZK / CHPROXY
        :type NodeType: str
        :param _NodeIpList: 符合节点类型的要重启的节点ip列表
        :type NodeIpList: list of str
        :param _RollingRestart: 是否滚动重启，默认为true
        :type RollingRestart: bool
        """
        self._InstanceId = None
        self._NodeType = None
        self._NodeIpList = None
        self._RollingRestart = None

    @property
    def InstanceId(self):
        r"""实例id
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId

    @property
    def NodeType(self):
        r"""节点类型，可选值：CK / ZK / CHPROXY
        :rtype: str
        """
        return self._NodeType

    @NodeType.setter
    def NodeType(self, NodeType):
        self._NodeType = NodeType

    @property
    def NodeIpList(self):
        r"""符合节点类型的要重启的节点ip列表
        :rtype: list of str
        """
        return self._NodeIpList

    @NodeIpList.setter
    def NodeIpList(self, NodeIpList):
        self._NodeIpList = NodeIpList

    @property
    def RollingRestart(self):
        r"""是否滚动重启，默认为true
        :rtype: bool
        """
        return self._RollingRestart

    @RollingRestart.setter
    def RollingRestart(self, RollingRestart):
        self._RollingRestart = RollingRestart


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        self._NodeType = params.get("NodeType")
        self._NodeIpList = params.get("NodeIpList")
        self._RollingRestart = params.get("RollingRestart")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class RestartInstanceResponse(AbstractModel):
    r"""RestartInstance返回参数结构体

    """

    def __init__(self):
        r"""
        :param _FlowId: 任务id
        :type FlowId: int
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._FlowId = None
        self._RequestId = None

    @property
    def FlowId(self):
        r"""任务id
        :rtype: int
        """
        return self._FlowId

    @FlowId.setter
    def FlowId(self, FlowId):
        self._FlowId = FlowId

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._FlowId = params.get("FlowId")
        self._RequestId = params.get("RequestId")


class ScaleCNOutUpInstanceRequest(AbstractModel):
    r"""ScaleCNOutUpInstance请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceId: 实例唯一ID
        :type InstanceId: str
        :param _VirtualCluster: warehouse名称
        :type VirtualCluster: str
        :param _UserSubnetID: 子网id
        :type UserSubnetID: str
        :param _NewCount: 新的warehouse的个数
        :type NewCount: int
        :param _NewSpecName: 集群的规格2X-Small、X-Small、Small
        :type NewSpecName: str
        """
        self._InstanceId = None
        self._VirtualCluster = None
        self._UserSubnetID = None
        self._NewCount = None
        self._NewSpecName = None

    @property
    def InstanceId(self):
        r"""实例唯一ID
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId

    @property
    def VirtualCluster(self):
        r"""warehouse名称
        :rtype: str
        """
        return self._VirtualCluster

    @VirtualCluster.setter
    def VirtualCluster(self, VirtualCluster):
        self._VirtualCluster = VirtualCluster

    @property
    def UserSubnetID(self):
        r"""子网id
        :rtype: str
        """
        return self._UserSubnetID

    @UserSubnetID.setter
    def UserSubnetID(self, UserSubnetID):
        self._UserSubnetID = UserSubnetID

    @property
    def NewCount(self):
        r"""新的warehouse的个数
        :rtype: int
        """
        return self._NewCount

    @NewCount.setter
    def NewCount(self, NewCount):
        self._NewCount = NewCount

    @property
    def NewSpecName(self):
        r"""集群的规格2X-Small、X-Small、Small
        :rtype: str
        """
        return self._NewSpecName

    @NewSpecName.setter
    def NewSpecName(self, NewSpecName):
        self._NewSpecName = NewSpecName


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        self._VirtualCluster = params.get("VirtualCluster")
        self._UserSubnetID = params.get("UserSubnetID")
        self._NewCount = params.get("NewCount")
        self._NewSpecName = params.get("NewSpecName")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ScaleCNOutUpInstanceResponse(AbstractModel):
    r"""ScaleCNOutUpInstance返回参数结构体

    """

    def __init__(self):
        r"""
        :param _FlowId: 流程ID
        :type FlowId: str
        :param _InstanceId: 实例ID
        :type InstanceId: str
        :param _ErrorMsg: 错误信息
        :type ErrorMsg: str
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._FlowId = None
        self._InstanceId = None
        self._ErrorMsg = None
        self._RequestId = None

    @property
    def FlowId(self):
        r"""流程ID
        :rtype: str
        """
        return self._FlowId

    @FlowId.setter
    def FlowId(self, FlowId):
        self._FlowId = FlowId

    @property
    def InstanceId(self):
        r"""实例ID
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId

    @property
    def ErrorMsg(self):
        r"""错误信息
        :rtype: str
        """
        return self._ErrorMsg

    @ErrorMsg.setter
    def ErrorMsg(self, ErrorMsg):
        self._ErrorMsg = ErrorMsg

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._FlowId = params.get("FlowId")
        self._InstanceId = params.get("InstanceId")
        self._ErrorMsg = params.get("ErrorMsg")
        self._RequestId = params.get("RequestId")


class ScaleOutInstanceRequest(AbstractModel):
    r"""ScaleOutInstance请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceId: 实例唯一ID
        :type InstanceId: str
        :param _Type: 节点类型，DATA：clickhouse节点，COMMON：为zookeeper节点
        :type Type: str
        :param _NodeCount: 调整clickhouse节点数量
        :type NodeCount: int
        :param _ScaleOutCluster: v_cluster分组，	
新增扩容节点将加入到已选择的v_cluster分组中，提交同步VIP生效.
        :type ScaleOutCluster: str
        :param _UserSubnetIPNum: 子网剩余ip数量，用于判断当前实例子网剩余ip数是否能扩容。需要根据实际填写
        :type UserSubnetIPNum: int
        :param _ScaleOutNodeIp: 同步元数据节点IP （uip），扩容的时候必填
        :type ScaleOutNodeIp: str
        :param _ReduceShardInfo: 缩容节点shard的节点IP （uip），其中ha集群需要主副节点ip都传入以逗号分隔，缩容的时候必填
        :type ReduceShardInfo: list of str
        """
        self._InstanceId = None
        self._Type = None
        self._NodeCount = None
        self._ScaleOutCluster = None
        self._UserSubnetIPNum = None
        self._ScaleOutNodeIp = None
        self._ReduceShardInfo = None

    @property
    def InstanceId(self):
        r"""实例唯一ID
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId

    @property
    def Type(self):
        r"""节点类型，DATA：clickhouse节点，COMMON：为zookeeper节点
        :rtype: str
        """
        return self._Type

    @Type.setter
    def Type(self, Type):
        self._Type = Type

    @property
    def NodeCount(self):
        r"""调整clickhouse节点数量
        :rtype: int
        """
        return self._NodeCount

    @NodeCount.setter
    def NodeCount(self, NodeCount):
        self._NodeCount = NodeCount

    @property
    def ScaleOutCluster(self):
        r"""v_cluster分组，	
新增扩容节点将加入到已选择的v_cluster分组中，提交同步VIP生效.
        :rtype: str
        """
        return self._ScaleOutCluster

    @ScaleOutCluster.setter
    def ScaleOutCluster(self, ScaleOutCluster):
        self._ScaleOutCluster = ScaleOutCluster

    @property
    def UserSubnetIPNum(self):
        r"""子网剩余ip数量，用于判断当前实例子网剩余ip数是否能扩容。需要根据实际填写
        :rtype: int
        """
        return self._UserSubnetIPNum

    @UserSubnetIPNum.setter
    def UserSubnetIPNum(self, UserSubnetIPNum):
        self._UserSubnetIPNum = UserSubnetIPNum

    @property
    def ScaleOutNodeIp(self):
        r"""同步元数据节点IP （uip），扩容的时候必填
        :rtype: str
        """
        return self._ScaleOutNodeIp

    @ScaleOutNodeIp.setter
    def ScaleOutNodeIp(self, ScaleOutNodeIp):
        self._ScaleOutNodeIp = ScaleOutNodeIp

    @property
    def ReduceShardInfo(self):
        r"""缩容节点shard的节点IP （uip），其中ha集群需要主副节点ip都传入以逗号分隔，缩容的时候必填
        :rtype: list of str
        """
        return self._ReduceShardInfo

    @ReduceShardInfo.setter
    def ReduceShardInfo(self, ReduceShardInfo):
        self._ReduceShardInfo = ReduceShardInfo


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        self._Type = params.get("Type")
        self._NodeCount = params.get("NodeCount")
        self._ScaleOutCluster = params.get("ScaleOutCluster")
        self._UserSubnetIPNum = params.get("UserSubnetIPNum")
        self._ScaleOutNodeIp = params.get("ScaleOutNodeIp")
        self._ReduceShardInfo = params.get("ReduceShardInfo")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ScaleOutInstanceResponse(AbstractModel):
    r"""ScaleOutInstance返回参数结构体

    """

    def __init__(self):
        r"""
        :param _FlowId: 流程ID
        :type FlowId: str
        :param _InstanceId: 实例ID
        :type InstanceId: str
        :param _ErrorMsg: 错误信息
        :type ErrorMsg: str
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._FlowId = None
        self._InstanceId = None
        self._ErrorMsg = None
        self._RequestId = None

    @property
    def FlowId(self):
        r"""流程ID
        :rtype: str
        """
        return self._FlowId

    @FlowId.setter
    def FlowId(self, FlowId):
        self._FlowId = FlowId

    @property
    def InstanceId(self):
        r"""实例ID
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId

    @property
    def ErrorMsg(self):
        r"""错误信息
        :rtype: str
        """
        return self._ErrorMsg

    @ErrorMsg.setter
    def ErrorMsg(self, ErrorMsg):
        self._ErrorMsg = ErrorMsg

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._FlowId = params.get("FlowId")
        self._InstanceId = params.get("InstanceId")
        self._ErrorMsg = params.get("ErrorMsg")
        self._RequestId = params.get("RequestId")


class ScaleUpInstanceRequest(AbstractModel):
    r"""ScaleUpInstance请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceId: 实例唯一ID
        :type InstanceId: str
        :param _Type: 节点类型，DATA：clickhouse节点，COMMON：为zookeeper节点
        :type Type: str
        :param _SpecName: clickhouse节点规格。
        :type SpecName: str
        :param _ScaleUpEnableRolling: 是否滚动重启，false为不滚动重启，true为滚动重启
        :type ScaleUpEnableRolling: bool
        """
        self._InstanceId = None
        self._Type = None
        self._SpecName = None
        self._ScaleUpEnableRolling = None

    @property
    def InstanceId(self):
        r"""实例唯一ID
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId

    @property
    def Type(self):
        r"""节点类型，DATA：clickhouse节点，COMMON：为zookeeper节点
        :rtype: str
        """
        return self._Type

    @Type.setter
    def Type(self, Type):
        self._Type = Type

    @property
    def SpecName(self):
        r"""clickhouse节点规格。
        :rtype: str
        """
        return self._SpecName

    @SpecName.setter
    def SpecName(self, SpecName):
        self._SpecName = SpecName

    @property
    def ScaleUpEnableRolling(self):
        r"""是否滚动重启，false为不滚动重启，true为滚动重启
        :rtype: bool
        """
        return self._ScaleUpEnableRolling

    @ScaleUpEnableRolling.setter
    def ScaleUpEnableRolling(self, ScaleUpEnableRolling):
        self._ScaleUpEnableRolling = ScaleUpEnableRolling


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        self._Type = params.get("Type")
        self._SpecName = params.get("SpecName")
        self._ScaleUpEnableRolling = params.get("ScaleUpEnableRolling")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ScaleUpInstanceResponse(AbstractModel):
    r"""ScaleUpInstance返回参数结构体

    """

    def __init__(self):
        r"""
        :param _FlowId: 流程ID
        :type FlowId: str
        :param _InstanceId: 实例ID
        :type InstanceId: str
        :param _ErrorMsg: 错误信息
        :type ErrorMsg: str
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._FlowId = None
        self._InstanceId = None
        self._ErrorMsg = None
        self._RequestId = None

    @property
    def FlowId(self):
        r"""流程ID
        :rtype: str
        """
        return self._FlowId

    @FlowId.setter
    def FlowId(self, FlowId):
        self._FlowId = FlowId

    @property
    def InstanceId(self):
        r"""实例ID
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId

    @property
    def ErrorMsg(self):
        r"""错误信息
        :rtype: str
        """
        return self._ErrorMsg

    @ErrorMsg.setter
    def ErrorMsg(self, ErrorMsg):
        self._ErrorMsg = ErrorMsg

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._FlowId = params.get("FlowId")
        self._InstanceId = params.get("InstanceId")
        self._ErrorMsg = params.get("ErrorMsg")
        self._RequestId = params.get("RequestId")


class ScheduleStrategy(AbstractModel):
    r"""策略详情

    """

    def __init__(self):
        r"""
        :param _CosBucketName: 备份桶名称
        :type CosBucketName: str
        :param _RetainDays: 备份保留天数
        :type RetainDays: int
        :param _WeekDays: 备份的天
        :type WeekDays: str
        :param _ExecuteHour: 备份小时
        :type ExecuteHour: int
        :param _ScheduleId: 策略id
        :type ScheduleId: int
        :param _NextBackupTime: 下次备份时间
        :type NextBackupTime: str
        """
        self._CosBucketName = None
        self._RetainDays = None
        self._WeekDays = None
        self._ExecuteHour = None
        self._ScheduleId = None
        self._NextBackupTime = None

    @property
    def CosBucketName(self):
        r"""备份桶名称
        :rtype: str
        """
        return self._CosBucketName

    @CosBucketName.setter
    def CosBucketName(self, CosBucketName):
        self._CosBucketName = CosBucketName

    @property
    def RetainDays(self):
        r"""备份保留天数
        :rtype: int
        """
        return self._RetainDays

    @RetainDays.setter
    def RetainDays(self, RetainDays):
        self._RetainDays = RetainDays

    @property
    def WeekDays(self):
        r"""备份的天
        :rtype: str
        """
        return self._WeekDays

    @WeekDays.setter
    def WeekDays(self, WeekDays):
        self._WeekDays = WeekDays

    @property
    def ExecuteHour(self):
        r"""备份小时
        :rtype: int
        """
        return self._ExecuteHour

    @ExecuteHour.setter
    def ExecuteHour(self, ExecuteHour):
        self._ExecuteHour = ExecuteHour

    @property
    def ScheduleId(self):
        r"""策略id
        :rtype: int
        """
        return self._ScheduleId

    @ScheduleId.setter
    def ScheduleId(self, ScheduleId):
        self._ScheduleId = ScheduleId

    @property
    def NextBackupTime(self):
        r"""下次备份时间
        :rtype: str
        """
        return self._NextBackupTime

    @NextBackupTime.setter
    def NextBackupTime(self, NextBackupTime):
        self._NextBackupTime = NextBackupTime


    def _deserialize(self, params):
        self._CosBucketName = params.get("CosBucketName")
        self._RetainDays = params.get("RetainDays")
        self._WeekDays = params.get("WeekDays")
        self._ExecuteHour = params.get("ExecuteHour")
        self._ScheduleId = params.get("ScheduleId")
        self._NextBackupTime = params.get("NextBackupTime")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class SearchTags(AbstractModel):
    r"""列表页搜索的标记列表

    """

    def __init__(self):
        r"""
        :param _TagKey: 标签的键
        :type TagKey: str
        :param _TagValue: 标签的值
        :type TagValue: str
        :param _AllValue: 1表示只输入标签的键，没有输入值；0表示输入键时且输入值
        :type AllValue: int
        """
        self._TagKey = None
        self._TagValue = None
        self._AllValue = None

    @property
    def TagKey(self):
        r"""标签的键
        :rtype: str
        """
        return self._TagKey

    @TagKey.setter
    def TagKey(self, TagKey):
        self._TagKey = TagKey

    @property
    def TagValue(self):
        r"""标签的值
        :rtype: str
        """
        return self._TagValue

    @TagValue.setter
    def TagValue(self, TagValue):
        self._TagValue = TagValue

    @property
    def AllValue(self):
        r"""1表示只输入标签的键，没有输入值；0表示输入键时且输入值
        :rtype: int
        """
        return self._AllValue

    @AllValue.setter
    def AllValue(self, AllValue):
        self._AllValue = AllValue


    def _deserialize(self, params):
        self._TagKey = params.get("TagKey")
        self._TagValue = params.get("TagValue")
        self._AllValue = params.get("AllValue")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class SecondaryZoneInfo(AbstractModel):
    r"""副可用区详情

    """

    def __init__(self):
        r"""
        :param _SecondaryZone: 副可用区
        :type SecondaryZone: str
        :param _SecondarySubnet: 可用区可用的子网id
        :type SecondarySubnet: str
        :param _UserIpNum: 可用区可用的子网可用ip的数量
        :type UserIpNum: str
        :param _SecondaryUserSubnetIPNum: 可用区可用的子网可用ip的数量
        :type SecondaryUserSubnetIPNum: int
        """
        self._SecondaryZone = None
        self._SecondarySubnet = None
        self._UserIpNum = None
        self._SecondaryUserSubnetIPNum = None

    @property
    def SecondaryZone(self):
        r"""副可用区
        :rtype: str
        """
        return self._SecondaryZone

    @SecondaryZone.setter
    def SecondaryZone(self, SecondaryZone):
        self._SecondaryZone = SecondaryZone

    @property
    def SecondarySubnet(self):
        r"""可用区可用的子网id
        :rtype: str
        """
        return self._SecondarySubnet

    @SecondarySubnet.setter
    def SecondarySubnet(self, SecondarySubnet):
        self._SecondarySubnet = SecondarySubnet

    @property
    def UserIpNum(self):
        r"""可用区可用的子网可用ip的数量
        :rtype: str
        """
        return self._UserIpNum

    @UserIpNum.setter
    def UserIpNum(self, UserIpNum):
        self._UserIpNum = UserIpNum

    @property
    def SecondaryUserSubnetIPNum(self):
        r"""可用区可用的子网可用ip的数量
        :rtype: int
        """
        return self._SecondaryUserSubnetIPNum

    @SecondaryUserSubnetIPNum.setter
    def SecondaryUserSubnetIPNum(self, SecondaryUserSubnetIPNum):
        self._SecondaryUserSubnetIPNum = SecondaryUserSubnetIPNum


    def _deserialize(self, params):
        self._SecondaryZone = params.get("SecondaryZone")
        self._SecondarySubnet = params.get("SecondarySubnet")
        self._UserIpNum = params.get("UserIpNum")
        self._SecondaryUserSubnetIPNum = params.get("SecondaryUserSubnetIPNum")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ServiceInfo(AbstractModel):
    r"""服务详细信息描述。

    """

    def __init__(self):
        r"""
        :param _Name: 服务名称
        :type Name: str
        :param _Version: 服务的版本
        :type Version: str
        """
        self._Name = None
        self._Version = None

    @property
    def Name(self):
        r"""服务名称
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def Version(self):
        r"""服务的版本
        :rtype: str
        """
        return self._Version

    @Version.setter
    def Version(self, Version):
        self._Version = Version


    def _deserialize(self, params):
        self._Name = params.get("Name")
        self._Version = params.get("Version")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class TablePrivilegeInfo(AbstractModel):
    r"""表权限

    """

    def __init__(self):
        r"""
        :param _TableName: 表名称
        :type TableName: str
        :param _TablePrivileges: 表权限列表 SELECT、INSERT_ALL、ALTER、TRUNCATE、DROP_TABLE 查询、插入、设置、清空表、删除表
        :type TablePrivileges: list of str
        """
        self._TableName = None
        self._TablePrivileges = None

    @property
    def TableName(self):
        r"""表名称
        :rtype: str
        """
        return self._TableName

    @TableName.setter
    def TableName(self, TableName):
        self._TableName = TableName

    @property
    def TablePrivileges(self):
        r"""表权限列表 SELECT、INSERT_ALL、ALTER、TRUNCATE、DROP_TABLE 查询、插入、设置、清空表、删除表
        :rtype: list of str
        """
        return self._TablePrivileges

    @TablePrivileges.setter
    def TablePrivileges(self, TablePrivileges):
        self._TablePrivileges = TablePrivileges


    def _deserialize(self, params):
        self._TableName = params.get("TableName")
        self._TablePrivileges = params.get("TablePrivileges")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class Tag(AbstractModel):
    r"""标签描述

    """

    def __init__(self):
        r"""
        :param _TagKey: 标签的键
        :type TagKey: str
        :param _TagValue: 标签的值
        :type TagValue: str
        """
        self._TagKey = None
        self._TagValue = None

    @property
    def TagKey(self):
        r"""标签的键
        :rtype: str
        """
        return self._TagKey

    @TagKey.setter
    def TagKey(self, TagKey):
        self._TagKey = TagKey

    @property
    def TagValue(self):
        r"""标签的值
        :rtype: str
        """
        return self._TagValue

    @TagValue.setter
    def TagValue(self, TagValue):
        self._TagValue = TagValue


    def _deserialize(self, params):
        self._TagKey = params.get("TagKey")
        self._TagValue = params.get("TagValue")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        