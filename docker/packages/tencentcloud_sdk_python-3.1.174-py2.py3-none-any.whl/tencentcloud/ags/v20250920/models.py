# -*- coding: utf8 -*-
# Copyright (c) 2017-2025 Tencent. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import warnings

from tencentcloud.common.abstract_model import AbstractModel


class APIKeyInfo(AbstractModel):
    r"""API密钥简略信息

    """

    def __init__(self):
        r"""
        :param _Name: API密钥名称
        :type Name: str
        :param _KeyId: API密钥ID
        :type KeyId: str
        :param _Status: 密钥状态。可以为API_KEY_STATUS_ACTIVE，或API_KEY_STATUS_INACTIVE
        :type Status: str
        :param _MaskedKey: 隐藏部分字符的API密钥，方便用户辨认
        :type MaskedKey: str
        :param _CreatedAt: API密钥创建时间
        :type CreatedAt: str
        """
        self._Name = None
        self._KeyId = None
        self._Status = None
        self._MaskedKey = None
        self._CreatedAt = None

    @property
    def Name(self):
        r"""API密钥名称
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def KeyId(self):
        r"""API密钥ID
        :rtype: str
        """
        return self._KeyId

    @KeyId.setter
    def KeyId(self, KeyId):
        self._KeyId = KeyId

    @property
    def Status(self):
        r"""密钥状态。可以为API_KEY_STATUS_ACTIVE，或API_KEY_STATUS_INACTIVE
        :rtype: str
        """
        return self._Status

    @Status.setter
    def Status(self, Status):
        self._Status = Status

    @property
    def MaskedKey(self):
        r"""隐藏部分字符的API密钥，方便用户辨认
        :rtype: str
        """
        return self._MaskedKey

    @MaskedKey.setter
    def MaskedKey(self, MaskedKey):
        self._MaskedKey = MaskedKey

    @property
    def CreatedAt(self):
        r"""API密钥创建时间
        :rtype: str
        """
        return self._CreatedAt

    @CreatedAt.setter
    def CreatedAt(self, CreatedAt):
        self._CreatedAt = CreatedAt


    def _deserialize(self, params):
        self._Name = params.get("Name")
        self._KeyId = params.get("KeyId")
        self._Status = params.get("Status")
        self._MaskedKey = params.get("MaskedKey")
        self._CreatedAt = params.get("CreatedAt")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class AcquireDeploymentTokenRequest(AbstractModel):
    r"""AcquireDeploymentToken请求参数结构体

    """

    def __init__(self):
        r"""
        :param _DeploymentId: <p>目标 ACTIVE Deployment 的稳定 ID。</p>
        :type DeploymentId: str
        """
        self._DeploymentId = None

    @property
    def DeploymentId(self):
        r"""<p>目标 ACTIVE Deployment 的稳定 ID。</p>
        :rtype: str
        """
        return self._DeploymentId

    @DeploymentId.setter
    def DeploymentId(self, DeploymentId):
        self._DeploymentId = DeploymentId


    def _deserialize(self, params):
        self._DeploymentId = params.get("DeploymentId")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class AcquireDeploymentTokenResponse(AbstractModel):
    r"""AcquireDeploymentToken返回参数结构体

    """

    def __init__(self):
        r"""
        :param _Token: <p>只用于目标 Deployment 数据面入口的短期 bearer Token，格式为 dpt_ 加非空、无 padding 的 Base64URL opaque 后缀。</p>
        :type Token: str
        :param _ExpiresAt: <p>Token 的绝对过期时间，UTC、秒精度 RFC3339 格式。</p>
        :type ExpiresAt: str
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._Token = None
        self._ExpiresAt = None
        self._RequestId = None

    @property
    def Token(self):
        r"""<p>只用于目标 Deployment 数据面入口的短期 bearer Token，格式为 dpt_ 加非空、无 padding 的 Base64URL opaque 后缀。</p>
        :rtype: str
        """
        return self._Token

    @Token.setter
    def Token(self, Token):
        self._Token = Token

    @property
    def ExpiresAt(self):
        r"""<p>Token 的绝对过期时间，UTC、秒精度 RFC3339 格式。</p>
        :rtype: str
        """
        return self._ExpiresAt

    @ExpiresAt.setter
    def ExpiresAt(self, ExpiresAt):
        self._ExpiresAt = ExpiresAt

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._Token = params.get("Token")
        self._ExpiresAt = params.get("ExpiresAt")
        self._RequestId = params.get("RequestId")


class AcquireSandboxInstanceTokenRequest(AbstractModel):
    r"""AcquireSandboxInstanceToken请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceId: <p>沙箱实例ID，生成的访问Token将仅可用于访问此沙箱实例</p>
        :type InstanceId: str
        """
        self._InstanceId = None

    @property
    def InstanceId(self):
        r"""<p>沙箱实例ID，生成的访问Token将仅可用于访问此沙箱实例</p>
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class AcquireSandboxInstanceTokenResponse(AbstractModel):
    r"""AcquireSandboxInstanceToken返回参数结构体

    """

    def __init__(self):
        r"""
        :param _Token: <p>访问Token</p>
        :type Token: str
        :param _ExpiresAt: <p>过期时间</p>
        :type ExpiresAt: str
        :param _TrafficToken: <p>非管控面（envd）的访问Token</p>
        :type TrafficToken: str
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._Token = None
        self._ExpiresAt = None
        self._TrafficToken = None
        self._RequestId = None

    @property
    def Token(self):
        r"""<p>访问Token</p>
        :rtype: str
        """
        return self._Token

    @Token.setter
    def Token(self, Token):
        self._Token = Token

    @property
    def ExpiresAt(self):
        r"""<p>过期时间</p>
        :rtype: str
        """
        return self._ExpiresAt

    @ExpiresAt.setter
    def ExpiresAt(self, ExpiresAt):
        self._ExpiresAt = ExpiresAt

    @property
    def TrafficToken(self):
        r"""<p>非管控面（envd）的访问Token</p>
        :rtype: str
        """
        return self._TrafficToken

    @TrafficToken.setter
    def TrafficToken(self, TrafficToken):
        self._TrafficToken = TrafficToken

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._Token = params.get("Token")
        self._ExpiresAt = params.get("ExpiresAt")
        self._TrafficToken = params.get("TrafficToken")
        self._RequestId = params.get("RequestId")


class AffinityConfiguration(AbstractModel):
    r"""Deployment 对 Sandbox Instance 的亲和配置。

    """

    def __init__(self):
        r"""
        :param _Mode: <p>Affinity 模式。</p><p>枚举值：</p><ul><li>BEST_EFFORT：优先复用原 Instance，不可用时允许改选。</li><li>STRICT：只复用原 Instance，不可用时失败且不改选。</li><li>EXCLUSIVE：一个 Affinity ID 独占一个 Instance，不能迁移。</li></ul><p>缺失或空字符串表示关闭 Affinity。</p>
        :type Mode: str
        :param _HeaderName: <p>请求和响应使用的 Affinity Header 名称。必须符合 HTTP field-name token 语法，长度为 1..128 个 ASCII 字节，且不能使用平台保留 Header。</p>
        :type HeaderName: str
        """
        self._Mode = None
        self._HeaderName = None

    @property
    def Mode(self):
        r"""<p>Affinity 模式。</p><p>枚举值：</p><ul><li>BEST_EFFORT：优先复用原 Instance，不可用时允许改选。</li><li>STRICT：只复用原 Instance，不可用时失败且不改选。</li><li>EXCLUSIVE：一个 Affinity ID 独占一个 Instance，不能迁移。</li></ul><p>缺失或空字符串表示关闭 Affinity。</p>
        :rtype: str
        """
        return self._Mode

    @Mode.setter
    def Mode(self, Mode):
        self._Mode = Mode

    @property
    def HeaderName(self):
        r"""<p>请求和响应使用的 Affinity Header 名称。必须符合 HTTP field-name token 语法，长度为 1..128 个 ASCII 字节，且不能使用平台保留 Header。</p>
        :rtype: str
        """
        return self._HeaderName

    @HeaderName.setter
    def HeaderName(self, HeaderName):
        self._HeaderName = HeaderName


    def _deserialize(self, params):
        self._Mode = params.get("Mode")
        self._HeaderName = params.get("HeaderName")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class AgentBucketStorageSource(AbstractModel):
    r"""用于记录 Agent Bucket 的 Storage Source

    """

    def __init__(self):
        r"""
        :param _LibraryId: <p>用于传入 AgentBucket 的 LibraryID</p>
        :type LibraryId: str
        :param _SpaceId: <p>用于传入 AgentBucket 的 spaceId</p>
        :type SpaceId: str
        :param _AccessDomain: <p>用于传入 AgentBucket 的 AccessDomain</p>
        :type AccessDomain: str
        """
        self._LibraryId = None
        self._SpaceId = None
        self._AccessDomain = None

    @property
    def LibraryId(self):
        r"""<p>用于传入 AgentBucket 的 LibraryID</p>
        :rtype: str
        """
        return self._LibraryId

    @LibraryId.setter
    def LibraryId(self, LibraryId):
        self._LibraryId = LibraryId

    @property
    def SpaceId(self):
        r"""<p>用于传入 AgentBucket 的 spaceId</p>
        :rtype: str
        """
        return self._SpaceId

    @SpaceId.setter
    def SpaceId(self, SpaceId):
        self._SpaceId = SpaceId

    @property
    def AccessDomain(self):
        r"""<p>用于传入 AgentBucket 的 AccessDomain</p>
        :rtype: str
        """
        return self._AccessDomain

    @AccessDomain.setter
    def AccessDomain(self, AccessDomain):
        self._AccessDomain = AccessDomain


    def _deserialize(self, params):
        self._LibraryId = params.get("LibraryId")
        self._SpaceId = params.get("SpaceId")
        self._AccessDomain = params.get("AccessDomain")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class CLSConfig(AbstractModel):
    r"""沙箱工具日志推送CLS相关配置

    """

    def __init__(self):
        r"""
        :param _TopicId: 沙箱工具日志推送所使用的CLS日志主题ID
        :type TopicId: str
        """
        self._TopicId = None

    @property
    def TopicId(self):
        r"""沙箱工具日志推送所使用的CLS日志主题ID
        :rtype: str
        """
        return self._TopicId

    @TopicId.setter
    def TopicId(self, TopicId):
        self._TopicId = TopicId


    def _deserialize(self, params):
        self._TopicId = params.get("TopicId")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class CfsStorageSource(AbstractModel):
    r"""文件存储配置

    """

    def __init__(self):
        r"""
        :param _FileSystemId: CFS资源ID
        :type FileSystemId: str
        :param _Path: CFS挂载路径
        :type Path: str
        """
        self._FileSystemId = None
        self._Path = None

    @property
    def FileSystemId(self):
        r"""CFS资源ID
        :rtype: str
        """
        return self._FileSystemId

    @FileSystemId.setter
    def FileSystemId(self, FileSystemId):
        self._FileSystemId = FileSystemId

    @property
    def Path(self):
        r"""CFS挂载路径
        :rtype: str
        """
        return self._Path

    @Path.setter
    def Path(self, Path):
        self._Path = Path


    def _deserialize(self, params):
        self._FileSystemId = params.get("FileSystemId")
        self._Path = params.get("Path")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ComputerConfiguration(AbstractModel):
    r"""桌面电脑环境类沙箱配置

    """

    def __init__(self):
        r"""
        :param _WAAConfiguration: <p>waa沙箱工具配置</p>
        :type WAAConfiguration: :class:`tencentcloud.ags.v20250920.models.WAAConfiguration`
        :param _OSWorldConfiguration: <p>配置内置 OSWorld</p>
        :type OSWorldConfiguration: :class:`tencentcloud.ags.v20250920.models.OSWorldConfiguration`
        """
        self._WAAConfiguration = None
        self._OSWorldConfiguration = None

    @property
    def WAAConfiguration(self):
        r"""<p>waa沙箱工具配置</p>
        :rtype: :class:`tencentcloud.ags.v20250920.models.WAAConfiguration`
        """
        return self._WAAConfiguration

    @WAAConfiguration.setter
    def WAAConfiguration(self, WAAConfiguration):
        self._WAAConfiguration = WAAConfiguration

    @property
    def OSWorldConfiguration(self):
        r"""<p>配置内置 OSWorld</p>
        :rtype: :class:`tencentcloud.ags.v20250920.models.OSWorldConfiguration`
        """
        return self._OSWorldConfiguration

    @OSWorldConfiguration.setter
    def OSWorldConfiguration(self, OSWorldConfiguration):
        self._OSWorldConfiguration = OSWorldConfiguration


    def _deserialize(self, params):
        if params.get("WAAConfiguration") is not None:
            self._WAAConfiguration = WAAConfiguration()
            self._WAAConfiguration._deserialize(params.get("WAAConfiguration"))
        if params.get("OSWorldConfiguration") is not None:
            self._OSWorldConfiguration = OSWorldConfiguration()
            self._OSWorldConfiguration._deserialize(params.get("OSWorldConfiguration"))
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class CosStorageSource(AbstractModel):
    r"""沙箱实例对象存储挂载配置

    """

    def __init__(self):
        r"""
        :param _Endpoint: 对象存储访问域名
        :type Endpoint: str
        :param _BucketName: 对象存储桶名称
        :type BucketName: str
        :param _BucketPath: 对象存储桶路径，必须为以/起始的绝对路径
        :type BucketPath: str
        """
        self._Endpoint = None
        self._BucketName = None
        self._BucketPath = None

    @property
    def Endpoint(self):
        r"""对象存储访问域名
        :rtype: str
        """
        return self._Endpoint

    @Endpoint.setter
    def Endpoint(self, Endpoint):
        self._Endpoint = Endpoint

    @property
    def BucketName(self):
        r"""对象存储桶名称
        :rtype: str
        """
        return self._BucketName

    @BucketName.setter
    def BucketName(self, BucketName):
        self._BucketName = BucketName

    @property
    def BucketPath(self):
        r"""对象存储桶路径，必须为以/起始的绝对路径
        :rtype: str
        """
        return self._BucketPath

    @BucketPath.setter
    def BucketPath(self, BucketPath):
        self._BucketPath = BucketPath


    def _deserialize(self, params):
        self._Endpoint = params.get("Endpoint")
        self._BucketName = params.get("BucketName")
        self._BucketPath = params.get("BucketPath")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class CreateAPIKeyRequest(AbstractModel):
    r"""CreateAPIKey请求参数结构体

    """

    def __init__(self):
        r"""
        :param _Name: API密钥名称，方便用户记忆
        :type Name: str
        """
        self._Name = None

    @property
    def Name(self):
        r"""API密钥名称，方便用户记忆
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name


    def _deserialize(self, params):
        self._Name = params.get("Name")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class CreateAPIKeyResponse(AbstractModel):
    r"""CreateAPIKey返回参数结构体

    """

    def __init__(self):
        r"""
        :param _Name: 用户传入的API密钥名称，方便用户记忆
        :type Name: str
        :param _APIKey: 生成的API密钥，仅返回此一次，后续无法获取
        :type APIKey: str
        :param _KeyId: API密钥ID
        :type KeyId: str
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._Name = None
        self._APIKey = None
        self._KeyId = None
        self._RequestId = None

    @property
    def Name(self):
        r"""用户传入的API密钥名称，方便用户记忆
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def APIKey(self):
        r"""生成的API密钥，仅返回此一次，后续无法获取
        :rtype: str
        """
        return self._APIKey

    @APIKey.setter
    def APIKey(self, APIKey):
        self._APIKey = APIKey

    @property
    def KeyId(self):
        r"""API密钥ID
        :rtype: str
        """
        return self._KeyId

    @KeyId.setter
    def KeyId(self, KeyId):
        self._KeyId = KeyId

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._Name = params.get("Name")
        self._APIKey = params.get("APIKey")
        self._KeyId = params.get("KeyId")
        self._RequestId = params.get("RequestId")


class CreateDeploymentRequest(AbstractModel):
    r"""CreateDeployment请求参数结构体

    """

    def __init__(self):
        r"""
        :param _DeploymentName: <p>唯一的 Deployment 名称，必须符合 DNS-1123 命名规范，创建后不可修改。</p>
        :type DeploymentName: str
        :param _ToolId: <p>用于关联 Sandbox Tool 的标识，格式为 sdt- 加 8 位小写 base36 字符。</p>
        :type ToolId: str
        :param _ScalingConfiguration: <p>伸缩配置；省略的成员由服务端补全默认值。</p>
        :type ScalingConfiguration: :class:`tencentcloud.ags.v20250920.models.ScalingConfiguration`
        :param _LifecycleConfiguration: <p>空闲生命周期配置；省略的成员由服务端补全默认值。</p>
        :type LifecycleConfiguration: :class:`tencentcloud.ags.v20250920.models.LifecycleConfiguration`
        :param _AffinityConfiguration: <p>Affinity 配置；省略或空 Mode 表示不启用。</p>
        :type AffinityConfiguration: :class:`tencentcloud.ags.v20250920.models.AffinityConfiguration`
        :param _Tags: <p>标签</p>
        :type Tags: list of Tag
        """
        self._DeploymentName = None
        self._ToolId = None
        self._ScalingConfiguration = None
        self._LifecycleConfiguration = None
        self._AffinityConfiguration = None
        self._Tags = None

    @property
    def DeploymentName(self):
        r"""<p>唯一的 Deployment 名称，必须符合 DNS-1123 命名规范，创建后不可修改。</p>
        :rtype: str
        """
        return self._DeploymentName

    @DeploymentName.setter
    def DeploymentName(self, DeploymentName):
        self._DeploymentName = DeploymentName

    @property
    def ToolId(self):
        r"""<p>用于关联 Sandbox Tool 的标识，格式为 sdt- 加 8 位小写 base36 字符。</p>
        :rtype: str
        """
        return self._ToolId

    @ToolId.setter
    def ToolId(self, ToolId):
        self._ToolId = ToolId

    @property
    def ScalingConfiguration(self):
        r"""<p>伸缩配置；省略的成员由服务端补全默认值。</p>
        :rtype: :class:`tencentcloud.ags.v20250920.models.ScalingConfiguration`
        """
        return self._ScalingConfiguration

    @ScalingConfiguration.setter
    def ScalingConfiguration(self, ScalingConfiguration):
        self._ScalingConfiguration = ScalingConfiguration

    @property
    def LifecycleConfiguration(self):
        r"""<p>空闲生命周期配置；省略的成员由服务端补全默认值。</p>
        :rtype: :class:`tencentcloud.ags.v20250920.models.LifecycleConfiguration`
        """
        return self._LifecycleConfiguration

    @LifecycleConfiguration.setter
    def LifecycleConfiguration(self, LifecycleConfiguration):
        self._LifecycleConfiguration = LifecycleConfiguration

    @property
    def AffinityConfiguration(self):
        r"""<p>Affinity 配置；省略或空 Mode 表示不启用。</p>
        :rtype: :class:`tencentcloud.ags.v20250920.models.AffinityConfiguration`
        """
        return self._AffinityConfiguration

    @AffinityConfiguration.setter
    def AffinityConfiguration(self, AffinityConfiguration):
        self._AffinityConfiguration = AffinityConfiguration

    @property
    def Tags(self):
        r"""<p>标签</p>
        :rtype: list of Tag
        """
        return self._Tags

    @Tags.setter
    def Tags(self, Tags):
        self._Tags = Tags


    def _deserialize(self, params):
        self._DeploymentName = params.get("DeploymentName")
        self._ToolId = params.get("ToolId")
        if params.get("ScalingConfiguration") is not None:
            self._ScalingConfiguration = ScalingConfiguration()
            self._ScalingConfiguration._deserialize(params.get("ScalingConfiguration"))
        if params.get("LifecycleConfiguration") is not None:
            self._LifecycleConfiguration = LifecycleConfiguration()
            self._LifecycleConfiguration._deserialize(params.get("LifecycleConfiguration"))
        if params.get("AffinityConfiguration") is not None:
            self._AffinityConfiguration = AffinityConfiguration()
            self._AffinityConfiguration._deserialize(params.get("AffinityConfiguration"))
        if params.get("Tags") is not None:
            self._Tags = []
            for item in params.get("Tags"):
                obj = Tag()
                obj._deserialize(item)
                self._Tags.append(obj)
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class CreateDeploymentResponse(AbstractModel):
    r"""CreateDeployment返回参数结构体

    """

    def __init__(self):
        r"""
        :param _Deployment: <p>已创建并完成默认值物化的 Deployment。</p>
        :type Deployment: :class:`tencentcloud.ags.v20250920.models.Deployment`
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._Deployment = None
        self._RequestId = None

    @property
    def Deployment(self):
        r"""<p>已创建并完成默认值物化的 Deployment。</p>
        :rtype: :class:`tencentcloud.ags.v20250920.models.Deployment`
        """
        return self._Deployment

    @Deployment.setter
    def Deployment(self, Deployment):
        self._Deployment = Deployment

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("Deployment") is not None:
            self._Deployment = Deployment()
            self._Deployment._deserialize(params.get("Deployment"))
        self._RequestId = params.get("RequestId")


class CreatePreCacheImageTaskRequest(AbstractModel):
    r"""CreatePreCacheImageTask请求参数结构体

    """

    def __init__(self):
        r"""
        :param _Image: <p>镜像地址</p>
        :type Image: str
        :param _ImageRegistryType: <p>镜像仓库类型：<code>enterprise</code>、<code>personal</code>、<code>custom</code></p><p>枚举值：</p><ul><li>enterprise： tcr 企业容器镜像服务</li><li>personal： ccr 个人容器镜像服务</li></ul>
        :type ImageRegistryType: str
        """
        self._Image = None
        self._ImageRegistryType = None

    @property
    def Image(self):
        r"""<p>镜像地址</p>
        :rtype: str
        """
        return self._Image

    @Image.setter
    def Image(self, Image):
        self._Image = Image

    @property
    def ImageRegistryType(self):
        r"""<p>镜像仓库类型：<code>enterprise</code>、<code>personal</code>、<code>custom</code></p><p>枚举值：</p><ul><li>enterprise： tcr 企业容器镜像服务</li><li>personal： ccr 个人容器镜像服务</li></ul>
        :rtype: str
        """
        return self._ImageRegistryType

    @ImageRegistryType.setter
    def ImageRegistryType(self, ImageRegistryType):
        self._ImageRegistryType = ImageRegistryType


    def _deserialize(self, params):
        self._Image = params.get("Image")
        self._ImageRegistryType = params.get("ImageRegistryType")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class CreatePreCacheImageTaskResponse(AbstractModel):
    r"""CreatePreCacheImageTask返回参数结构体

    """

    def __init__(self):
        r"""
        :param _Image: <p>镜像地址</p>
        :type Image: str
        :param _ImageDigest: <p>镜像 Digest</p>
        :type ImageDigest: str
        :param _ImageRegistryType: <p>镜像仓库类型：<code>enterprise</code>、<code>personal</code>。</p>
        :type ImageRegistryType: str
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._Image = None
        self._ImageDigest = None
        self._ImageRegistryType = None
        self._RequestId = None

    @property
    def Image(self):
        r"""<p>镜像地址</p>
        :rtype: str
        """
        return self._Image

    @Image.setter
    def Image(self, Image):
        self._Image = Image

    @property
    def ImageDigest(self):
        r"""<p>镜像 Digest</p>
        :rtype: str
        """
        return self._ImageDigest

    @ImageDigest.setter
    def ImageDigest(self, ImageDigest):
        self._ImageDigest = ImageDigest

    @property
    def ImageRegistryType(self):
        r"""<p>镜像仓库类型：<code>enterprise</code>、<code>personal</code>。</p>
        :rtype: str
        """
        return self._ImageRegistryType

    @ImageRegistryType.setter
    def ImageRegistryType(self, ImageRegistryType):
        self._ImageRegistryType = ImageRegistryType

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._Image = params.get("Image")
        self._ImageDigest = params.get("ImageDigest")
        self._ImageRegistryType = params.get("ImageRegistryType")
        self._RequestId = params.get("RequestId")


class CreateSandboxToolRequest(AbstractModel):
    r"""CreateSandboxTool请求参数结构体

    """

    def __init__(self):
        r"""
        :param _ToolName: <p>沙箱工具名称，长度 1-50 字符，支持英文、数字、下划线和连接线。同一 AppId 下沙箱工具名称必须唯一</p>
        :type ToolName: str
        :param _ToolType: <p>沙箱工具类型，目前支持：browser、code-interpreter、custom等</p><p>枚举值：</p><ul><li>browser： browser</li><li>code-interpreter： code-interpreter</li><li>mobile： mobile</li><li>osworld： osworld</li><li>custom： custom</li><li>swebench： swebench</li><li>aio： aio</li><li>android-world： android-world</li><li>waa： waa</li></ul>
        :type ToolType: str
        :param _NetworkConfiguration: <p>网络配置</p>
        :type NetworkConfiguration: :class:`tencentcloud.ags.v20250920.models.NetworkConfiguration`
        :param _Description: <p>沙箱工具描述，最大长度 200 字符</p>
        :type Description: str
        :param _DefaultTimeout: <p>默认超时时间，支持格式：5m、300s、1h 等，不指定则使用系统默认值（5 分钟）。最大 24 小时</p>
        :type DefaultTimeout: str
        :param _Tags: <p>标签规格，为沙箱工具绑定标签，支持多种资源类型的标签绑定</p>
        :type Tags: list of Tag
        :param _ClientToken: <p>幂等性 Token，长度不超过 64 字符</p>
        :type ClientToken: str
        :param _RoleArn: <p>角色ARN</p>
        :type RoleArn: str
        :param _StorageMounts: <p>沙箱工具存储配置</p>
        :type StorageMounts: list of StorageMount
        :param _CustomConfiguration: <p>沙箱工具自定义配置</p>
        :type CustomConfiguration: :class:`tencentcloud.ags.v20250920.models.CustomConfiguration`
        :param _ComputerConfiguration: <p>桌面电脑环境类沙箱配置</p>
        :type ComputerConfiguration: :class:`tencentcloud.ags.v20250920.models.ComputerConfiguration`
        :param _LogConfiguration: <p>沙箱工具日志推送相关配置</p>
        :type LogConfiguration: :class:`tencentcloud.ags.v20250920.models.LogConfiguration`
        :param _Persistent: <p>常驻沙箱标识</p>
        :type Persistent: bool
        """
        self._ToolName = None
        self._ToolType = None
        self._NetworkConfiguration = None
        self._Description = None
        self._DefaultTimeout = None
        self._Tags = None
        self._ClientToken = None
        self._RoleArn = None
        self._StorageMounts = None
        self._CustomConfiguration = None
        self._ComputerConfiguration = None
        self._LogConfiguration = None
        self._Persistent = None

    @property
    def ToolName(self):
        r"""<p>沙箱工具名称，长度 1-50 字符，支持英文、数字、下划线和连接线。同一 AppId 下沙箱工具名称必须唯一</p>
        :rtype: str
        """
        return self._ToolName

    @ToolName.setter
    def ToolName(self, ToolName):
        self._ToolName = ToolName

    @property
    def ToolType(self):
        r"""<p>沙箱工具类型，目前支持：browser、code-interpreter、custom等</p><p>枚举值：</p><ul><li>browser： browser</li><li>code-interpreter： code-interpreter</li><li>mobile： mobile</li><li>osworld： osworld</li><li>custom： custom</li><li>swebench： swebench</li><li>aio： aio</li><li>android-world： android-world</li><li>waa： waa</li></ul>
        :rtype: str
        """
        return self._ToolType

    @ToolType.setter
    def ToolType(self, ToolType):
        self._ToolType = ToolType

    @property
    def NetworkConfiguration(self):
        r"""<p>网络配置</p>
        :rtype: :class:`tencentcloud.ags.v20250920.models.NetworkConfiguration`
        """
        return self._NetworkConfiguration

    @NetworkConfiguration.setter
    def NetworkConfiguration(self, NetworkConfiguration):
        self._NetworkConfiguration = NetworkConfiguration

    @property
    def Description(self):
        r"""<p>沙箱工具描述，最大长度 200 字符</p>
        :rtype: str
        """
        return self._Description

    @Description.setter
    def Description(self, Description):
        self._Description = Description

    @property
    def DefaultTimeout(self):
        r"""<p>默认超时时间，支持格式：5m、300s、1h 等，不指定则使用系统默认值（5 分钟）。最大 24 小时</p>
        :rtype: str
        """
        return self._DefaultTimeout

    @DefaultTimeout.setter
    def DefaultTimeout(self, DefaultTimeout):
        self._DefaultTimeout = DefaultTimeout

    @property
    def Tags(self):
        r"""<p>标签规格，为沙箱工具绑定标签，支持多种资源类型的标签绑定</p>
        :rtype: list of Tag
        """
        return self._Tags

    @Tags.setter
    def Tags(self, Tags):
        self._Tags = Tags

    @property
    def ClientToken(self):
        r"""<p>幂等性 Token，长度不超过 64 字符</p>
        :rtype: str
        """
        return self._ClientToken

    @ClientToken.setter
    def ClientToken(self, ClientToken):
        self._ClientToken = ClientToken

    @property
    def RoleArn(self):
        r"""<p>角色ARN</p>
        :rtype: str
        """
        return self._RoleArn

    @RoleArn.setter
    def RoleArn(self, RoleArn):
        self._RoleArn = RoleArn

    @property
    def StorageMounts(self):
        r"""<p>沙箱工具存储配置</p>
        :rtype: list of StorageMount
        """
        return self._StorageMounts

    @StorageMounts.setter
    def StorageMounts(self, StorageMounts):
        self._StorageMounts = StorageMounts

    @property
    def CustomConfiguration(self):
        r"""<p>沙箱工具自定义配置</p>
        :rtype: :class:`tencentcloud.ags.v20250920.models.CustomConfiguration`
        """
        return self._CustomConfiguration

    @CustomConfiguration.setter
    def CustomConfiguration(self, CustomConfiguration):
        self._CustomConfiguration = CustomConfiguration

    @property
    def ComputerConfiguration(self):
        r"""<p>桌面电脑环境类沙箱配置</p>
        :rtype: :class:`tencentcloud.ags.v20250920.models.ComputerConfiguration`
        """
        return self._ComputerConfiguration

    @ComputerConfiguration.setter
    def ComputerConfiguration(self, ComputerConfiguration):
        self._ComputerConfiguration = ComputerConfiguration

    @property
    def LogConfiguration(self):
        r"""<p>沙箱工具日志推送相关配置</p>
        :rtype: :class:`tencentcloud.ags.v20250920.models.LogConfiguration`
        """
        return self._LogConfiguration

    @LogConfiguration.setter
    def LogConfiguration(self, LogConfiguration):
        self._LogConfiguration = LogConfiguration

    @property
    def Persistent(self):
        r"""<p>常驻沙箱标识</p>
        :rtype: bool
        """
        return self._Persistent

    @Persistent.setter
    def Persistent(self, Persistent):
        self._Persistent = Persistent


    def _deserialize(self, params):
        self._ToolName = params.get("ToolName")
        self._ToolType = params.get("ToolType")
        if params.get("NetworkConfiguration") is not None:
            self._NetworkConfiguration = NetworkConfiguration()
            self._NetworkConfiguration._deserialize(params.get("NetworkConfiguration"))
        self._Description = params.get("Description")
        self._DefaultTimeout = params.get("DefaultTimeout")
        if params.get("Tags") is not None:
            self._Tags = []
            for item in params.get("Tags"):
                obj = Tag()
                obj._deserialize(item)
                self._Tags.append(obj)
        self._ClientToken = params.get("ClientToken")
        self._RoleArn = params.get("RoleArn")
        if params.get("StorageMounts") is not None:
            self._StorageMounts = []
            for item in params.get("StorageMounts"):
                obj = StorageMount()
                obj._deserialize(item)
                self._StorageMounts.append(obj)
        if params.get("CustomConfiguration") is not None:
            self._CustomConfiguration = CustomConfiguration()
            self._CustomConfiguration._deserialize(params.get("CustomConfiguration"))
        if params.get("ComputerConfiguration") is not None:
            self._ComputerConfiguration = ComputerConfiguration()
            self._ComputerConfiguration._deserialize(params.get("ComputerConfiguration"))
        if params.get("LogConfiguration") is not None:
            self._LogConfiguration = LogConfiguration()
            self._LogConfiguration._deserialize(params.get("LogConfiguration"))
        self._Persistent = params.get("Persistent")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class CreateSandboxToolResponse(AbstractModel):
    r"""CreateSandboxTool返回参数结构体

    """

    def __init__(self):
        r"""
        :param _ToolId: <p>创建的沙箱工具 ID</p>
        :type ToolId: str
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._ToolId = None
        self._RequestId = None

    @property
    def ToolId(self):
        r"""<p>创建的沙箱工具 ID</p>
        :rtype: str
        """
        return self._ToolId

    @ToolId.setter
    def ToolId(self, ToolId):
        self._ToolId = ToolId

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._ToolId = params.get("ToolId")
        self._RequestId = params.get("RequestId")


class CustomConfiguration(AbstractModel):
    r"""沙箱自定义配置

    """

    def __init__(self):
        r"""
        :param _Image: <p>镜像地址</p>
        :type Image: str
        :param _ImageRegistryType: <p>镜像仓库类型：<code>enterprise</code>、<code>personal</code>、<code>custom</code></p><p>枚举值：</p><ul><li>enterprise： tcr 企业容器镜像服务</li><li>personal： ccr 个人容器镜像服务</li></ul>
        :type ImageRegistryType: str
        :param _Command: <p>启动命令</p>
        :type Command: list of str
        :param _Args: <p>启动参数</p>
        :type Args: list of str
        :param _Env: <p>环境变量</p>
        :type Env: list of EnvVar
        :param _Ports: <p>端口配置</p>
        :type Ports: list of PortConfiguration
        :param _Resources: <p>资源配置</p>
        :type Resources: :class:`tencentcloud.ags.v20250920.models.ResourceConfiguration`
        :param _Probe: <p>探针配置</p>
        :type Probe: :class:`tencentcloud.ags.v20250920.models.ProbeConfiguration`
        :param _DNSConfig: <p>沙箱 DNS 配置</p>
        :type DNSConfig: :class:`tencentcloud.ags.v20250920.models.DNSConfig`
        """
        self._Image = None
        self._ImageRegistryType = None
        self._Command = None
        self._Args = None
        self._Env = None
        self._Ports = None
        self._Resources = None
        self._Probe = None
        self._DNSConfig = None

    @property
    def Image(self):
        r"""<p>镜像地址</p>
        :rtype: str
        """
        return self._Image

    @Image.setter
    def Image(self, Image):
        self._Image = Image

    @property
    def ImageRegistryType(self):
        r"""<p>镜像仓库类型：<code>enterprise</code>、<code>personal</code>、<code>custom</code></p><p>枚举值：</p><ul><li>enterprise： tcr 企业容器镜像服务</li><li>personal： ccr 个人容器镜像服务</li></ul>
        :rtype: str
        """
        return self._ImageRegistryType

    @ImageRegistryType.setter
    def ImageRegistryType(self, ImageRegistryType):
        self._ImageRegistryType = ImageRegistryType

    @property
    def Command(self):
        r"""<p>启动命令</p>
        :rtype: list of str
        """
        return self._Command

    @Command.setter
    def Command(self, Command):
        self._Command = Command

    @property
    def Args(self):
        r"""<p>启动参数</p>
        :rtype: list of str
        """
        return self._Args

    @Args.setter
    def Args(self, Args):
        self._Args = Args

    @property
    def Env(self):
        r"""<p>环境变量</p>
        :rtype: list of EnvVar
        """
        return self._Env

    @Env.setter
    def Env(self, Env):
        self._Env = Env

    @property
    def Ports(self):
        r"""<p>端口配置</p>
        :rtype: list of PortConfiguration
        """
        return self._Ports

    @Ports.setter
    def Ports(self, Ports):
        self._Ports = Ports

    @property
    def Resources(self):
        r"""<p>资源配置</p>
        :rtype: :class:`tencentcloud.ags.v20250920.models.ResourceConfiguration`
        """
        return self._Resources

    @Resources.setter
    def Resources(self, Resources):
        self._Resources = Resources

    @property
    def Probe(self):
        r"""<p>探针配置</p>
        :rtype: :class:`tencentcloud.ags.v20250920.models.ProbeConfiguration`
        """
        return self._Probe

    @Probe.setter
    def Probe(self, Probe):
        self._Probe = Probe

    @property
    def DNSConfig(self):
        r"""<p>沙箱 DNS 配置</p>
        :rtype: :class:`tencentcloud.ags.v20250920.models.DNSConfig`
        """
        return self._DNSConfig

    @DNSConfig.setter
    def DNSConfig(self, DNSConfig):
        self._DNSConfig = DNSConfig


    def _deserialize(self, params):
        self._Image = params.get("Image")
        self._ImageRegistryType = params.get("ImageRegistryType")
        self._Command = params.get("Command")
        self._Args = params.get("Args")
        if params.get("Env") is not None:
            self._Env = []
            for item in params.get("Env"):
                obj = EnvVar()
                obj._deserialize(item)
                self._Env.append(obj)
        if params.get("Ports") is not None:
            self._Ports = []
            for item in params.get("Ports"):
                obj = PortConfiguration()
                obj._deserialize(item)
                self._Ports.append(obj)
        if params.get("Resources") is not None:
            self._Resources = ResourceConfiguration()
            self._Resources._deserialize(params.get("Resources"))
        if params.get("Probe") is not None:
            self._Probe = ProbeConfiguration()
            self._Probe._deserialize(params.get("Probe"))
        if params.get("DNSConfig") is not None:
            self._DNSConfig = DNSConfig()
            self._DNSConfig._deserialize(params.get("DNSConfig"))
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class CustomConfigurationDetail(AbstractModel):
    r"""沙箱自定义配置详细信息

    """

    def __init__(self):
        r"""
        :param _Image: <p>镜像地址</p>
        :type Image: str
        :param _ImageRegistryType: <p>镜像仓库类型：<code>enterprise</code>、<code>personal</code>、<code>custom</code>。</p><p>枚举值：</p><ul><li>enterprise： TCR 企业容器镜像服务</li><li>personal： CCR 个人容器镜像服务</li></ul>
        :type ImageRegistryType: str
        :param _ImageDigest: <p>镜像 Digest</p>
        :type ImageDigest: str
        :param _Command: <p>启动命令</p>
        :type Command: list of str
        :param _Args: <p>启动参数</p>
        :type Args: list of str
        :param _Env: <p>环境变量</p>
        :type Env: list of EnvVar
        :param _Ports: <p>端口配置</p>
        :type Ports: list of PortConfiguration
        :param _Resources: <p>资源配置</p>
        :type Resources: :class:`tencentcloud.ags.v20250920.models.ResourceConfiguration`
        :param _Probe: <p>探针配置</p>
        :type Probe: :class:`tencentcloud.ags.v20250920.models.ProbeConfiguration`
        :param _DNSConfig: <p>沙箱 DNS 配置</p>
        :type DNSConfig: :class:`tencentcloud.ags.v20250920.models.DNSConfig`
        """
        self._Image = None
        self._ImageRegistryType = None
        self._ImageDigest = None
        self._Command = None
        self._Args = None
        self._Env = None
        self._Ports = None
        self._Resources = None
        self._Probe = None
        self._DNSConfig = None

    @property
    def Image(self):
        r"""<p>镜像地址</p>
        :rtype: str
        """
        return self._Image

    @Image.setter
    def Image(self, Image):
        self._Image = Image

    @property
    def ImageRegistryType(self):
        r"""<p>镜像仓库类型：<code>enterprise</code>、<code>personal</code>、<code>custom</code>。</p><p>枚举值：</p><ul><li>enterprise： TCR 企业容器镜像服务</li><li>personal： CCR 个人容器镜像服务</li></ul>
        :rtype: str
        """
        return self._ImageRegistryType

    @ImageRegistryType.setter
    def ImageRegistryType(self, ImageRegistryType):
        self._ImageRegistryType = ImageRegistryType

    @property
    def ImageDigest(self):
        r"""<p>镜像 Digest</p>
        :rtype: str
        """
        return self._ImageDigest

    @ImageDigest.setter
    def ImageDigest(self, ImageDigest):
        self._ImageDigest = ImageDigest

    @property
    def Command(self):
        r"""<p>启动命令</p>
        :rtype: list of str
        """
        return self._Command

    @Command.setter
    def Command(self, Command):
        self._Command = Command

    @property
    def Args(self):
        r"""<p>启动参数</p>
        :rtype: list of str
        """
        return self._Args

    @Args.setter
    def Args(self, Args):
        self._Args = Args

    @property
    def Env(self):
        r"""<p>环境变量</p>
        :rtype: list of EnvVar
        """
        return self._Env

    @Env.setter
    def Env(self, Env):
        self._Env = Env

    @property
    def Ports(self):
        r"""<p>端口配置</p>
        :rtype: list of PortConfiguration
        """
        return self._Ports

    @Ports.setter
    def Ports(self, Ports):
        self._Ports = Ports

    @property
    def Resources(self):
        r"""<p>资源配置</p>
        :rtype: :class:`tencentcloud.ags.v20250920.models.ResourceConfiguration`
        """
        return self._Resources

    @Resources.setter
    def Resources(self, Resources):
        self._Resources = Resources

    @property
    def Probe(self):
        r"""<p>探针配置</p>
        :rtype: :class:`tencentcloud.ags.v20250920.models.ProbeConfiguration`
        """
        return self._Probe

    @Probe.setter
    def Probe(self, Probe):
        self._Probe = Probe

    @property
    def DNSConfig(self):
        r"""<p>沙箱 DNS 配置</p>
        :rtype: :class:`tencentcloud.ags.v20250920.models.DNSConfig`
        """
        return self._DNSConfig

    @DNSConfig.setter
    def DNSConfig(self, DNSConfig):
        self._DNSConfig = DNSConfig


    def _deserialize(self, params):
        self._Image = params.get("Image")
        self._ImageRegistryType = params.get("ImageRegistryType")
        self._ImageDigest = params.get("ImageDigest")
        self._Command = params.get("Command")
        self._Args = params.get("Args")
        if params.get("Env") is not None:
            self._Env = []
            for item in params.get("Env"):
                obj = EnvVar()
                obj._deserialize(item)
                self._Env.append(obj)
        if params.get("Ports") is not None:
            self._Ports = []
            for item in params.get("Ports"):
                obj = PortConfiguration()
                obj._deserialize(item)
                self._Ports.append(obj)
        if params.get("Resources") is not None:
            self._Resources = ResourceConfiguration()
            self._Resources._deserialize(params.get("Resources"))
        if params.get("Probe") is not None:
            self._Probe = ProbeConfiguration()
            self._Probe._deserialize(params.get("Probe"))
        if params.get("DNSConfig") is not None:
            self._DNSConfig = DNSConfig()
            self._DNSConfig._deserialize(params.get("DNSConfig"))
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DNSConfig(AbstractModel):
    r"""沙箱自定义 dns 配置

    """

    def __init__(self):
        r"""
        :param _Servers: <p>DNS 服务器地址</p><p>参数格式：需要有效 IP 地址</p><p>默认值：10.0.0.1</p>
        :type Servers: list of str
        :param _Searches: <p>搜索域(对应 resolv.conf 的 search 指令)</p>
        :type Searches: list of str
        :param _Options: <p>配置项(对应  resolv.conf 选项)</p>
        :type Options: list of str
        """
        self._Servers = None
        self._Searches = None
        self._Options = None

    @property
    def Servers(self):
        r"""<p>DNS 服务器地址</p><p>参数格式：需要有效 IP 地址</p><p>默认值：10.0.0.1</p>
        :rtype: list of str
        """
        return self._Servers

    @Servers.setter
    def Servers(self, Servers):
        self._Servers = Servers

    @property
    def Searches(self):
        r"""<p>搜索域(对应 resolv.conf 的 search 指令)</p>
        :rtype: list of str
        """
        return self._Searches

    @Searches.setter
    def Searches(self, Searches):
        self._Searches = Searches

    @property
    def Options(self):
        r"""<p>配置项(对应  resolv.conf 选项)</p>
        :rtype: list of str
        """
        return self._Options

    @Options.setter
    def Options(self, Options):
        self._Options = Options


    def _deserialize(self, params):
        self._Servers = params.get("Servers")
        self._Searches = params.get("Searches")
        self._Options = params.get("Options")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DeleteAPIKeyRequest(AbstractModel):
    r"""DeleteAPIKey请求参数结构体

    """

    def __init__(self):
        r"""
        :param _KeyId: 需要删除的API密钥ID
        :type KeyId: str
        """
        self._KeyId = None

    @property
    def KeyId(self):
        r"""需要删除的API密钥ID
        :rtype: str
        """
        return self._KeyId

    @KeyId.setter
    def KeyId(self, KeyId):
        self._KeyId = KeyId


    def _deserialize(self, params):
        self._KeyId = params.get("KeyId")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DeleteAPIKeyResponse(AbstractModel):
    r"""DeleteAPIKey返回参数结构体

    """

    def __init__(self):
        r"""
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._RequestId = None

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._RequestId = params.get("RequestId")


class DeleteDeploymentRequest(AbstractModel):
    r"""DeleteDeployment请求参数结构体

    """

    def __init__(self):
        r"""
        :param _DeploymentId: <p>待删除的 Deployment ID。</p>
        :type DeploymentId: str
        """
        self._DeploymentId = None

    @property
    def DeploymentId(self):
        r"""<p>待删除的 Deployment ID。</p>
        :rtype: str
        """
        return self._DeploymentId

    @DeploymentId.setter
    def DeploymentId(self, DeploymentId):
        self._DeploymentId = DeploymentId


    def _deserialize(self, params):
        self._DeploymentId = params.get("DeploymentId")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DeleteDeploymentResponse(AbstractModel):
    r"""DeleteDeployment返回参数结构体

    """

    def __init__(self):
        r"""
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._RequestId = None

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._RequestId = params.get("RequestId")


class DeleteSandboxToolRequest(AbstractModel):
    r"""DeleteSandboxTool请求参数结构体

    """

    def __init__(self):
        r"""
        :param _ToolId: 沙箱工具ID
        :type ToolId: str
        """
        self._ToolId = None

    @property
    def ToolId(self):
        r"""沙箱工具ID
        :rtype: str
        """
        return self._ToolId

    @ToolId.setter
    def ToolId(self, ToolId):
        self._ToolId = ToolId


    def _deserialize(self, params):
        self._ToolId = params.get("ToolId")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DeleteSandboxToolResponse(AbstractModel):
    r"""DeleteSandboxTool返回参数结构体

    """

    def __init__(self):
        r"""
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._RequestId = None

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._RequestId = params.get("RequestId")


class Deployment(AbstractModel):
    r"""Deployment 稳定访问入口定义

    """

    def __init__(self):
        r"""
        :param _DeploymentId: <p>Deployment 稳定 ID，格式为 dpl- 加 8 位小写 base36 字符。</p>
        :type DeploymentId: str
        :param _DeploymentName: <p>唯一且创建后不可修改的名称，必须符合 DNS-1123 命名规范。</p>
        :type DeploymentName: str
        :param _ToolId: <p>用于关联 Sandbox Tool 的标识，格式为 sdt- 加 8 位小写 base36 字符。</p>
        :type ToolId: str
        :param _ScalingConfiguration: <p>完整的活跃容量配置。</p>
        :type ScalingConfiguration: :class:`tencentcloud.ags.v20250920.models.ScalingConfiguration`
        :param _LifecycleConfiguration: <p>完整的空闲生命周期配置。</p>
        :type LifecycleConfiguration: :class:`tencentcloud.ags.v20250920.models.LifecycleConfiguration`
        :param _AffinityConfiguration: <p>可选 Affinity 配置；未启用时省略。</p>
        :type AffinityConfiguration: :class:`tencentcloud.ags.v20250920.models.AffinityConfiguration`
        :param _Status: <p>Deployment 控制面状态。</p><p>枚举值：</p><ul><li>ACTIVE：入口可用。</li><li>DELETING：入口已关闭并正在异步删除。</li><li>DELETE_FAILED：最近一次异步删除失败，可再次调用 DeleteDeployment。</li></ul>
        :type Status: str
        :param _StatusReason: <p>DELETE_FAILED 状态下 1..1024 个 UTF-8 字节的安全失败摘要，格式为 {Code}[.{SubCode}]: {Message}；其他状态省略。</p>
        :type StatusReason: str
        :param _CreatedTime: <p>创建时间，UTC、秒精度 RFC3339 格式。</p>
        :type CreatedTime: str
        :param _UpdatedTime: <p>最近一次成功公共配置写入或 Deployment 状态迁移时间，UTC、秒精度 RFC3339 格式。</p>
        :type UpdatedTime: str
        :param _Tags: <p>标签</p>
        :type Tags: list of Tag
        """
        self._DeploymentId = None
        self._DeploymentName = None
        self._ToolId = None
        self._ScalingConfiguration = None
        self._LifecycleConfiguration = None
        self._AffinityConfiguration = None
        self._Status = None
        self._StatusReason = None
        self._CreatedTime = None
        self._UpdatedTime = None
        self._Tags = None

    @property
    def DeploymentId(self):
        r"""<p>Deployment 稳定 ID，格式为 dpl- 加 8 位小写 base36 字符。</p>
        :rtype: str
        """
        return self._DeploymentId

    @DeploymentId.setter
    def DeploymentId(self, DeploymentId):
        self._DeploymentId = DeploymentId

    @property
    def DeploymentName(self):
        r"""<p>唯一且创建后不可修改的名称，必须符合 DNS-1123 命名规范。</p>
        :rtype: str
        """
        return self._DeploymentName

    @DeploymentName.setter
    def DeploymentName(self, DeploymentName):
        self._DeploymentName = DeploymentName

    @property
    def ToolId(self):
        r"""<p>用于关联 Sandbox Tool 的标识，格式为 sdt- 加 8 位小写 base36 字符。</p>
        :rtype: str
        """
        return self._ToolId

    @ToolId.setter
    def ToolId(self, ToolId):
        self._ToolId = ToolId

    @property
    def ScalingConfiguration(self):
        r"""<p>完整的活跃容量配置。</p>
        :rtype: :class:`tencentcloud.ags.v20250920.models.ScalingConfiguration`
        """
        return self._ScalingConfiguration

    @ScalingConfiguration.setter
    def ScalingConfiguration(self, ScalingConfiguration):
        self._ScalingConfiguration = ScalingConfiguration

    @property
    def LifecycleConfiguration(self):
        r"""<p>完整的空闲生命周期配置。</p>
        :rtype: :class:`tencentcloud.ags.v20250920.models.LifecycleConfiguration`
        """
        return self._LifecycleConfiguration

    @LifecycleConfiguration.setter
    def LifecycleConfiguration(self, LifecycleConfiguration):
        self._LifecycleConfiguration = LifecycleConfiguration

    @property
    def AffinityConfiguration(self):
        r"""<p>可选 Affinity 配置；未启用时省略。</p>
        :rtype: :class:`tencentcloud.ags.v20250920.models.AffinityConfiguration`
        """
        return self._AffinityConfiguration

    @AffinityConfiguration.setter
    def AffinityConfiguration(self, AffinityConfiguration):
        self._AffinityConfiguration = AffinityConfiguration

    @property
    def Status(self):
        r"""<p>Deployment 控制面状态。</p><p>枚举值：</p><ul><li>ACTIVE：入口可用。</li><li>DELETING：入口已关闭并正在异步删除。</li><li>DELETE_FAILED：最近一次异步删除失败，可再次调用 DeleteDeployment。</li></ul>
        :rtype: str
        """
        return self._Status

    @Status.setter
    def Status(self, Status):
        self._Status = Status

    @property
    def StatusReason(self):
        r"""<p>DELETE_FAILED 状态下 1..1024 个 UTF-8 字节的安全失败摘要，格式为 {Code}[.{SubCode}]: {Message}；其他状态省略。</p>
        :rtype: str
        """
        return self._StatusReason

    @StatusReason.setter
    def StatusReason(self, StatusReason):
        self._StatusReason = StatusReason

    @property
    def CreatedTime(self):
        r"""<p>创建时间，UTC、秒精度 RFC3339 格式。</p>
        :rtype: str
        """
        return self._CreatedTime

    @CreatedTime.setter
    def CreatedTime(self, CreatedTime):
        self._CreatedTime = CreatedTime

    @property
    def UpdatedTime(self):
        r"""<p>最近一次成功公共配置写入或 Deployment 状态迁移时间，UTC、秒精度 RFC3339 格式。</p>
        :rtype: str
        """
        return self._UpdatedTime

    @UpdatedTime.setter
    def UpdatedTime(self, UpdatedTime):
        self._UpdatedTime = UpdatedTime

    @property
    def Tags(self):
        r"""<p>标签</p>
        :rtype: list of Tag
        """
        return self._Tags

    @Tags.setter
    def Tags(self, Tags):
        self._Tags = Tags


    def _deserialize(self, params):
        self._DeploymentId = params.get("DeploymentId")
        self._DeploymentName = params.get("DeploymentName")
        self._ToolId = params.get("ToolId")
        if params.get("ScalingConfiguration") is not None:
            self._ScalingConfiguration = ScalingConfiguration()
            self._ScalingConfiguration._deserialize(params.get("ScalingConfiguration"))
        if params.get("LifecycleConfiguration") is not None:
            self._LifecycleConfiguration = LifecycleConfiguration()
            self._LifecycleConfiguration._deserialize(params.get("LifecycleConfiguration"))
        if params.get("AffinityConfiguration") is not None:
            self._AffinityConfiguration = AffinityConfiguration()
            self._AffinityConfiguration._deserialize(params.get("AffinityConfiguration"))
        self._Status = params.get("Status")
        self._StatusReason = params.get("StatusReason")
        self._CreatedTime = params.get("CreatedTime")
        self._UpdatedTime = params.get("UpdatedTime")
        if params.get("Tags") is not None:
            self._Tags = []
            for item in params.get("Tags"):
                obj = Tag()
                obj._deserialize(item)
                self._Tags.append(obj)
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeAPIKeyListRequest(AbstractModel):
    r"""DescribeAPIKeyList请求参数结构体

    """


class DescribeAPIKeyListResponse(AbstractModel):
    r"""DescribeAPIKeyList返回参数结构体

    """

    def __init__(self):
        r"""
        :param _APIKeySet: API密钥简略信息列表。
        :type APIKeySet: list of APIKeyInfo
        :param _TotalCount: 列表中API密钥数量
        :type TotalCount: int
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._APIKeySet = None
        self._TotalCount = None
        self._RequestId = None

    @property
    def APIKeySet(self):
        r"""API密钥简略信息列表。
        :rtype: list of APIKeyInfo
        """
        return self._APIKeySet

    @APIKeySet.setter
    def APIKeySet(self, APIKeySet):
        self._APIKeySet = APIKeySet

    @property
    def TotalCount(self):
        r"""列表中API密钥数量
        :rtype: int
        """
        return self._TotalCount

    @TotalCount.setter
    def TotalCount(self, TotalCount):
        self._TotalCount = TotalCount

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("APIKeySet") is not None:
            self._APIKeySet = []
            for item in params.get("APIKeySet"):
                obj = APIKeyInfo()
                obj._deserialize(item)
                self._APIKeySet.append(obj)
        self._TotalCount = params.get("TotalCount")
        self._RequestId = params.get("RequestId")


class DescribeDeploymentListRequest(AbstractModel):
    r"""DescribeDeploymentList请求参数结构体

    """

    def __init__(self):
        r"""
        :param _Offset: <p>分页偏移量，默认 0，必须大于等于 0。</p>
        :type Offset: int
        :param _Limit: <p>分页返回数量，默认 20，范围 1..200。</p>
        :type Limit: int
        :param _Filters: <p>查询过滤条件。</p><p>Filter.Name 枚举值：</p><ul><li>deployment-id：按 DeploymentId 精确匹配</li><li>deployment-name：按 DeploymentName 精确匹配</li><li>deployment-name-like：按 DeploymentName 进行普通文本包含匹配，%、_ 等字符没有通配语义</li><li>tool-id：按 ToolId 精确匹配</li><li>status：按 Deployment 状态精确匹配，支持 ACTIVE、DELETING、DELETE_FAILED</li></ul><p>所有匹配均区分大小写。不同 Filter 之间为 AND，同一 Filter 的 Values 之间为 OR。</p>
        :type Filters: list of Filter
        """
        self._Offset = None
        self._Limit = None
        self._Filters = None

    @property
    def Offset(self):
        r"""<p>分页偏移量，默认 0，必须大于等于 0。</p>
        :rtype: int
        """
        return self._Offset

    @Offset.setter
    def Offset(self, Offset):
        self._Offset = Offset

    @property
    def Limit(self):
        r"""<p>分页返回数量，默认 20，范围 1..200。</p>
        :rtype: int
        """
        return self._Limit

    @Limit.setter
    def Limit(self, Limit):
        self._Limit = Limit

    @property
    def Filters(self):
        r"""<p>查询过滤条件。</p><p>Filter.Name 枚举值：</p><ul><li>deployment-id：按 DeploymentId 精确匹配</li><li>deployment-name：按 DeploymentName 精确匹配</li><li>deployment-name-like：按 DeploymentName 进行普通文本包含匹配，%、_ 等字符没有通配语义</li><li>tool-id：按 ToolId 精确匹配</li><li>status：按 Deployment 状态精确匹配，支持 ACTIVE、DELETING、DELETE_FAILED</li></ul><p>所有匹配均区分大小写。不同 Filter 之间为 AND，同一 Filter 的 Values 之间为 OR。</p>
        :rtype: list of Filter
        """
        return self._Filters

    @Filters.setter
    def Filters(self, Filters):
        self._Filters = Filters


    def _deserialize(self, params):
        self._Offset = params.get("Offset")
        self._Limit = params.get("Limit")
        if params.get("Filters") is not None:
            self._Filters = []
            for item in params.get("Filters"):
                obj = Filter()
                obj._deserialize(item)
                self._Filters.append(obj)
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeDeploymentListResponse(AbstractModel):
    r"""DescribeDeploymentList返回参数结构体

    """

    def __init__(self):
        r"""
        :param _DeploymentSet: <p>当前页完整 Deployment；无匹配时为空数组。</p>
        :type DeploymentSet: list of Deployment
        :param _TotalCount: <p>应用 Filters 后、分页前的结果总数。</p>
        :type TotalCount: int
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._DeploymentSet = None
        self._TotalCount = None
        self._RequestId = None

    @property
    def DeploymentSet(self):
        r"""<p>当前页完整 Deployment；无匹配时为空数组。</p>
        :rtype: list of Deployment
        """
        return self._DeploymentSet

    @DeploymentSet.setter
    def DeploymentSet(self, DeploymentSet):
        self._DeploymentSet = DeploymentSet

    @property
    def TotalCount(self):
        r"""<p>应用 Filters 后、分页前的结果总数。</p>
        :rtype: int
        """
        return self._TotalCount

    @TotalCount.setter
    def TotalCount(self, TotalCount):
        self._TotalCount = TotalCount

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("DeploymentSet") is not None:
            self._DeploymentSet = []
            for item in params.get("DeploymentSet"):
                obj = Deployment()
                obj._deserialize(item)
                self._DeploymentSet.append(obj)
        self._TotalCount = params.get("TotalCount")
        self._RequestId = params.get("RequestId")


class DescribeDeploymentRequest(AbstractModel):
    r"""DescribeDeployment请求参数结构体

    """

    def __init__(self):
        r"""
        :param _DeploymentId: <p>待查询的 Deployment ID。</p>
        :type DeploymentId: str
        """
        self._DeploymentId = None

    @property
    def DeploymentId(self):
        r"""<p>待查询的 Deployment ID。</p>
        :rtype: str
        """
        return self._DeploymentId

    @DeploymentId.setter
    def DeploymentId(self, DeploymentId):
        self._DeploymentId = DeploymentId


    def _deserialize(self, params):
        self._DeploymentId = params.get("DeploymentId")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeDeploymentResponse(AbstractModel):
    r"""DescribeDeployment返回参数结构体

    """

    def __init__(self):
        r"""
        :param _Deployment: <p>完整 Deployment。</p>
        :type Deployment: :class:`tencentcloud.ags.v20250920.models.Deployment`
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._Deployment = None
        self._RequestId = None

    @property
    def Deployment(self):
        r"""<p>完整 Deployment。</p>
        :rtype: :class:`tencentcloud.ags.v20250920.models.Deployment`
        """
        return self._Deployment

    @Deployment.setter
    def Deployment(self, Deployment):
        self._Deployment = Deployment

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("Deployment") is not None:
            self._Deployment = Deployment()
            self._Deployment._deserialize(params.get("Deployment"))
        self._RequestId = params.get("RequestId")


class DescribePreCacheImageTaskRequest(AbstractModel):
    r"""DescribePreCacheImageTask请求参数结构体

    """

    def __init__(self):
        r"""
        :param _Image: <p>镜像地址</p>
        :type Image: str
        :param _ImageDigest: <p>镜像 Digest</p>
        :type ImageDigest: str
        :param _ImageRegistryType: <p>镜像仓库类型：<code>enterprise</code>、<code>personal</code>、<code>custom</code> 。</p><p>枚举值：</p><ul><li>enterprise： tcr 企业容器镜像服务</li><li>personal： ccr 个人容器镜像服务</li></ul>
        :type ImageRegistryType: str
        """
        self._Image = None
        self._ImageDigest = None
        self._ImageRegistryType = None

    @property
    def Image(self):
        r"""<p>镜像地址</p>
        :rtype: str
        """
        return self._Image

    @Image.setter
    def Image(self, Image):
        self._Image = Image

    @property
    def ImageDigest(self):
        r"""<p>镜像 Digest</p>
        :rtype: str
        """
        return self._ImageDigest

    @ImageDigest.setter
    def ImageDigest(self, ImageDigest):
        self._ImageDigest = ImageDigest

    @property
    def ImageRegistryType(self):
        r"""<p>镜像仓库类型：<code>enterprise</code>、<code>personal</code>、<code>custom</code> 。</p><p>枚举值：</p><ul><li>enterprise： tcr 企业容器镜像服务</li><li>personal： ccr 个人容器镜像服务</li></ul>
        :rtype: str
        """
        return self._ImageRegistryType

    @ImageRegistryType.setter
    def ImageRegistryType(self, ImageRegistryType):
        self._ImageRegistryType = ImageRegistryType


    def _deserialize(self, params):
        self._Image = params.get("Image")
        self._ImageDigest = params.get("ImageDigest")
        self._ImageRegistryType = params.get("ImageRegistryType")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribePreCacheImageTaskResponse(AbstractModel):
    r"""DescribePreCacheImageTask返回参数结构体

    """

    def __init__(self):
        r"""
        :param _Image: <p>镜像地址</p>
        :type Image: str
        :param _ImageDigest: <p>镜像 Digest</p>
        :type ImageDigest: str
        :param _ImageRegistryType: <p>镜像仓库类型：<code>enterprise</code>、<code>personal</code>。</p>
        :type ImageRegistryType: str
        :param _Status: <p>镜像预热状态</p>
        :type Status: str
        :param _Message: <p>镜像预热状态描述</p>
        :type Message: str
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._Image = None
        self._ImageDigest = None
        self._ImageRegistryType = None
        self._Status = None
        self._Message = None
        self._RequestId = None

    @property
    def Image(self):
        r"""<p>镜像地址</p>
        :rtype: str
        """
        return self._Image

    @Image.setter
    def Image(self, Image):
        self._Image = Image

    @property
    def ImageDigest(self):
        r"""<p>镜像 Digest</p>
        :rtype: str
        """
        return self._ImageDigest

    @ImageDigest.setter
    def ImageDigest(self, ImageDigest):
        self._ImageDigest = ImageDigest

    @property
    def ImageRegistryType(self):
        r"""<p>镜像仓库类型：<code>enterprise</code>、<code>personal</code>。</p>
        :rtype: str
        """
        return self._ImageRegistryType

    @ImageRegistryType.setter
    def ImageRegistryType(self, ImageRegistryType):
        self._ImageRegistryType = ImageRegistryType

    @property
    def Status(self):
        r"""<p>镜像预热状态</p>
        :rtype: str
        """
        return self._Status

    @Status.setter
    def Status(self, Status):
        self._Status = Status

    @property
    def Message(self):
        r"""<p>镜像预热状态描述</p>
        :rtype: str
        """
        return self._Message

    @Message.setter
    def Message(self, Message):
        self._Message = Message

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._Image = params.get("Image")
        self._ImageDigest = params.get("ImageDigest")
        self._ImageRegistryType = params.get("ImageRegistryType")
        self._Status = params.get("Status")
        self._Message = params.get("Message")
        self._RequestId = params.get("RequestId")


class DescribeSandboxInstanceListRequest(AbstractModel):
    r"""DescribeSandboxInstanceList请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceIds: 沙箱实例ID列表，指定要查询的实例。如果为空则查询所有实例。最大支持100个ID
        :type InstanceIds: list of str
        :param _ToolId: 沙箱工具ID，指定时查询该沙箱模板下的实例，为空则查询所有沙箱模板的实例
        :type ToolId: str
        :param _Offset: 偏移量，默认为0
        :type Offset: int
        :param _Limit: 返回数量，默认为20，最大值为100
        :type Limit: int
        :param _Filters: 过滤条件
        :type Filters: list of Filter
        """
        self._InstanceIds = None
        self._ToolId = None
        self._Offset = None
        self._Limit = None
        self._Filters = None

    @property
    def InstanceIds(self):
        r"""沙箱实例ID列表，指定要查询的实例。如果为空则查询所有实例。最大支持100个ID
        :rtype: list of str
        """
        return self._InstanceIds

    @InstanceIds.setter
    def InstanceIds(self, InstanceIds):
        self._InstanceIds = InstanceIds

    @property
    def ToolId(self):
        r"""沙箱工具ID，指定时查询该沙箱模板下的实例，为空则查询所有沙箱模板的实例
        :rtype: str
        """
        return self._ToolId

    @ToolId.setter
    def ToolId(self, ToolId):
        self._ToolId = ToolId

    @property
    def Offset(self):
        r"""偏移量，默认为0
        :rtype: int
        """
        return self._Offset

    @Offset.setter
    def Offset(self, Offset):
        self._Offset = Offset

    @property
    def Limit(self):
        r"""返回数量，默认为20，最大值为100
        :rtype: int
        """
        return self._Limit

    @Limit.setter
    def Limit(self, Limit):
        self._Limit = Limit

    @property
    def Filters(self):
        r"""过滤条件
        :rtype: list of Filter
        """
        return self._Filters

    @Filters.setter
    def Filters(self, Filters):
        self._Filters = Filters


    def _deserialize(self, params):
        self._InstanceIds = params.get("InstanceIds")
        self._ToolId = params.get("ToolId")
        self._Offset = params.get("Offset")
        self._Limit = params.get("Limit")
        if params.get("Filters") is not None:
            self._Filters = []
            for item in params.get("Filters"):
                obj = Filter()
                obj._deserialize(item)
                self._Filters.append(obj)
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeSandboxInstanceListResponse(AbstractModel):
    r"""DescribeSandboxInstanceList返回参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceSet: 沙箱实例列表
        :type InstanceSet: list of SandboxInstance
        :param _TotalCount: 符合条件的实例总数
        :type TotalCount: int
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._InstanceSet = None
        self._TotalCount = None
        self._RequestId = None

    @property
    def InstanceSet(self):
        r"""沙箱实例列表
        :rtype: list of SandboxInstance
        """
        return self._InstanceSet

    @InstanceSet.setter
    def InstanceSet(self, InstanceSet):
        self._InstanceSet = InstanceSet

    @property
    def TotalCount(self):
        r"""符合条件的实例总数
        :rtype: int
        """
        return self._TotalCount

    @TotalCount.setter
    def TotalCount(self, TotalCount):
        self._TotalCount = TotalCount

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("InstanceSet") is not None:
            self._InstanceSet = []
            for item in params.get("InstanceSet"):
                obj = SandboxInstance()
                obj._deserialize(item)
                self._InstanceSet.append(obj)
        self._TotalCount = params.get("TotalCount")
        self._RequestId = params.get("RequestId")


class DescribeSandboxToolListRequest(AbstractModel):
    r"""DescribeSandboxToolList请求参数结构体

    """

    def __init__(self):
        r"""
        :param _ToolIds: 沙箱工具ID列表，指定要查询的工具。如果为空则查询所有工具。最大支持100个ID
        :type ToolIds: list of str
        :param _Offset: 偏移量，默认为0
        :type Offset: int
        :param _Limit: 返回数量，默认为20，最大值为100
        :type Limit: int
        :param _Filters: 过滤条件
        :type Filters: list of Filter
        """
        self._ToolIds = None
        self._Offset = None
        self._Limit = None
        self._Filters = None

    @property
    def ToolIds(self):
        r"""沙箱工具ID列表，指定要查询的工具。如果为空则查询所有工具。最大支持100个ID
        :rtype: list of str
        """
        return self._ToolIds

    @ToolIds.setter
    def ToolIds(self, ToolIds):
        self._ToolIds = ToolIds

    @property
    def Offset(self):
        r"""偏移量，默认为0
        :rtype: int
        """
        return self._Offset

    @Offset.setter
    def Offset(self, Offset):
        self._Offset = Offset

    @property
    def Limit(self):
        r"""返回数量，默认为20，最大值为100
        :rtype: int
        """
        return self._Limit

    @Limit.setter
    def Limit(self, Limit):
        self._Limit = Limit

    @property
    def Filters(self):
        r"""过滤条件
        :rtype: list of Filter
        """
        return self._Filters

    @Filters.setter
    def Filters(self, Filters):
        self._Filters = Filters


    def _deserialize(self, params):
        self._ToolIds = params.get("ToolIds")
        self._Offset = params.get("Offset")
        self._Limit = params.get("Limit")
        if params.get("Filters") is not None:
            self._Filters = []
            for item in params.get("Filters"):
                obj = Filter()
                obj._deserialize(item)
                self._Filters.append(obj)
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DescribeSandboxToolListResponse(AbstractModel):
    r"""DescribeSandboxToolList返回参数结构体

    """

    def __init__(self):
        r"""
        :param _SandboxToolSet: 沙箱工具列表
        :type SandboxToolSet: list of SandboxTool
        :param _TotalCount: 符合条件的沙箱工具总数
        :type TotalCount: int
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._SandboxToolSet = None
        self._TotalCount = None
        self._RequestId = None

    @property
    def SandboxToolSet(self):
        r"""沙箱工具列表
        :rtype: list of SandboxTool
        """
        return self._SandboxToolSet

    @SandboxToolSet.setter
    def SandboxToolSet(self, SandboxToolSet):
        self._SandboxToolSet = SandboxToolSet

    @property
    def TotalCount(self):
        r"""符合条件的沙箱工具总数
        :rtype: int
        """
        return self._TotalCount

    @TotalCount.setter
    def TotalCount(self, TotalCount):
        self._TotalCount = TotalCount

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("SandboxToolSet") is not None:
            self._SandboxToolSet = []
            for item in params.get("SandboxToolSet"):
                obj = SandboxTool()
                obj._deserialize(item)
                self._SandboxToolSet.append(obj)
        self._TotalCount = params.get("TotalCount")
        self._RequestId = params.get("RequestId")


class EnvVar(AbstractModel):
    r"""环境变量

    """

    def __init__(self):
        r"""
        :param _Name: 环境变量名
        :type Name: str
        :param _Value: 环境变量值
        :type Value: str
        """
        self._Name = None
        self._Value = None

    @property
    def Name(self):
        r"""环境变量名
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def Value(self):
        r"""环境变量值
        :rtype: str
        """
        return self._Value

    @Value.setter
    def Value(self, Value):
        self._Value = Value


    def _deserialize(self, params):
        self._Name = params.get("Name")
        self._Value = params.get("Value")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class Filter(AbstractModel):
    r"""过滤列表规则

    """

    def __init__(self):
        r"""
        :param _Name: 属性名称, 若存在多个Filter时，Filter间的关系为逻辑与（AND）关系。
        :type Name: str
        :param _Values: 属性值, 若同一个Filter存在多个Values，同一Filter下Values间的关系为逻辑或（OR）关系。
        :type Values: list of str
        """
        self._Name = None
        self._Values = None

    @property
    def Name(self):
        r"""属性名称, 若存在多个Filter时，Filter间的关系为逻辑与（AND）关系。
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def Values(self):
        r"""属性值, 若同一个Filter存在多个Values，同一Filter下Values间的关系为逻辑或（OR）关系。
        :rtype: list of str
        """
        return self._Values

    @Values.setter
    def Values(self, Values):
        self._Values = Values


    def _deserialize(self, params):
        self._Name = params.get("Name")
        self._Values = params.get("Values")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class HttpGetAction(AbstractModel):
    r"""HTTP GET 探测动作配置

    """

    def __init__(self):
        r"""
        :param _Path: 路径
        :type Path: str
        :param _Port: 端口
        :type Port: int
        :param _Scheme: 协议
        :type Scheme: str
        """
        self._Path = None
        self._Port = None
        self._Scheme = None

    @property
    def Path(self):
        r"""路径
        :rtype: str
        """
        return self._Path

    @Path.setter
    def Path(self, Path):
        self._Path = Path

    @property
    def Port(self):
        r"""端口
        :rtype: int
        """
        return self._Port

    @Port.setter
    def Port(self, Port):
        self._Port = Port

    @property
    def Scheme(self):
        r"""协议
        :rtype: str
        """
        return self._Scheme

    @Scheme.setter
    def Scheme(self, Scheme):
        self._Scheme = Scheme


    def _deserialize(self, params):
        self._Path = params.get("Path")
        self._Port = params.get("Port")
        self._Scheme = params.get("Scheme")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ImageStorageSource(AbstractModel):
    r"""镜像卷挂载源配置

    """

    def __init__(self):
        r"""
        :param _Reference: <p>镜像地址</p>
        :type Reference: str
        :param _ImageRegistryType: <p>镜像仓库类型：<code>enterprise</code>、<code>personal</code>。</p>
        :type ImageRegistryType: str
        :param _SubPath: <p>镜像内部的路径</p>
        :type SubPath: str
        :param _Digest: <p>镜像 Digest，请求时无需传入</p>
        :type Digest: str
        """
        self._Reference = None
        self._ImageRegistryType = None
        self._SubPath = None
        self._Digest = None

    @property
    def Reference(self):
        r"""<p>镜像地址</p>
        :rtype: str
        """
        return self._Reference

    @Reference.setter
    def Reference(self, Reference):
        self._Reference = Reference

    @property
    def ImageRegistryType(self):
        r"""<p>镜像仓库类型：<code>enterprise</code>、<code>personal</code>。</p>
        :rtype: str
        """
        return self._ImageRegistryType

    @ImageRegistryType.setter
    def ImageRegistryType(self, ImageRegistryType):
        self._ImageRegistryType = ImageRegistryType

    @property
    def SubPath(self):
        r"""<p>镜像内部的路径</p>
        :rtype: str
        """
        return self._SubPath

    @SubPath.setter
    def SubPath(self, SubPath):
        self._SubPath = SubPath

    @property
    def Digest(self):
        r"""<p>镜像 Digest，请求时无需传入</p>
        :rtype: str
        """
        return self._Digest

    @Digest.setter
    def Digest(self, Digest):
        self._Digest = Digest


    def _deserialize(self, params):
        self._Reference = params.get("Reference")
        self._ImageRegistryType = params.get("ImageRegistryType")
        self._SubPath = params.get("SubPath")
        self._Digest = params.get("Digest")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class LifecycleConfiguration(AbstractModel):
    r"""Deployment 管理的 Sandbox Instance 的空闲生命周期配置

    """

    def __init__(self):
        r"""
        :param _IdleTimeoutSeconds: <p>Sandbox Instance 没有活跃 Deployment 请求或连接后进入 IdleAction 的秒数，必须大于等于 30。</p>
        :type IdleTimeoutSeconds: int
        :param _IdleAction: <p>空闲处理动作。</p><p>枚举值：</p><ul><li>STOP：停止并释放 Sandbox Instance。</li><li>PAUSE：暂停并保留 Sandbox Instance 状态。</li></ul>
        :type IdleAction: str
        """
        self._IdleTimeoutSeconds = None
        self._IdleAction = None

    @property
    def IdleTimeoutSeconds(self):
        r"""<p>Sandbox Instance 没有活跃 Deployment 请求或连接后进入 IdleAction 的秒数，必须大于等于 30。</p>
        :rtype: int
        """
        return self._IdleTimeoutSeconds

    @IdleTimeoutSeconds.setter
    def IdleTimeoutSeconds(self, IdleTimeoutSeconds):
        self._IdleTimeoutSeconds = IdleTimeoutSeconds

    @property
    def IdleAction(self):
        r"""<p>空闲处理动作。</p><p>枚举值：</p><ul><li>STOP：停止并释放 Sandbox Instance。</li><li>PAUSE：暂停并保留 Sandbox Instance 状态。</li></ul>
        :rtype: str
        """
        return self._IdleAction

    @IdleAction.setter
    def IdleAction(self, IdleAction):
        self._IdleAction = IdleAction


    def _deserialize(self, params):
        self._IdleTimeoutSeconds = params.get("IdleTimeoutSeconds")
        self._IdleAction = params.get("IdleAction")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class LogConfiguration(AbstractModel):
    r"""沙箱工具日志采集相关配置

    """

    def __init__(self):
        r"""
        :param _CLSConfig: <p>日志推送CLS的配置。</p>
        :type CLSConfig: :class:`tencentcloud.ags.v20250920.models.CLSConfig`
        :param _LogSources: <p>日志源配置</p>
        :type LogSources: :class:`tencentcloud.ags.v20250920.models.LogSources`
        """
        self._CLSConfig = None
        self._LogSources = None

    @property
    def CLSConfig(self):
        r"""<p>日志推送CLS的配置。</p>
        :rtype: :class:`tencentcloud.ags.v20250920.models.CLSConfig`
        """
        return self._CLSConfig

    @CLSConfig.setter
    def CLSConfig(self, CLSConfig):
        self._CLSConfig = CLSConfig

    @property
    def LogSources(self):
        r"""<p>日志源配置</p>
        :rtype: :class:`tencentcloud.ags.v20250920.models.LogSources`
        """
        return self._LogSources

    @LogSources.setter
    def LogSources(self, LogSources):
        self._LogSources = LogSources


    def _deserialize(self, params):
        if params.get("CLSConfig") is not None:
            self._CLSConfig = CLSConfig()
            self._CLSConfig._deserialize(params.get("CLSConfig"))
        if params.get("LogSources") is not None:
            self._LogSources = LogSources()
            self._LogSources._deserialize(params.get("LogSources"))
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class LogSources(AbstractModel):
    r"""日志源配置

    """

    def __init__(self):
        r"""
        :param _Files: <p>需要采集的日志文件路径，必须是 /logs/ 目录下的文件，不支持子目录，最大支持 10 个文件。</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type Files: list of str
        """
        self._Files = None

    @property
    def Files(self):
        r"""<p>需要采集的日志文件路径，必须是 /logs/ 目录下的文件，不支持子目录，最大支持 10 个文件。</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: list of str
        """
        return self._Files

    @Files.setter
    def Files(self, Files):
        self._Files = Files


    def _deserialize(self, params):
        self._Files = params.get("Files")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class MetadataVar(AbstractModel):
    r"""metadata 项

    """

    def __init__(self):
        r"""
        :param _Name: <p>元数据名</p>
        :type Name: str
        :param _Value: <p>元数据值</p>
        :type Value: str
        """
        self._Name = None
        self._Value = None

    @property
    def Name(self):
        r"""<p>元数据名</p>
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def Value(self):
        r"""<p>元数据值</p>
        :rtype: str
        """
        return self._Value

    @Value.setter
    def Value(self, Value):
        self._Value = Value


    def _deserialize(self, params):
        self._Name = params.get("Name")
        self._Value = params.get("Value")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ModifyDeploymentRequest(AbstractModel):
    r"""ModifyDeployment请求参数结构体

    """

    def __init__(self):
        r"""
        :param _DeploymentId: <p>待修改的 Deployment ID。</p>
        :type DeploymentId: str
        :param _ScalingConfiguration: <p>完整替换伸缩配置；提供时必须包含全部三个成员。</p>
        :type ScalingConfiguration: :class:`tencentcloud.ags.v20250920.models.ScalingConfiguration`
        :param _LifecycleConfiguration: <p>完整替换生命周期配置；提供时必须包含全部两个成员。</p>
        :type LifecycleConfiguration: :class:`tencentcloud.ags.v20250920.models.LifecycleConfiguration`
        :param _Tags: <p>标签</p>
        :type Tags: list of Tag
        """
        self._DeploymentId = None
        self._ScalingConfiguration = None
        self._LifecycleConfiguration = None
        self._Tags = None

    @property
    def DeploymentId(self):
        r"""<p>待修改的 Deployment ID。</p>
        :rtype: str
        """
        return self._DeploymentId

    @DeploymentId.setter
    def DeploymentId(self, DeploymentId):
        self._DeploymentId = DeploymentId

    @property
    def ScalingConfiguration(self):
        r"""<p>完整替换伸缩配置；提供时必须包含全部三个成员。</p>
        :rtype: :class:`tencentcloud.ags.v20250920.models.ScalingConfiguration`
        """
        return self._ScalingConfiguration

    @ScalingConfiguration.setter
    def ScalingConfiguration(self, ScalingConfiguration):
        self._ScalingConfiguration = ScalingConfiguration

    @property
    def LifecycleConfiguration(self):
        r"""<p>完整替换生命周期配置；提供时必须包含全部两个成员。</p>
        :rtype: :class:`tencentcloud.ags.v20250920.models.LifecycleConfiguration`
        """
        return self._LifecycleConfiguration

    @LifecycleConfiguration.setter
    def LifecycleConfiguration(self, LifecycleConfiguration):
        self._LifecycleConfiguration = LifecycleConfiguration

    @property
    def Tags(self):
        r"""<p>标签</p>
        :rtype: list of Tag
        """
        return self._Tags

    @Tags.setter
    def Tags(self, Tags):
        self._Tags = Tags


    def _deserialize(self, params):
        self._DeploymentId = params.get("DeploymentId")
        if params.get("ScalingConfiguration") is not None:
            self._ScalingConfiguration = ScalingConfiguration()
            self._ScalingConfiguration._deserialize(params.get("ScalingConfiguration"))
        if params.get("LifecycleConfiguration") is not None:
            self._LifecycleConfiguration = LifecycleConfiguration()
            self._LifecycleConfiguration._deserialize(params.get("LifecycleConfiguration"))
        if params.get("Tags") is not None:
            self._Tags = []
            for item in params.get("Tags"):
                obj = Tag()
                obj._deserialize(item)
                self._Tags.append(obj)
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ModifyDeploymentResponse(AbstractModel):
    r"""ModifyDeployment返回参数结构体

    """

    def __init__(self):
        r"""
        :param _Deployment: <p>修改后的完整 Deployment。</p>
        :type Deployment: :class:`tencentcloud.ags.v20250920.models.Deployment`
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._Deployment = None
        self._RequestId = None

    @property
    def Deployment(self):
        r"""<p>修改后的完整 Deployment。</p>
        :rtype: :class:`tencentcloud.ags.v20250920.models.Deployment`
        """
        return self._Deployment

    @Deployment.setter
    def Deployment(self, Deployment):
        self._Deployment = Deployment

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("Deployment") is not None:
            self._Deployment = Deployment()
            self._Deployment._deserialize(params.get("Deployment"))
        self._RequestId = params.get("RequestId")


class MountOption(AbstractModel):
    r"""沙箱实例存储挂载配置可选项，用于覆盖沙箱工具的存储配置的部分选项，并提供子路径挂载配置。

    """

    def __init__(self):
        r"""
        :param _Name: 指定沙箱工具中的存储配置名称
        :type Name: str
        :param _MountPath: 沙箱实例本地挂载路径（可选），默认继承工具中的存储配置
        :type MountPath: str
        :param _SubPath: 沙箱实例存储挂载子路径（可选）
        :type SubPath: str
        :param _ReadOnly: 沙箱实例存储挂载读写权限（可选），默认继承工具存储配置
        :type ReadOnly: bool
        """
        self._Name = None
        self._MountPath = None
        self._SubPath = None
        self._ReadOnly = None

    @property
    def Name(self):
        r"""指定沙箱工具中的存储配置名称
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def MountPath(self):
        r"""沙箱实例本地挂载路径（可选），默认继承工具中的存储配置
        :rtype: str
        """
        return self._MountPath

    @MountPath.setter
    def MountPath(self, MountPath):
        self._MountPath = MountPath

    @property
    def SubPath(self):
        r"""沙箱实例存储挂载子路径（可选）
        :rtype: str
        """
        return self._SubPath

    @SubPath.setter
    def SubPath(self, SubPath):
        self._SubPath = SubPath

    @property
    def ReadOnly(self):
        r"""沙箱实例存储挂载读写权限（可选），默认继承工具存储配置
        :rtype: bool
        """
        return self._ReadOnly

    @ReadOnly.setter
    def ReadOnly(self, ReadOnly):
        self._ReadOnly = ReadOnly


    def _deserialize(self, params):
        self._Name = params.get("Name")
        self._MountPath = params.get("MountPath")
        self._SubPath = params.get("SubPath")
        self._ReadOnly = params.get("ReadOnly")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class NetworkConfiguration(AbstractModel):
    r"""沙箱网络配置

    """

    def __init__(self):
        r"""
        :param _NetworkMode: 网络模式（当前支持 PUBLIC, VPC, SANDBOX）
        :type NetworkMode: str
        :param _VpcConfig: VPC网络相关配置
        :type VpcConfig: :class:`tencentcloud.ags.v20250920.models.VPCConfig`
        """
        self._NetworkMode = None
        self._VpcConfig = None

    @property
    def NetworkMode(self):
        r"""网络模式（当前支持 PUBLIC, VPC, SANDBOX）
        :rtype: str
        """
        return self._NetworkMode

    @NetworkMode.setter
    def NetworkMode(self, NetworkMode):
        self._NetworkMode = NetworkMode

    @property
    def VpcConfig(self):
        r"""VPC网络相关配置
        :rtype: :class:`tencentcloud.ags.v20250920.models.VPCConfig`
        """
        return self._VpcConfig

    @VpcConfig.setter
    def VpcConfig(self, VpcConfig):
        self._VpcConfig = VpcConfig


    def _deserialize(self, params):
        self._NetworkMode = params.get("NetworkMode")
        if params.get("VpcConfig") is not None:
            self._VpcConfig = VPCConfig()
            self._VpcConfig._deserialize(params.get("VpcConfig"))
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class OSWorldConfiguration(AbstractModel):
    r"""OSWorld 内置版本配置

    """

    def __init__(self):
        r"""
        :param _Version: <p>指定内置 OSWorld 版本</p><p>枚举值：</p><ul><li>osworld1： osworld v1</li><li>osworld2： osworld v2</li></ul><p>默认值：osworld1</p>
        :type Version: str
        """
        self._Version = None

    @property
    def Version(self):
        r"""<p>指定内置 OSWorld 版本</p><p>枚举值：</p><ul><li>osworld1： osworld v1</li><li>osworld2： osworld v2</li></ul><p>默认值：osworld1</p>
        :rtype: str
        """
        return self._Version

    @Version.setter
    def Version(self, Version):
        self._Version = Version


    def _deserialize(self, params):
        self._Version = params.get("Version")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class PauseSandboxInstanceRequest(AbstractModel):
    r"""PauseSandboxInstance请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceId: <p>沙箱实例ID</p>
        :type InstanceId: str
        :param _Memory: <p>可选。带内存暂停，恢复后保留进程和内存状态。true=带内存；false=仅磁盘；不传=系统默认（当前默认 true，带内存）。</p>
        :type Memory: bool
        """
        self._InstanceId = None
        self._Memory = None

    @property
    def InstanceId(self):
        r"""<p>沙箱实例ID</p>
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId

    @property
    def Memory(self):
        r"""<p>可选。带内存暂停，恢复后保留进程和内存状态。true=带内存；false=仅磁盘；不传=系统默认（当前默认 true，带内存）。</p>
        :rtype: bool
        """
        return self._Memory

    @Memory.setter
    def Memory(self, Memory):
        self._Memory = Memory


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        self._Memory = params.get("Memory")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class PauseSandboxInstanceResponse(AbstractModel):
    r"""PauseSandboxInstance返回参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceStatus: <p>目标沙箱实例当前的状态</p><p>枚举值：</p><ul><li>PAUSING： 正在暂停中</li><li>PAUSED： 已暂停</li><li>PAUSE_FAILED： 暂停失败</li></ul>
        :type InstanceStatus: str
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._InstanceStatus = None
        self._RequestId = None

    @property
    def InstanceStatus(self):
        r"""<p>目标沙箱实例当前的状态</p><p>枚举值：</p><ul><li>PAUSING： 正在暂停中</li><li>PAUSED： 已暂停</li><li>PAUSE_FAILED： 暂停失败</li></ul>
        :rtype: str
        """
        return self._InstanceStatus

    @InstanceStatus.setter
    def InstanceStatus(self, InstanceStatus):
        self._InstanceStatus = InstanceStatus

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._InstanceStatus = params.get("InstanceStatus")
        self._RequestId = params.get("RequestId")


class PortConfiguration(AbstractModel):
    r"""端口配置

    """

    def __init__(self):
        r"""
        :param _Name: 端口名
        :type Name: str
        :param _Port: 端口
        :type Port: int
        :param _Protocol: 协议
        :type Protocol: str
        """
        self._Name = None
        self._Port = None
        self._Protocol = None

    @property
    def Name(self):
        r"""端口名
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def Port(self):
        r"""端口
        :rtype: int
        """
        return self._Port

    @Port.setter
    def Port(self, Port):
        self._Port = Port

    @property
    def Protocol(self):
        r"""协议
        :rtype: str
        """
        return self._Protocol

    @Protocol.setter
    def Protocol(self, Protocol):
        self._Protocol = Protocol


    def _deserialize(self, params):
        self._Name = params.get("Name")
        self._Port = params.get("Port")
        self._Protocol = params.get("Protocol")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ProbeConfiguration(AbstractModel):
    r"""健康检查探针配置

    """

    def __init__(self):
        r"""
        :param _HttpGet: HTTP GET 探测配置
        :type HttpGet: :class:`tencentcloud.ags.v20250920.models.HttpGetAction`
        :param _ReadyTimeoutMs: 健康检查就绪超时
        :type ReadyTimeoutMs: int
        :param _ProbeTimeoutMs: 健康检查单次探测超时
        :type ProbeTimeoutMs: int
        :param _ProbePeriodMs: 健康检查间隔
        :type ProbePeriodMs: int
        :param _SuccessThreshold: 健康检查成功阈值
        :type SuccessThreshold: int
        :param _FailureThreshold: 健康检查失败阈值
        :type FailureThreshold: int
        """
        self._HttpGet = None
        self._ReadyTimeoutMs = None
        self._ProbeTimeoutMs = None
        self._ProbePeriodMs = None
        self._SuccessThreshold = None
        self._FailureThreshold = None

    @property
    def HttpGet(self):
        r"""HTTP GET 探测配置
        :rtype: :class:`tencentcloud.ags.v20250920.models.HttpGetAction`
        """
        return self._HttpGet

    @HttpGet.setter
    def HttpGet(self, HttpGet):
        self._HttpGet = HttpGet

    @property
    def ReadyTimeoutMs(self):
        r"""健康检查就绪超时
        :rtype: int
        """
        return self._ReadyTimeoutMs

    @ReadyTimeoutMs.setter
    def ReadyTimeoutMs(self, ReadyTimeoutMs):
        self._ReadyTimeoutMs = ReadyTimeoutMs

    @property
    def ProbeTimeoutMs(self):
        r"""健康检查单次探测超时
        :rtype: int
        """
        return self._ProbeTimeoutMs

    @ProbeTimeoutMs.setter
    def ProbeTimeoutMs(self, ProbeTimeoutMs):
        self._ProbeTimeoutMs = ProbeTimeoutMs

    @property
    def ProbePeriodMs(self):
        r"""健康检查间隔
        :rtype: int
        """
        return self._ProbePeriodMs

    @ProbePeriodMs.setter
    def ProbePeriodMs(self, ProbePeriodMs):
        self._ProbePeriodMs = ProbePeriodMs

    @property
    def SuccessThreshold(self):
        r"""健康检查成功阈值
        :rtype: int
        """
        return self._SuccessThreshold

    @SuccessThreshold.setter
    def SuccessThreshold(self, SuccessThreshold):
        self._SuccessThreshold = SuccessThreshold

    @property
    def FailureThreshold(self):
        r"""健康检查失败阈值
        :rtype: int
        """
        return self._FailureThreshold

    @FailureThreshold.setter
    def FailureThreshold(self, FailureThreshold):
        self._FailureThreshold = FailureThreshold


    def _deserialize(self, params):
        if params.get("HttpGet") is not None:
            self._HttpGet = HttpGetAction()
            self._HttpGet._deserialize(params.get("HttpGet"))
        self._ReadyTimeoutMs = params.get("ReadyTimeoutMs")
        self._ProbeTimeoutMs = params.get("ProbeTimeoutMs")
        self._ProbePeriodMs = params.get("ProbePeriodMs")
        self._SuccessThreshold = params.get("SuccessThreshold")
        self._FailureThreshold = params.get("FailureThreshold")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ResourceConfiguration(AbstractModel):
    r"""资源配置

    """

    def __init__(self):
        r"""
        :param _CPU: <p>cpu 资源量</p>
        :type CPU: str
        :param _Memory: <p>内存资源量</p>
        :type Memory: str
        :param _Storage: <p>自定义磁盘大小</p><p>枚举值：</p><ul><li>1Gi： 1Gi</li><li>5Gi： 5Gi</li><li>10Gi： 10Gi</li><li>20Gi： 20Gi</li></ul>
注意：此字段可能返回 null，表示取不到有效值。
        :type Storage: str
        """
        self._CPU = None
        self._Memory = None
        self._Storage = None

    @property
    def CPU(self):
        r"""<p>cpu 资源量</p>
        :rtype: str
        """
        return self._CPU

    @CPU.setter
    def CPU(self, CPU):
        self._CPU = CPU

    @property
    def Memory(self):
        r"""<p>内存资源量</p>
        :rtype: str
        """
        return self._Memory

    @Memory.setter
    def Memory(self, Memory):
        self._Memory = Memory

    @property
    def Storage(self):
        r"""<p>自定义磁盘大小</p><p>枚举值：</p><ul><li>1Gi： 1Gi</li><li>5Gi： 5Gi</li><li>10Gi： 10Gi</li><li>20Gi： 20Gi</li></ul>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: str
        """
        return self._Storage

    @Storage.setter
    def Storage(self, Storage):
        self._Storage = Storage


    def _deserialize(self, params):
        self._CPU = params.get("CPU")
        self._Memory = params.get("Memory")
        self._Storage = params.get("Storage")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ResumeSandboxInstanceRequest(AbstractModel):
    r"""ResumeSandboxInstance请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceId: <p>沙箱实例ID</p>
        :type InstanceId: str
        :param _Timeout: <p>超时时间，超过这个时间就自动回收实例。支持格式：5m、300s、1h 等，默认 5m。最小 30s，最大 24h</p>
        :type Timeout: str
        """
        self._InstanceId = None
        self._Timeout = None

    @property
    def InstanceId(self):
        r"""<p>沙箱实例ID</p>
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId

    @property
    def Timeout(self):
        r"""<p>超时时间，超过这个时间就自动回收实例。支持格式：5m、300s、1h 等，默认 5m。最小 30s，最大 24h</p>
        :rtype: str
        """
        return self._Timeout

    @Timeout.setter
    def Timeout(self, Timeout):
        self._Timeout = Timeout


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        self._Timeout = params.get("Timeout")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ResumeSandboxInstanceResponse(AbstractModel):
    r"""ResumeSandboxInstance返回参数结构体

    """

    def __init__(self):
        r"""
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._RequestId = None

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._RequestId = params.get("RequestId")


class SandboxInstance(AbstractModel):
    r"""沙箱实例结构体

    """

    def __init__(self):
        r"""
        :param _InstanceId: <p>沙箱实例唯一标识符</p>
        :type InstanceId: str
        :param _ToolId: <p>所属沙箱工具 ID</p>
        :type ToolId: str
        :param _ToolName: <p>所属沙箱工具名称</p>
        :type ToolName: str
        :param _Status: <p>实例状态：STARTING（启动中）、RUNNING（运行中）、STOPPING（停止中）、STOPPED（已停止）、STOP_FAILED（停止失败）、FAILED（失败状态）</p>
        :type Status: str
        :param _Persistent: <p>是否常驻实例</p>
        :type Persistent: bool
        :param _TimeoutSeconds: <p>超时时间（秒），null 表示无超时设置</p>
        :type TimeoutSeconds: int
        :param _ExpiresAt: <p>过期时间（ISO 8601 格式），null 表示无过期时间</p>
        :type ExpiresAt: str
        :param _StopReason: <p>停止原因：manual（手动）、timeout（超时）、error（错误）、system（系统），仅在状态为 STOPPED、STOP_FAILED 或 FAILED 时有值。当 provider 停止失败时，状态为 STOP_FAILED，原因为 error</p>
        :type StopReason: str
        :param _CreateTime: <p>创建时间（ISO 8601 格式）</p>
        :type CreateTime: str
        :param _UpdateTime: <p>更新时间（ISO 8601 格式）</p>
        :type UpdateTime: str
        :param _MountOptions: <p>存储挂载选项</p>
        :type MountOptions: list of MountOption
        :param _CustomConfiguration: <p>沙箱实例自定义配置</p>
        :type CustomConfiguration: :class:`tencentcloud.ags.v20250920.models.CustomConfigurationDetail`
        :param _ComputerConfiguration: <p>桌面电脑环境类沙箱配置</p>
        :type ComputerConfiguration: :class:`tencentcloud.ags.v20250920.models.ComputerConfiguration`
        :param _NetworkMode: <p>网络模式</p><p>枚举值：</p><ul><li>PUBLIC： 公网访问</li><li>SANDBOX： 无网络</li><li>INTERNAL_SERVICE： 腾讯云内部公共服务</li></ul><p>可以覆盖工具级别的网络配置。但如果一个工具本身就不支持 VPC 网络，那么即便在实例设置里选了 VPC 模式，也是无效的</p>
        :type NetworkMode: str
        :param _Metadata: <p>沙箱实例元数据</p>
        :type Metadata: list of MetadataVar
        :param _AuthMode: <p>沙箱访问认证模式</p><p>枚举值：</p><ul><li>DEFAULT： 默认，即 TOKEN 认证</li><li>TOKEN： Token认证，即所有端口访问都需携带TOKEN</li><li>NONE： 免认证，即所有端口访问无需携带TOKEN</li><li>PUBLIC： 公开模式，即ENVD管理端口（49983）访问需携带TOKEN，其他端口无需携带TOKEN</li></ul><p>默认值：DEFAULT</p>
        :type AuthMode: str
        """
        self._InstanceId = None
        self._ToolId = None
        self._ToolName = None
        self._Status = None
        self._Persistent = None
        self._TimeoutSeconds = None
        self._ExpiresAt = None
        self._StopReason = None
        self._CreateTime = None
        self._UpdateTime = None
        self._MountOptions = None
        self._CustomConfiguration = None
        self._ComputerConfiguration = None
        self._NetworkMode = None
        self._Metadata = None
        self._AuthMode = None

    @property
    def InstanceId(self):
        r"""<p>沙箱实例唯一标识符</p>
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId

    @property
    def ToolId(self):
        r"""<p>所属沙箱工具 ID</p>
        :rtype: str
        """
        return self._ToolId

    @ToolId.setter
    def ToolId(self, ToolId):
        self._ToolId = ToolId

    @property
    def ToolName(self):
        r"""<p>所属沙箱工具名称</p>
        :rtype: str
        """
        return self._ToolName

    @ToolName.setter
    def ToolName(self, ToolName):
        self._ToolName = ToolName

    @property
    def Status(self):
        r"""<p>实例状态：STARTING（启动中）、RUNNING（运行中）、STOPPING（停止中）、STOPPED（已停止）、STOP_FAILED（停止失败）、FAILED（失败状态）</p>
        :rtype: str
        """
        return self._Status

    @Status.setter
    def Status(self, Status):
        self._Status = Status

    @property
    def Persistent(self):
        r"""<p>是否常驻实例</p>
        :rtype: bool
        """
        return self._Persistent

    @Persistent.setter
    def Persistent(self, Persistent):
        self._Persistent = Persistent

    @property
    def TimeoutSeconds(self):
        r"""<p>超时时间（秒），null 表示无超时设置</p>
        :rtype: int
        """
        return self._TimeoutSeconds

    @TimeoutSeconds.setter
    def TimeoutSeconds(self, TimeoutSeconds):
        self._TimeoutSeconds = TimeoutSeconds

    @property
    def ExpiresAt(self):
        r"""<p>过期时间（ISO 8601 格式），null 表示无过期时间</p>
        :rtype: str
        """
        return self._ExpiresAt

    @ExpiresAt.setter
    def ExpiresAt(self, ExpiresAt):
        self._ExpiresAt = ExpiresAt

    @property
    def StopReason(self):
        r"""<p>停止原因：manual（手动）、timeout（超时）、error（错误）、system（系统），仅在状态为 STOPPED、STOP_FAILED 或 FAILED 时有值。当 provider 停止失败时，状态为 STOP_FAILED，原因为 error</p>
        :rtype: str
        """
        return self._StopReason

    @StopReason.setter
    def StopReason(self, StopReason):
        self._StopReason = StopReason

    @property
    def CreateTime(self):
        r"""<p>创建时间（ISO 8601 格式）</p>
        :rtype: str
        """
        return self._CreateTime

    @CreateTime.setter
    def CreateTime(self, CreateTime):
        self._CreateTime = CreateTime

    @property
    def UpdateTime(self):
        r"""<p>更新时间（ISO 8601 格式）</p>
        :rtype: str
        """
        return self._UpdateTime

    @UpdateTime.setter
    def UpdateTime(self, UpdateTime):
        self._UpdateTime = UpdateTime

    @property
    def MountOptions(self):
        r"""<p>存储挂载选项</p>
        :rtype: list of MountOption
        """
        return self._MountOptions

    @MountOptions.setter
    def MountOptions(self, MountOptions):
        self._MountOptions = MountOptions

    @property
    def CustomConfiguration(self):
        r"""<p>沙箱实例自定义配置</p>
        :rtype: :class:`tencentcloud.ags.v20250920.models.CustomConfigurationDetail`
        """
        return self._CustomConfiguration

    @CustomConfiguration.setter
    def CustomConfiguration(self, CustomConfiguration):
        self._CustomConfiguration = CustomConfiguration

    @property
    def ComputerConfiguration(self):
        r"""<p>桌面电脑环境类沙箱配置</p>
        :rtype: :class:`tencentcloud.ags.v20250920.models.ComputerConfiguration`
        """
        return self._ComputerConfiguration

    @ComputerConfiguration.setter
    def ComputerConfiguration(self, ComputerConfiguration):
        self._ComputerConfiguration = ComputerConfiguration

    @property
    def NetworkMode(self):
        r"""<p>网络模式</p><p>枚举值：</p><ul><li>PUBLIC： 公网访问</li><li>SANDBOX： 无网络</li><li>INTERNAL_SERVICE： 腾讯云内部公共服务</li></ul><p>可以覆盖工具级别的网络配置。但如果一个工具本身就不支持 VPC 网络，那么即便在实例设置里选了 VPC 模式，也是无效的</p>
        :rtype: str
        """
        return self._NetworkMode

    @NetworkMode.setter
    def NetworkMode(self, NetworkMode):
        self._NetworkMode = NetworkMode

    @property
    def Metadata(self):
        r"""<p>沙箱实例元数据</p>
        :rtype: list of MetadataVar
        """
        return self._Metadata

    @Metadata.setter
    def Metadata(self, Metadata):
        self._Metadata = Metadata

    @property
    def AuthMode(self):
        r"""<p>沙箱访问认证模式</p><p>枚举值：</p><ul><li>DEFAULT： 默认，即 TOKEN 认证</li><li>TOKEN： Token认证，即所有端口访问都需携带TOKEN</li><li>NONE： 免认证，即所有端口访问无需携带TOKEN</li><li>PUBLIC： 公开模式，即ENVD管理端口（49983）访问需携带TOKEN，其他端口无需携带TOKEN</li></ul><p>默认值：DEFAULT</p>
        :rtype: str
        """
        return self._AuthMode

    @AuthMode.setter
    def AuthMode(self, AuthMode):
        self._AuthMode = AuthMode


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        self._ToolId = params.get("ToolId")
        self._ToolName = params.get("ToolName")
        self._Status = params.get("Status")
        self._Persistent = params.get("Persistent")
        self._TimeoutSeconds = params.get("TimeoutSeconds")
        self._ExpiresAt = params.get("ExpiresAt")
        self._StopReason = params.get("StopReason")
        self._CreateTime = params.get("CreateTime")
        self._UpdateTime = params.get("UpdateTime")
        if params.get("MountOptions") is not None:
            self._MountOptions = []
            for item in params.get("MountOptions"):
                obj = MountOption()
                obj._deserialize(item)
                self._MountOptions.append(obj)
        if params.get("CustomConfiguration") is not None:
            self._CustomConfiguration = CustomConfigurationDetail()
            self._CustomConfiguration._deserialize(params.get("CustomConfiguration"))
        if params.get("ComputerConfiguration") is not None:
            self._ComputerConfiguration = ComputerConfiguration()
            self._ComputerConfiguration._deserialize(params.get("ComputerConfiguration"))
        self._NetworkMode = params.get("NetworkMode")
        if params.get("Metadata") is not None:
            self._Metadata = []
            for item in params.get("Metadata"):
                obj = MetadataVar()
                obj._deserialize(item)
                self._Metadata.append(obj)
        self._AuthMode = params.get("AuthMode")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class SandboxTool(AbstractModel):
    r"""沙箱工具结构体

    """

    def __init__(self):
        r"""
        :param _ToolId: <p>沙箱工具唯一标识符</p>
        :type ToolId: str
        :param _ToolName: <p>沙箱工具名称，长度 1-50 字符，支持中英文、数字、下划线。同一 AppId 下沙箱工具名称必须唯一</p>
        :type ToolName: str
        :param _ToolType: <p>沙箱工具类型，取值：browser（浏览器工具）、code-interpreter（代码解释器工具）、computer（计算机控制工具）、mobile（移动设备工具）</p>
        :type ToolType: str
        :param _Status: <p>沙箱工具状态，取值：CREATING（创建中）、ACTIVE（可用）、DELETING（删除中）、FAILED（失败）</p>
        :type Status: str
        :param _Description: <p>沙箱工具描述信息，最大长度 200 字符</p>
        :type Description: str
        :param _Persistent: <p>是否常驻沙箱</p>
        :type Persistent: bool
        :param _DefaultTimeoutSeconds: <p>默认超时时间，支持格式：5m、300s、1h 等，不指定则使用系统默认值（5 分钟）。最大 24 小时</p>
        :type DefaultTimeoutSeconds: int
        :param _NetworkConfiguration: <p>网络配置</p>
        :type NetworkConfiguration: :class:`tencentcloud.ags.v20250920.models.NetworkConfiguration`
        :param _Tags: <p>标签规格，包含资源标签绑定关系。用于为沙箱工具绑定标签，支持多种资源类型的标签绑定</p>
        :type Tags: list of Tag
        :param _CreateTime: <p>沙箱工具创建时间，格式：ISO8601</p>
        :type CreateTime: str
        :param _UpdateTime: <p>沙箱工具更新时间，格式：ISO8601</p>
        :type UpdateTime: str
        :param _RoleArn: <p>沙箱工具绑定角色ARN</p>
        :type RoleArn: str
        :param _StorageMounts: <p>沙箱工具中实例存储挂载配置</p>
        :type StorageMounts: list of StorageMount
        :param _CustomConfiguration: <p>沙箱工具自定义配置</p>
        :type CustomConfiguration: :class:`tencentcloud.ags.v20250920.models.CustomConfigurationDetail`
        :param _LogConfiguration: <p>沙箱工具日志推送相关配置</p>
        :type LogConfiguration: :class:`tencentcloud.ags.v20250920.models.LogConfiguration`
        :param _ComputerConfiguration: <p>桌面电脑环境类沙箱配置</p>
        :type ComputerConfiguration: :class:`tencentcloud.ags.v20250920.models.ComputerConfiguration`
        :param _StatusReason: <p>用于说明沙箱工具处于该状态的原因</p>
        :type StatusReason: str
        """
        self._ToolId = None
        self._ToolName = None
        self._ToolType = None
        self._Status = None
        self._Description = None
        self._Persistent = None
        self._DefaultTimeoutSeconds = None
        self._NetworkConfiguration = None
        self._Tags = None
        self._CreateTime = None
        self._UpdateTime = None
        self._RoleArn = None
        self._StorageMounts = None
        self._CustomConfiguration = None
        self._LogConfiguration = None
        self._ComputerConfiguration = None
        self._StatusReason = None

    @property
    def ToolId(self):
        r"""<p>沙箱工具唯一标识符</p>
        :rtype: str
        """
        return self._ToolId

    @ToolId.setter
    def ToolId(self, ToolId):
        self._ToolId = ToolId

    @property
    def ToolName(self):
        r"""<p>沙箱工具名称，长度 1-50 字符，支持中英文、数字、下划线。同一 AppId 下沙箱工具名称必须唯一</p>
        :rtype: str
        """
        return self._ToolName

    @ToolName.setter
    def ToolName(self, ToolName):
        self._ToolName = ToolName

    @property
    def ToolType(self):
        r"""<p>沙箱工具类型，取值：browser（浏览器工具）、code-interpreter（代码解释器工具）、computer（计算机控制工具）、mobile（移动设备工具）</p>
        :rtype: str
        """
        return self._ToolType

    @ToolType.setter
    def ToolType(self, ToolType):
        self._ToolType = ToolType

    @property
    def Status(self):
        r"""<p>沙箱工具状态，取值：CREATING（创建中）、ACTIVE（可用）、DELETING（删除中）、FAILED（失败）</p>
        :rtype: str
        """
        return self._Status

    @Status.setter
    def Status(self, Status):
        self._Status = Status

    @property
    def Description(self):
        r"""<p>沙箱工具描述信息，最大长度 200 字符</p>
        :rtype: str
        """
        return self._Description

    @Description.setter
    def Description(self, Description):
        self._Description = Description

    @property
    def Persistent(self):
        r"""<p>是否常驻沙箱</p>
        :rtype: bool
        """
        return self._Persistent

    @Persistent.setter
    def Persistent(self, Persistent):
        self._Persistent = Persistent

    @property
    def DefaultTimeoutSeconds(self):
        r"""<p>默认超时时间，支持格式：5m、300s、1h 等，不指定则使用系统默认值（5 分钟）。最大 24 小时</p>
        :rtype: int
        """
        return self._DefaultTimeoutSeconds

    @DefaultTimeoutSeconds.setter
    def DefaultTimeoutSeconds(self, DefaultTimeoutSeconds):
        self._DefaultTimeoutSeconds = DefaultTimeoutSeconds

    @property
    def NetworkConfiguration(self):
        r"""<p>网络配置</p>
        :rtype: :class:`tencentcloud.ags.v20250920.models.NetworkConfiguration`
        """
        return self._NetworkConfiguration

    @NetworkConfiguration.setter
    def NetworkConfiguration(self, NetworkConfiguration):
        self._NetworkConfiguration = NetworkConfiguration

    @property
    def Tags(self):
        r"""<p>标签规格，包含资源标签绑定关系。用于为沙箱工具绑定标签，支持多种资源类型的标签绑定</p>
        :rtype: list of Tag
        """
        return self._Tags

    @Tags.setter
    def Tags(self, Tags):
        self._Tags = Tags

    @property
    def CreateTime(self):
        r"""<p>沙箱工具创建时间，格式：ISO8601</p>
        :rtype: str
        """
        return self._CreateTime

    @CreateTime.setter
    def CreateTime(self, CreateTime):
        self._CreateTime = CreateTime

    @property
    def UpdateTime(self):
        r"""<p>沙箱工具更新时间，格式：ISO8601</p>
        :rtype: str
        """
        return self._UpdateTime

    @UpdateTime.setter
    def UpdateTime(self, UpdateTime):
        self._UpdateTime = UpdateTime

    @property
    def RoleArn(self):
        r"""<p>沙箱工具绑定角色ARN</p>
        :rtype: str
        """
        return self._RoleArn

    @RoleArn.setter
    def RoleArn(self, RoleArn):
        self._RoleArn = RoleArn

    @property
    def StorageMounts(self):
        r"""<p>沙箱工具中实例存储挂载配置</p>
        :rtype: list of StorageMount
        """
        return self._StorageMounts

    @StorageMounts.setter
    def StorageMounts(self, StorageMounts):
        self._StorageMounts = StorageMounts

    @property
    def CustomConfiguration(self):
        r"""<p>沙箱工具自定义配置</p>
        :rtype: :class:`tencentcloud.ags.v20250920.models.CustomConfigurationDetail`
        """
        return self._CustomConfiguration

    @CustomConfiguration.setter
    def CustomConfiguration(self, CustomConfiguration):
        self._CustomConfiguration = CustomConfiguration

    @property
    def LogConfiguration(self):
        r"""<p>沙箱工具日志推送相关配置</p>
        :rtype: :class:`tencentcloud.ags.v20250920.models.LogConfiguration`
        """
        return self._LogConfiguration

    @LogConfiguration.setter
    def LogConfiguration(self, LogConfiguration):
        self._LogConfiguration = LogConfiguration

    @property
    def ComputerConfiguration(self):
        r"""<p>桌面电脑环境类沙箱配置</p>
        :rtype: :class:`tencentcloud.ags.v20250920.models.ComputerConfiguration`
        """
        return self._ComputerConfiguration

    @ComputerConfiguration.setter
    def ComputerConfiguration(self, ComputerConfiguration):
        self._ComputerConfiguration = ComputerConfiguration

    @property
    def StatusReason(self):
        r"""<p>用于说明沙箱工具处于该状态的原因</p>
        :rtype: str
        """
        return self._StatusReason

    @StatusReason.setter
    def StatusReason(self, StatusReason):
        self._StatusReason = StatusReason


    def _deserialize(self, params):
        self._ToolId = params.get("ToolId")
        self._ToolName = params.get("ToolName")
        self._ToolType = params.get("ToolType")
        self._Status = params.get("Status")
        self._Description = params.get("Description")
        self._Persistent = params.get("Persistent")
        self._DefaultTimeoutSeconds = params.get("DefaultTimeoutSeconds")
        if params.get("NetworkConfiguration") is not None:
            self._NetworkConfiguration = NetworkConfiguration()
            self._NetworkConfiguration._deserialize(params.get("NetworkConfiguration"))
        if params.get("Tags") is not None:
            self._Tags = []
            for item in params.get("Tags"):
                obj = Tag()
                obj._deserialize(item)
                self._Tags.append(obj)
        self._CreateTime = params.get("CreateTime")
        self._UpdateTime = params.get("UpdateTime")
        self._RoleArn = params.get("RoleArn")
        if params.get("StorageMounts") is not None:
            self._StorageMounts = []
            for item in params.get("StorageMounts"):
                obj = StorageMount()
                obj._deserialize(item)
                self._StorageMounts.append(obj)
        if params.get("CustomConfiguration") is not None:
            self._CustomConfiguration = CustomConfigurationDetail()
            self._CustomConfiguration._deserialize(params.get("CustomConfiguration"))
        if params.get("LogConfiguration") is not None:
            self._LogConfiguration = LogConfiguration()
            self._LogConfiguration._deserialize(params.get("LogConfiguration"))
        if params.get("ComputerConfiguration") is not None:
            self._ComputerConfiguration = ComputerConfiguration()
            self._ComputerConfiguration._deserialize(params.get("ComputerConfiguration"))
        self._StatusReason = params.get("StatusReason")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ScalingConfiguration(AbstractModel):
    r"""Deployment 活跃容量配置

    """

    def __init__(self):
        r"""
        :param _MinInstanceCount: <p>活跃 Sandbox Instance 下限，必须大于等于 0。</p>
        :type MinInstanceCount: int
        :param _MaxInstanceCount: <p>活跃 Sandbox Instance 上限，必须大于等于 1，并且不小于 MinInstanceCount。</p>
        :type MaxInstanceCount: int
        :param _MaxInstanceRequestConcurrency: <p>每个活跃 Sandbox Instance 同时持有的 Deployment 请求或连接 Lease 上限，必须大于等于 1。</p>
        :type MaxInstanceRequestConcurrency: int
        """
        self._MinInstanceCount = None
        self._MaxInstanceCount = None
        self._MaxInstanceRequestConcurrency = None

    @property
    def MinInstanceCount(self):
        r"""<p>活跃 Sandbox Instance 下限，必须大于等于 0。</p>
        :rtype: int
        """
        return self._MinInstanceCount

    @MinInstanceCount.setter
    def MinInstanceCount(self, MinInstanceCount):
        self._MinInstanceCount = MinInstanceCount

    @property
    def MaxInstanceCount(self):
        r"""<p>活跃 Sandbox Instance 上限，必须大于等于 1，并且不小于 MinInstanceCount。</p>
        :rtype: int
        """
        return self._MaxInstanceCount

    @MaxInstanceCount.setter
    def MaxInstanceCount(self, MaxInstanceCount):
        self._MaxInstanceCount = MaxInstanceCount

    @property
    def MaxInstanceRequestConcurrency(self):
        r"""<p>每个活跃 Sandbox Instance 同时持有的 Deployment 请求或连接 Lease 上限，必须大于等于 1。</p>
        :rtype: int
        """
        return self._MaxInstanceRequestConcurrency

    @MaxInstanceRequestConcurrency.setter
    def MaxInstanceRequestConcurrency(self, MaxInstanceRequestConcurrency):
        self._MaxInstanceRequestConcurrency = MaxInstanceRequestConcurrency


    def _deserialize(self, params):
        self._MinInstanceCount = params.get("MinInstanceCount")
        self._MaxInstanceCount = params.get("MaxInstanceCount")
        self._MaxInstanceRequestConcurrency = params.get("MaxInstanceRequestConcurrency")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class StartSandboxInstanceRequest(AbstractModel):
    r"""StartSandboxInstance请求参数结构体

    """

    def __init__(self):
        r"""
        :param _ToolId: <p>沙箱工具 ID，与 ToolName 至少有一个要填</p>
        :type ToolId: str
        :param _ToolName: <p>沙箱工具名称，与 ToolId 至少有一个要填</p>
        :type ToolName: str
        :param _Timeout: <p>超时时间，超过这个时间就自动回收实例。支持格式：5m、300s、1h 等，默认 5m。最小 30s，最大 24h</p>
        :type Timeout: str
        :param _ClientToken: <p>幂等性 Token，长度不超过 64 字符</p>
        :type ClientToken: str
        :param _MountOptions: <p>沙箱实例存储挂载配置</p>
        :type MountOptions: list of MountOption
        :param _CustomConfiguration: <p>沙箱实例自定义配置</p>
        :type CustomConfiguration: :class:`tencentcloud.ags.v20250920.models.CustomConfiguration`
        :param _AuthMode: <p>沙箱访问认证模式</p><p>枚举值：</p><ul><li>DEFAULT： 默认，即TOKEN认证</li><li>TOKEN： Token认证，即所有端口访问都需携带Token</li><li>NONE： 免认证，即所有端口访问无需携带Token</li><li>PUBLIC： 公开模式，即ENVD管理端口（49983）访问需携带Token，其他端口无需携带Token</li></ul><p>默认值：DEFAULT</p>
        :type AuthMode: str
        :param _Metadata: <p>沙箱元数据</p>
        :type Metadata: list of MetadataVar
        """
        self._ToolId = None
        self._ToolName = None
        self._Timeout = None
        self._ClientToken = None
        self._MountOptions = None
        self._CustomConfiguration = None
        self._AuthMode = None
        self._Metadata = None

    @property
    def ToolId(self):
        r"""<p>沙箱工具 ID，与 ToolName 至少有一个要填</p>
        :rtype: str
        """
        return self._ToolId

    @ToolId.setter
    def ToolId(self, ToolId):
        self._ToolId = ToolId

    @property
    def ToolName(self):
        r"""<p>沙箱工具名称，与 ToolId 至少有一个要填</p>
        :rtype: str
        """
        return self._ToolName

    @ToolName.setter
    def ToolName(self, ToolName):
        self._ToolName = ToolName

    @property
    def Timeout(self):
        r"""<p>超时时间，超过这个时间就自动回收实例。支持格式：5m、300s、1h 等，默认 5m。最小 30s，最大 24h</p>
        :rtype: str
        """
        return self._Timeout

    @Timeout.setter
    def Timeout(self, Timeout):
        self._Timeout = Timeout

    @property
    def ClientToken(self):
        r"""<p>幂等性 Token，长度不超过 64 字符</p>
        :rtype: str
        """
        return self._ClientToken

    @ClientToken.setter
    def ClientToken(self, ClientToken):
        self._ClientToken = ClientToken

    @property
    def MountOptions(self):
        r"""<p>沙箱实例存储挂载配置</p>
        :rtype: list of MountOption
        """
        return self._MountOptions

    @MountOptions.setter
    def MountOptions(self, MountOptions):
        self._MountOptions = MountOptions

    @property
    def CustomConfiguration(self):
        r"""<p>沙箱实例自定义配置</p>
        :rtype: :class:`tencentcloud.ags.v20250920.models.CustomConfiguration`
        """
        return self._CustomConfiguration

    @CustomConfiguration.setter
    def CustomConfiguration(self, CustomConfiguration):
        self._CustomConfiguration = CustomConfiguration

    @property
    def AuthMode(self):
        r"""<p>沙箱访问认证模式</p><p>枚举值：</p><ul><li>DEFAULT： 默认，即TOKEN认证</li><li>TOKEN： Token认证，即所有端口访问都需携带Token</li><li>NONE： 免认证，即所有端口访问无需携带Token</li><li>PUBLIC： 公开模式，即ENVD管理端口（49983）访问需携带Token，其他端口无需携带Token</li></ul><p>默认值：DEFAULT</p>
        :rtype: str
        """
        return self._AuthMode

    @AuthMode.setter
    def AuthMode(self, AuthMode):
        self._AuthMode = AuthMode

    @property
    def Metadata(self):
        r"""<p>沙箱元数据</p>
        :rtype: list of MetadataVar
        """
        return self._Metadata

    @Metadata.setter
    def Metadata(self, Metadata):
        self._Metadata = Metadata


    def _deserialize(self, params):
        self._ToolId = params.get("ToolId")
        self._ToolName = params.get("ToolName")
        self._Timeout = params.get("Timeout")
        self._ClientToken = params.get("ClientToken")
        if params.get("MountOptions") is not None:
            self._MountOptions = []
            for item in params.get("MountOptions"):
                obj = MountOption()
                obj._deserialize(item)
                self._MountOptions.append(obj)
        if params.get("CustomConfiguration") is not None:
            self._CustomConfiguration = CustomConfiguration()
            self._CustomConfiguration._deserialize(params.get("CustomConfiguration"))
        self._AuthMode = params.get("AuthMode")
        if params.get("Metadata") is not None:
            self._Metadata = []
            for item in params.get("Metadata"):
                obj = MetadataVar()
                obj._deserialize(item)
                self._Metadata.append(obj)
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class StartSandboxInstanceResponse(AbstractModel):
    r"""StartSandboxInstance返回参数结构体

    """

    def __init__(self):
        r"""
        :param _Instance: <p>创建的沙箱实例完整信息</p>
        :type Instance: :class:`tencentcloud.ags.v20250920.models.SandboxInstance`
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._Instance = None
        self._RequestId = None

    @property
    def Instance(self):
        r"""<p>创建的沙箱实例完整信息</p>
        :rtype: :class:`tencentcloud.ags.v20250920.models.SandboxInstance`
        """
        return self._Instance

    @Instance.setter
    def Instance(self, Instance):
        self._Instance = Instance

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        if params.get("Instance") is not None:
            self._Instance = SandboxInstance()
            self._Instance._deserialize(params.get("Instance"))
        self._RequestId = params.get("RequestId")


class StopSandboxInstanceRequest(AbstractModel):
    r"""StopSandboxInstance请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceId: 沙箱实例ID
        :type InstanceId: str
        """
        self._InstanceId = None

    @property
    def InstanceId(self):
        r"""沙箱实例ID
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class StopSandboxInstanceResponse(AbstractModel):
    r"""StopSandboxInstance返回参数结构体

    """

    def __init__(self):
        r"""
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._RequestId = None

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._RequestId = params.get("RequestId")


class StorageMount(AbstractModel):
    r"""沙箱工具中实例存储挂载配置

    """

    def __init__(self):
        r"""
        :param _Name: <p>存储挂载配置名称</p>
        :type Name: str
        :param _StorageSource: <p>存储配置</p>
注意：此字段可能返回 null，表示取不到有效值。
        :type StorageSource: :class:`tencentcloud.ags.v20250920.models.StorageSource`
        :param _MountPath: <p>沙箱实例本地挂载路径</p>
        :type MountPath: str
        :param _ReadOnly: <p>存储挂载读写权限配置，默认为false</p>
        :type ReadOnly: bool
        """
        self._Name = None
        self._StorageSource = None
        self._MountPath = None
        self._ReadOnly = None

    @property
    def Name(self):
        r"""<p>存储挂载配置名称</p>
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def StorageSource(self):
        r"""<p>存储配置</p>
注意：此字段可能返回 null，表示取不到有效值。
        :rtype: :class:`tencentcloud.ags.v20250920.models.StorageSource`
        """
        return self._StorageSource

    @StorageSource.setter
    def StorageSource(self, StorageSource):
        self._StorageSource = StorageSource

    @property
    def MountPath(self):
        r"""<p>沙箱实例本地挂载路径</p>
        :rtype: str
        """
        return self._MountPath

    @MountPath.setter
    def MountPath(self, MountPath):
        self._MountPath = MountPath

    @property
    def ReadOnly(self):
        r"""<p>存储挂载读写权限配置，默认为false</p>
        :rtype: bool
        """
        return self._ReadOnly

    @ReadOnly.setter
    def ReadOnly(self, ReadOnly):
        self._ReadOnly = ReadOnly


    def _deserialize(self, params):
        self._Name = params.get("Name")
        if params.get("StorageSource") is not None:
            self._StorageSource = StorageSource()
            self._StorageSource._deserialize(params.get("StorageSource"))
        self._MountPath = params.get("MountPath")
        self._ReadOnly = params.get("ReadOnly")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class StorageSource(AbstractModel):
    r"""挂载存储配置

    """

    def __init__(self):
        r"""
        :param _Cos: <p>对象存储桶配置</p>
        :type Cos: :class:`tencentcloud.ags.v20250920.models.CosStorageSource`
        :param _Image: <p>镜像卷配置</p>
        :type Image: :class:`tencentcloud.ags.v20250920.models.ImageStorageSource`
        :param _Cfs: <p>文件存储配置</p>
        :type Cfs: :class:`tencentcloud.ags.v20250920.models.CfsStorageSource`
        :param _AgentBucket: <p>AgentBucket 存储配置</p>
        :type AgentBucket: :class:`tencentcloud.ags.v20250920.models.AgentBucketStorageSource`
        """
        self._Cos = None
        self._Image = None
        self._Cfs = None
        self._AgentBucket = None

    @property
    def Cos(self):
        r"""<p>对象存储桶配置</p>
        :rtype: :class:`tencentcloud.ags.v20250920.models.CosStorageSource`
        """
        return self._Cos

    @Cos.setter
    def Cos(self, Cos):
        self._Cos = Cos

    @property
    def Image(self):
        r"""<p>镜像卷配置</p>
        :rtype: :class:`tencentcloud.ags.v20250920.models.ImageStorageSource`
        """
        return self._Image

    @Image.setter
    def Image(self, Image):
        self._Image = Image

    @property
    def Cfs(self):
        r"""<p>文件存储配置</p>
        :rtype: :class:`tencentcloud.ags.v20250920.models.CfsStorageSource`
        """
        return self._Cfs

    @Cfs.setter
    def Cfs(self, Cfs):
        self._Cfs = Cfs

    @property
    def AgentBucket(self):
        r"""<p>AgentBucket 存储配置</p>
        :rtype: :class:`tencentcloud.ags.v20250920.models.AgentBucketStorageSource`
        """
        return self._AgentBucket

    @AgentBucket.setter
    def AgentBucket(self, AgentBucket):
        self._AgentBucket = AgentBucket


    def _deserialize(self, params):
        if params.get("Cos") is not None:
            self._Cos = CosStorageSource()
            self._Cos._deserialize(params.get("Cos"))
        if params.get("Image") is not None:
            self._Image = ImageStorageSource()
            self._Image._deserialize(params.get("Image"))
        if params.get("Cfs") is not None:
            self._Cfs = CfsStorageSource()
            self._Cfs._deserialize(params.get("Cfs"))
        if params.get("AgentBucket") is not None:
            self._AgentBucket = AgentBucketStorageSource()
            self._AgentBucket._deserialize(params.get("AgentBucket"))
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class Tag(AbstractModel):
    r"""标签

    """

    def __init__(self):
        r"""
        :param _Key: 标签键
        :type Key: str
        :param _Value: 标签值
        :type Value: str
        """
        self._Key = None
        self._Value = None

    @property
    def Key(self):
        r"""标签键
        :rtype: str
        """
        return self._Key

    @Key.setter
    def Key(self, Key):
        self._Key = Key

    @property
    def Value(self):
        r"""标签值
        :rtype: str
        """
        return self._Value

    @Value.setter
    def Value(self, Value):
        self._Value = Value


    def _deserialize(self, params):
        self._Key = params.get("Key")
        self._Value = params.get("Value")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class UpdateSandboxInstanceRequest(AbstractModel):
    r"""UpdateSandboxInstance请求参数结构体

    """

    def __init__(self):
        r"""
        :param _InstanceId: <p>沙箱实例ID</p>
        :type InstanceId: str
        :param _Timeout: <p>新的超时时间（从设置时开始重新计算超时），支持格式：5m、300s、1h等。最小30s，最大24h。如果不指定则保持原有超时设置</p>
        :type Timeout: str
        :param _Metadata: <p>沙箱实例元数据</p>
        :type Metadata: list of MetadataVar
        """
        self._InstanceId = None
        self._Timeout = None
        self._Metadata = None

    @property
    def InstanceId(self):
        r"""<p>沙箱实例ID</p>
        :rtype: str
        """
        return self._InstanceId

    @InstanceId.setter
    def InstanceId(self, InstanceId):
        self._InstanceId = InstanceId

    @property
    def Timeout(self):
        r"""<p>新的超时时间（从设置时开始重新计算超时），支持格式：5m、300s、1h等。最小30s，最大24h。如果不指定则保持原有超时设置</p>
        :rtype: str
        """
        return self._Timeout

    @Timeout.setter
    def Timeout(self, Timeout):
        self._Timeout = Timeout

    @property
    def Metadata(self):
        r"""<p>沙箱实例元数据</p>
        :rtype: list of MetadataVar
        """
        return self._Metadata

    @Metadata.setter
    def Metadata(self, Metadata):
        self._Metadata = Metadata


    def _deserialize(self, params):
        self._InstanceId = params.get("InstanceId")
        self._Timeout = params.get("Timeout")
        if params.get("Metadata") is not None:
            self._Metadata = []
            for item in params.get("Metadata"):
                obj = MetadataVar()
                obj._deserialize(item)
                self._Metadata.append(obj)
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class UpdateSandboxInstanceResponse(AbstractModel):
    r"""UpdateSandboxInstance返回参数结构体

    """

    def __init__(self):
        r"""
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._RequestId = None

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._RequestId = params.get("RequestId")


class UpdateSandboxToolRequest(AbstractModel):
    r"""UpdateSandboxTool请求参数结构体

    """

    def __init__(self):
        r"""
        :param _ToolId: <p>沙箱工具ID</p>
        :type ToolId: str
        :param _Description: <p>沙箱工具描述，最大长度200字符</p>
        :type Description: str
        :param _NetworkConfiguration: <p>网络配置</p>
        :type NetworkConfiguration: :class:`tencentcloud.ags.v20250920.models.NetworkConfiguration`
        :param _Tags: <p>标签</p>
        :type Tags: list of Tag
        :param _CustomConfiguration: <p>沙箱工具自定义配置</p>
        :type CustomConfiguration: :class:`tencentcloud.ags.v20250920.models.CustomConfiguration`
        :param _ComputerConfiguration: <p>桌面电脑环境类沙箱配置</p>
        :type ComputerConfiguration: :class:`tencentcloud.ags.v20250920.models.ComputerConfiguration`
        """
        self._ToolId = None
        self._Description = None
        self._NetworkConfiguration = None
        self._Tags = None
        self._CustomConfiguration = None
        self._ComputerConfiguration = None

    @property
    def ToolId(self):
        r"""<p>沙箱工具ID</p>
        :rtype: str
        """
        return self._ToolId

    @ToolId.setter
    def ToolId(self, ToolId):
        self._ToolId = ToolId

    @property
    def Description(self):
        r"""<p>沙箱工具描述，最大长度200字符</p>
        :rtype: str
        """
        return self._Description

    @Description.setter
    def Description(self, Description):
        self._Description = Description

    @property
    def NetworkConfiguration(self):
        r"""<p>网络配置</p>
        :rtype: :class:`tencentcloud.ags.v20250920.models.NetworkConfiguration`
        """
        return self._NetworkConfiguration

    @NetworkConfiguration.setter
    def NetworkConfiguration(self, NetworkConfiguration):
        self._NetworkConfiguration = NetworkConfiguration

    @property
    def Tags(self):
        r"""<p>标签</p>
        :rtype: list of Tag
        """
        return self._Tags

    @Tags.setter
    def Tags(self, Tags):
        self._Tags = Tags

    @property
    def CustomConfiguration(self):
        r"""<p>沙箱工具自定义配置</p>
        :rtype: :class:`tencentcloud.ags.v20250920.models.CustomConfiguration`
        """
        return self._CustomConfiguration

    @CustomConfiguration.setter
    def CustomConfiguration(self, CustomConfiguration):
        self._CustomConfiguration = CustomConfiguration

    @property
    def ComputerConfiguration(self):
        r"""<p>桌面电脑环境类沙箱配置</p>
        :rtype: :class:`tencentcloud.ags.v20250920.models.ComputerConfiguration`
        """
        return self._ComputerConfiguration

    @ComputerConfiguration.setter
    def ComputerConfiguration(self, ComputerConfiguration):
        self._ComputerConfiguration = ComputerConfiguration


    def _deserialize(self, params):
        self._ToolId = params.get("ToolId")
        self._Description = params.get("Description")
        if params.get("NetworkConfiguration") is not None:
            self._NetworkConfiguration = NetworkConfiguration()
            self._NetworkConfiguration._deserialize(params.get("NetworkConfiguration"))
        if params.get("Tags") is not None:
            self._Tags = []
            for item in params.get("Tags"):
                obj = Tag()
                obj._deserialize(item)
                self._Tags.append(obj)
        if params.get("CustomConfiguration") is not None:
            self._CustomConfiguration = CustomConfiguration()
            self._CustomConfiguration._deserialize(params.get("CustomConfiguration"))
        if params.get("ComputerConfiguration") is not None:
            self._ComputerConfiguration = ComputerConfiguration()
            self._ComputerConfiguration._deserialize(params.get("ComputerConfiguration"))
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class UpdateSandboxToolResponse(AbstractModel):
    r"""UpdateSandboxTool返回参数结构体

    """

    def __init__(self):
        r"""
        :param _RequestId: 唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self._RequestId = None

    @property
    def RequestId(self):
        r"""唯一请求 ID，由服务端生成，每次请求都会返回（若请求因其他原因未能抵达服务端，则该次请求不会获得 RequestId）。定位问题时需要提供该次请求的 RequestId。
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._RequestId = params.get("RequestId")


class VPCConfig(AbstractModel):
    r"""沙箱工具VPC相关配置

    """

    def __init__(self):
        r"""
        :param _SubnetIds: <p>VPC子网ID列表</p>
        :type SubnetIds: list of str
        :param _SecurityGroupIds: <p>安全组ID列表</p>
        :type SecurityGroupIds: list of str
        """
        self._SubnetIds = None
        self._SecurityGroupIds = None

    @property
    def SubnetIds(self):
        r"""<p>VPC子网ID列表</p>
        :rtype: list of str
        """
        return self._SubnetIds

    @SubnetIds.setter
    def SubnetIds(self, SubnetIds):
        self._SubnetIds = SubnetIds

    @property
    def SecurityGroupIds(self):
        r"""<p>安全组ID列表</p>
        :rtype: list of str
        """
        return self._SecurityGroupIds

    @SecurityGroupIds.setter
    def SecurityGroupIds(self, SecurityGroupIds):
        self._SecurityGroupIds = SecurityGroupIds


    def _deserialize(self, params):
        self._SubnetIds = params.get("SubnetIds")
        self._SecurityGroupIds = params.get("SecurityGroupIds")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class WAAConfiguration(AbstractModel):
    r"""waa自定义配置项

    """

    def __init__(self):
        r"""
        :param _ImageId: <p>自定义waa镜像ID</p>
        :type ImageId: str
        """
        self._ImageId = None

    @property
    def ImageId(self):
        r"""<p>自定义waa镜像ID</p>
        :rtype: str
        """
        return self._ImageId

    @ImageId.setter
    def ImageId(self, ImageId):
        self._ImageId = ImageId


    def _deserialize(self, params):
        self._ImageId = params.get("ImageId")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        