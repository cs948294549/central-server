# -*- coding: utf8 -*-
# Copyright (c) 2017-2025 Tencent. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.



from tencentcloud.common.abstract_client_async import AbstractClient
from tencentcloud.chdfs.v20201112 import models
from typing import Dict


class ChdfsClient(AbstractClient):
    _apiVersion = '2020-11-12'
    _endpoint = 'chdfs.tencentcloudapi.com'
    _service = 'chdfs'

    async def AssociateAccessGroups(
            self,
            request: models.AssociateAccessGroupsRequest,
            opts: Dict = None,
    ) -> models.AssociateAccessGroupsResponse:
        """
        给挂载点绑定多个权限组。
        """
        
        kwargs = {}
        kwargs["action"] = "AssociateAccessGroups"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.AssociateAccessGroupsResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateAccessGroup(
            self,
            request: models.CreateAccessGroupRequest,
            opts: Dict = None,
    ) -> models.CreateAccessGroupResponse:
        """
        创建权限组。
        """
        
        kwargs = {}
        kwargs["action"] = "CreateAccessGroup"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateAccessGroupResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateAccessRules(
            self,
            request: models.CreateAccessRulesRequest,
            opts: Dict = None,
    ) -> models.CreateAccessRulesResponse:
        """
        批量创建权限规则，权限规则ID和创建时间无需填写。
        """
        
        kwargs = {}
        kwargs["action"] = "CreateAccessRules"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateAccessRulesResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateFileSystem(
            self,
            request: models.CreateFileSystemRequest,
            opts: Dict = None,
    ) -> models.CreateFileSystemResponse:
        """
        创建文件系统（异步）。
        """
        
        kwargs = {}
        kwargs["action"] = "CreateFileSystem"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateFileSystemResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateLifeCycleRules(
            self,
            request: models.CreateLifeCycleRulesRequest,
            opts: Dict = None,
    ) -> models.CreateLifeCycleRulesResponse:
        """
        批量创建生命周期规则，生命周期规则ID和创建时间无需填写。
        """
        
        kwargs = {}
        kwargs["action"] = "CreateLifeCycleRules"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateLifeCycleRulesResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateMountPoint(
            self,
            request: models.CreateMountPointRequest,
            opts: Dict = None,
    ) -> models.CreateMountPointResponse:
        """
        创建文件系统挂载点，仅限于创建成功的文件系统。
        """
        
        kwargs = {}
        kwargs["action"] = "CreateMountPoint"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateMountPointResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreatePathProtectionRule(
            self,
            request: models.CreatePathProtectionRuleRequest,
            opts: Dict = None,
    ) -> models.CreatePathProtectionRuleResponse:
        """
        创建路径保护规则。
        """
        
        kwargs = {}
        kwargs["action"] = "CreatePathProtectionRule"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreatePathProtectionRuleResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateRestoreTasks(
            self,
            request: models.CreateRestoreTasksRequest,
            opts: Dict = None,
    ) -> models.CreateRestoreTasksResponse:
        """
        批量创建回热任务，回热任务ID、状态和创建时间无需填写。
        """
        
        kwargs = {}
        kwargs["action"] = "CreateRestoreTasks"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateRestoreTasksResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def CreateTrashConfig(
            self,
            request: models.CreateTrashConfigRequest,
            opts: Dict = None,
    ) -> models.CreateTrashConfigResponse:
        """
        创建回收站配置。
        """
        
        kwargs = {}
        kwargs["action"] = "CreateTrashConfig"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.CreateTrashConfigResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DeleteAccessGroup(
            self,
            request: models.DeleteAccessGroupRequest,
            opts: Dict = None,
    ) -> models.DeleteAccessGroupResponse:
        """
        删除权限组。
        """
        
        kwargs = {}
        kwargs["action"] = "DeleteAccessGroup"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DeleteAccessGroupResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DeleteAccessRules(
            self,
            request: models.DeleteAccessRulesRequest,
            opts: Dict = None,
    ) -> models.DeleteAccessRulesResponse:
        """
        批量删除权限规则。
        """
        
        kwargs = {}
        kwargs["action"] = "DeleteAccessRules"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DeleteAccessRulesResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DeleteFileSystem(
            self,
            request: models.DeleteFileSystemRequest,
            opts: Dict = None,
    ) -> models.DeleteFileSystemResponse:
        """
        删除文件系统，不允许删除非空文件系统。
        """
        
        kwargs = {}
        kwargs["action"] = "DeleteFileSystem"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DeleteFileSystemResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DeleteLifeCycleRules(
            self,
            request: models.DeleteLifeCycleRulesRequest,
            opts: Dict = None,
    ) -> models.DeleteLifeCycleRulesResponse:
        """
        批量删除生命周期规则。
        """
        
        kwargs = {}
        kwargs["action"] = "DeleteLifeCycleRules"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DeleteLifeCycleRulesResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DeleteMountPoint(
            self,
            request: models.DeleteMountPointRequest,
            opts: Dict = None,
    ) -> models.DeleteMountPointResponse:
        """
        删除挂载点。
        """
        
        kwargs = {}
        kwargs["action"] = "DeleteMountPoint"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DeleteMountPointResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DeletePathProtectionRule(
            self,
            request: models.DeletePathProtectionRuleRequest,
            opts: Dict = None,
    ) -> models.DeletePathProtectionRuleResponse:
        """
        删除路径保护规则。
        """
        
        kwargs = {}
        kwargs["action"] = "DeletePathProtectionRule"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DeletePathProtectionRuleResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DeleteTrashConfig(
            self,
            request: models.DeleteTrashConfigRequest,
            opts: Dict = None,
    ) -> models.DeleteTrashConfigResponse:
        """
        删除回收站配置。
        """
        
        kwargs = {}
        kwargs["action"] = "DeleteTrashConfig"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DeleteTrashConfigResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeAccessGroup(
            self,
            request: models.DescribeAccessGroupRequest,
            opts: Dict = None,
    ) -> models.DescribeAccessGroupResponse:
        """
        查看权限组详细信息。
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeAccessGroup"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeAccessGroupResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeAccessGroups(
            self,
            request: models.DescribeAccessGroupsRequest,
            opts: Dict = None,
    ) -> models.DescribeAccessGroupsResponse:
        """
        查看权限组列表。
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeAccessGroups"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeAccessGroupsResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeAccessRules(
            self,
            request: models.DescribeAccessRulesRequest,
            opts: Dict = None,
    ) -> models.DescribeAccessRulesResponse:
        """
        通过权限组ID查看权限规则列表。
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeAccessRules"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeAccessRulesResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeFileSystem(
            self,
            request: models.DescribeFileSystemRequest,
            opts: Dict = None,
    ) -> models.DescribeFileSystemResponse:
        """
        查看文件系统详细信息。
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeFileSystem"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeFileSystemResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeFileSystems(
            self,
            request: models.DescribeFileSystemsRequest,
            opts: Dict = None,
    ) -> models.DescribeFileSystemsResponse:
        """
        查看文件系统列表。
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeFileSystems"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeFileSystemsResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeLifeCycleRules(
            self,
            request: models.DescribeLifeCycleRulesRequest,
            opts: Dict = None,
    ) -> models.DescribeLifeCycleRulesResponse:
        """
        通过文件系统ID查看生命周期规则列表。
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeLifeCycleRules"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeLifeCycleRulesResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeMountPoint(
            self,
            request: models.DescribeMountPointRequest,
            opts: Dict = None,
    ) -> models.DescribeMountPointResponse:
        """
        查看挂载点详细信息。
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeMountPoint"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeMountPointResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeMountPoints(
            self,
            request: models.DescribeMountPointsRequest,
            opts: Dict = None,
    ) -> models.DescribeMountPointsResponse:
        """
        查看挂载点列表。
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeMountPoints"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeMountPointsResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribePathProtectionRules(
            self,
            request: models.DescribePathProtectionRulesRequest,
            opts: Dict = None,
    ) -> models.DescribePathProtectionRulesResponse:
        """
        通过文件系统ID查看路径保护规则列表。
        """
        
        kwargs = {}
        kwargs["action"] = "DescribePathProtectionRules"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribePathProtectionRulesResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeResourceTags(
            self,
            request: models.DescribeResourceTagsRequest,
            opts: Dict = None,
    ) -> models.DescribeResourceTagsResponse:
        """
        通过文件系统ID查看资源标签列表。
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeResourceTags"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeResourceTagsResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeRestoreTasks(
            self,
            request: models.DescribeRestoreTasksRequest,
            opts: Dict = None,
    ) -> models.DescribeRestoreTasksResponse:
        """
        通过文件系统ID查看回热任务列表。
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeRestoreTasks"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeRestoreTasksResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DescribeTrashConfig(
            self,
            request: models.DescribeTrashConfigRequest,
            opts: Dict = None,
    ) -> models.DescribeTrashConfigResponse:
        """
        通过文件系统ID查看回收站配置。
        """
        
        kwargs = {}
        kwargs["action"] = "DescribeTrashConfig"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DescribeTrashConfigResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def DisassociateAccessGroups(
            self,
            request: models.DisassociateAccessGroupsRequest,
            opts: Dict = None,
    ) -> models.DisassociateAccessGroupsResponse:
        """
        给挂载点解绑多个权限组。
        """
        
        kwargs = {}
        kwargs["action"] = "DisassociateAccessGroups"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.DisassociateAccessGroupsResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ModifyAccessGroup(
            self,
            request: models.ModifyAccessGroupRequest,
            opts: Dict = None,
    ) -> models.ModifyAccessGroupResponse:
        """
        修改权限组属性。
        """
        
        kwargs = {}
        kwargs["action"] = "ModifyAccessGroup"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ModifyAccessGroupResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ModifyAccessRules(
            self,
            request: models.ModifyAccessRulesRequest,
            opts: Dict = None,
    ) -> models.ModifyAccessRulesResponse:
        """
        批量修改权限规则属性，需要指定权限规则ID，支持修改权限规则地址、访问模式和优先级。
        """
        
        kwargs = {}
        kwargs["action"] = "ModifyAccessRules"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ModifyAccessRulesResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ModifyFileSystem(
            self,
            request: models.ModifyFileSystemRequest,
            opts: Dict = None,
    ) -> models.ModifyFileSystemResponse:
        """
        修改文件系统属性，仅限于创建成功的文件系统。
        """
        
        kwargs = {}
        kwargs["action"] = "ModifyFileSystem"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ModifyFileSystemResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ModifyLifeCycleRules(
            self,
            request: models.ModifyLifeCycleRulesRequest,
            opts: Dict = None,
    ) -> models.ModifyLifeCycleRulesResponse:
        """
        批量修改生命周期规则属性，需要指定生命周期规则ID，支持修改生命周期规则名称、路径、转换列表和状态。
        """
        
        kwargs = {}
        kwargs["action"] = "ModifyLifeCycleRules"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ModifyLifeCycleRulesResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ModifyMountPoint(
            self,
            request: models.ModifyMountPointRequest,
            opts: Dict = None,
    ) -> models.ModifyMountPointResponse:
        """
        修改挂载点属性。
        """
        
        kwargs = {}
        kwargs["action"] = "ModifyMountPoint"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ModifyMountPointResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ModifyPathProtectionRule(
            self,
            request: models.ModifyPathProtectionRuleRequest,
            opts: Dict = None,
    ) -> models.ModifyPathProtectionRuleResponse:
        """
        修改路径保护规则属性，需要指定路径保护规则ID，支持修改规则名称、路径和状态。
        """
        
        kwargs = {}
        kwargs["action"] = "ModifyPathProtectionRule"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ModifyPathProtectionRuleResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ModifyResourceTags(
            self,
            request: models.ModifyResourceTagsRequest,
            opts: Dict = None,
    ) -> models.ModifyResourceTagsResponse:
        """
        修改资源标签列表，全量覆盖。
        """
        
        kwargs = {}
        kwargs["action"] = "ModifyResourceTags"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ModifyResourceTagsResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)
        
    async def ModifyTrashConfig(
            self,
            request: models.ModifyTrashConfigRequest,
            opts: Dict = None,
    ) -> models.ModifyTrashConfigResponse:
        """
        修改回收站配置，需要指定回收站路径，数据保留时间、和状态。
        """
        
        kwargs = {}
        kwargs["action"] = "ModifyTrashConfig"
        kwargs["params"] = request._serialize()
        kwargs["resp_cls"] = models.ModifyTrashConfigResponse
        kwargs["headers"] = request.headers
        kwargs["opts"] = opts or {}
        
        return await self.call_and_deserialize(**kwargs)