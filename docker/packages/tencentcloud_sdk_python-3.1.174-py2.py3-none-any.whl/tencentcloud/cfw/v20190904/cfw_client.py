# -*- coding: utf8 -*-
# Copyright (c) 2017-2025 Tencent. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import json

from tencentcloud.common.exception.tencent_cloud_sdk_exception import TencentCloudSDKException
from tencentcloud.common.abstract_client import AbstractClient
from tencentcloud.cfw.v20190904 import models


class CfwClient(AbstractClient):
    _apiVersion = '2019-09-04'
    _endpoint = 'cfw.tencentcloudapi.com'
    _service = 'cfw'


    def AddAclRule(self, request):
        r"""新增一条或多条互联网边界访问控制规则。

        :param request: Request instance for AddAclRule.
        :type request: :class:`tencentcloud.cfw.v20190904.models.AddAclRuleRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.AddAclRuleResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("AddAclRule", params, headers=headers)
            response = json.loads(body)
            model = models.AddAclRuleResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def AddEnterpriseSecurityGroupRules(self, request):
        r"""新增一条或多条企业安全组规则。

        :param request: Request instance for AddEnterpriseSecurityGroupRules.
        :type request: :class:`tencentcloud.cfw.v20190904.models.AddEnterpriseSecurityGroupRulesRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.AddEnterpriseSecurityGroupRulesResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("AddEnterpriseSecurityGroupRules", params, headers=headers)
            response = json.loads(body)
            model = models.AddEnterpriseSecurityGroupRulesResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def AddNatAcRule(self, request):
        r"""新增一条或多条 NAT边界访问控制规则。

        :param request: Request instance for AddNatAcRule.
        :type request: :class:`tencentcloud.cfw.v20190904.models.AddNatAcRuleRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.AddNatAcRuleResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("AddNatAcRule", params, headers=headers)
            response = json.loads(body)
            model = models.AddNatAcRuleResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def AddVpcAcRule(self, request):
        r"""新增一条或多条 VPC 边界访问控制规则。

        :param request: Request instance for AddVpcAcRule.
        :type request: :class:`tencentcloud.cfw.v20190904.models.AddVpcAcRuleRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.AddVpcAcRuleResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("AddVpcAcRule", params, headers=headers)
            response = json.loads(body)
            model = models.AddVpcAcRuleResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def CheckClusterNatFwPreAccess(self, request):
        r"""发起 NAT CCN 集群模式防火墙预接入检查（仅支持自动接入模式）。入参与 OpenClusterNatFwSwitch 完全相同，传入相同的 NatCcnSwitch 配置 JSON 即可发起检查。检查为异步执行：接口立即返回 CheckItems 检查项清单，前端轮询 DescribeClusterNatCcnFwSwitchList 接口读取 CheckResult 获取各阶段的通过/失败状态。

        :param request: Request instance for CheckClusterNatFwPreAccess.
        :type request: :class:`tencentcloud.cfw.v20190904.models.CheckClusterNatFwPreAccessRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.CheckClusterNatFwPreAccessResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("CheckClusterNatFwPreAccess", params, headers=headers)
            response = json.loads(body)
            model = models.CheckClusterNatFwPreAccessResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def CheckClusterVpcFwPreAccess(self, request):
        r"""发起 VPC 集群防火墙预接入检查（仅支持自动接入模式）。入参与 ModifyClusterVpcFwSwitch 完全相同，传入相同的 CcnSwitch 配置 JSON 即可发起检查。检查为异步执行：接口立即返回 CheckItems 检查项清单，前端轮询 DescribeClusterVpcFwSwitchs 接口读取 CheckResult 获取各阶段的通过/失败状态。

        :param request: Request instance for CheckClusterVpcFwPreAccess.
        :type request: :class:`tencentcloud.cfw.v20190904.models.CheckClusterVpcFwPreAccessRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.CheckClusterVpcFwPreAccessResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("CheckClusterVpcFwPreAccess", params, headers=headers)
            response = json.loads(body)
            model = models.CheckClusterVpcFwPreAccessResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def CloseClusterNatFwSwitch(self, request):
        r"""关闭NAT CCN集群模式防火墙开关

        :param request: Request instance for CloseClusterNatFwSwitch.
        :type request: :class:`tencentcloud.cfw.v20190904.models.CloseClusterNatFwSwitchRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.CloseClusterNatFwSwitchResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("CloseClusterNatFwSwitch", params, headers=headers)
            response = json.loads(body)
            model = models.CloseClusterNatFwSwitchResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def CreateAcRules(self, request):
        r"""创建访问控制规则

        :param request: Request instance for CreateAcRules.
        :type request: :class:`tencentcloud.cfw.v20190904.models.CreateAcRulesRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.CreateAcRulesResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("CreateAcRules", params, headers=headers)
            response = json.loads(body)
            model = models.CreateAcRulesResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def CreateAddressTemplate(self, request):
        r"""创建地址模板规则

        :param request: Request instance for CreateAddressTemplate.
        :type request: :class:`tencentcloud.cfw.v20190904.models.CreateAddressTemplateRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.CreateAddressTemplateResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("CreateAddressTemplate", params, headers=headers)
            response = json.loads(body)
            model = models.CreateAddressTemplateResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def CreateAlertCenterIsolate(self, request):
        r"""用户告警中心-封隔离处置按钮

        :param request: Request instance for CreateAlertCenterIsolate.
        :type request: :class:`tencentcloud.cfw.v20190904.models.CreateAlertCenterIsolateRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.CreateAlertCenterIsolateResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("CreateAlertCenterIsolate", params, headers=headers)
            response = json.loads(body)
            model = models.CreateAlertCenterIsolateResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def CreateAlertCenterOmit(self, request):
        r"""忽略告警中心或拦截列表中的记录。忽略操作不支持撤销。

        :param request: Request instance for CreateAlertCenterOmit.
        :type request: :class:`tencentcloud.cfw.v20190904.models.CreateAlertCenterOmitRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.CreateAlertCenterOmitResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("CreateAlertCenterOmit", params, headers=headers)
            response = json.loads(body)
            model = models.CreateAlertCenterOmitResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def CreateAlertCenterRule(self, request):
        r"""用户告警中心-封禁、放通处置按钮

        :param request: Request instance for CreateAlertCenterRule.
        :type request: :class:`tencentcloud.cfw.v20190904.models.CreateAlertCenterRuleRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.CreateAlertCenterRuleResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("CreateAlertCenterRule", params, headers=headers)
            response = json.loads(body)
            model = models.CreateAlertCenterRuleResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def CreateAlertCenterRuleAsync(self, request):
        r"""异步处置新告警中心的告警。支持告警封禁、告警加白、IP 封禁、IP 加白、域名加白、加入安全基线和资产隔离。

        :param request: Request instance for CreateAlertCenterRuleAsync.
        :type request: :class:`tencentcloud.cfw.v20190904.models.CreateAlertCenterRuleAsyncRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.CreateAlertCenterRuleAsyncResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("CreateAlertCenterRuleAsync", params, headers=headers)
            response = json.loads(body)
            model = models.CreateAlertCenterRuleAsyncResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def CreateBlockIgnoreRuleList(self, request):
        r"""批量添加入侵防御封禁列表、放通列表规则

        :param request: Request instance for CreateBlockIgnoreRuleList.
        :type request: :class:`tencentcloud.cfw.v20190904.models.CreateBlockIgnoreRuleListRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.CreateBlockIgnoreRuleListResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("CreateBlockIgnoreRuleList", params, headers=headers)
            response = json.loads(body)
            model = models.CreateBlockIgnoreRuleListResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def CreateBlockIgnoreRuleNew(self, request):
        r"""批量新增封禁或放通规则。

        :param request: Request instance for CreateBlockIgnoreRuleNew.
        :type request: :class:`tencentcloud.cfw.v20190904.models.CreateBlockIgnoreRuleNewRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.CreateBlockIgnoreRuleNewResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("CreateBlockIgnoreRuleNew", params, headers=headers)
            response = json.loads(body)
            model = models.CreateBlockIgnoreRuleNewResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def CreateChooseVpcs(self, request):
        r"""创建、选择vpc

        :param request: Request instance for CreateChooseVpcs.
        :type request: :class:`tencentcloud.cfw.v20190904.models.CreateChooseVpcsRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.CreateChooseVpcsResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("CreateChooseVpcs", params, headers=headers)
            response = json.loads(body)
            model = models.CreateChooseVpcsResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def CreateDatabaseWhiteListRules(self, request):
        r"""创建暴露数据库白名单规则

        :param request: Request instance for CreateDatabaseWhiteListRules.
        :type request: :class:`tencentcloud.cfw.v20190904.models.CreateDatabaseWhiteListRulesRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.CreateDatabaseWhiteListRulesResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("CreateDatabaseWhiteListRules", params, headers=headers)
            response = json.loads(body)
            model = models.CreateDatabaseWhiteListRulesResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def CreateNatFwDnatRule(self, request):
        r"""创建Nat防火墙Dnat规则

        :param request: Request instance for CreateNatFwDnatRule.
        :type request: :class:`tencentcloud.cfw.v20190904.models.CreateNatFwDnatRuleRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.CreateNatFwDnatRuleResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("CreateNatFwDnatRule", params, headers=headers)
            response = json.loads(body)
            model = models.CreateNatFwDnatRuleResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def CreateNatFwInstance(self, request):
        r"""创建NAT防火墙实例（Region参数必填）

        :param request: Request instance for CreateNatFwInstance.
        :type request: :class:`tencentcloud.cfw.v20190904.models.CreateNatFwInstanceRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.CreateNatFwInstanceResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("CreateNatFwInstance", params, headers=headers)
            response = json.loads(body)
            model = models.CreateNatFwInstanceResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def CreateNatFwInstanceWithDomain(self, request):
        r"""创建防火墙实例和接入域名（Region参数必填）

        :param request: Request instance for CreateNatFwInstanceWithDomain.
        :type request: :class:`tencentcloud.cfw.v20190904.models.CreateNatFwInstanceWithDomainRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.CreateNatFwInstanceWithDomainResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("CreateNatFwInstanceWithDomain", params, headers=headers)
            response = json.loads(body)
            model = models.CreateNatFwInstanceWithDomainResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def CreateSecurityGroupRules(self, request):
        r"""创建企业安全组规则

        :param request: Request instance for CreateSecurityGroupRules.
        :type request: :class:`tencentcloud.cfw.v20190904.models.CreateSecurityGroupRulesRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.CreateSecurityGroupRulesResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("CreateSecurityGroupRules", params, headers=headers)
            response = json.loads(body)
            model = models.CreateSecurityGroupRulesResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def CreateVpcFwGroup(self, request):
        r"""创建VPC间防火墙(防火墙组)

        :param request: Request instance for CreateVpcFwGroup.
        :type request: :class:`tencentcloud.cfw.v20190904.models.CreateVpcFwGroupRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.CreateVpcFwGroupResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("CreateVpcFwGroup", params, headers=headers)
            response = json.loads(body)
            model = models.CreateVpcFwGroupResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def CreateWhiteRule(self, request):
        r"""创建入侵防御白名单。先选择 RuleType，再按该类型填写 Rules[].Info；每条策略使用唯一 RuleName。创建成功后调用 DescribeWhiteRule，使用 RuleName+OperatorType 9 查询并精确核对 RuleName，取得 WhiteId。

        :param request: Request instance for CreateWhiteRule.
        :type request: :class:`tencentcloud.cfw.v20190904.models.CreateWhiteRuleRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.CreateWhiteRuleResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("CreateWhiteRule", params, headers=headers)
            response = json.loads(body)
            model = models.CreateWhiteRuleResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DeleteAcRule(self, request):
        r"""删除规则

        :param request: Request instance for DeleteAcRule.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DeleteAcRuleRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DeleteAcRuleResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DeleteAcRule", params, headers=headers)
            response = json.loads(body)
            model = models.DeleteAcRuleResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DeleteAddressTemplate(self, request):
        r"""删除地址模板规则

        :param request: Request instance for DeleteAddressTemplate.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DeleteAddressTemplateRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DeleteAddressTemplateResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DeleteAddressTemplate", params, headers=headers)
            response = json.loads(body)
            model = models.DeleteAddressTemplateResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DeleteBlockIgnoreRuleList(self, request):
        r"""批量删除入侵防御封禁列表、放通列表规则

        :param request: Request instance for DeleteBlockIgnoreRuleList.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DeleteBlockIgnoreRuleListRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DeleteBlockIgnoreRuleListResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DeleteBlockIgnoreRuleList", params, headers=headers)
            response = json.loads(body)
            model = models.DeleteBlockIgnoreRuleListResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DeleteBlockIgnoreRuleNew(self, request):
        r"""删除 IP 封禁规则，或清空封禁列表。

        :param request: Request instance for DeleteBlockIgnoreRuleNew.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DeleteBlockIgnoreRuleNewRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DeleteBlockIgnoreRuleNewResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DeleteBlockIgnoreRuleNew", params, headers=headers)
            response = json.loads(body)
            model = models.DeleteBlockIgnoreRuleNewResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DeleteNatFwDnatRule(self, request):
        r"""删除Nat防火墙Dnat规则

        :param request: Request instance for DeleteNatFwDnatRule.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DeleteNatFwDnatRuleRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DeleteNatFwDnatRuleResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DeleteNatFwDnatRule", params, headers=headers)
            response = json.loads(body)
            model = models.DeleteNatFwDnatRuleResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DeleteNatFwInstance(self, request):
        r"""销毁防火墙实例

        :param request: Request instance for DeleteNatFwInstance.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DeleteNatFwInstanceRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DeleteNatFwInstanceResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DeleteNatFwInstance", params, headers=headers)
            response = json.loads(body)
            model = models.DeleteNatFwInstanceResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DeleteRemoteAccessDomain(self, request):
        r"""删除远程运维域名

        :param request: Request instance for DeleteRemoteAccessDomain.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DeleteRemoteAccessDomainRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DeleteRemoteAccessDomainResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DeleteRemoteAccessDomain", params, headers=headers)
            response = json.loads(body)
            model = models.DeleteRemoteAccessDomainResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DeleteResourceGroup(self, request):
        r"""DeleteResourceGroup-资产中心资产组删除

        :param request: Request instance for DeleteResourceGroup.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DeleteResourceGroupRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DeleteResourceGroupResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DeleteResourceGroup", params, headers=headers)
            response = json.loads(body)
            model = models.DeleteResourceGroupResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DeleteSecurityGroupRule(self, request):
        r"""删除规则

        :param request: Request instance for DeleteSecurityGroupRule.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DeleteSecurityGroupRuleRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DeleteSecurityGroupRuleResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DeleteSecurityGroupRule", params, headers=headers)
            response = json.loads(body)
            model = models.DeleteSecurityGroupRuleResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DeleteVpcFwGroup(self, request):
        r"""删除防火墙(组)，或者删除其中实例

        :param request: Request instance for DeleteVpcFwGroup.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DeleteVpcFwGroupRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DeleteVpcFwGroupResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DeleteVpcFwGroup", params, headers=headers)
            response = json.loads(body)
            model = models.DeleteVpcFwGroupResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DeleteWhiteRule(self, request):
        r"""按 WhiteId 删除入侵防御白名单。先从 DescribeWhiteRule.Data[].WhiteId 读取目标 ID；提交删除后调用 DescribeWhiteRule，Filters 使用 Name=WD、OperatorType=1 和目标 WhiteId，Data 为空表示删除完成。

        :param request: Request instance for DeleteWhiteRule.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DeleteWhiteRuleRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DeleteWhiteRuleResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DeleteWhiteRule", params, headers=headers)
            response = json.loads(body)
            model = models.DeleteWhiteRuleResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeAcLists(self, request):
        r"""访问控制列表

        :param request: Request instance for DescribeAcLists.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeAcListsRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeAcListsResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeAcLists", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeAcListsResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeAclRegInfo(self, request):
        r"""查询ACL规则支持配置的地区

        :param request: Request instance for DescribeAclRegInfo.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeAclRegInfoRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeAclRegInfoResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeAclRegInfo", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeAclRegInfoResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeAclRule(self, request):
        r"""查询互联网边界访问控制列表

        :param request: Request instance for DescribeAclRule.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeAclRuleRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeAclRuleResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeAclRule", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeAclRuleResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeAddressTemplateList(self, request):
        r"""查询地址模板列表

        :param request: Request instance for DescribeAddressTemplateList.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeAddressTemplateListRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeAddressTemplateListResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeAddressTemplateList", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeAddressTemplateListResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeAssetSync(self, request):
        r"""资产同步状态查询

        :param request: Request instance for DescribeAssetSync.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeAssetSyncRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeAssetSyncResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeAssetSync", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeAssetSyncResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeAssociatedInstanceList(self, request):
        r"""获取安全组关联实例列表

        :param request: Request instance for DescribeAssociatedInstanceList.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeAssociatedInstanceListRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeAssociatedInstanceListResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeAssociatedInstanceList", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeAssociatedInstanceListResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeBlockByIpTimesList(self, request):
        r"""DescribeBlockByIpTimesList 告警中心阻断IP折线图

        :param request: Request instance for DescribeBlockByIpTimesList.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeBlockByIpTimesListRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeBlockByIpTimesListResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeBlockByIpTimesList", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeBlockByIpTimesListResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeBlockIgnoreList(self, request):
        r"""查询入侵防御放通封禁列表

        :param request: Request instance for DescribeBlockIgnoreList.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeBlockIgnoreListRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeBlockIgnoreListResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeBlockIgnoreList", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeBlockIgnoreListResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeBlockList(self, request):
        r"""DescribeBlockList 告警中心阻断资产视图列表

        :param request: Request instance for DescribeBlockList.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeBlockListRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeBlockListResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeBlockList", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeBlockListResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeBlockStaticList(self, request):
        r"""DescribeBlockStaticList 告警中心柱形图

        :param request: Request instance for DescribeBlockStaticList.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeBlockStaticListRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeBlockStaticListResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeBlockStaticList", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeBlockStaticListResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeCcnAssociatedInstances(self, request):
        r"""查询云联网关联的实例信息

        :param request: Request instance for DescribeCcnAssociatedInstances.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeCcnAssociatedInstancesRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeCcnAssociatedInstancesResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeCcnAssociatedInstances", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeCcnAssociatedInstancesResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeCcnInstanceRegionStatus(self, request):
        r"""查询CCN关联实例的地域防火墙引流网络部署状态
        1.根据CCN ID和实例ID列表，返回实例对应地域的防火墙引流网络部署状态
        2.如果传入实例ID列表为空，则返回CCN关联的所有实例的地域防火墙引流网络部署状态

        :param request: Request instance for DescribeCcnInstanceRegionStatus.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeCcnInstanceRegionStatusRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeCcnInstanceRegionStatusResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeCcnInstanceRegionStatus", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeCcnInstanceRegionStatusResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeCcnVpcFwPolicyLimit(self, request):
        r"""查询CCN中VPC防火墙接入策略配置时的规则数量限制

        :param request: Request instance for DescribeCcnVpcFwPolicyLimit.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeCcnVpcFwPolicyLimitRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeCcnVpcFwPolicyLimitResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeCcnVpcFwPolicyLimit", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeCcnVpcFwPolicyLimitResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeCcnVpcFwSwitch(self, request):
        r"""查询CCN VPC防火墙开关配置

        :param request: Request instance for DescribeCcnVpcFwSwitch.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeCcnVpcFwSwitchRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeCcnVpcFwSwitchResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeCcnVpcFwSwitch", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeCcnVpcFwSwitchResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeCfwAlerts(self, request):
        r"""查询当前租户防火墙聚合告警事件。Response.Data 内 total 表示聚合告警事件数；alerts[].occurrence_count 表示单个聚合告警事件的告警发生次数/命中次数。

        :param request: Request instance for DescribeCfwAlerts.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeCfwAlertsRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeCfwAlertsResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeCfwAlerts", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeCfwAlertsResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeCfwAnalysisData(self, request):
        r"""查询当前租户防火墙分析报告数据。按分析场景返回整组分析结果，结果在 Response.Data 的 JSON 字符串中。

        :param request: Request instance for DescribeCfwAnalysisData.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeCfwAnalysisDataRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeCfwAnalysisDataResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeCfwAnalysisData", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeCfwAnalysisDataResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeCfwAssets(self, request):
        r"""查询当前租户防火墙纳管资产。首次查询传 AssetType、过滤条件和 Limit；Response.Data.HasMore=true 时，续查只传 NextToken。默认查询 host；broad 查询分页返回资产，exact InstanceId 查询分页返回该实例 fingerprints 且每页重复基础资产。仅明确需要 VPC 或子网时传 AssetType。

        :param request: Request instance for DescribeCfwAssets.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeCfwAssetsRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeCfwAssetsResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeCfwAssets", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeCfwAssetsResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeCfwEips(self, request):
        r"""查询防火墙弹性公网IP

        :param request: Request instance for DescribeCfwEips.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeCfwEipsRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeCfwEipsResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeCfwEips", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeCfwEipsResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeCfwInsStatus(self, request):
        r"""cfw实例运行状态查询

        :param request: Request instance for DescribeCfwInsStatus.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeCfwInsStatusRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeCfwInsStatusResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeCfwInsStatus", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeCfwInsStatusResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeCfwLogs(self, request):
        r"""查询当前租户防火墙日志。分页只使用 Response.Data 内的 HasMore / NextToken。

        :param request: Request instance for DescribeCfwLogs.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeCfwLogsRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeCfwLogsResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeCfwLogs", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeCfwLogsResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeCfwRiskOverview(self, request):
        r"""查询当前租户风险中心未处理风险概览。默认查询最近 7 天；自定义时间范围需同时传 StartTime 和 EndTime。结果在 Response.Data 的 JSON 字符串中。

        :param request: Request instance for DescribeCfwRiskOverview.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeCfwRiskOverviewRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeCfwRiskOverviewResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeCfwRiskOverview", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeCfwRiskOverviewResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeCfwRuleOptimization(self, request):
        r"""查询当前租户防火墙规则优化建议。只读分析，不修改规则；Action 名保持单数 RuleOptimization。结果在 Response.Data 的 JSON 字符串中。

        :param request: Request instance for DescribeCfwRuleOptimization.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeCfwRuleOptimizationRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeCfwRuleOptimizationResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeCfwRuleOptimization", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeCfwRuleOptimizationResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeCfwRules(self, request):
        r"""查询当前租户防火墙规则配置。覆盖互联网边界、NAT、VPC、企业安全组，以及入侵防御 intrusion_prevention 的 blocklist、whitelist、isolate 三类有效列表。结果在 Response.Data 的 JSON 字符串中。

        :param request: Request instance for DescribeCfwRules.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeCfwRulesRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeCfwRulesResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeCfwRules", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeCfwRulesResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeCfwStatusMonitor(self, request):
        r"""查询状态监控场景。Op=describe_scene 用于发现可用场景、指标、视角和二级下拉 available_options；Op=fetch_scene 用于拉取具体场景快照，结果在 Response.Data 的 JSON 字符串中。

        :param request: Request instance for DescribeCfwStatusMonitor.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeCfwStatusMonitorRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeCfwStatusMonitorResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeCfwStatusMonitor", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeCfwStatusMonitorResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeCfwSwitches(self, request):
        r"""查询当前租户防火墙防护开关总览。结果在 Response.Data 的 JSON 字符串中。本接口没有自定义业务入参，不支持过滤、排序或分页。border_firewall、nat_firewall、vpc_firewall、ndr 的 available 表示至少一个对应防护开关实际开启，不表示仅已购买或已创建；ips.mode 可能为跟随全局、观察、拦截、严格、关闭或未知。

        :param request: Request instance for DescribeCfwSwitches.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeCfwSwitchesRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeCfwSwitchesResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeCfwSwitches", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeCfwSwitchesResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeClusterNatCcnFwSwitchList(self, request):
        r"""查询NAT CCN集群模式防火墙开关列表

        :param request: Request instance for DescribeClusterNatCcnFwSwitchList.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeClusterNatCcnFwSwitchListRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeClusterNatCcnFwSwitchListResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeClusterNatCcnFwSwitchList", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeClusterNatCcnFwSwitchListResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeClusterVpcFwSwitchs(self, request):
        r"""查询集群模式Vpc间防火墙开关

        :param request: Request instance for DescribeClusterVpcFwSwitchs.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeClusterVpcFwSwitchsRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeClusterVpcFwSwitchsResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeClusterVpcFwSwitchs", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeClusterVpcFwSwitchsResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeDefenseSwitch(self, request):
        r"""获取入侵防御按钮列表

        :param request: Request instance for DescribeDefenseSwitch.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeDefenseSwitchRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeDefenseSwitchResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeDefenseSwitch", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeDefenseSwitchResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeEdgeIpSimple(self, request):
        r"""互联网边界防火墙开关列表(轻量)

        :param request: Request instance for DescribeEdgeIpSimple.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeEdgeIpSimpleRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeEdgeIpSimpleResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeEdgeIpSimple", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeEdgeIpSimpleResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeEnterpriseSGRuleProgress(self, request):
        r"""查询新版安全组下发进度

        :param request: Request instance for DescribeEnterpriseSGRuleProgress.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeEnterpriseSGRuleProgressRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeEnterpriseSGRuleProgressResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeEnterpriseSGRuleProgress", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeEnterpriseSGRuleProgressResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeEnterpriseSecurityGroupRule(self, request):
        r"""查询新企业安全组规则

        :param request: Request instance for DescribeEnterpriseSecurityGroupRule.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeEnterpriseSecurityGroupRuleRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeEnterpriseSecurityGroupRuleResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeEnterpriseSecurityGroupRule", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeEnterpriseSecurityGroupRuleResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeEnterpriseSecurityGroupRuleList(self, request):
        r"""查询新企业安全组规则  从node接口迁移   原接口DescribeSecurityGroupNewList

        :param request: Request instance for DescribeEnterpriseSecurityGroupRuleList.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeEnterpriseSecurityGroupRuleListRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeEnterpriseSecurityGroupRuleListResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeEnterpriseSecurityGroupRuleList", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeEnterpriseSecurityGroupRuleListResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeFwEdgeIps(self, request):
        r"""串行防火墙IP开关列表

        :param request: Request instance for DescribeFwEdgeIps.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeFwEdgeIpsRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeFwEdgeIpsResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeFwEdgeIps", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeFwEdgeIpsResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeFwGroupIdNames(self, request):
        r"""获取用户防火墙(组)的ID名称列表

        :param request: Request instance for DescribeFwGroupIdNames.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeFwGroupIdNamesRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeFwGroupIdNamesResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeFwGroupIdNames", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeFwGroupIdNamesResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeFwGroupInstanceInfo(self, request):
        r"""获取租户所有VPC防火墙(组)及VPC防火墙实例卡片信息

        :param request: Request instance for DescribeFwGroupInstanceInfo.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeFwGroupInstanceInfoRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeFwGroupInstanceInfoResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeFwGroupInstanceInfo", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeFwGroupInstanceInfoResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeFwSyncStatus(self, request):
        r"""获取防火墙同步状态，一般在执行同步操作后查询

        :param request: Request instance for DescribeFwSyncStatus.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeFwSyncStatusRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeFwSyncStatusResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeFwSyncStatus", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeFwSyncStatusResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeGuideScanInfo(self, request):
        r"""DescribeGuideScanInfo新手引导扫描接口信息

        :param request: Request instance for DescribeGuideScanInfo.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeGuideScanInfoRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeGuideScanInfoResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeGuideScanInfo", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeGuideScanInfoResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeIPStatusList(self, request):
        r"""IP防护状态查询

        :param request: Request instance for DescribeIPStatusList.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeIPStatusListRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeIPStatusListResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeIPStatusList", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeIPStatusListResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeIpsModeSwitch(self, request):
        r"""获取入侵防御防护模式

        :param request: Request instance for DescribeIpsModeSwitch.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeIpsModeSwitchRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeIpsModeSwitchResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeIpsModeSwitch", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeIpsModeSwitchResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeIpsRuleListNew(self, request):
        r"""IPS规则查询接口新

        :param request: Request instance for DescribeIpsRuleListNew.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeIpsRuleListNewRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeIpsRuleListNewResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeIpsRuleListNew", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeIpsRuleListNewResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeLogStorageStatistic(self, request):
        r"""租户日志存储统计

        :param request: Request instance for DescribeLogStorageStatistic.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeLogStorageStatisticRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeLogStorageStatisticResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeLogStorageStatistic", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeLogStorageStatisticResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeLogs(self, request):
        r"""请使用 [日志分析SearchLog接口](https://cloud.tencent.com/document/product/1132/118363)

        :param request: Request instance for DescribeLogs.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeLogsRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeLogsResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeLogs", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeLogsResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeNDRAssetIdentificationCursorList(self, request):
        r"""DescribeNDRAssetIdentificationCursorList - 游标获取NDR资产识别结果列表

        :param request: Request instance for DescribeNDRAssetIdentificationCursorList.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeNDRAssetIdentificationCursorListRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeNDRAssetIdentificationCursorListResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeNDRAssetIdentificationCursorList", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeNDRAssetIdentificationCursorListResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeNDRAssetIdentificationList(self, request):
        r"""DescribeNDRAssetIdentificationList - 获取NDR资产识别结果列表

        :param request: Request instance for DescribeNDRAssetIdentificationList.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeNDRAssetIdentificationListRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeNDRAssetIdentificationListResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeNDRAssetIdentificationList", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeNDRAssetIdentificationListResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeNDRDataLeakOutAlertList(self, request):
        r"""DescribeNDRDataLeakOutAlertList -- 查询NDR数据泄露出站告警列表

        :param request: Request instance for DescribeNDRDataLeakOutAlertList.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeNDRDataLeakOutAlertListRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeNDRDataLeakOutAlertListResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeNDRDataLeakOutAlertList", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeNDRDataLeakOutAlertListResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeNatAcRule(self, request):
        r"""查询NAT访问控制列表

        :param request: Request instance for DescribeNatAcRule.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeNatAcRuleRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeNatAcRuleResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeNatAcRule", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeNatAcRuleResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeNatCcnFwSwitch(self, request):
        r"""查询NAT CCN防火墙开关配置

        :param request: Request instance for DescribeNatCcnFwSwitch.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeNatCcnFwSwitchRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeNatCcnFwSwitchResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeNatCcnFwSwitch", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeNatCcnFwSwitchResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeNatFwClusterRegionStatus(self, request):
        r"""查询指定NAT所在地域是否有NAT防火墙引流集群

        :param request: Request instance for DescribeNatFwClusterRegionStatus.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeNatFwClusterRegionStatusRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeNatFwClusterRegionStatusResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeNatFwClusterRegionStatus", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeNatFwClusterRegionStatusResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeNatFwDnatRule(self, request):
        r"""查询Nat防火墙Dnat规则

        :param request: Request instance for DescribeNatFwDnatRule.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeNatFwDnatRuleRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeNatFwDnatRuleResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeNatFwDnatRule", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeNatFwDnatRuleResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeNatFwInfoCount(self, request):
        r"""获取当前用户接入nat防火墙的所有子网数及natfw实例个数

        :param request: Request instance for DescribeNatFwInfoCount.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeNatFwInfoCountRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeNatFwInfoCountResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeNatFwInfoCount", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeNatFwInfoCountResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeNatFwInstance(self, request):
        r"""DescribeNatFwInstance 获取租户所有NAT实例

        :param request: Request instance for DescribeNatFwInstance.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeNatFwInstanceRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeNatFwInstanceResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeNatFwInstance", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeNatFwInstanceResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeNatFwInstanceWithRegion(self, request):
        r"""GetNatFwInstanceWithRegion 获取租户新增运维的NAT实例，带上地域

        :param request: Request instance for DescribeNatFwInstanceWithRegion.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeNatFwInstanceWithRegionRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeNatFwInstanceWithRegionResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeNatFwInstanceWithRegion", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeNatFwInstanceWithRegionResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeNatFwInstancesInfo(self, request):
        r"""GetNatInstance 获取租户所有NAT实例及实例卡片信息

        :param request: Request instance for DescribeNatFwInstancesInfo.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeNatFwInstancesInfoRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeNatFwInstancesInfoResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeNatFwInstancesInfo", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeNatFwInstancesInfoResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeNatFwSwitch(self, request):
        r"""查询NAT边界防火墙开关列表

        :param request: Request instance for DescribeNatFwSwitch.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeNatFwSwitchRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeNatFwSwitchResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeNatFwSwitch", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeNatFwSwitchResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeNatFwVpcDnsLst(self, request):
        r"""展示当前natfw 实例对应的vpc dns开关

        :param request: Request instance for DescribeNatFwVpcDnsLst.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeNatFwVpcDnsLstRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeNatFwVpcDnsLstResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeNatFwVpcDnsLst", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeNatFwVpcDnsLstResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeNatRuleScopes(self, request):
        r"""查询nat规则的配额和使用情况

        :param request: Request instance for DescribeNatRuleScopes.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeNatRuleScopesRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeNatRuleScopesResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeNatRuleScopes", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeNatRuleScopesResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeOfflineExportTask(self, request):
        r"""获取日志离线导出任务列表

        :param request: Request instance for DescribeOfflineExportTask.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeOfflineExportTaskRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeOfflineExportTaskResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeOfflineExportTask", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeOfflineExportTaskResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeOfflineExportTemporaryCredentials(self, request):
        r"""获取日志离线导出任务文件下载临时凭证

        :param request: Request instance for DescribeOfflineExportTemporaryCredentials.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeOfflineExportTemporaryCredentialsRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeOfflineExportTemporaryCredentialsResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeOfflineExportTemporaryCredentials", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeOfflineExportTemporaryCredentialsResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeResourceGroup(self, request):
        r"""DescribeResourceGroup资产中心资产树信息

        :param request: Request instance for DescribeResourceGroup.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeResourceGroupRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeResourceGroupResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeResourceGroup", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeResourceGroupResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeResourceGroupNew(self, request):
        r"""资产中心资产组数数据信息查询

        :param request: Request instance for DescribeResourceGroupNew.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeResourceGroupNewRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeResourceGroupNewResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeResourceGroupNew", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeResourceGroupNewResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeRuleOverview(self, request):
        r"""查询规则列表概况

        :param request: Request instance for DescribeRuleOverview.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeRuleOverviewRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeRuleOverviewResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeRuleOverview", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeRuleOverviewResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeSecurityGroupList(self, request):
        r"""查询安全组规则列表

        :param request: Request instance for DescribeSecurityGroupList.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeSecurityGroupListRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeSecurityGroupListResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeSecurityGroupList", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeSecurityGroupListResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeSecurityGroupRegionList(self, request):
        r"""查询地域配置信息-DescribeAllRegionList

        :param request: Request instance for DescribeSecurityGroupRegionList.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeSecurityGroupRegionListRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeSecurityGroupRegionListResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeSecurityGroupRegionList", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeSecurityGroupRegionListResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeSerialRegion(self, request):
        r"""查询串行防火墙地域带宽分配信息

        :param request: Request instance for DescribeSerialRegion.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeSerialRegionRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeSerialRegionResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeSerialRegion", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeSerialRegionResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeSourceAsset(self, request):
        r"""DescribeSourceAsset-查询全部资产信息

        :param request: Request instance for DescribeSourceAsset.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeSourceAssetRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeSourceAssetResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeSourceAsset", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeSourceAssetResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeSwitchError(self, request):
        r"""互联网边界防火墙开关横幅错误信息

        :param request: Request instance for DescribeSwitchError.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeSwitchErrorRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeSwitchErrorResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeSwitchError", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeSwitchErrorResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeSwitchLists(self, request):
        r"""防火墙开关列表，请换用DescribeFwEdgeIps

        :param request: Request instance for DescribeSwitchLists.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeSwitchListsRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeSwitchListsResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeSwitchLists", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeSwitchListsResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeTLogInfo(self, request):
        r"""DescribeTLogInfo告警中心概况查询

        :param request: Request instance for DescribeTLogInfo.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeTLogInfoRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeTLogInfoResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeTLogInfo", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeTLogInfoResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeTLogIpList(self, request):
        r"""DescribeTLogIpList告警中心IP柱形图

        :param request: Request instance for DescribeTLogIpList.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeTLogIpListRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeTLogIpListResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeTLogIpList", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeTLogIpListResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeTableStatus(self, request):
        r"""查询规则表状态

        :param request: Request instance for DescribeTableStatus.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeTableStatusRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeTableStatusResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeTableStatus", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeTableStatusResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeUnHandleEventTabList(self, request):
        r"""DescribeUnHandleEventTabList 告警中心伪攻击链事件未处置接口

        :param request: Request instance for DescribeUnHandleEventTabList.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeUnHandleEventTabListRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeUnHandleEventTabListResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeUnHandleEventTabList", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeUnHandleEventTabListResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeVpcAcRule(self, request):
        r"""查询内网间访问控制列表

        :param request: Request instance for DescribeVpcAcRule.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeVpcAcRuleRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeVpcAcRuleResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeVpcAcRule", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeVpcAcRuleResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeVpcAclEdgeRange(self, request):
        r"""查询内网间访问控制规则的生效范围

        :param request: Request instance for DescribeVpcAclEdgeRange.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeVpcAclEdgeRangeRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeVpcAclEdgeRangeResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeVpcAclEdgeRange", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeVpcAclEdgeRangeResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeVpcFwCcnPolicyWhiteList(self, request):
        r"""查询VPC防火墙策略路由功能开白的CCN列表

        :param request: Request instance for DescribeVpcFwCcnPolicyWhiteList.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeVpcFwCcnPolicyWhiteListRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeVpcFwCcnPolicyWhiteListResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeVpcFwCcnPolicyWhiteList", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeVpcFwCcnPolicyWhiteListResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def DescribeVpcFwGroupSwitch(self, request):
        r"""VPC防火墙(组)开关列表

        :param request: Request instance for DescribeVpcFwGroupSwitch.
        :type request: :class:`tencentcloud.cfw.v20190904.models.DescribeVpcFwGroupSwitchRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.DescribeVpcFwGroupSwitchResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("DescribeVpcFwGroupSwitch", params, headers=headers)
            response = json.loads(body)
            model = models.DescribeVpcFwGroupSwitchResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def ExpandCfwVertical(self, request):
        r"""防火墙垂直扩容

        :param request: Request instance for ExpandCfwVertical.
        :type request: :class:`tencentcloud.cfw.v20190904.models.ExpandCfwVerticalRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.ExpandCfwVerticalResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("ExpandCfwVertical", params, headers=headers)
            response = json.loads(body)
            model = models.ExpandCfwVerticalResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def ExportLogsOffline(self, request):
        r"""日志审计日志离线导出

        :param request: Request instance for ExportLogsOffline.
        :type request: :class:`tencentcloud.cfw.v20190904.models.ExportLogsOfflineRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.ExportLogsOfflineResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("ExportLogsOffline", params, headers=headers)
            response = json.loads(body)
            model = models.ExportLogsOfflineResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def ModifyAcRule(self, request):
        r"""修改规则

        :param request: Request instance for ModifyAcRule.
        :type request: :class:`tencentcloud.cfw.v20190904.models.ModifyAcRuleRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.ModifyAcRuleResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("ModifyAcRule", params, headers=headers)
            response = json.loads(body)
            model = models.ModifyAcRuleResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def ModifyAclRule(self, request):
        r"""修改一条互联网边界访问控制规则。

        :param request: Request instance for ModifyAclRule.
        :type request: :class:`tencentcloud.cfw.v20190904.models.ModifyAclRuleRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.ModifyAclRuleResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("ModifyAclRule", params, headers=headers)
            response = json.loads(body)
            model = models.ModifyAclRuleResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def ModifyAddressTemplate(self, request):
        r"""修改地址模板

        :param request: Request instance for ModifyAddressTemplate.
        :type request: :class:`tencentcloud.cfw.v20190904.models.ModifyAddressTemplateRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.ModifyAddressTemplateResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("ModifyAddressTemplate", params, headers=headers)
            response = json.loads(body)
            model = models.ModifyAddressTemplateResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def ModifyAllPublicIPSwitchStatus(self, request):
        r"""互联网边界防火墙一键开关

        :param request: Request instance for ModifyAllPublicIPSwitchStatus.
        :type request: :class:`tencentcloud.cfw.v20190904.models.ModifyAllPublicIPSwitchStatusRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.ModifyAllPublicIPSwitchStatusResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("ModifyAllPublicIPSwitchStatus", params, headers=headers)
            response = json.loads(body)
            model = models.ModifyAllPublicIPSwitchStatusResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def ModifyAllRuleStatus(self, request):
        r"""启用停用全部规则

        :param request: Request instance for ModifyAllRuleStatus.
        :type request: :class:`tencentcloud.cfw.v20190904.models.ModifyAllRuleStatusRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.ModifyAllRuleStatusResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("ModifyAllRuleStatus", params, headers=headers)
            response = json.loads(body)
            model = models.ModifyAllRuleStatusResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def ModifyAssetScan(self, request):
        r"""资产扫描

        :param request: Request instance for ModifyAssetScan.
        :type request: :class:`tencentcloud.cfw.v20190904.models.ModifyAssetScanRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.ModifyAssetScanResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("ModifyAssetScan", params, headers=headers)
            response = json.loads(body)
            model = models.ModifyAssetScanResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def ModifyAssetSync(self, request):
        r"""资产同步

        :param request: Request instance for ModifyAssetSync.
        :type request: :class:`tencentcloud.cfw.v20190904.models.ModifyAssetSyncRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.ModifyAssetSyncResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("ModifyAssetSync", params, headers=headers)
            response = json.loads(body)
            model = models.ModifyAssetSyncResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def ModifyBlockIgnoreList(self, request):
        r"""支持对封禁列表、放通列表如下操作：
        批量增加封禁IP、放通IP/域名
        批量删除封禁IP、放通IP/域名
        批量修改封禁IP、放通IP/域名生效事件

        :param request: Request instance for ModifyBlockIgnoreList.
        :type request: :class:`tencentcloud.cfw.v20190904.models.ModifyBlockIgnoreListRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.ModifyBlockIgnoreListResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("ModifyBlockIgnoreList", params, headers=headers)
            response = json.loads(body)
            model = models.ModifyBlockIgnoreListResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def ModifyBlockIgnoreRule(self, request):
        r"""编辑单条入侵防御封禁列表、放通列表规则

        :param request: Request instance for ModifyBlockIgnoreRule.
        :type request: :class:`tencentcloud.cfw.v20190904.models.ModifyBlockIgnoreRuleRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.ModifyBlockIgnoreRuleResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("ModifyBlockIgnoreRule", params, headers=headers)
            response = json.loads(body)
            model = models.ModifyBlockIgnoreRuleResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def ModifyBlockIgnoreRuleNew(self, request):
        r"""编辑单条入侵防御封禁列表、放通列表规则（新）

        :param request: Request instance for ModifyBlockIgnoreRuleNew.
        :type request: :class:`tencentcloud.cfw.v20190904.models.ModifyBlockIgnoreRuleNewRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.ModifyBlockIgnoreRuleNewResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("ModifyBlockIgnoreRuleNew", params, headers=headers)
            response = json.loads(body)
            model = models.ModifyBlockIgnoreRuleNewResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def ModifyBlockTop(self, request):
        r"""ModifyBlockTop取消置顶接口

        :param request: Request instance for ModifyBlockTop.
        :type request: :class:`tencentcloud.cfw.v20190904.models.ModifyBlockTopRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.ModifyBlockTopResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("ModifyBlockTop", params, headers=headers)
            response = json.loads(body)
            model = models.ModifyBlockTopResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def ModifyClusterFwBypass(self, request):
        r"""修改集群防火墙Bypass状态

        :param request: Request instance for ModifyClusterFwBypass.
        :type request: :class:`tencentcloud.cfw.v20190904.models.ModifyClusterFwBypassRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.ModifyClusterFwBypassResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("ModifyClusterFwBypass", params, headers=headers)
            response = json.loads(body)
            model = models.ModifyClusterFwBypassResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def ModifyClusterNatFwSwitch(self, request):
        r"""修改NAT CCN集群模式防火墙开关配置

        :param request: Request instance for ModifyClusterNatFwSwitch.
        :type request: :class:`tencentcloud.cfw.v20190904.models.ModifyClusterNatFwSwitchRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.ModifyClusterNatFwSwitchResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("ModifyClusterNatFwSwitch", params, headers=headers)
            response = json.loads(body)
            model = models.ModifyClusterNatFwSwitchResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def ModifyClusterVpcFwSwitch(self, request):
        r"""修改集群模式VPC防火墙开关

        :param request: Request instance for ModifyClusterVpcFwSwitch.
        :type request: :class:`tencentcloud.cfw.v20190904.models.ModifyClusterVpcFwSwitchRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.ModifyClusterVpcFwSwitchResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("ModifyClusterVpcFwSwitch", params, headers=headers)
            response = json.loads(body)
            model = models.ModifyClusterVpcFwSwitchResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def ModifyEWRuleStatus(self, request):
        r"""启用停用VPC间规则或Nat边界规则
        VPC间规则需指定EdgeId。Nat边界规则需指定地域Region与Direction。

        :param request: Request instance for ModifyEWRuleStatus.
        :type request: :class:`tencentcloud.cfw.v20190904.models.ModifyEWRuleStatusRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.ModifyEWRuleStatusResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("ModifyEWRuleStatus", params, headers=headers)
            response = json.loads(body)
            model = models.ModifyEWRuleStatusResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def ModifyEdgeIpSwitch(self, request):
        r"""修改边界防火墙开关(旁路、串行)

        :param request: Request instance for ModifyEdgeIpSwitch.
        :type request: :class:`tencentcloud.cfw.v20190904.models.ModifyEdgeIpSwitchRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.ModifyEdgeIpSwitchResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("ModifyEdgeIpSwitch", params, headers=headers)
            response = json.loads(body)
            model = models.ModifyEdgeIpSwitchResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def ModifyEnterpriseSecurityDispatchStatus(self, request):
        r"""修改企业安全组下发状态

        :param request: Request instance for ModifyEnterpriseSecurityDispatchStatus.
        :type request: :class:`tencentcloud.cfw.v20190904.models.ModifyEnterpriseSecurityDispatchStatusRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.ModifyEnterpriseSecurityDispatchStatusResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("ModifyEnterpriseSecurityDispatchStatus", params, headers=headers)
            response = json.loads(body)
            model = models.ModifyEnterpriseSecurityDispatchStatusResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def ModifyEnterpriseSecurityGroupRule(self, request):
        r"""修改企业安全组规则，包括编辑内容或启停规则。

        :param request: Request instance for ModifyEnterpriseSecurityGroupRule.
        :type request: :class:`tencentcloud.cfw.v20190904.models.ModifyEnterpriseSecurityGroupRuleRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.ModifyEnterpriseSecurityGroupRuleResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("ModifyEnterpriseSecurityGroupRule", params, headers=headers)
            response = json.loads(body)
            model = models.ModifyEnterpriseSecurityGroupRuleResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def ModifyFwGroupSwitch(self, request):
        r"""修改防火墙(组)开关(支持单点模式、多点模式、全互通模式)

        :param request: Request instance for ModifyFwGroupSwitch.
        :type request: :class:`tencentcloud.cfw.v20190904.models.ModifyFwGroupSwitchRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.ModifyFwGroupSwitchResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("ModifyFwGroupSwitch", params, headers=headers)
            response = json.loads(body)
            model = models.ModifyFwGroupSwitchResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def ModifyIpsModeSwitch(self, request):
        r"""修改入侵防御防护模式

        :param request: Request instance for ModifyIpsModeSwitch.
        :type request: :class:`tencentcloud.cfw.v20190904.models.ModifyIpsModeSwitchRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.ModifyIpsModeSwitchResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("ModifyIpsModeSwitch", params, headers=headers)
            response = json.loads(body)
            model = models.ModifyIpsModeSwitchResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def ModifyIsolateTable(self, request):
        r"""修改或解除已有入侵防御隔离记录，不用于新增隔离。

        :param request: Request instance for ModifyIsolateTable.
        :type request: :class:`tencentcloud.cfw.v20190904.models.ModifyIsolateTableRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.ModifyIsolateTableResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("ModifyIsolateTable", params, headers=headers)
            response = json.loads(body)
            model = models.ModifyIsolateTableResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def ModifyNatAcRule(self, request):
        r"""修改一条 NAT边界访问控制规则。

        :param request: Request instance for ModifyNatAcRule.
        :type request: :class:`tencentcloud.cfw.v20190904.models.ModifyNatAcRuleRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.ModifyNatAcRuleResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("ModifyNatAcRule", params, headers=headers)
            response = json.loads(body)
            model = models.ModifyNatAcRuleResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def ModifyNatFwReSelect(self, request):
        r"""防火墙实例重新选择vpc或nat

        :param request: Request instance for ModifyNatFwReSelect.
        :type request: :class:`tencentcloud.cfw.v20190904.models.ModifyNatFwReSelectRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.ModifyNatFwReSelectResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("ModifyNatFwReSelect", params, headers=headers)
            response = json.loads(body)
            model = models.ModifyNatFwReSelectResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def ModifyNatFwSwitch(self, request):
        r"""修改NAT防火墙开关

        :param request: Request instance for ModifyNatFwSwitch.
        :type request: :class:`tencentcloud.cfw.v20190904.models.ModifyNatFwSwitchRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.ModifyNatFwSwitchResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("ModifyNatFwSwitch", params, headers=headers)
            response = json.loads(body)
            model = models.ModifyNatFwSwitchResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def ModifyNatFwVpcDnsSwitch(self, request):
        r"""nat 防火墙VPC DNS 开关切换

        :param request: Request instance for ModifyNatFwVpcDnsSwitch.
        :type request: :class:`tencentcloud.cfw.v20190904.models.ModifyNatFwVpcDnsSwitchRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.ModifyNatFwVpcDnsSwitchResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("ModifyNatFwVpcDnsSwitch", params, headers=headers)
            response = json.loads(body)
            model = models.ModifyNatFwVpcDnsSwitchResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def ModifyNatInstance(self, request):
        r"""编辑NAT防火墙

        :param request: Request instance for ModifyNatInstance.
        :type request: :class:`tencentcloud.cfw.v20190904.models.ModifyNatInstanceRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.ModifyNatInstanceResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("ModifyNatInstance", params, headers=headers)
            response = json.loads(body)
            model = models.ModifyNatInstanceResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def ModifyNatSequenceRules(self, request):
        r"""NAT防火墙规则快速排序

        :param request: Request instance for ModifyNatSequenceRules.
        :type request: :class:`tencentcloud.cfw.v20190904.models.ModifyNatSequenceRulesRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.ModifyNatSequenceRulesResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("ModifyNatSequenceRules", params, headers=headers)
            response = json.loads(body)
            model = models.ModifyNatSequenceRulesResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def ModifyResourceGroup(self, request):
        r"""ModifyResourceGroup-资产中心资产组信息修改

        :param request: Request instance for ModifyResourceGroup.
        :type request: :class:`tencentcloud.cfw.v20190904.models.ModifyResourceGroupRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.ModifyResourceGroupResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("ModifyResourceGroup", params, headers=headers)
            response = json.loads(body)
            model = models.ModifyResourceGroupResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def ModifyRunSyncAsset(self, request):
        r"""同步资产-互联网&VPC（新）

        :param request: Request instance for ModifyRunSyncAsset.
        :type request: :class:`tencentcloud.cfw.v20190904.models.ModifyRunSyncAssetRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.ModifyRunSyncAssetResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("ModifyRunSyncAsset", params, headers=headers)
            response = json.loads(body)
            model = models.ModifyRunSyncAssetResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def ModifySecurityGroupItemRuleStatus(self, request):
        r"""启用停用单条企业安全组规则

        :param request: Request instance for ModifySecurityGroupItemRuleStatus.
        :type request: :class:`tencentcloud.cfw.v20190904.models.ModifySecurityGroupItemRuleStatusRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.ModifySecurityGroupItemRuleStatusResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("ModifySecurityGroupItemRuleStatus", params, headers=headers)
            response = json.loads(body)
            model = models.ModifySecurityGroupItemRuleStatusResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def ModifySecurityGroupRule(self, request):
        r"""编辑单条安全组规则

        :param request: Request instance for ModifySecurityGroupRule.
        :type request: :class:`tencentcloud.cfw.v20190904.models.ModifySecurityGroupRuleRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.ModifySecurityGroupRuleResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("ModifySecurityGroupRule", params, headers=headers)
            response = json.loads(body)
            model = models.ModifySecurityGroupRuleResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def ModifySecurityGroupSequenceRules(self, request):
        r"""企业安全组规则快速排序

        :param request: Request instance for ModifySecurityGroupSequenceRules.
        :type request: :class:`tencentcloud.cfw.v20190904.models.ModifySecurityGroupSequenceRulesRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.ModifySecurityGroupSequenceRulesResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("ModifySecurityGroupSequenceRules", params, headers=headers)
            response = json.loads(body)
            model = models.ModifySecurityGroupSequenceRulesResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def ModifySequenceAclRules(self, request):
        r"""互联网边界规则快速排序

        :param request: Request instance for ModifySequenceAclRules.
        :type request: :class:`tencentcloud.cfw.v20190904.models.ModifySequenceAclRulesRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.ModifySequenceAclRulesResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("ModifySequenceAclRules", params, headers=headers)
            response = json.loads(body)
            model = models.ModifySequenceAclRulesResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def ModifySequenceRules(self, request):
        r"""修改规则执行顺序

        :param request: Request instance for ModifySequenceRules.
        :type request: :class:`tencentcloud.cfw.v20190904.models.ModifySequenceRulesRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.ModifySequenceRulesResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("ModifySequenceRules", params, headers=headers)
            response = json.loads(body)
            model = models.ModifySequenceRulesResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def ModifyStorageSetting(self, request):
        r"""日志存储设置，可以修改存储时间和清空日志

        :param request: Request instance for ModifyStorageSetting.
        :type request: :class:`tencentcloud.cfw.v20190904.models.ModifyStorageSettingRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.ModifyStorageSettingResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("ModifyStorageSetting", params, headers=headers)
            response = json.loads(body)
            model = models.ModifyStorageSettingResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def ModifyTableStatus(self, request):
        r"""修改规则表状态

        :param request: Request instance for ModifyTableStatus.
        :type request: :class:`tencentcloud.cfw.v20190904.models.ModifyTableStatusRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.ModifyTableStatusResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("ModifyTableStatus", params, headers=headers)
            response = json.loads(body)
            model = models.ModifyTableStatusResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def ModifyVpcAcRule(self, request):
        r"""修改一条 VPC边界访问控制规则。

        :param request: Request instance for ModifyVpcAcRule.
        :type request: :class:`tencentcloud.cfw.v20190904.models.ModifyVpcAcRuleRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.ModifyVpcAcRuleResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("ModifyVpcAcRule", params, headers=headers)
            response = json.loads(body)
            model = models.ModifyVpcAcRuleResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def ModifyVpcFwGroup(self, request):
        r"""编辑VPC间防火墙(防火墙组)

        :param request: Request instance for ModifyVpcFwGroup.
        :type request: :class:`tencentcloud.cfw.v20190904.models.ModifyVpcFwGroupRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.ModifyVpcFwGroupResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("ModifyVpcFwGroup", params, headers=headers)
            response = json.loads(body)
            model = models.ModifyVpcFwGroupResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def ModifyVpcFwSequenceRules(self, request):
        r"""vpc间规则快速排序

        :param request: Request instance for ModifyVpcFwSequenceRules.
        :type request: :class:`tencentcloud.cfw.v20190904.models.ModifyVpcFwSequenceRulesRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.ModifyVpcFwSequenceRulesResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("ModifyVpcFwSequenceRules", params, headers=headers)
            response = json.loads(body)
            model = models.ModifyVpcFwSequenceRulesResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def ModifyWhiteRule(self, request):
        r"""修改入侵防御白名单采用整条替换。先调用 DescribeWhiteRule，选择 BanEdit=0 的策略并沿用其 WhiteId 和 RuleType；Rule 提交修改后的全部可写字段。Info 多值字段按笛卡尔积展开，第一项更新原 WhiteId，其余组合创建新 WhiteId，展开后最多 100 条且新增组合消耗配额。成功后调用 DescribeWhiteRule：原策略使用 Name=WD、OperatorType=1 精确查询，新组合使用 Name=RuleName、OperatorType=9 查询并逐项核对。

        :param request: Request instance for ModifyWhiteRule.
        :type request: :class:`tencentcloud.cfw.v20190904.models.ModifyWhiteRuleRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.ModifyWhiteRuleResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("ModifyWhiteRule", params, headers=headers)
            response = json.loads(body)
            model = models.ModifyWhiteRuleResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def OpenClusterNatFwSwitch(self, request):
        r"""开启NAT CCN集群模式防火墙开关

        :param request: Request instance for OpenClusterNatFwSwitch.
        :type request: :class:`tencentcloud.cfw.v20190904.models.OpenClusterNatFwSwitchRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.OpenClusterNatFwSwitchResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("OpenClusterNatFwSwitch", params, headers=headers)
            response = json.loads(body)
            model = models.OpenClusterNatFwSwitchResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def RemoveAcRule(self, request):
        r"""删除互联网边界规则

        :param request: Request instance for RemoveAcRule.
        :type request: :class:`tencentcloud.cfw.v20190904.models.RemoveAcRuleRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.RemoveAcRuleResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("RemoveAcRule", params, headers=headers)
            response = json.loads(body)
            model = models.RemoveAcRuleResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def RemoveAclRule(self, request):
        r"""删除互联网边界访问控制规则。

        :param request: Request instance for RemoveAclRule.
        :type request: :class:`tencentcloud.cfw.v20190904.models.RemoveAclRuleRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.RemoveAclRuleResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("RemoveAclRule", params, headers=headers)
            response = json.loads(body)
            model = models.RemoveAclRuleResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def RemoveEnterpriseSecurityGroupRule(self, request):
        r"""删除企业安全组规则。

        :param request: Request instance for RemoveEnterpriseSecurityGroupRule.
        :type request: :class:`tencentcloud.cfw.v20190904.models.RemoveEnterpriseSecurityGroupRuleRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.RemoveEnterpriseSecurityGroupRuleResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("RemoveEnterpriseSecurityGroupRule", params, headers=headers)
            response = json.loads(body)
            model = models.RemoveEnterpriseSecurityGroupRuleResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def RemoveNatAcRule(self, request):
        r"""删除 NAT 边界访问控制规则。

        :param request: Request instance for RemoveNatAcRule.
        :type request: :class:`tencentcloud.cfw.v20190904.models.RemoveNatAcRuleRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.RemoveNatAcRuleResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("RemoveNatAcRule", params, headers=headers)
            response = json.loads(body)
            model = models.RemoveNatAcRuleResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def RemoveOfflineExportTask(self, request):
        r"""删除日志离线导出任务

        :param request: Request instance for RemoveOfflineExportTask.
        :type request: :class:`tencentcloud.cfw.v20190904.models.RemoveOfflineExportTaskRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.RemoveOfflineExportTaskResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("RemoveOfflineExportTask", params, headers=headers)
            response = json.loads(body)
            model = models.RemoveOfflineExportTaskResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def RemoveVpcAcRule(self, request):
        r"""删除 VPC 边界访问控制规则。

        :param request: Request instance for RemoveVpcAcRule.
        :type request: :class:`tencentcloud.cfw.v20190904.models.RemoveVpcAcRuleRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.RemoveVpcAcRuleResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("RemoveVpcAcRule", params, headers=headers)
            response = json.loads(body)
            model = models.RemoveVpcAcRuleResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def SearchLog(self, request):
        r"""本接口用于检索分析日志，使用该接口时请注意如下事项：
        1. 该接口除受默认接口请求频率限制外，针对单个日志主题，查询并发数不能超过15。
        2. 检索语法建议使用日志服务专用检索语法CQL，请使用SyntaxRule参数，将值设置为1，控制台默认也使用该语法规则。
        3. API返回数据包最大49MB，建议启用 gzip 压缩（HTTP Request Header Accept-Encoding:gzip）。

        :param request: Request instance for SearchLog.
        :type request: :class:`tencentcloud.cfw.v20190904.models.SearchLogRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.SearchLogResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("SearchLog", params, headers=headers)
            response = json.loads(body)
            model = models.SearchLogResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def SetNatFwDnatRule(self, request):
        r"""配置防火墙Dnat规则

        :param request: Request instance for SetNatFwDnatRule.
        :type request: :class:`tencentcloud.cfw.v20190904.models.SetNatFwDnatRuleRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.SetNatFwDnatRuleResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("SetNatFwDnatRule", params, headers=headers)
            response = json.loads(body)
            model = models.SetNatFwDnatRuleResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def SetNatFwEip(self, request):
        r"""设置防火墙实例弹性公网ip，目前仅支持新增模式的防火墙实例

        :param request: Request instance for SetNatFwEip.
        :type request: :class:`tencentcloud.cfw.v20190904.models.SetNatFwEipRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.SetNatFwEipResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("SetNatFwEip", params, headers=headers)
            response = json.loads(body)
            model = models.SetNatFwEipResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def StopSecurityGroupRuleDispatch(self, request):
        r"""中止安全组规则下发

        :param request: Request instance for StopSecurityGroupRuleDispatch.
        :type request: :class:`tencentcloud.cfw.v20190904.models.StopSecurityGroupRuleDispatchRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.StopSecurityGroupRuleDispatchResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("StopSecurityGroupRuleDispatch", params, headers=headers)
            response = json.loads(body)
            model = models.StopSecurityGroupRuleDispatchResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def SyncFwOperate(self, request):
        r"""同步防火墙操作，包括同步防火墙路由（若vpc，专线网关等增加了Cidr，需要手动同步一下路由使之在防火墙上生效）等。

        :param request: Request instance for SyncFwOperate.
        :type request: :class:`tencentcloud.cfw.v20190904.models.SyncFwOperateRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.SyncFwOperateResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("SyncFwOperate", params, headers=headers)
            response = json.loads(body)
            model = models.SyncFwOperateResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def UpdateCheckCcnNonDirectFlag(self, request):
        r"""重新检测CCN中接入VPC防火墙的VPC实例非同城直通标记

        :param request: Request instance for UpdateCheckCcnNonDirectFlag.
        :type request: :class:`tencentcloud.cfw.v20190904.models.UpdateCheckCcnNonDirectFlagRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.UpdateCheckCcnNonDirectFlagResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("UpdateCheckCcnNonDirectFlag", params, headers=headers)
            response = json.loads(body)
            model = models.UpdateCheckCcnNonDirectFlagResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))


    def UpdateClusterVpcFw(self, request):
        r"""修改更新CCN中VPC防火墙策略配置

        :param request: Request instance for UpdateClusterVpcFw.
        :type request: :class:`tencentcloud.cfw.v20190904.models.UpdateClusterVpcFwRequest`
        :rtype: :class:`tencentcloud.cfw.v20190904.models.UpdateClusterVpcFwResponse`

        """
        try:
            params = request._serialize()
            headers = request.headers
            body = self.call("UpdateClusterVpcFw", params, headers=headers)
            response = json.loads(body)
            model = models.UpdateClusterVpcFwResponse()
            model._deserialize(response["Response"])
            return model
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(type(e).__name__, str(e))